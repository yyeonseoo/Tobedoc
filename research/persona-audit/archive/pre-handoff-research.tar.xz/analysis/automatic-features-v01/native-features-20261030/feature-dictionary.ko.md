# 자동 feature 정의

0.1 · 모두 관측/계산 정의이며 임상 등급이 아님. 결측은 null.

임베딩: Apple English sentence embedding revision 1, 512D. 문장 centroid는 각 문장 벡터를 단위 정규화한 뒤 동일 가중 평균한다. 각 대화의 feature는 평가 가능한 턴 값의 평균이다. 표본별/스타일별 계산 가능 분모를 함께 보존한다.

## word_count

Definition: Number of English regex word tokens including contractions

Unit: words

## sentence_count

Definition: Number of nonempty Apple NLTokenizer sentence spans

Unit: sentences

## mean_sentence_words

Definition: Mean regex words per Apple sentence span

Unit: words/sentence

## mattr20

Definition: Mean distinct-type proportion across every fixed 20-token sliding window; null if fewer than 20 tokens

Unit: proportion

## distinct_bigram_ratio

Definition: Unique lowercased word bigrams divided by number of bigram occurrences

Unit: proportion

## first_person_token_ratio

Definition: Count of i/me/my/mine/myself and i-prefixed contractions divided by regex word count

Unit: proportion

## pronoun_pos_ratio

Definition: Apple lexicalClass Pronoun tags divided by all tagged word spans

Unit: proportion

## verb_absent_sentence_rate

Definition: Fraction of sentences without any Verb lexicalClass tag; a descriptive flag, not a grammatical error rate

Unit: proportion

## adjacent_cos_mean

Definition: Mean cosine between consecutive sentence vectors; null for fewer than two sentences

Unit: cosine

## adjacent_cos_min

Definition: Minimum consecutive-sentence cosine

Unit: cosine

## adjacent_cos_sd

Definition: Population SD of consecutive-sentence cosines; null with fewer than two pairs

Unit: cosine

## question_answer_cos

Definition: Cosine of mean unit sentence vectors for current interviewer question vs reply

Unit: cosine

## topic_answer_cos

Definition: Cosine of initial situation vector vs mean unit sentence vectors of reply

Unit: cosine

## topic_cos_slope

Definition: OLS slope of sentence-topic cosine over sentence position scaled to 0..1; null for one sentence

Unit: cosine/normalized_position

## adjacent_lemma_jaccard

Definition: Mean Jaccard overlap of adjacent sentence open-class lemma sets (Noun/Verb/Adjective/Adverb); null for empty unions

Unit: proportion

## adjacent_cos_shuffle_delta

Definition: Observed adjacent mean minus mean over 100 deterministic within-reply sentence permutations

Unit: cosine

## turn_to_previous_reply_cos

Definition: Current vs preceding patient reply centroid cosine within a dialogue; null for first reply

Unit: cosine

## 해석 제한

MATTR20은 고정 20단어 창의 표면 어휘 다양도이며 의미의 풍부함이 아니다. 대명사 비율은 지시어 모호성 점수가 아니다. Verb 태그가 없다는 것은 문법 오류의 판정이 아니다. 인접 코사인 평균/최솟값 등은 임베딩 유사도이며 임상 coherence·derailment·진단 중증도로 환산하지 않는다. 질문–응답 유사도가 낮아도 올바른 답일 수 있고, 높아도 단어 반복일 수 있다.
