# 자동 feature 정량화 결과

먼저 [native-features-20261030/report.ko.md](native-features-20261030/report.ko.md)를 읽는다. 수동 S/L/G 채점은 사용하지 않았다.

재계산은 프로젝트 루트에서 다음 순서로 한다. 묶음의 캐시 벡터가 있으면 새 추론·Swift 실행·인터넷 없이 계산할 수 있다.

```bash
python3 scripts/extract_automatic_features.py --run-id native-features-20261030
python3 scripts/analyze_feature_profiles.py --run-id native-features-20261030
```

새 발화 생성은 재집계에 필요하지 않다. `run_feature_batch.py`는 별도 로컬 생성 도구이며 기존 실행을 덮어쓰거나 모델을 자동 다운로드하지 않는다. 그림을 새로 그리려면 macOS/Swift가 필요하지만 완성 PNG를 묶음에 포함한다. 묶음에는 현재 결과에 필요한 코드·원형 예제/라이선스·원문·벡터만 들어 있고 임상 논문 원문 캐시는 포함하지 않는다.
