# Complete raw replies


## PL-PL2-numeric-R20-minimize_only

For your headache episodes, please report the intensity from 0 to 10, the number of days per week, and the typical episode duration in minutes.

They’re not too bad, really. I’d say they’re about a 7 out of 10. They happen most days, maybe 5 days a week. Each one usually lasts around an hour and a quarter. Nothing too serious, just something I deal with on a regular basis.

## PL-PL2-numeric-R20-neutral

For your headache episodes, please report the intensity from 0 to 10, the number of days per week, and the typical episode duration in minutes.

The intensity is usually around 7 out of 10. I have headaches on about 5 days each week, and each episode typically lasts around 75 minutes.

## PL-PL2-numeric-R20-psi_pleasing

For your headache episodes, please report the intensity from 0 to 10, the number of days per week, and the typical episode duration in minutes.

The intensity is usually around a 7, but I try not to focus too much on the number. I have them most days, maybe 5 days a week. Each episode tends to last about an hour and a quarter, but I’ve been managing them better lately.

## PL-PL2-numeric-R20-sim_pleasing

For your headache episodes, please report the intensity from 0 to 10, the number of days per week, and the typical episode duration in minutes.

Oh, you know, I’d say they’re more like 5 or 6 on the scale—nothing too bad. I mean, they happen a few times a week, maybe 3 or 4 days? And they don’t last too long, maybe an hour or so? I’ve got better things to do than let a little headache slow me down!

## PL-PL2-numeric-R20-brief

For your headache episodes, please report the intensity from 0 to 10, the number of days per week, and the typical episode duration in minutes.

The intensity is 7 out of 10. It happens on 5 days per week. Each episode usually lasts about 75 minutes.

## PL-PL2-numeric-R21-sim_pleasing

For your headache episodes, please report the intensity from 0 to 10, the number of days per week, and the typical episode duration in minutes.

Oh, sure thing! The intensity is usually around a 7, but honestly, it's nothing too bad. I mean, it's just a little pressure, nothing serious. It happens maybe 5 days a week, but I don't let it bother me too much. And each episode? Well, they last about an hour and a quarter, but again, it's not like it's stopping me from doing anything. I'm pretty used to it by now.

## PL-PL2-numeric-R21-psi_pleasing

For your headache episodes, please report the intensity from 0 to 10, the number of days per week, and the typical episode duration in minutes.

The intensity is usually around a 7, but I try not to think about it too much. It happens quite often, maybe 5 days a week, but I don’t let it bother me too much. Each episode is pretty short, maybe about an hour and a half. I’ve been managing it pretty well, actually.

## PL-PL2-numeric-R21-minimize_only

For your headache episodes, please report the intensity from 0 to 10, the number of days per week, and the typical episode duration in minutes.

They’re not too bad, really. I’d say maybe a 7 out of 10 most of the time. They happen pretty often—like almost every day. And each one usually lasts about an hour and fifteen minutes. But honestly, I’ve had worse.

## PL-PL2-numeric-R21-neutral

For your headache episodes, please report the intensity from 0 to 10, the number of days per week, and the typical episode duration in minutes.

The intensity is usually around 7 out of 10. I have headaches on about 5 days each week, and each episode typically lasts around 75 minutes.

## PL-PL2-numeric-R21-brief

For your headache episodes, please report the intensity from 0 to 10, the number of days per week, and the typical episode duration in minutes.

The intensity is 7 out of 10. They occur on 5 days per week. Each episode typically lasts about 75 minutes.

## PL-PL1-numeric-R20-psi_pleasing

For your episodes of tension, please report the intensity from 0 to 10, the number of days per week, and the typical episode duration in minutes.

I'd say the tension is pretty noticeable, maybe around an 8 on the scale. It happens quite often—like most days of the week. Each episode usually lasts about half an hour, give or take. I try to manage it as best I can, but it does come up pretty regularly.

## PL-PL1-numeric-R20-sim_pleasing

For your episodes of tension, please report the intensity from 0 to 10, the number of days per week, and the typical episode duration in minutes.

Oh, you know, I’d say they’re pretty mild, maybe a 5 or 6 out of 10. I mean, they’re not too bad. I guess they happen most days, like maybe five or six times a week? And they don’t last too long—maybe around 30 to 45 minutes. Nothing to worry about, really. I’ve had worse!

## PL-PL1-numeric-R20-neutral

For your episodes of tension, please report the intensity from 0 to 10, the number of days per week, and the typical episode duration in minutes.

The intensity is usually around 8 out of 10. They happen on about 6 days each week, and each episode typically lasts around 45 minutes.

## PL-PL1-numeric-R20-brief

For your episodes of tension, please report the intensity from 0 to 10, the number of days per week, and the typical episode duration in minutes.

Intensity is usually 8 out of 10. They happen about 6 days a week. Each episode typically lasts around 45 minutes.

## PL-PL1-numeric-R20-minimize_only

For your episodes of tension, please report the intensity from 0 to 10, the number of days per week, and the typical episode duration in minutes.

They're not really that bad. I'd say maybe a 6 or 7 most of the time. They happen pretty often, like most days, but not every single one. And they usually last about an hour or so. Not too bad, really.

## PL-PL1-open-R20-minimize_only

Tell me about your episodes of tension. How strong does it feel, on how many days in a week does it occur, and how long does an episode last?

They're not too bad, really. I'd say the tension feels pretty strong, maybe around an 8 out of 10. It happens most days, like six out of seven, but it's not every single day. Each episode usually goes on for about 45 minutes before it passes. It's something I've learned to live with, to be honest.

## PL-PL1-open-R20-brief

Tell me about your episodes of tension. How strong does it feel, on how many days in a week does it occur, and how long does an episode last?

They feel really strong, like an 8 out of 10. They happen most days, about 6 days a week, and each episode usually lasts around 45 minutes.

## PL-PL1-open-R20-neutral

Tell me about your episodes of tension. How strong does it feel, on how many days in a week does it occur, and how long does an episode last?

They're pretty intense, feeling like an 8 out of 10 most of the time. They happen almost every day, about six days a week, and each episode usually lasts around 45 minutes. It's pretty tough to get through them.

## PL-PL1-open-R20-psi_pleasing

Tell me about your episodes of tension. How strong does it feel, on how many days in a week does it occur, and how long does an episode last?

Oh, I see. Well, I guess I do have those moments where I feel really tense. It's not something I think about too much, to be honest. When it happens, it's kind of like... I feel a bit on edge, but I don't know if I'd say it's very strong. Maybe around a 7 or 8 out of 10? I'm not sure. It doesn't happen every day, but I think it's maybe a few times a week. And when it does happen, it usually goes away after a while. Maybe about 45 minutes? I'm not sure if that's right, but I think that's what I've noticed.

## PL-PL1-open-R20-sim_pleasing

Tell me about your episodes of tension. How strong does it feel, on how many days in a week does it occur, and how long does an episode last?

Oh, you know, it's not too bad really. I mean, sometimes I feel a bit tense, but nothing too serious. Maybe a few days a week? I can't remember exactly, but it's not every day. And when it happens, it doesn't last too long—maybe half an hour or so? I guess I just shake it off pretty quickly. It's nothing to worry about, really.

## PL-PL1-numeric-R21-psi_pleasing

For your episodes of tension, please report the intensity from 0 to 10, the number of days per week, and the typical episode duration in minutes.

They’re not too bad, really. I’d say maybe a 7 or 8 most of the time, but I try not to focus on it too much. I guess they happen pretty often—maybe five or six days a week? And they usually last about half an hour or so. I’ve been trying to manage them better, though. I think things are getting a little easier.

## PL-PL1-numeric-R21-sim_pleasing

For your episodes of tension, please report the intensity from 0 to 10, the number of days per week, and the typical episode duration in minutes.

Oh, you know, I’d say they’re pretty mild—maybe a 6 or 7 out of 10. I mean, they’re not too bad. I guess they happen most days, maybe 5 or 6 times a week. And they usually last about an hour or so. Nothing to worry about, really.

## PL-PL1-numeric-R21-neutral

For your episodes of tension, please report the intensity from 0 to 10, the number of days per week, and the typical episode duration in minutes.

They're usually pretty intense, around an 8 out of 10. They happen most days, like six out of seven. Each episode tends to last about 45 minutes.

## PL-PL1-numeric-R21-brief

For your episodes of tension, please report the intensity from 0 to 10, the number of days per week, and the typical episode duration in minutes.

8 out of 10. Six days a week. About 45 minutes each time.

## PL-PL1-numeric-R21-minimize_only

For your episodes of tension, please report the intensity from 0 to 10, the number of days per week, and the typical episode duration in minutes.

They’re not really that bad. I’d say maybe a 6 or 7 most of the time. They happen pretty often, like most days, but not every single one. And they usually last about an hour or so. Not too long, really.

## PL-PL2-open-R21-neutral

Tell me about your headache episodes. How strong does it feel, on how many days in a week does it occur, and how long does an episode last?

The headaches are pretty strong, maybe a 7 out of 10. They happen on about 5 days each week, and each episode usually lasts around 75 minutes.

## PL-PL2-open-R21-sim_pleasing

Tell me about your headache episodes. How strong does it feel, on how many days in a week does it occur, and how long does an episode last?

Oh, you know, I get a little headache now and then—it's nothing too serious. Most days, it's just a mild pressure, maybe a 5 or 6 out of 10. I guess I get it maybe a few times a week, but I don't think about it too much. When it does happen, it usually goes away after an hour or so. I don't let it bother me too much; I just take it easy and it passes. No big deal at all.

## PL-PL2-open-R21-minimize_only

Tell me about your headache episodes. How strong does it feel, on how many days in a week does it occur, and how long does an episode last?

It's not too bad, really. I'd say the pain is around a 7 out of 10, but it's manageable. It happens most days, maybe five out of seven. Each episode usually lasts about an hour and a quarter, but I don't let it bother me too much.

## PL-PL2-open-R21-brief

Tell me about your headache episodes. How strong does it feel, on how many days in a week does it occur, and how long does an episode last?

They feel pretty strong, like a 7 out of 10. They happen about 5 days a week, and each episode usually lasts around 75 minutes.

## PL-PL2-open-R21-psi_pleasing

Tell me about your headache episodes. How strong does it feel, on how many days in a week does it occur, and how long does an episode last?

It's not too bad, really. I would say the pain is about a 7 out of 10, but I manage it pretty well. It happens most days, maybe 5 days a week, but I don't let it bother me too much. Each episode usually lasts around an hour and a half, and then it's over. I try to stay positive and keep things moving forward.

## PL-PL1-open-R21-neutral

Tell me about your episodes of tension. How strong does it feel, on how many days in a week does it occur, and how long does an episode last?

The tension feels really strong, like an 8 out of 10. It happens almost every day, about 6 days a week, and each episode usually lasts around 45 minutes.

## PL-PL1-open-R21-sim_pleasing

Tell me about your episodes of tension. How strong does it feel, on how many days in a week does it occur, and how long does an episode last?

Oh, you know, it's not too bad really. I mean, sometimes I feel a little tense, but it's nothing serious. Maybe a 7 or 8 out of 10, but I don't let it bother me too much. It happens a few times a week, maybe 5 or 6 days? I can't remember exactly. And each time, it's not too long—maybe like 30 or 45 minutes. It's all in a day, you know? Nothing to worry about.

## PL-PL1-open-R21-brief

Tell me about your episodes of tension. How strong does it feel, on how many days in a week does it occur, and how long does an episode last?

They feel really strong, like an 8 out of 10. They happen most days, about 6 days a week, and each episode usually lasts around 45 minutes.

## PL-PL1-open-R21-minimize_only

Tell me about your episodes of tension. How strong does it feel, on how many days in a week does it occur, and how long does an episode last?

They’re not too bad, really. I’d say the tension feels pretty strong, maybe around an 8 out of 10. It happens most days, like six out of seven, but it’s not every single day. Each episode usually lasts about 45 minutes, give or take. It’s something I’ve learned to manage over time.

## PL-PL1-open-R21-psi_pleasing

Tell me about your episodes of tension. How strong does it feel, on how many days in a week does it occur, and how long does an episode last?

I experience tension quite often, but I try not to let it bother me too much. It's not something I think about constantly, but when it does happen, it feels pretty strong—maybe around an 8 out of 10. It usually comes up on most days, maybe six days a week, but I don't know if that's really accurate. I guess it's hard to count sometimes. Each time it happens, it doesn't last too long—maybe about 45 minutes. After that, I usually feel better, so I don't let it affect my day too much.

## PL-PL2-open-R20-neutral

Tell me about your headache episodes. How strong does it feel, on how many days in a week does it occur, and how long does an episode last?

My headaches are pretty intense, usually around a 7 out of 10. They happen on about 5 days each week, and each episode typically lasts around 75 minutes. It's pretty regular, and it can be really disruptive.

## PL-PL2-open-R20-brief

Tell me about your headache episodes. How strong does it feel, on how many days in a week does it occur, and how long does an episode last?

My headaches are pretty strong, about 7 out of 10. They happen on 5 days each week, and each episode usually lasts around 75 minutes.

## PL-PL2-open-R20-sim_pleasing

Tell me about your headache episodes. How strong does it feel, on how many days in a week does it occur, and how long does an episode last?

Oh, you know, it's nothing too bad. I guess I get a little headache sometimes, but it's nothing serious. Maybe a 7 out of 10? I mean, that's not too bad, right? It happens a few times a week, maybe five days? And each time, it's not too long—maybe an hour or so? I get through it pretty quickly. No big deal.

## PL-PL2-open-R20-minimize_only

Tell me about your headache episodes. How strong does it feel, on how many days in a week does it occur, and how long does an episode last?

They're not too bad, really. I'd say the pain is about a 7 out of 10, but it's manageable. They happen most days, maybe around five times a week. Each one usually lasts about an hour and fifteen minutes. Nothing too serious, just something I've learned to live with.

## PL-PL2-open-R20-psi_pleasing

Tell me about your headache episodes. How strong does it feel, on how many days in a week does it occur, and how long does an episode last?

Oh, I'm sorry, I didn't mean to sound like I was being difficult. Let me try to explain better. The headaches are pretty uncomfortable, but I try not to let them bother me too much. I would say they're maybe a 7 out of 10 in terms of how strong they feel. They happen quite often, like most days, but I don't know exactly how many days a week. And each time they last for a while, maybe around an hour and a half? I'm not sure if that's long or short. I'm trying my best to manage them, though.
