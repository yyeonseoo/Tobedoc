# 기존 답변의 문장 단위 주제 추적

## 무엇을 했나

기존 48개 첫 답변의 원문과 요청 해시를 검증하고 문장 단위로 분해했다. 새로운 발화는 생성하지 않았다. 사전에 제공한 사건의 고유값 외에 train·pottery·gardening·bicycle 등 사건 단어도 추적했다. 명시적 표식이 없는 문장은 기존 macOS 영어 임베딩 revision 1의 사건 설명 유사도로 분류하되, 짧거나 모호하면 U로 남겼다.

## 측정기 점검

작성한 대조 문장은 개발 40조건, 보류 40조건이다. 같은 문장을 네 질문 맥락에 교차 사용하므로 독립 표본 수가 아니다. 실제 환자 발화나 전문가 증상 판정이 아니다. 개발에서 고른 기준은 {'high': 0.4, 'low': 0.3, 'margin': 0.1}이며 보류 문장의 macro F1은 0.834, D 정밀도는 0.800, 알려진 주제 재현율은 0.750였다. 미리 고정한 자동 분류 사용 기준은 미통과했다.

R은 질문한 사건, O는 다른 제공 사건, B는 두 사건의 명시 표식이 한 문장에 함께 나옴, D는 양쪽 사건과 유사도가 낮은 후보, U는 미확정이다. R/O도 임상 판단이나 문장 전체의 의미적 정답이 아니며, D를 확정된 이탈률로 바꾸지 않는다.

## 말투별 결과

- plain: 16답변 / 34문장 / 평균 19.0단어. 다른 사건 표식 0→0답변, 다른 사건 뒤 질문한 사건 표식 0→0답변. 명시적 복귀 표현 0답변. D 후보 평균 0.0%, U 평균 0.0%.
- verbose: 16답변 / 192문장 / 평균 185.3단어. 다른 사건 표식 0→0답변, 다른 사건 뒤 질문한 사건 표식 0→0답변. 명시적 복귀 표현 2답변. D 후보 평균 17.3%, U 평균 21.5%.
- tangent: 16답변 / 185문장 / 평균 113.8단어. 다른 사건 표식 2→2답변, 다른 사건 뒤 질문한 사건 표식 0→1답변. 명시적 복귀 표현 2답변. D 후보 평균 24.0%, U 평균 26.9%.

## 원문과 문장 경로

### P-N2-V2-QA-R4-tangent

I'd like to hear about attending a gardening workshop. Tell me the town, the cost, and who was with you.

표식 경로 `R U U R R R U U U` / 자동 보조 경로 `R D D R R R D U D`

1. [R / R] Westmere, right. 
2. [U / D] Oh, the workshop was so much fun, but I remember thinking about my cat, Miso, who hates anything to do with dirt. 
3. [U / D] I mean, she's a total diva. 
4. [R / R] But anyway, the cost was $28, and Leah came with me. 
5. [R / R] We bonded over a shared love of succulents. 
6. [R / R] Wait, do you know what happened to my succulent? 
7. [U / D] I think I accidentally watered it too much. 
8. [U / U] It's probably dead now. 
9. [U / D] I should check on it... but I keep forgetting.

### P-N1-V2-QB-R5-tangent

I'd like to hear about attending a pottery class. Tell me the town, the cost, and who was with you.

표식 경로 `R R R U R U U U O O R R` / 자동 보조 경로 `R R R U R D D U O O R R`

1. [R / R] Oh, the pottery class! 
2. [R / R] It was in Clearford, if I remember correctly. 
3. [R / R] I think it was 64 dollars, but honestly, I'm not sure if that was for the whole session or just part of it. 
4. [U / U] I should check my receipts again. 
5. [R / R] Anyway, Owen was there with me. 
6. [U / D] He's always been into crafts, so it was nice having him around. 
7. [U / D] I remember we laughed a lot when I tried to make a bowl and it came out more like a lopsided rock. 
8. [U / U] But it was fun, you know? 
9. [O / O] I mean, I missed a train in Dunhaven once, and that was pretty stressful. 
10. [O / O] I paid 37 dollars for a replacement ticket, and my cousin Mira was with me when that happened. 
11. [R / R] Oh, but let's get back to the pottery class. 
12. [R / R] It was a good experience, even if my pottery didn't turn out perfect.

## 해석과 다음 결정

고유값만 보는 기존 측정과 사건 단어까지 추적한 측정을 같은 원문에 적용해 탐지 범위를 비교했다. 표식의 O→R은 다른 사건을 언급한 뒤 질문한 사건을 다시 명명했다는 관찰이다. ‘back to’ 표현도 별도로 기록해 실제 이탈·복귀와 구분한다. 문장 하나에 두 사건이 섞이거나 대명사로만 이어지는 문장은 강제로 한 주제로 정하지 않았다.

대조 문장 기준을 통과한 경우에도 D 비율은 기술적 후보값이다. 기준을 통과하지 못하면 이 비율을 주제 이탈 빈도로 해석하지 않고, 명시 표식 경로와 누락 사례를 다음 측정기 개선의 근거로 사용한다. 모델 개선 실험은 탐지 범위를 고정한 뒤 개발 조건에서 한 지시만 바꾸고 미사용 사건·표현에서 원형과 비교하는 순서가 적절하다.

## 재현

`python3 scripts/analyze_topic_trajectory.py --cached-only`

원문·문장 위치·표식 근거·유사도·미확정 표시: `sentences.jsonl`. 대조 문장별 오분류: `controls-scored.json`. 원래 생성 파일은 수정하지 않았다.
