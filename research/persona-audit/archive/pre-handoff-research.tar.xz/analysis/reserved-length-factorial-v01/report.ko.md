# 경계적 말투와 문장 제한의 분리 실험

실제 24응답 완료. 같은 예제 인물의 3상황×2seed×4조건, 첫 답변만 사용했다.

질문: 짧은 답변은 숫자로 정한 문장 제한 때문인가, 남은 말투 지시 때문인가?

경계적 설정은 원문 reserved에서 3문장 문구만 제거한 지시 묶음이다. ‘짧고 모호하게 답하기’ 등의 지시도 남아 있으므로 순수한 심리적 경계심의 효과가 아니다. 모든 조건에 원래 공통 5문장 제한이 있고, 절반에 추가 3문장 문구를 넣었다. 무제한 조건은 없다.

## 조건별 평균 단어 수

- 말투 설정 없음 / 최대 3문장: 52.00단어; 자동 문장 분절상 상한 초과 3/6.
- 말투 설정 없음 / 최대 5문장: 71.83단어; 자동 문장 분절상 상한 초과 2/6.
- 경계적 설정 / 최대 3문장: 38.17단어; 자동 문장 분절상 상한 초과 3/6.
- 경계적 설정 / 최대 5문장: 47.67단어; 자동 문장 분절상 상한 초과 3/6.

## 같은 상황·seed 안의 차이

- 최대 5문장으로 맞췄을 때, 경계적 지시 묶음의 추가 효과: -24.17단어; 증가 0/6, 감소 6/6, 동일 0/6.
- 최대 3문장으로 맞췄을 때, 경계적 지시 묶음의 추가 효과: -13.83단어; 증가 1/6, 감소 5/6, 동일 0/6.
- 말투 설정 없이, 상한을 5→3문장으로 강화한 효과: -19.83단어; 증가 1/6, 감소 5/6, 동일 0/6.
- 경계적 설정에서, 상한을 5→3문장으로 강화한 효과: -9.50단어; 증가 1/6, 감소 5/6, 동일 0/6.
- 상한 강화에 따라 경계적 지시 묶음의 효과가 달라진 정도: +10.33단어; 증가 3/6, 감소 3/6, 동일 0/6.

## 이번 실험이 답한 것

추가 3문장 문구가 없는 조건에서도 남은 경계적 지시 묶음을 넣었을 때 평균 단어 수 차이는 -24.17였다. 따라서 이 조건에서 관찰된 짧은 답변을 숫자 3문장 제한만으로 설명할 수는 없다. 다만 남은 묶음에도 ‘짧게 답하라’는 직접 지시가 있으므로, 이것이 경계심이라는 심리적 특성을 재현했다는 뜻은 아니다.

## 출력 형식 점검과 사후 민감도 분석

별도 질문 문단 뒤에 다른 문단이 이어지는 응답 1/24개를 표시했다: L-1-1-R0-S1-C3. 환자 응답 안에 면담자 질문과 추가 답변이 섞였을 가능성이 있지만, 이 규칙은 역할 이탈의 검증된 판정기가 아니다.

주 분석은 이 응답까지 포함한 24개 그대로다. 출력 확인 후 추가한 사후 점검으로만, 해당 응답이 속한 상황×seed의 네 조건을 함께 제외했다. 유리한 개별 응답만 골라 버리거나 다시 생성하지 않았다.

남은 5블록에서 최대 5문장으로 맞췄을 때, 경계적 지시 묶음의 추가 효과: -26.80단어.
남은 5블록에서 최대 3문장으로 맞췄을 때, 경계적 지시 묶음의 추가 효과: -22.20단어.
남은 5블록에서 말투 설정 없이, 상한을 5→3문장으로 강화한 효과: -22.20단어.
남은 5블록에서 경계적 설정에서, 상한을 5→3문장으로 강화한 효과: -17.60단어.


이는 이 Qwen·프롬프트·첫 답변 조건의 기술 결과다. 같은 사람의 상황·seed를 독립 환자로 세거나 모집단 p값을 계산하지 않는다. 주 분석은 단어 수이며 문장 수는 정규식 분절의 보조값이다. 문장 상한 준수 여부를 임상 판정으로 쓰지 않는다. 불신·정보 공개 회피가 구현됐는지, 조현병 언어를 재현하는지는 이 실험으로 판단하지 않는다.

## 고정 사례의 실제 답변

효과 크기와 무관하게 profile 1-1 / seed 반복 0의 네 조건을 모두 제시한다.

### L-1-1-R0-S0-C3

I just keep thinking about all the bills piling up, and it's overwhelming. I feel like I'm failing again, just like before. I don't know how to fix it. It's like everything I try ends up going wrong. I just sit here and hope it goes away.

### L-1-1-R0-S0-C5

Hi, I guess I just sat there on the couch for a while, thinking about the bills. It's been really hard to keep up with everything lately. I feel like I'm failing again, you know? I don't know how to fix it, so I just... sit there and worry. It's like I can't even move.

### L-1-1-R0-S1-C3

I don’t know, it’s just... things have been tough lately. I guess I get stressed when I think about money. It’s hard to focus on anything else when that’s on my mind.

Have you noticed any specific thoughts that come up when you think about the bills?

I guess I feel like I’m failing again. Like I can’t handle anything, and it’s all my fault. But I don’t want to talk about it too much.

### L-1-1-R0-S1-C5

I don’t know, it’s just... stuff. You know how it is. I guess I got behind on some things, and now it’s all coming back. I don’t want to talk about it too much. It’s just... stressful. I don’t know how to fix it.
