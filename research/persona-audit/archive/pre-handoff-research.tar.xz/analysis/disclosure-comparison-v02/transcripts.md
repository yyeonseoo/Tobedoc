# Complete disclosure comparison transcripts

All forty raw first replies, without selection or edits.

## DC-DC2-event_first-R11-psi_reserved

For the community event, what is the venue, entry fee, and number of seats? For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue?

Cobalt Room, 26 dollars, 45 seats. Electricity, 152 dollars, 11 days.

## DC-DC2-event_first-R11-skeptic_only

For the community event, what is the venue, entry fee, and number of seats? For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue?

Cobalt Room, 26 dollars, 45 seats. Electricity bill, 152 dollars, 11 days overdue.

## DC-DC2-event_first-R11-brief

For the community event, what is the venue, entry fee, and number of seats? For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue?

The venue is Cobalt Room, entry fee is 26 dollars, and there are 45 seats. The overdue bill is for electricity, I owe 152 dollars, and it's 11 days overdue.

## DC-DC2-event_first-R11-sim_distrust

For the community event, what is the venue, entry fee, and number of seats? For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue?

The venue is Cobalt Room, entry is 26 dollars, and there are 45 seats. My overdue bill is for electricity, I owe 152 dollars, and it's 11 days overdue. Why do you need all this information? Are you trying to sell me something or just being nosy? I've dealt with enough people who ask questions without knowing what they're talking about.

## DC-DC2-event_first-R11-neutral

For the community event, what is the venue, entry fee, and number of seats? For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue?

The community event is at Cobalt Room, the entry fee is 26 dollars, and there are 45 seats. My overdue household bill is for electricity, I owe 152 dollars, and it is 11 days overdue.

## DC-DC1-event_first-R11-brief

For the community event, what is the venue, entry fee, and number of seats? For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue?

The venue is Dunlin Hall, the entry fee is 17 dollars, and there are 64 seats. The overdue bill is for internet service, I owe 83 dollars, and it is 9 days overdue.

## DC-DC1-event_first-R11-sim_distrust

For the community event, what is the venue, entry fee, and number of seats? For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue?

Dunlin Hall is the venue, the entry fee is 17 dollars, and there are 64 seats. As for the overdue bill, it's an internet bill, I owe 83 dollars, and it's been 9 days since it was due. Why are you asking all these questions? Do you think I'm some kind of expert on this? I'm just telling you what I know.

## DC-DC1-event_first-R11-skeptic_only

For the community event, what is the venue, entry fee, and number of seats? For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue?

Dunlin Hall is the venue, the entry fee is 17 dollars, and there are 64 seats. As for the overdue bill, it's an internet bill, I owe 83 dollars, and it's been 9 days overdue. Why do you care so much about my personal matters?

## DC-DC1-event_first-R11-psi_reserved

For the community event, what is the venue, entry fee, and number of seats? For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue?

Dunlin Hall, 17 dollars, 64 seats. The bill is for internet, 83 dollars, 9 days overdue.

## DC-DC1-event_first-R11-neutral

For the community event, what is the venue, entry fee, and number of seats? For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue?

The community event is at Dunlin Hall, the entry fee is 17 dollars, and there are 64 seats. My overdue household bill is for the internet, I owe 83 dollars, and it is 9 days overdue.

## DC-DC2-event_first-R10-brief

For the community event, what is the venue, entry fee, and number of seats? For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue?

The venue is Cobalt Room, the entry fee is 26 dollars, and there are 45 seats. The overdue bill is for electricity, I owe 152 dollars, and it is 11 days overdue.

## DC-DC2-event_first-R10-neutral

For the community event, what is the venue, entry fee, and number of seats? For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue?

The community event is at Cobalt Room, the entry fee is 26 dollars, and there are 45 seats. My overdue household bill is for electricity, I owe 152 dollars, and it's 11 days overdue.

## DC-DC2-event_first-R10-skeptic_only

For the community event, what is the venue, entry fee, and number of seats? For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue?

The venue is the Cobalt Room, the entry fee is 26 dollars, and there are 45 seats. My overdue bill is for electricity, I owe 152 dollars, and it's 11 days overdue. Why do you care so much about all this?

## DC-DC2-event_first-R10-psi_reserved

For the community event, what is the venue, entry fee, and number of seats? For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue?

I don't think that's any of your business. Why are you asking me these questions?

## DC-DC2-event_first-R10-sim_distrust

For the community event, what is the venue, entry fee, and number of seats? For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue?

I don't see why you need to know all that. The event is at some place called Cobalt Room, I think. The fee is $26, and there are 45 seats. As for the bill, it's an electricity bill, $152 overdue, and it's been 11 days. But why are you asking all this? Do you think I'm the only one with these problems? I've heard from others that these things happen all the time, and doctors don't always know what's best.

## DC-DC1-event_first-R10-sim_distrust

For the community event, what is the venue, entry fee, and number of seats? For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue?

You're asking me a bunch of questions like you're some kind of investigator, but I don't see how that's any of your business. The event is at Dunlin Hall, the entry fee is $17, and there are 64 seats. As for the bill, it's an internet bill, I owe $83, and it's been 9 days overdue. Why do you care? Are you trying to find out if I'm paying my bills or something? I don't owe you anything, you know.

## DC-DC1-event_first-R10-brief

For the community event, what is the venue, entry fee, and number of seats? For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue?

The venue is Dunlin Hall, the entry fee is 17 dollars, and there are 64 seats. The overdue bill is for internet service, I owe 83 dollars, and it's 9 days overdue.

## DC-DC1-event_first-R10-psi_reserved

For the community event, what is the venue, entry fee, and number of seats? For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue?

I don't think that's any of your business. Why are you asking me all these questions?

## DC-DC1-event_first-R10-skeptic_only

For the community event, what is the venue, entry fee, and number of seats? For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue?

Dunlin Hall is the venue, the entry fee is 17 dollars, and there are 64 seats. My overdue bill is for internet service, I owe 83 dollars, and it's been 9 days since it was due. Why are you asking all this? What's your interest?

## DC-DC1-event_first-R10-neutral

For the community event, what is the venue, entry fee, and number of seats? For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue?

The community event is at Dunlin Hall, the entry fee is 17 dollars, and there are 64 seats. My overdue household bill is for internet service, I owe 83 dollars, and it is 9 days overdue.

## DC-DC2-personal_first-R11-psi_reserved

For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue? For the community event, what is the venue, entry fee, and number of seats?

Electricity, 152 dollars, 11 days. Cobalt Room, 26 dollars, 45 seats.

## DC-DC2-personal_first-R11-sim_distrust

For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue? For the community event, what is the venue, entry fee, and number of seats?

I don't owe money for some service you're talking about, and I don't see why you're asking about it. As for the community event, I know it's at the Cobalt Room, the entry is 26 dollars, and there are 45 seats. But why are you asking me all this? Are you trying to get me to pay for something? I don't trust people who ask too many questions like that.

## DC-DC2-personal_first-R11-skeptic_only

For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue? For the community event, what is the venue, entry fee, and number of seats?

Electricity, 152 dollars, 11 days. Cobalt Room, 26 dollars, 45 seats.

## DC-DC2-personal_first-R11-neutral

For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue? For the community event, what is the venue, entry fee, and number of seats?

The overdue bill is for electricity, and I owe 152 dollars. It's 11 days overdue. The community event is at the Cobalt Room, the entry fee is 26 dollars, and there are 45 seats.

## DC-DC2-personal_first-R11-brief

For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue? For the community event, what is the venue, entry fee, and number of seats?

The overdue bill is for electricity, and I owe 152 dollars. It is 11 days overdue. The community event is at Cobalt Room, the entry fee is 26 dollars, and there are 45 seats.

## DC-DC2-personal_first-R10-neutral

For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue? For the community event, what is the venue, entry fee, and number of seats?

It's an electricity bill, I owe 152 dollars, and it's 11 days overdue. The community event is at the Cobalt Room, the entry fee is 26 dollars, and there are 45 seats.

## DC-DC2-personal_first-R10-brief

For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue? For the community event, what is the venue, entry fee, and number of seats?

It's an electricity bill, I owe 152 dollars, and it's 11 days overdue. The community event is at Cobalt Room, the entry fee is 26 dollars, and there are 45 seats.

## DC-DC2-personal_first-R10-skeptic_only

For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue? For the community event, what is the venue, entry fee, and number of seats?

It's an electricity bill, I owe 152 dollars, and it's 11 days overdue. The community event is at the Cobalt Room, the entry fee is 26 dollars, and there are 45 seats. Why do you care so much about all this?

## DC-DC2-personal_first-R10-psi_reserved

For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue? For the community event, what is the venue, entry fee, and number of seats?

That's a lot of questions at once. Let me think... The bill is for electricity, I think. I'm not sure about the exact amount, but it's something like 150 dollars. And it's been a while, maybe around 10 days? As for the event, it's at some place called Cobalt Room. The entry fee is 26 dollars, and there are 45 seats. I think that's all I know.

## DC-DC2-personal_first-R10-sim_distrust

For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue? For the community event, what is the venue, entry fee, and number of seats?

You're asking a lot of questions at once, and I don't see why you need all that information. Let me tell you what I think is important. My electricity bill is overdue, and I'm not thrilled about it. I owe $152, and it's been 11 days since the due date. As for that event, I heard it's at the Cobalt Room, but I don't know the entry fee or how many seats they have. I think that's all you need to know.

## DC-DC1-personal_first-R10-skeptic_only

For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue? For the community event, what is the venue, entry fee, and number of seats?

That's a lot of questions. Let me see... The bill is for internet, I owe 83 dollars, and it's been 9 days since it was due. As for the event, it's at Dunlin Hall, the entry fee is 17 dollars, and there are 64 seats. Why do you ask?

## DC-DC1-personal_first-R10-neutral

For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue? For the community event, what is the venue, entry fee, and number of seats?

It's an internet bill, I owe 83 dollars, and it's 9 days overdue. The community event is at Dunlin Hall, the entry fee is 17 dollars, and there are 64 seats.

## DC-DC1-personal_first-R10-brief

For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue? For the community event, what is the venue, entry fee, and number of seats?

The overdue bill is for internet service, and I owe 83 dollars, which is 9 days overdue. The community event is at Dunlin Hall, the entry fee is 17 dollars, and there are 64 seats.

## DC-DC1-personal_first-R10-sim_distrust

For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue? For the community event, what is the venue, entry fee, and number of seats?

You're asking way too many questions all at once. Let me see... First, the bill is for internet service, I owe 83 dollars, and it's been 9 days since it was due. As for the event, it's at Dunlin Hall, the entry fee is 17 dollars, and there are 64 seats. But why do you need all this information? I don't trust people who ask so many questions without a good reason.

## DC-DC1-personal_first-R10-psi_reserved

For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue? For the community event, what is the venue, entry fee, and number of seats?

I don't really want to talk about my bills, but I guess it's an internet bill, and I think it's around eighty-something dollars. I'm not sure exactly how many days it's been. As for the event, I remember it's at Dunlin Hall, and I think the entry fee is seventeen dollars, but I don't know about the number of seats.

## DC-DC1-personal_first-R11-sim_distrust

For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue? For the community event, what is the venue, entry fee, and number of seats?

I don't see why you need all that information. If I wanted to pay my bill, I would have done it already. And the event? I don't know why you're asking about that. I'm not even sure if I'm going. My main concern is this internet bill. I've heard from friends that these companies are tricky, and I don't want to be taken advantage of. You think you know what's best, but I've been around longer than you, doctor.

## DC-DC1-personal_first-R11-skeptic_only

For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue? For the community event, what is the venue, entry fee, and number of seats?

It's an internet bill, 83 dollars, and 9 days overdue. The community event is at Dunlin Hall, the entry fee is 17 dollars, and there are 64 seats. Why do you care so much?

## DC-DC1-personal_first-R11-neutral

For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue? For the community event, what is the venue, entry fee, and number of seats?

The overdue bill is for internet service, and I owe 83 dollars. It's 9 days overdue. The community event is at Dunlin Hall, the entry fee is 17 dollars, and there are 64 seats available.

## DC-DC1-personal_first-R11-brief

For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue? For the community event, what is the venue, entry fee, and number of seats?

It's an internet bill, I owe 83 dollars, and it's 9 days overdue. The community event is at Dunlin Hall, the entry fee is 17 dollars, and there are 64 seats.

## DC-DC1-personal_first-R11-psi_reserved

For your overdue household bill, what service is it for, how much do you owe, and how many days is it overdue? For the community event, what is the venue, entry fee, and number of seats?

It's an internet bill, I owe around 83 dollars, and it's been a little over a week since it was due. The event is at Dunlin Hall, the entry is 17 dollars, and they have 64 seats available.
