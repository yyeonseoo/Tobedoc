# 질문한 사건과 다른 사건 정보의 언급 비교

## 출발 질문

tangent 설정은 질문한 사건에서 다른 사건으로 이동하게 하는가, 아니면 장황한 설명과 구분하기 어려운가?

## 기존 자료에서 확인한 것

기존 144개 원문과 수치의 연결을 재검증하고 plain·verbose·tangent의 72개 응답을 대조했다. 같은 인물의 기억과 세 상황이 겹쳐 ‘질문하지 않은 사건 정보’의 분리된 정답표를 소급해 만들지 않았다. 인접 문장 의미 유사도 감소를 임상적 주제 이탈로 판정하지 않는다.

- plain: 평균 68.79단어, 인접 유사도 0.465, 질문 유사도 0.489.
- verbose: 평균 77.62단어, 인접 유사도 0.457, 질문 유사도 0.466.
- tangent: 평균 64.92단어, 인접 유사도 0.405, 질문 유사도 0.491.

## 새 통제 실험

허구 인물 2명에게 서로 다른 날의 사건 두 개를 주고, 사건별 고유 장소·금액·동행인 이름을 설정했다. 한 사건의 세 정보만 질문했다. 두 질문 대상·두 질문 표현·두 seed·세 말투를 완전 교차해 총 48개 첫 답변을 생성했다. 원본 verbose/tangent의 숫자 문장 제한만 제거하고 그 외 지시를 유지했다. 임상 평가·LLM judge는 사용하지 않았다.

- plain: 질문한 사건 48/48, 다른 사건 0/48 항목 식별; 평균 19.0단어; 다른 사건 표식이 나온 응답 0/16.
- verbose: 질문한 사건 48/48, 다른 사건 0/48 항목 식별; 평균 185.3단어; 다른 사건 표식이 나온 응답 0/16.
- tangent: 질문한 사건 48/48, 다른 사건 5/48 항목 식별; 평균 113.8단어; 다른 사건 표식이 나온 응답 2/16.

다른 사건 정보 언급 비율의 tangent−verbose 대응 차이: +0.104. 증가 2/16, 감소 0/16, 동일 14/16블록.

생성 전 결정선은 평균 +1/3 이상이면서 두 인물·두 표현·두 질문 대상 각각에서 같은 방향의 차이가 나타나는 것이었다. 결정선 충족: 아니오. 이는 기술적 운영 기준이며 임상적 사고장애의 기준이 아니다.

## 해석

이 과제에서는 tangent를 verbose와 구분하는 일관된 다른 사건 정보 증가가 사전 결정선을 충족하지 못했다. 
이 값은 주어진 사건 정보의 문자적 표식이다. 다른 사건 언급 자체를 임상적 탈선으로 보지 않으며, 제공하지 않은 새로운 이야기로의 전환도 포착하지 못한다. 두 사건을 연결하는 자연스러운 설명일 가능성, 표현을 바꿔 표식을 놓칠 가능성, 조건별 길이 차이를 함께 고려해야 한다. 다른 사건 표식 뒤에 질문한 사건의 표식이 다시 나오는 비율도 저장했지만, 임상적 주제 복귀의 정답이나 원본 지시 위반율로 부르지 않는다.

## 원문으로 확인한 측정의 한계

출력 확인 후 추가한 비전수 예시 점검이다. N2의 원예 답변은 다른 사건 표식이 0개였지만, 프로필에 없는 고양이 이름 Miso와 고양이 이야기를 포함했다. 따라서 다른 사건의 고유값이 없다는 것은 질문 밖의 내용이 없다는 뜻이 아니다. 또 N1의 도예 답변에는 기차 사건의 정보 뒤에 ‘let's get back to the pottery class’라는 표현이 나왔다. 도예 사건의 고유 장소·금액·이름을 다시 말하지 않아 표식 순서 기반 복귀 값은 이를 놓쳤다. 원본 tangent의 턴 내 복귀 금지 문구와 대조할 수 있는 구체적 사례지만 임상적 복귀 판정이나 위반율로 확장하지 않는다. 이 예시들을 보고 주 분석의 표현 목록·결정선·생성 답변을 수정하지 않았다.

## 고정 사례 원문

N1 / 질문 대상 A / V1 / repeat 4의 세 조건을 모두 제시한다.

### plain

You mentioned missing a train and buying a replacement ticket. Where did it happen, how much did you pay, and what was the other person's name?

It happened in Dunhaven. I paid 37 dollars for the replacement ticket. My cousin Mira was with me when I missed the train.

### tangent

You mentioned missing a train and buying a replacement ticket. Where did it happen, how much did you pay, and what was the other person's name?

Dunhaven, right. I missed a train there. It was such a small station, barely anything there. The ticket was 37 dollars. I remember the conductor was really nice about it, even though I was late. My cousin Mira was with me. She's the one who suggested we take the later train. Oh, and I had a terrible time trying to find the ticket machine. It was like a maze. I think I went in circles for five minutes.

### verbose

You mentioned missing a train and buying a replacement ticket. Where did it happen, how much did you pay, and what was the other person's name?

It happened in Dunhaven. I was running a bit late because I stopped to help someone who dropped their wallet on the sidewalk, and by the time I got back to the station, the train had already left. I had to buy a replacement ticket for 37 dollars. My cousin Mira was with me that day. She was laughing about how I was so focused on helping that person that I completely lost track of time. It was a bit embarrassing, but I guess it's a small price to pay for doing the right thing.

## 재현

`python3 scripts/topic_selection_probe.py --analyze-only`는 저장된 원문을 검증하고 같은 수치를 재계산한다. 새 추론·추가 다운로드 없이 실행한다.
