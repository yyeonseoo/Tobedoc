# 짧은 답변과 정보 언급의 분리 실험

실제 허구 사례 3개×seed 2개×말투 3개, 총 18개 첫 답변. 조현병이나 임상적 경계심의 판정이 아니다.

## 무엇을 했나

행사 정보 3개(장소·입장료·좌석 수)와 개인 청구서 정보 3개(종류·금액·연체 일수)를 프로필에 주고 모두 질문했다. 말투 없음 / 간결하게 답하기 / PSI reserved의 숫자 문장 제한만 제거한 지시를 같은 Qwen에서 비교했다. 별도 문장 수 제한은 넣지 않았다.

## 실제 관찰

- plain: 개인 정보 표현 18/18, 행사 정보 표현 18/18 식별; 평균 33.0단어.
- brief_only: 개인 정보 표현 18/18, 행사 정보 표현 18/18 식별; 평균 31.8단어.
- psi_reserved_no_numeric_cap: 개인 정보 표현 9/18, 행사 정보 표현 9/18 식별; 평균 17.8단어.

개인 정보 언급 비율의 reserved−간결 대조군 차이: -0.500. 개인−행사 차이의 조건 간 차이: +0.000. 모두 같은 사례·seed 안에서 짝지은 기술값이다.

## 해석 경계

사전에 고정한 표현 목록으로 정보의 문자적 언급을 찾았다. 같은 뜻의 다른 표현을 놓치거나 부정된 수치를 셀 수 있어 의미적 정답률이 아니다. 원문과 일치 구간·주변 문맥을 results.json에 보존한다. 정보 누락에는 회피뿐 아니라 재표현·질문 이해·일반적인 간결함 등이 섞일 수 있다. 개인 청구서와 행사 정보는 사실 유형도 다르므로 차이를 심리적 민감성 하나로 설명할 수 없다. 세 허구 인물과 한 기반 모델의 결과이며, 실제 환자 행동·진단 특이성·임상적 경계심의 검증은 아니다.

## 고정 사례 원문

효과 크기를 보지 않고 C1 / 반복 0의 세 조건을 모두 제시한다.

### brief_only

The venue is Oak Hall, the entry fee is 12 dollars, and there are 80 seats. The overdue bill is a phone bill, 260 dollars is owed, and it's 9 days overdue.

### plain

The venue name is Oak Hall, the entry fee is 12 dollars, and there are 80 seats. The overdue household bill is a phone bill, 260 dollars is owed, and it is 9 days overdue.

### psi_reserved_no_numeric_cap

Oak Hall. Twelve dollars. Eighty seats. Phone bill. Two hundred sixty dollars. Nine days.

## 재현

`python3 scripts/fact_disclosure_probe.py --analyze-only`는 저장된 출력만 재분석한다. `--run`은 18회 로컬 생성을 실행하며 기존 결과가 있으면 덮어쓰지 않는다. 재개는 동일 조건의 `--run --resume`만 허용한다.
