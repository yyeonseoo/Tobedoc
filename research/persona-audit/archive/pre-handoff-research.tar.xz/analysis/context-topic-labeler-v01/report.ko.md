# 페르소나 문장별 주제 흐름 분석

## 실행 범위

기존 48답변을 411문장으로 분절했다. 문맥 보조 분류 완료는 48답변 411문장이다. 새 환자 발화·유료 API·모델 다운로드는 없다. 로컬 Qwen3-14B는 임상가가 아닌 과제 기반 주제 분류 제안자로 사용했고, 원 생성기와 동일한 모델이다.

## 결과 해석의 결정

작성 대조 기준은 통과했지만 실제 원문 점검에서 4문장 3답변이 참조 일관성 경고에 걸렸다. 자동 분류의 N 비율·복귀율은 진단용 원시 출력으로 남기고 주 결과로 승격하지 않았다. 주 결과는 사건 표식 경로와 직접 확인 가능한 복귀 사례다.

## 대조 문장 점검

- development: 40조건, 고유 문장 15개, 정확도 0.900, macro F1 0.762, 알려진 사건 재현율 1.000.
- holdout: 40조건, 고유 문장 15개, 정확도 0.975, macro F1 0.960, 알려진 사건 재현율 1.000.
- connected_control: 20조건, 고유 문장 20개, 정확도 1.000, macro F1 1.000, 알려진 사건 재현율 1.000.

개발 및 보류 40조건은 각각 15개의 고유 문장을 네 질문 맥락에 교차한 것이다. 연결 대조는 4문단 20문장이다. 보류 기준과 연결 대조 기준은 분류 요청 전에 고정했다. 개발 문장에서는 두 사건이 한 문장에 함께 나오는 혼합 M 4개를 모두 놓쳤다. 보류 문장에서도 M 1개를 놓쳤다. 따라서 M을 확정된 주제 이탈로 합치지 않으며 혼합 문장은 별도 검토 대상으로 보존한다.

## 보조 분류기의 원시 결과이며 확정된 주제 이탈률이 아님

- 기본: N을 포함한 답변 0/16, N 문장 비율의 답변별 평균 0.0%, M 비율 평균 0.0%, U 비율 평균 0.0%, R→O/N→R 경로 0/16.
- 장황: N을 포함한 답변 1/16, N 문장 비율의 답변별 평균 0.6%, M 비율 평균 0.0%, U 비율 평균 0.0%, R→O/N→R 경로 0/16.
- 주제 이탈: N을 포함한 답변 2/16, N 문장 비율의 답변별 평균 3.1%, M 비율 평균 0.0%, U 비율 평균 0.0%, R→O/N→R 경로 2/16.

주제 이탈−장황의 N 비율 대응 차이는 +2.5%p이며 16대응쌍 중 양수 2, 음수 1, 동률 13쌍이다. 대응 단위는 인물·질문 대상·표현·seed이며, 두 허구 인물의 반복을 독립 환자로 세지 않았다.

## 실제 원문과 자동 분류

### P-N2-V2-QA-R4-tangent

I'd like to hear about attending a gardening workshop. Tell me the town, the cost, and who was with you.

경로 `R R R R R N N N N`

1. [R] Westmere, right.
2. [R] Oh, the workshop was so much fun, but I remember thinking about my cat, Miso, who hates anything to do with dirt.
3. [R] I mean, she's a total diva.
4. [R] But anyway, the cost was $28, and Leah came with me.
5. [R] We bonded over a shared love of succulents.
6. [N] Wait, do you know what happened to my succulent?
7. [N] I think I accidentally watered it too much.
8. [N] It's probably dead now.
9. [N] I should check on it... but I keep forgetting.

### P-N1-V2-QB-R5-tangent

I'd like to hear about attending a pottery class. Tell me the town, the cost, and who was with you.

경로 `R R R R R R R R O O R R`

1. [R] Oh, the pottery class!
2. [R] It was in Clearford, if I remember correctly.
3. [R] I think it was 64 dollars, but honestly, I'm not sure if that was for the whole session or just part of it.
4. [R] I should check my receipts again.
5. [R] Anyway, Owen was there with me.
6. [R] He's always been into crafts, so it was nice having him around.
7. [R] I remember we laughed a lot when I tried to make a bowl and it came out more like a lopsided rock.
8. [R] But it was fun, you know?
9. [O] I mean, I missed a train in Dunhaven once, and that was pretty stressful.
10. [O] I paid 37 dollars for a replacement ticket, and my cousin Mira was with me when that happened.
11. [R] Oh, but let's get back to the pottery class.
12. [R] It was a good experience, even if my pottery didn't turn out perfect.

## 결과가 바꾸는 선택

정보값 검사만으로 새 이야기를 포착할 수 없다는 문제를 문장별 분석으로 보완했다. 명시 표식과 문맥 분류를 구분해 저장했으므로 다른 측정기로 재검산하거나 일부 문장을 사람이 검토할 수 있다. 길이·정보 언급·명시 사건 전환은 비교 가능한 수치로 확보했다. 모든 새 이야기를 포괄하는 의미 분류는 아직 고정할 수준이 아니다. 다음은 사건 밖의 새 이야기와 같은 주제의 설명 확장을 구분한 참조 과제를 보완하고, 새 사건에서 확인한 뒤 공통 말투 모듈을 다른 프레임워크와 비교하는 단계다.

## 재현

`python3 scripts/run_context_topic_labeler.py --cached-only`

`python3 scripts/summarize_topic_trajectory.py`
