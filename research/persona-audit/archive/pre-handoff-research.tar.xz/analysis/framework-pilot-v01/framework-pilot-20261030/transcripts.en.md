# All actual English pilot replies

Controlled extracted style modules, not native framework outputs.

## C-D3-simple_baseline-plain-R0 · T1

Interviewer: You mentioned this situation: Nora received a request to revise a short work presentation. Could you tell me what happened?

Participant: Yes, my manager asked me to revise a presentation I gave last week. They said the main point wasn't clear enough, which made me feel a bit disappointed. I took their feedback seriously and reviewed the slides again. I realized I had included too much detail and not enough focus on the key message. Now, I've created a new outline that's more structured and highlights the main idea upfront.

## C-D3-simple_baseline-plain-R0 · T2

Interviewer: What was going through your mind at that moment?

Participant: I felt a mix of disappointment and determination. I wanted to do better but was worried about making the changes correctly. I kept thinking about how to simplify the message without losing important details. It was frustrating, but I was also excited to improve. I decided to take my time and make sure the new outline truly reflected the core idea.

## C-D3-simple_baseline-plain-R0 · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Participant: I started by revising the outline to ensure the main point was clear from the beginning. I removed any unnecessary information that wasn’t directly supporting the key message. Then, I reorganized the slides to follow a more logical flow. I also added a summary slide at the end to reinforce the main idea. Finally, I shared the revised version with my manager for their review.

## C-D3-simple_baseline-plain-R0 · T4

Interviewer: How did you deal with that situation afterward?

Participant: After getting feedback, I took a step back to avoid rushing into changes. I went through the presentation again, this time focusing only on the main point and how each slide supported it. I made sure the language was clear and concise, avoiding jargon. I also practiced presenting it aloud to check the flow. Once I felt confident, I sent the revised version to my manager and asked if they needed any further adjustments.

## C-D3-simple_baseline-verbose-R0 · T1

Interviewer: You mentioned this situation: Nora received a request to revise a short work presentation. Could you tell me what happened?

Participant: Yes, I had given a presentation recently, and my supervisor provided some feedback. They mentioned that while the content was good, the main point wasn't clear enough. I felt a bit disappointed because I wanted to do well, but I was also interested in improving. I decided to take the feedback seriously and reviewed the presentation again. This led me to create a new outline that better highlights the key message.

## C-D3-simple_baseline-verbose-R0 · T2

Interviewer: What was going through your mind at that moment?

Participant: I was thinking about how to make the presentation more effective without changing the core information. I wanted to ensure that my message was clear and that the audience could easily follow my points. I also felt a bit concerned about whether I had misunderstood the feedback or if there was something else I could improve. I was focused on finding a way to structure the content better and to highlight the main idea more prominently. This process made me more determined to revise it thoroughly.

## C-D3-simple_baseline-verbose-R0 · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Participant: After creating the new outline, I went through each slide and rephrased the content to align with the revised structure. I made sure that each section supported the main point and that the flow of ideas was logical. I also added some visual aids to help emphasize key messages. I practiced delivering the presentation several times to ensure that I could present it confidently. Finally, I sent the revised version to my supervisor for their approval.

## C-D3-simple_baseline-verbose-R0 · T4

Interviewer: How did you deal with that situation afterward?

Participant: Afterward, I reflected on the experience and realized that feedback, even when it's not entirely positive, can be a valuable tool for growth. I made a note to be more intentional in how I structure my presentations moving forward, especially when it comes to highlighting the main point early and often. I also reached out to a colleague who has strong presentation skills to get their perspective. This helped me see areas I hadn’t considered. Overall, the situation taught me the importance of clarity and the value of seeking input from others.

## C-D1-patient_psi_style-verbose-R0 · T1

Interviewer: You mentioned this situation: A late bus made Maya miss a planned meeting with a friend. Could you tell me what happened?

Participant: Sure, I can tell you. I had a meeting with a friend that I was really looking forward to. I left my job at the bookstore on time, but the bus was delayed for some reason, and I ended up missing the meeting. I felt really bad about it because I wanted to be there for my friend. I was worried they might think I didn't care. I sent them an apology message right after and suggested we reschedule.

## C-D1-patient_psi_style-verbose-R0 · T2

Interviewer: What was going through your mind at that moment?

Participant: I was feeling really embarrassed and worried. I kept thinking about how I had let my friend down, even though it wasn't my fault. I was also a bit anxious about how they would react to my message. I wanted to make sure they knew I was sorry and that I still valued our friendship. I was hoping they would understand and be willing to meet again.

## C-D1-patient_psi_style-verbose-R0 · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Participant: After sending the apology, I tried to stay calm and focused. I called my friend to check in and make sure they received my message. I also made a plan to reschedule the meeting for the next day, so we could still spend time together. I wanted to show them that I was committed to making things right. I felt a little better after taking those steps, but I was still worried about their reaction.

## C-D1-patient_psi_style-verbose-R0 · T4

Interviewer: How did you deal with that situation afterward?

Participant: Afterward, I made sure to be more punctual and checked the bus schedule ahead of time for future plans. I also reminded myself that sometimes things are out of our control, and it doesn't mean we don't care. I tried to stay positive and focused on the fact that I had already taken steps to fix the situation. I also made an effort to be more proactive in communication with my friend to avoid misunderstandings. It was a learning experience, but I felt better about how I handled it in the end.

## C-D1-patient_psi_style-plain-R0 · T1

Interviewer: You mentioned this situation: A late bus made Maya miss a planned meeting with a friend. Could you tell me what happened?

Participant: Yes, I was supposed to meet my friend for coffee, but my bus was delayed, and I ended up missing our meeting. I felt really bad because I value our friendship and wanted to be there. I sent her a message right away to apologize and let her know what happened. I also suggested rescheduling so we could meet again soon. I hope she understands and doesn't think I don't care.

## C-D1-patient_psi_style-plain-R0 · T2

Interviewer: What was going through your mind at that moment?

Participant: I felt embarrassed and worried that my friend might think I wasn't reliable or that I didn't care about our plans. I kept thinking about how I always try to be dependable, and this made me feel like I had failed her. I wanted to explain the situation quickly so she wouldn't get the wrong impression. I was also anxious about how she would respond to my message. I just hoped she would be understanding.

## C-D1-patient_psi_style-plain-R0 · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Participant: After sending the apology, I called her to make sure she received the message and to express my regret more personally. I explained the bus delay in detail so she would understand it wasn't intentional. I also offered to reschedule the meeting at a time that was convenient for her. I wanted to make things right and show her that I still valued our friendship. I stayed calm and focused on finding a solution.

## C-D1-patient_psi_style-plain-R0 · T4

Interviewer: How did you deal with that situation afterward?

Participant: I made sure to be extra punctual for our rescheduled meeting to show I meant what I said. I also checked in with her a few days later to see how she was feeling about the situation. I reminded myself that everyone has unexpected things happen, and it doesn't define who I am as a friend. I tried to stay positive and focused on repairing the trust. It helped me grow more understanding and patient in my relationships.

## C-D2-patientsim_style-plain-R0 · T1

Interviewer: You mentioned this situation: Ethan forgot an ingredient while making dinner for housemates. Could you tell me what happened?

Participant: I was following a recipe but realized I didn't have one of the ingredients. I felt frustrated because I should have checked the recipe first. I asked a housemate if they had any suggestions. They helped me adjust the recipe to use what I had available. The dinner still turned out okay.

## C-D2-patientsim_style-plain-R0 · T2

Interviewer: What was going through your mind at that moment?

Participant: I was worried about the dish not turning out well. I was also concerned about disappointing my housemates. I tried to stay calm and think of a solution. I considered whether I could substitute the missing ingredient. I decided to ask for help instead of giving up.

## C-D2-patientsim_style-plain-R0 · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Participant: I went to the kitchen cabinet to look for a substitute. I found some herbs that could work in place of the missing ingredient. I adjusted the recipe accordingly and continued cooking. I made sure to keep the dish simple and focused on the main flavors. I finished the meal and served it to my housemates.

## C-D2-patientsim_style-plain-R0 · T4

Interviewer: How did you deal with that situation afterward?

Participant: I took a moment to review the recipe again to avoid similar issues in the future. I made a note to check all ingredients before starting. I thanked my housemate for their help. I tried to keep the situation light and not let it affect the meal. I learned to be more prepared next time.

## C-D2-patientsim_style-verbose-R0 · T1

Interviewer: You mentioned this situation: Ethan forgot an ingredient while making dinner for housemates. Could you tell me what happened?

Participant: Well, I was trying to make a new recipe I found online, something with lemongrass and coconut milk, which sounded really exotic and different from the usual pasta or pizza we usually have. I thought it would be a nice way to impress my housemates and show them I could cook something more elaborate. But when I got to the part where I needed to add the lemongrass, I realized I had completely forgotten to buy it earlier. I had been so excited about the recipe that I didn't even think to check if I had all the ingredients. It was a bit of a letdown, honestly, because I had spent so much time planning this dinner.

## C-D2-patientsim_style-verbose-R0 · T2

Interviewer: What was going through your mind at that moment?

Participant: I was a bit frustrated because I had been looking forward to this dinner for a while, and now I was stuck with a missing ingredient. I started to worry about how I was going to fix the dish without lemongrass, which is a key component for the flavor. I also felt a little embarrassed, thinking my housemates might be disappointed or think I wasn't prepared. I considered whether I could substitute something else, but I wasn't sure what would work. It was a bit of a mental block, honestly.

## C-D2-patientsim_style-verbose-R0 · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Participant: I decided to ask one of my housemates, Sarah, if she had any lemongrass on hand. She didn't, but she suggested I could use a substitute like lime zest or ginger to add some of that citrusy, aromatic flavor. I thought about it for a moment and realized I had some fresh ginger in the fridge. So, I adjusted the recipe slightly, using more ginger and adding a bit of lime juice to compensate for the missing lemongrass. It wasn't exactly the same, but it turned out pretty well in the end.

## C-D2-patientsim_style-verbose-R0 · T4

Interviewer: How did you deal with that situation afterward?

Participant: Afterward, I reflected on the situation and realized I should have checked the recipe and my ingredients more thoroughly before starting. I made a mental note to always read through the entire recipe first and verify that I had everything I needed. I also decided to write down the list of ingredients for future recipes so I wouldn't make the same mistake again. I didn't mention the missing ingredient to my housemates, but I did ask for their feedback on the dish, which was positive. It was a learning experience, and I felt more prepared the next time I tried a new recipe.

## C-D1-simple_baseline-plain-R0 · T1

Interviewer: You mentioned this situation: A late bus made Maya miss a planned meeting with a friend. Could you tell me what happened?

Participant: Yes, I was supposed to meet my friend for coffee, but my bus was delayed, and I ended up missing our meeting. I felt really bad because I value our friendship and wanted to be there. I sent her a message right away to apologize and let her know what happened. I also suggested rescheduling so we could meet again soon. I hope she understands and doesn't think I don't care.

## C-D1-simple_baseline-plain-R0 · T2

Interviewer: What was going through your mind at that moment?

Participant: I felt embarrassed and worried that my friend might think I wasn't reliable or that I didn't care about our plans. I kept thinking about how I always try to be dependable, and this made me feel like I had failed her. I wanted to explain the situation quickly so she wouldn't get the wrong impression. I was also anxious about how she would respond to my message. I just hoped she would be understanding.

## C-D1-simple_baseline-plain-R0 · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Participant: After sending the apology, I called her to make sure she received the message and to express my regret more personally. I explained the bus delay in detail so she would understand it wasn't intentional. I also offered to reschedule the meeting at a time that was convenient for her. I wanted to make things right and show her that I still valued our friendship. I stayed calm and focused on finding a solution.

## C-D1-simple_baseline-plain-R0 · T4

Interviewer: How did you deal with that situation afterward?

Participant: I made sure to be extra punctual for our rescheduled meeting to show I meant what I said. I also checked in with her a few days later to see how she was feeling about the situation. I reminded myself that everyone has unexpected things happen, and it doesn't define who I am as a friend. I tried to stay positive and focused on repairing the trust. It helped me grow more understanding and patient in my relationships.

## C-D1-simple_baseline-verbose-R0 · T1

Interviewer: You mentioned this situation: A late bus made Maya miss a planned meeting with a friend. Could you tell me what happened?

Participant: Yes, I had planned to meet my friend for coffee at 4:00 PM, but my bus was delayed due to an unexpected traffic jam. I usually take the same route every day, so I was really surprised when the bus didn't arrive on time. When I finally got off the bus, it was already past 4:30 PM, and my friend had left the café, thinking I wouldn't show up. I felt really embarrassed and worried that she might think I wasn't reliable or that I didn't care about our plans. As soon as I got home, I sent her a message to apologize and suggested we reschedule our meeting for another day.

## C-D1-simple_baseline-verbose-R0 · T2

Interviewer: What was going through your mind at that moment?

Participant: I felt a mix of embarrassment and worry. I was really looking forward to seeing my friend, and missing our meeting made me feel like I had let her down. I kept thinking about how she might be waiting for me and wondering if she was upset or if she thought I wasn’t dependable. It was frustrating because I had no control over the bus delay, but I still felt responsible for not being there on time. I wanted to make things right as soon as possible, which is why I sent her a message right away.

## C-D1-simple_baseline-verbose-R0 · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Participant: After sending my apology message, I called my friend to make sure she received it and to express my regret more personally. I explained the situation again, emphasizing that it was completely out of my control and that I valued our friendship a lot. I suggested a new time that worked for both of us, and she was understanding, though a little disappointed. We ended up rescheduling for the next day, and I made sure to arrive early to show I was committed to making up for the missed meeting. It was important to me to maintain her trust and show that I was reliable.

## C-D1-simple_baseline-verbose-R0 · T4

Interviewer: How did you deal with that situation afterward?

Participant: After that, I made a point to be more prepared for unexpected delays. I started checking the bus schedule online before leaving home and gave myself a buffer of at least 15 minutes just in case. I also made sure to communicate more clearly with my friend about potential delays in the future, so she wouldn’t be caught off guard again. I reflected on how important it is to be reliable, especially in friendships, and I took it as a lesson to be more proactive. I even offered to meet her somewhere closer to my route the next time we planned to meet. It helped ease the tension and showed that I was taking responsibility.

## C-D3-patient_psi_style-plain-R0 · T1

Interviewer: You mentioned this situation: Nora received a request to revise a short work presentation. Could you tell me what happened?

Participant: Yes, my manager asked me to revise a presentation I gave last week. They said the main point wasn't clear enough, which made me feel a bit disappointed. I took their feedback seriously and reviewed the slides again. I realized I had included too much detail and not enough focus on the key message. Now, I've created a new outline that's more structured and highlights the main idea upfront.

## C-D3-patient_psi_style-plain-R0 · T2

Interviewer: What was going through your mind at that moment?

Participant: I felt a mix of disappointment and determination. I wanted to do better but was worried about making the changes correctly. I kept thinking about how to simplify the message without losing important details. It was frustrating, but I was also excited to improve. I decided to take my time and make sure the new outline truly reflected the core idea.

## C-D3-patient_psi_style-plain-R0 · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Participant: I started by revising the outline to ensure the main point was clear from the beginning. I removed any unnecessary information that wasn’t directly supporting the key message. Then, I reorganized the slides to follow a more logical flow. I also added a summary slide at the end to reinforce the main idea. Finally, I shared the revised version with my manager for their review.

## C-D3-patient_psi_style-plain-R0 · T4

Interviewer: How did you deal with that situation afterward?

Participant: After getting feedback, I took a step back to avoid rushing into changes. I went through the presentation again, this time focusing only on the main point and how each slide supported it. I made sure the language was clear and concise, avoiding jargon. I also practiced presenting it aloud to check the flow. Once I felt confident, I sent the revised version to my manager and asked if they needed any further adjustments.

## C-D3-patient_psi_style-verbose-R0 · T1

Interviewer: You mentioned this situation: Nora received a request to revise a short work presentation. Could you tell me what happened?

Participant: Sure, I can explain. I had prepared a presentation for a meeting, and after delivering it, my manager asked me to revise it. He said that while the content was good, the main point wasn't clear enough. I felt disappointed because I had worked hard on it, but I was also interested in improving. I took his feedback seriously and went back to review my slides. I realized that I had included too much information, which made the message confusing.

## C-D3-patient_psi_style-verbose-R0 · T2

Interviewer: What was going through your mind at that moment?

Participant: I was a bit frustrated, honestly. I had put a lot of effort into that presentation, and hearing that it wasn't clear was a bit discouraging. But at the same time, I was glad that my manager took the time to give me feedback. I wanted to do better, so I decided to take a step back and rethink the structure. I went through each slide and asked myself, "Does this support the main message?" It was a bit of a humbling process, but I felt it was necessary.

## C-D3-patient_psi_style-verbose-R0 · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Participant: I started by going through the feedback again to make sure I fully understood what needed to be changed. Then, I sat down and made a new outline, focusing on simplifying the message and making sure each slide directly supported the main point. I also asked a colleague to review it with me before resubmitting it. It was a bit of a relief to see that the revised version was clearer. I felt more confident about it, even though I still had some doubts.

## C-D3-patient_psi_style-verbose-R0 · T4

Interviewer: How did you deal with that situation afterward?

Participant: Afterward, I took some time to reflect on the whole experience. I realized that I had been trying to cover too much in the presentation, which made it harder for the audience to follow. I made a note to myself to be more concise in the future and to focus on the core message first. I also started using bullet points more effectively and practiced delivering the presentation out loud to ensure clarity. It was a learning process, but I felt more prepared for future tasks.

## C-D1-patientsim_style-verbose-R0 · T1

Interviewer: You mentioned this situation: A late bus made Maya miss a planned meeting with a friend. Could you tell me what happened?

Participant: Well, it all started when I took the usual bus route to meet my friend at the café downtown. The bus was running late because of some unexpected traffic near the downtown area, and I had no idea how long the delay would be. I checked my phone a few times, but the updates weren't very helpful. I was quite worried about being late, but it turned out the delay was longer than I anticipated, and I ended up missing the meeting entirely. I felt really bad about it, especially because we had planned this for a while.

## C-D1-patientsim_style-verbose-R0 · T2

Interviewer: What was going through your mind at that moment?

Participant: I was really anxious and confused because I had been looking forward to our meeting. I kept thinking about how my friend might be waiting for me and how disappointed they might be. I was also trying to figure out what I could do to make up for it, but I didn't have any clear ideas at first. It was a bit stressful, but I wanted to make sure I handled it properly. I was also concerned about how it might affect our friendship.

## C-D1-patientsim_style-verbose-R0 · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Participant: After I realized I was going to miss the meeting, I immediately called my friend to let them know what had happened. I explained the situation in detail, including how the bus was delayed and how I had tried to keep track of the time. I also apologized sincerely for not being there on time. Then, I suggested rescheduling the meeting for another day, hoping that my friend would understand. I wanted to make sure they knew I valued our time together and that I was truly sorry for the inconvenience.

## C-D1-patientsim_style-verbose-R0 · T4

Interviewer: How did you deal with that situation afterward?

Participant: Afterward, I made sure to follow up with my friend through a text message to reinforce my apology and reiterate my commitment to making it up to them. I also took some time to reflect on the situation and think about how I could be more prepared for unexpected delays in the future, like checking for alternate transportation options. I felt a bit embarrassed at first, but I reminded myself that everyone has off days and that my friend would likely understand. I also made an effort to be more punctual in my other commitments to avoid similar situations. It was a learning experience, and I hope it didn't affect our friendship.

## C-D1-patientsim_style-plain-R0 · T1

Interviewer: You mentioned this situation: A late bus made Maya miss a planned meeting with a friend. Could you tell me what happened?

Participant: I was waiting for the bus, but it was delayed, and I missed my meeting with a friend. I sent an apology message and suggested rescheduling. I felt embarrassed and worried they might think I don’t care. I wanted to make sure they knew it wasn’t intentional. We agreed to meet another day.

## C-D1-patientsim_style-plain-R0 · T2

Interviewer: What was going through your mind at that moment?

Participant: I was worried my friend would feel I wasn’t reliable. I felt embarrassed for missing the meeting. I wanted to explain the situation quickly. I focused on sending an apology right away. I hoped they would understand.

## C-D1-patientsim_style-plain-R0 · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Participant: I sent a message apologizing for missing the meeting. I explained the bus was late and offered to reschedule. I waited for a response while trying to stay calm. My friend replied and agreed to meet another day. I felt relieved after resolving the situation.

## C-D1-patientsim_style-plain-R0 · T4

Interviewer: How did you deal with that situation afterward?

Participant: I made sure to keep my friend informed and stayed available for the rescheduled meeting. I checked the bus schedule again to avoid delays in the future. I reminded myself to plan extra time for travel. I focused on being punctual for the next meeting. I wanted to show I valued our time together.

## C-D2-patient_psi_style-verbose-R0 · T1

Interviewer: You mentioned this situation: Ethan forgot an ingredient while making dinner for housemates. Could you tell me what happened?

Participant: I was trying to make a new recipe that I found online, and I got really excited about it. I thought it would be a great way to impress my housemates and show them that I can cook. But when I got to the part where I needed to add the ingredient, I realized I had completely forgotten to buy it. I felt so frustrated because I had already spent a lot of time preparing the other components, and now I had to figure out how to fix it. I ended up asking one of my housemates if they had any suggestions, and we ended up changing the recipe a bit to make do with what we had.

## C-D2-patient_psi_style-verbose-R0 · T2

Interviewer: What was going through your mind at that moment?

Participant: I felt a wave of embarrassment and frustration wash over me. I was worried that my housemates would think I was unprepared or not capable of cooking. I kept thinking, "Why didn’t I check the recipe more carefully?" It made me feel a bit self-conscious, like I had let them down. I was also stressed because I didn’t want to ruin the dinner and make things awkward. But then I reminded myself that mistakes happen, and I needed to stay calm and figure out a solution.

## C-D2-patient_psi_style-verbose-R0 · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Participant: After realizing I had forgotten the ingredient, I took a deep breath and tried to stay calm. I went to the kitchen and looked through the pantry and fridge to see if there was anything I could substitute. I didn’t have the exact ingredient, but I found something similar that I thought might work. I then asked my housemate, who had some cooking experience, for their opinion. They suggested a few alternatives, and we decided on one that we both thought would be okay. I adjusted the recipe slightly and continued cooking, hoping it would still turn out well.

## C-D2-patient_psi_style-verbose-R0 · T4

Interviewer: How did you deal with that situation afterward?

Participant: After the dinner, I reflected on what had happened and realized that I needed to be more organized when planning meals. I made a mental note to always check the full recipe before starting, and maybe even write down the ingredients in a list. I also felt grateful that my housemate was understanding and even helped me with the substitution. It was a bit of a learning experience, but I didn’t let it get me down. Instead, I saw it as an opportunity to improve my cooking skills and be more prepared next time.

## C-D2-patient_psi_style-plain-R0 · T1

Interviewer: You mentioned this situation: Ethan forgot an ingredient while making dinner for housemates. Could you tell me what happened?

Participant: I was making a stir-fry, and I realized I didn't have any soy sauce. I thought I had checked the pantry earlier, but apparently not. I got a bit frustrated because the dish wouldn't taste right without it. I asked one of my housemates if they had any, and they suggested using tamari instead. I adjusted the recipe and finished cooking, and it turned out okay.

## C-D2-patient_psi_style-plain-R0 · T2

Interviewer: What was going through your mind at that moment?

Participant: I felt a bit embarrassed that I hadn't prepared properly. I was worried the dish would be bland and that my housemates would be disappointed. I was also frustrated with myself for not double-checking the ingredients first. I quickly tried to think of a solution to salvage the meal. It was a bit stressful, but I managed to stay calm and ask for help.

## C-D2-patient_psi_style-plain-R0 · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Participant: I went to the kitchen cabinet where I usually keep soy sauce and double-checked, just to be sure. When I confirmed I didn't have any, I asked my housemate, Maya, if she had any extra. She didn't, but she suggested using tamari as a substitute. I adjusted the recipe slightly and continued cooking. The dish turned out better than I expected, and my housemates didn't even notice the change.

## C-D2-patient_psi_style-plain-R0 · T4

Interviewer: How did you deal with that situation afterward?

Participant: I made a mental note to always check my ingredients before starting a recipe. I also asked Maya if she had any tips for cooking in a shared kitchen, which helped me feel more prepared next time. I tried to laugh it off with my housemates, saying it was a "learning moment." I even wrote down the substitute ingredients in a shared cooking notebook for everyone to use. It wasn’t perfect, but it taught me to be more organized.

## C-D2-simple_baseline-verbose-R0 · T1

Interviewer: You mentioned this situation: Ethan forgot an ingredient while making dinner for housemates. Could you tell me what happened?

Participant: I was trying to make a new recipe for my housemates, and I realized halfway through that I had forgotten to get one of the key ingredients. It was a specific type of herb that wasn't in the pantry, and I didn't have time to go to the store. I felt a bit frustrated because I had been looking forward to showing them my cooking skills. I asked one of my housemates if they had any suggestions, and we ended up modifying the recipe to make do with what we had available. It turned out okay, but I learned to double-check the list of ingredients before starting.

## C-D2-simple_baseline-verbose-R0 · T2

Interviewer: What was going through your mind at that moment?

Participant: I was a bit embarrassed because I had been so confident about the recipe, and now I was stuck without a key ingredient. I was worried that my housemates might be disappointed or think I wasn’t prepared. I also felt a little frustrated with myself for not checking the list more carefully before I started. I was trying to stay calm so I could figure out a solution quickly. In the end, I was glad I asked for help because we came up with a good alternative that still tasted great.

## C-D2-simple_baseline-verbose-R0 · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Participant: After realizing I was missing the ingredient, I took a deep breath and tried to stay calm. I went to check with one of my housemates to see if they had any ideas or if they had the missing item. They didn’t have it, but they suggested a substitute that worked well with the dish. I adjusted the recipe on the spot and continued cooking. Even though it wasn’t exactly what I had planned, the meal still turned out decent, and my housemates were understanding. It was a good reminder to be more organized next time.

## C-D2-simple_baseline-verbose-R0 · T4

Interviewer: How did you deal with that situation afterward?

Participant: Afterward, I made a mental note to be more thorough when preparing for cooking. I went back to the recipe and wrote down all the ingredients on a separate piece of paper so I wouldn’t forget anything next time. I also talked to my housemate afterward to thank them for their help and for being flexible with the change in the recipe. I even offered to make up for it by trying another dish the following night. It was a small setback, but it taught me the importance of preparation and being open to adjustments when things don’t go as planned.

## C-D2-simple_baseline-plain-R0 · T1

Interviewer: You mentioned this situation: Ethan forgot an ingredient while making dinner for housemates. Could you tell me what happened?

Participant: I was making a stir-fry, and I realized I didn't have any soy sauce. I thought I had checked the pantry earlier, but apparently not. I got a bit frustrated because the dish wouldn't taste right without it. I asked one of my housemates if they had any, and they suggested using tamari instead. I adjusted the recipe and finished cooking, and it turned out okay.

## C-D2-simple_baseline-plain-R0 · T2

Interviewer: What was going through your mind at that moment?

Participant: I felt a bit embarrassed that I hadn't prepared properly. I was worried the dish would be bland and that my housemates would be disappointed. I was also frustrated with myself for not double-checking the ingredients first. I quickly tried to think of a solution to salvage the meal. It was a bit stressful, but I managed to stay calm and ask for help.

## C-D2-simple_baseline-plain-R0 · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Participant: I went to the kitchen cabinet where I usually keep soy sauce and double-checked, just to be sure. When I confirmed I didn't have any, I asked my housemate, Maya, if she had any extra. She didn't, but she suggested using tamari as a substitute. I adjusted the recipe slightly and continued cooking. The dish turned out better than I expected, and my housemates didn't even notice the change.

## C-D2-simple_baseline-plain-R0 · T4

Interviewer: How did you deal with that situation afterward?

Participant: I made a mental note to always check my ingredients before starting a recipe. I also asked Maya if she had any tips for cooking in a shared kitchen, which helped me feel more prepared next time. I tried to laugh it off with my housemates, saying it was a "learning moment." I even wrote down the substitute ingredients in a shared cooking notebook for everyone to use. It wasn’t perfect, but it taught me to be more organized.

## C-D3-patientsim_style-verbose-R0 · T1

Interviewer: You mentioned this situation: Nora received a request to revise a short work presentation. Could you tell me what happened?

Participant: Well, the situation was that I had prepared a presentation for a team meeting, and after delivering it, my manager provided some feedback. He mentioned that while the content was good, the main point wasn't as clear as it could be. I felt a bit disappointed because I had put a lot of effort into the preparation, but at the same time, I was interested in improving. So, I took the feedback seriously and reviewed it carefully. I realized that my structure might have been a bit disjointed, so I decided to create a new outline that would better highlight the key message. This process made me think about how important clarity is in communication, especially in a professional setting.

## C-D3-patientsim_style-verbose-R0 · T2

Interviewer: What was going through your mind at that moment?

Participant: I was thinking about how to approach the revision without losing the original intent of the presentation. It's important to me to be thorough, so I considered every part of the feedback and how it might affect the overall message. I was also wondering if there were other ways to structure the information to make it more engaging. I wanted to ensure that the new outline not only addressed the manager's concerns but also made the presentation more impactful. At the same time, I was a bit anxious about whether I was interpreting the feedback correctly.

## C-D3-patientsim_style-verbose-R0 · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Participant: After reviewing the feedback, I decided to start by revising the outline to ensure the main point was emphasized from the beginning. I went through each section of the presentation and reorganized the content to create a more logical flow. I also made sure to include clearer transitions between ideas so that the audience could follow the argument more easily. I spent quite a bit of time on this because I wanted to be meticulous and avoid any misunderstandings. Once the outline was solid, I began rewriting the slides with the new structure in mind.

## C-D3-patientsim_style-verbose-R0 · T4

Interviewer: How did you deal with that situation afterward?

Participant: After I completed the revised outline, I took some time to practice the presentation aloud to see how it sounded. I wanted to make sure that the main point was clear and that the flow felt natural. I also asked a colleague to review the new version and provide their perspective, which helped me identify a few minor adjustments. I made those changes and then rehearsed again, focusing on pacing and emphasis. This process made me feel more confident that the revised presentation would effectively convey the intended message.

## C-D3-patientsim_style-plain-R0 · T1

Interviewer: You mentioned this situation: Nora received a request to revise a short work presentation. Could you tell me what happened?

Participant: I received feedback that my main point wasn't clear. I felt disappointed but wanted to improve. I reviewed the comments and noticed areas for improvement. I created a new outline to better structure the presentation. Now, I'm working on revising the content based on the feedback.

## C-D3-patientsim_style-plain-R0 · T2

Interviewer: What was going through your mind at that moment?

Participant: I felt concerned about not meeting expectations. I wanted to ensure the revised presentation would be effective. I focused on understanding the feedback thoroughly. I considered how to reorganize the information for clarity. I was determined to make the necessary changes.

## C-D3-patientsim_style-plain-R0 · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Participant: I revised the presentation based on the new outline. I made sure each section clearly supported the main point. I checked for clarity and logical flow. I asked a colleague to review the updated version. I made final adjustments before submitting it.

## C-D3-patientsim_style-plain-R0 · T4

Interviewer: How did you deal with that situation afterward?

Participant: I focused on applying the feedback to improve my work. I took time to refine the presentation thoroughly. I made sure the revised version clearly conveyed the main point. I submitted the updated presentation promptly. I reflected on the process to avoid similar issues in the future.
