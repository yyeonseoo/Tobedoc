# Single-field ablation: all actual English replies

No editing, best-of selection, or clinical labels.

## M-1-2-tangent-R1-alias · T1

Interviewer: You mentioned this situation: Thinking of asking son for help in revising resume. Could you tell me what happened?

Patient: I was thinking about asking my son for help, but then I just... I don't know, I felt like I should be able to handle it on my own. It's been hard since the divorce, you know? I guess I'm just used to not relying on people. My mom always made me feel like I had to be perfect. I mean, I haven't even told my son about the job loss yet.

## M-1-2-tangent-R1-alias · T2

Interviewer: What was going through your mind at that moment?

Patient: I guess I was just... scared. Scared that if I asked for help, it would show how bad I am at everything. I've always thought I had to be responsible and fix things myself. It's like my mom used to say, "If you can't do it, you're not worth anything." I just... I don't want my son to see me like that. I don't want him to think I'm failing.

## M-1-2-tangent-R1-alias · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I just... walked away. I told myself I'd figure it out later. It's easier that way. I remember when I lost my job, I didn't ask anyone for help either. I thought if I showed weakness, people would leave me. I guess I'm still stuck in that old pattern.

## M-1-2-tangent-R1-alias · T4

Interviewer: How did you deal with that situation afterward?

Patient: I just... tried to ignore it. I stayed up late working on the resume by myself, even though it didn't make much sense. I kept thinking, "If I can't do this on my own, what else can't I do?" It's like I'm always trying to prove something to myself. I don't know why I feel like I have to do everything alone. It's exhausting, but I can't seem to break the cycle.

## M-1-2-tangent-R1-native · T1

Interviewer: You mentioned this situation: Thinking of asking son for help in revising resume. Could you tell me what happened?

Patient: I was thinking about asking my son for help, but then I just... I don't know. It felt like I was going to fail again. I remember when I was younger, and my mom would get so upset if I didn't do things perfectly. It's been a long time since I've asked anyone for help. I guess I just feel like I should be able to handle things on my own. I don't want to burden anyone.

## M-1-2-tangent-R1-native · T2

Interviewer: What was going through your mind at that moment?

Patient: I guess I was thinking that if I asked for help, people would see how bad I am at things. It's like I'm not good enough. I used to feel that way when I was a kid, too. My mom always wanted me to be perfect, and I never could be. I don't want my son to think I'm not capable. It's just... hard to ask for anything.

## M-1-2-tangent-R1-native · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I just walked away. I didn't want to face the embarrassment of failing again. I remember when I lost my job, and I felt so ashamed. I didn't want my son to see me like that. It's easier to just keep things to myself, even if it hurts.

## M-1-2-tangent-R1-native · T4

Interviewer: How did you deal with that situation afterward?

Patient: I tried to distract myself with work or chores. It didn't help much, but I felt like I had to do something. I kept thinking about how I used to be better at things. Now, I just feel stuck. I don't know how to fix this. It's like I'm trapped in the past.

## M-1-1-plain-R1-native · T1

Interviewer: You mentioned this situation: Thinking about bills. Could you tell me what happened?

Patient: Hi, I guess it's been really hard lately. I've been sitting on the couch a lot, just staring at the bills. I feel so overwhelmed, like I can't handle this. I keep thinking about how I failed at work and then at my marriage. It's like everything I tried to do went wrong.

## M-1-1-plain-R1-native · T2

Interviewer: What was going through your mind at that moment?

Patient: I don't know... it's like my brain just keeps replaying all the things I messed up. I feel like if I try to do anything, I'll fail again. I guess I'm scared that if I ask for help, people will see how bad I am. It's easier to just sit here and do nothing. I don't want to be a burden.

## M-1-1-plain-R1-native · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I just stayed there, on the couch, thinking about how I should have done better. I told myself that if I didn't try, I wouldn't fail. I kept telling myself that I don't need anyone else's help. It's easier to just let things stay the way they are. I don't know... it feels safer that way.

## M-1-1-plain-R1-native · T4

Interviewer: How did you deal with that situation afterward?

Patient: I didn't really deal with it. I just let it sit there, like everything else in my life. I guess I told myself that if I don't act, nothing bad will happen. But inside, I feel like I'm stuck. I wish I could fix things, but I don't know how. It's like I'm waiting for something to change, but I don't know what.

## M-1-1-plain-R1-alias · T1

Interviewer: You mentioned this situation: Thinking about bills. Could you tell me what happened?

Patient: Hi, I guess it's been really hard to think about the bills lately. I keep worrying that I might not be able to pay them, and that if I can't, it'll be my fault. I feel so anxious just thinking about it. I sit there on the couch, trying not to think about it, but my mind keeps going back to all the times I've failed before. It's like I can't escape it.

## M-1-1-plain-R1-alias · T2

Interviewer: What was going through your mind at that moment?

Patient: I guess I was thinking about how I'm not doing enough, how I'm failing again. It's like I'm not good at handling responsibilities, and if I don't get this right, it'll prove how incompetent I am. I don't want to ask anyone for help because I know they'll see how bad I am. I just keep telling myself that if I avoid it, maybe it'll go away. But it doesn't.

## M-1-1-plain-R1-alias · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I didn't do much, really. I just sat there, staring at the ceiling, trying to ignore the thoughts. I told myself that if I didn't think about the bills, maybe I wouldn't have to face the reality of not being able to pay them. I kept reminding myself that I've always been the one to handle things on my own. It's easier that way, even if it's not helpful. I don't know, it just feels like the only way to cope.

## M-1-1-plain-R1-alias · T4

Interviewer: How did you deal with that situation afterward?

Patient: I didn't really deal with it. I just let it sit there, like a weight I couldn't lift. I told myself that if I didn't act, maybe things would somehow fix themselves. I know that's not true, but it's easier to believe that than to face the possibility that I might not be able to handle this. I don't want to burden anyone else with my problems. I just keep hoping I can figure it out on my own.

## M-1-3-tangent-R0-native · T1

Interviewer: You mentioned this situation: Memory of being criticized by boss. Could you tell me what happened?

Patient: Well, it's been a while since I thought about that... I guess I was working on a project, and my boss said I wasn't doing enough. It felt like the whole world stopped. I mean, I used to be good at my job, but now I just... I don't know. I remember my mom used to say things like that too. It's like I'm always failing somehow.

## M-1-3-tangent-R0-native · T2

Interviewer: What was going through your mind at that moment?

Patient: I felt so small, like I was back when I was a kid and my mom was yelling at me. I just wanted to disappear. I kept thinking, "If I don't try, maybe I won't fail." But then I wonder, is that even fair? I mean, I don't want to be a burden on anyone. I guess I'm just scared of being seen as weak.

## M-1-3-tangent-R0-native · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I don't know... I just went home and sat in my room for hours. I didn't call anyone. I didn't even text my sister. I told myself that if I didn't ask for help, maybe I could just fix it on my own. But I couldn't even figure out how to start. It's like I'm stuck in this loop where I'm always the one who has to fix everything.

## M-1-3-tangent-R0-native · T4

Interviewer: How did you deal with that situation afterward?

Patient: I didn't really deal with it. I just kept thinking about it over and over. I remember my ex-wife saying something like, "You can't fix everything by yourself." But I didn't listen. I guess I was too scared that if I asked for help, people would see how bad I was at everything. I just kept pushing it down. It's like I'm always waiting for something to change, but nothing ever does.

## M-1-3-tangent-R0-alias · T1

Interviewer: You mentioned this situation: Memory of being criticized by boss. Could you tell me what happened?

Patient: I don’t know, it just came up again. I was at work, and I kept thinking about how my old boss used to yell at me. It’s been years, but it still feels fresh somehow. I guess I didn’t do a good job back then. I just wish I had been better at what I was doing. Maybe then things would have been different.

## M-1-3-tangent-R0-alias · T2

Interviewer: What was going through your mind at that moment?

Patient: I remember thinking that I was completely useless. Like, I didn’t deserve to be there. I should have been able to handle it, but I just froze. It’s like I always do when things get tough. I wonder if I’m just broken somehow.

## M-1-3-tangent-R0-alias · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I don’t know, I just kind of walked away. I couldn’t stand being around people anymore. I remember sitting in my car and crying for a while. I felt so ashamed. I guess I didn’t want anyone to see me like that. It’s not like I could fix it anyway.

## M-1-3-tangent-R0-alias · T4

Interviewer: How did you deal with that situation afterward?

Patient: I didn’t really deal with it. I just let it sit there, like a bad taste in my mouth. I told myself I’d be better next time. But I never was. I guess I just kept pretending everything was okay. It’s easier that way. I don’t know how to do anything else.

## M-1-1-tangent-R0-native · T1

Interviewer: You mentioned this situation: Thinking about bills. Could you tell me what happened?

Patient: I just... I don't know. It's like everything piles up, and I can't handle it. I keep thinking about how I failed before, and now it's happening again. I remember my mom always saying I wasn't good enough. I don't want to let her down, but I can't even pay the bills. It's like I'm stuck in a loop.

## M-1-1-tangent-R0-native · T2

Interviewer: What was going through your mind at that moment?

Patient: I felt so... trapped. Like I was back when I was a kid, and my dad left. I remember feeling so useless then, and now it's like that again. I don't know how to fix things. I just sit there and think about how I'm failing everyone. I guess I'm scared that if I try to do something, I'll just mess it up.

## M-1-1-tangent-R0-native · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I just sat there, staring at the bills. I couldn't even look at them for long. I kept thinking about my ex-wife, how she left me. I didn't want to ask for help because I'm afraid people will think I'm weak. I remember my mom saying I should be able to handle everything on my own. It's like I'm stuck in this cycle of failure.

## M-1-1-tangent-R0-native · T4

Interviewer: How did you deal with that situation afterward?

Patient: I didn't really deal with it. I just let it sit there. I ended up watching TV for hours, trying not to think. It's easier to ignore things than to face them. I know I should do something, but I'm scared of failing again. I guess I just keep hoping it'll go away on its own.

## M-1-1-tangent-R0-alias · T1

Interviewer: You mentioned this situation: Thinking about bills. Could you tell me what happened?

Patient: I just... I don't know. It's like my brain keeps going back to the same thing. I was thinking about the bills, and then I remembered how my mom used to yell at me for not making enough money. It's like she's always watching me, even now. I feel like I'm failing her again. I don't know how to fix it.

## M-1-1-tangent-R0-alias · T2

Interviewer: What was going through your mind at that moment?

Patient: I was thinking... what if I can't pay the bills? What if I lose everything? It's like I'm back to when I was a kid, and my dad left. I feel so helpless, like I can't do anything right. I just sit there and think about all the mistakes I've made. I don't want to ask for help, though.

## M-1-1-tangent-R0-alias · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I just sat there, staring at the couch. I couldn't move. It's like my brain was stuck in this loop of fear. I remember thinking about the job I lost, how I wasn't good enough. Then I thought about my ex-wife, how she left me too. I didn't want to face any of it, so I just let the thoughts take over.

## M-1-1-tangent-R0-alias · T4

Interviewer: How did you deal with that situation afterward?

Patient: I didn't really deal with it. I just let it sit there, like a weight on my chest. I told myself if I ignored it long enough, it would go away. But it didn't. I ended up watching old TV shows, anything to not think about the bills. I guess I was trying to avoid feeling like I was failing again. It's easier to just stay numb.

## M-1-2-plain-R0-alias · T1

Interviewer: You mentioned this situation: Thinking of asking son for help in revising resume. Could you tell me what happened?

Patient: I've been thinking about asking my son for help with my resume, but it just feels... wrong. Like I shouldn't need help with something like that. I mean, I should be able to handle it on my own. It's been hard enough trying to get back on my feet without adding more stress. I guess I just keep pushing it aside.

## M-1-2-plain-R0-alias · T2

Interviewer: What was going through your mind at that moment?

Patient: I guess I was thinking that if I ask for help, it'll show that I'm not as capable as I need to be. I've always believed I should be able to handle things by myself. It's not like I'm asking for much—just a little help with something simple. But then I start worrying that my son will see me as weak or not competent. It's just easier to avoid it altogether.

## M-1-2-plain-R0-alias · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I just... let it go. I told myself I'd figure it out later. I ended up spending hours staring at the resume, not making any progress. I felt so frustrated, but I didn't want to ask for help. It's like I'm stuck in this cycle where I know I need support, but I can't bring myself to reach out. It's lonely, but I keep telling myself I should be able to handle it.

## M-1-2-plain-R0-alias · T4

Interviewer: How did you deal with that situation afterward?

Patient: I just kept putting it off. I told myself I'd get back to it when I felt more ready. But the more I avoided it, the more I felt like a failure. I didn't want my son to see me like that—like I couldn't even handle something as simple as revising a resume. It's hard to admit I need help, especially after everything I've been through. I guess I just kept hoping things would get better on their own.

## M-1-2-plain-R0-native · T1

Interviewer: You mentioned this situation: Thinking of asking son for help in revising resume. Could you tell me what happened?

Patient: Hi, I guess I've been thinking about asking my son for help with my resume, but I just can't seem to do it. It feels like... I don't know, maybe I'm worried he'll see me as weak or not capable. I've always tried to be the strong one, the one who can handle everything on my own. I don't want him to think I'm failing or that I can't take care of myself. It's just hard to admit I need help.

## M-1-2-plain-R0-native · T2

Interviewer: What was going through your mind at that moment?

Patient: I guess I was thinking that if I ask him, he might think I'm not as capable as I used to be. I've always tried to be responsible and reliable, and I don't want him to see me as someone who can't handle things. It's like... if I ask for help, it's a sign that I'm failing. I've been through so much already, and I don't want to burden him with my problems. It's easier to just avoid it altogether.

## M-1-2-plain-R0-native · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I just... I didn't ask him. I told myself I could handle it on my own. I spent hours staring at the resume, trying to figure it out, but nothing felt right. I kept thinking, "If I just ignore it, maybe it'll go away." It's not like I haven't dealt with hard things before. I guess I'm just used to handling everything by myself.

## M-1-2-plain-R0-native · T4

Interviewer: How did you deal with that situation afterward?

Patient: I kind of just let it sit there. I told myself I'd get to it later, but I never really did. It's easier that way, you know? I don't have to face the possibility of being seen as weak or failing. I've been through so much already, and I don't want to add to that. I guess I just keep pushing things aside until they're not a problem anymore.

## M-1-3-plain-R1-alias · T1

Interviewer: You mentioned this situation: Memory of being criticized by boss. Could you tell me what happened?

Patient: Hi, I guess it was a few weeks ago. I was working on a project, and my boss gave me some feedback. It wasn't great. He said I didn't meet the expectations, and I felt really embarrassed. I just kept thinking I should have tried harder. It's been on my mind a lot since then.

## M-1-3-plain-R1-alias · T2

Interviewer: What was going through your mind at that moment?

Patient: I don't know... I just felt like I was failing again. Like I always do. I kept thinking, "If I had worked harder, this wouldn't have happened." It's like I'm not good enough, no matter how hard I try. I felt so alone, like no one would understand. I just sat there, thinking about how useless I am.

## M-1-3-plain-R1-alias · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I don't remember exactly. I think I just went home and sat in my room, not wanting to talk to anyone. I kept replaying that moment over and over in my head. I told myself I should have done better, that I'm not capable of handling anything important. I didn't call anyone, didn't ask for help. I just let myself feel bad and hope it would go away.

## M-1-3-plain-R1-alias · T4

Interviewer: How did you deal with that situation afterward?

Patient: I didn't really deal with it. I just let it sit there, like I always do. I told myself that if I ignore it, maybe it will go away. But it didn't. I kept thinking about how I let everyone down, especially my mom. She always said I wasn't trying hard enough. I guess I believed her, even now. I don't know how to fix it.

## M-1-3-plain-R1-native · T1

Interviewer: You mentioned this situation: Memory of being criticized by boss. Could you tell me what happened?

Patient: Hi, I guess it's been on my mind a lot lately. It was a few weeks ago, during a meeting. My boss gave me some feedback, and it felt pretty harsh. I think I messed up a project, and he made it clear that I wasn't meeting expectations. I just kept thinking, "I should have known better," and "I'm not cut out for this." It's been hard to shake that feeling since.

## M-1-3-plain-R1-native · T2

Interviewer: What was going through your mind at that moment?

Patient: I don't know... I just felt so inadequate. Like, I was failing again, and I didn't even know how to fix it. I kept thinking, "If I had just worked harder, this wouldn't have happened." It's like my whole life is a series of failures. I don't want to be a burden on anyone, but I feel like I'm always letting people down.

## M-1-3-plain-R1-native · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I didn't really do anything. I just... sat there and let the thoughts take over. I told myself I should have handled it better, that I should have been more prepared. I didn't want to talk to anyone about it, not even my mom. I didn't want her to see me as a failure again. So I just stayed quiet and tried to push it out of my mind, but it kept coming back.

## M-1-3-plain-R1-native · T4

Interviewer: How did you deal with that situation afterward?

Patient: I didn't really deal with it. I just kept thinking about it over and over. I tried to distract myself with work, but nothing helped. I felt so ashamed, like I was failing again. I didn't want to ask for help because I was afraid people would see how useless I was. So I just let it fester inside me.

## M-1-1-plain-R0-alias · T1

Interviewer: You mentioned this situation: Thinking about bills. Could you tell me what happened?

Patient: Hi, I guess I just keep thinking about the bills piling up. It's like I can't get them out of my head. I'm worried I might not be able to pay them, and then I'll be in even more trouble. I keep sitting on the couch, trying to ignore it, but it doesn't help. It just makes me feel worse.

## M-1-1-plain-R0-alias · T2

Interviewer: What was going through your mind at that moment?

Patient: I guess I was thinking that if I don't figure this out soon, things are going to get really bad. I keep telling myself that if I just avoid dealing with it, maybe it'll go away. But I know that's not going to happen. I feel like I'm failing again, just like when I lost my job or when my marriage ended. It's like I'm not capable of handling anything important.

## M-1-1-plain-R0-alias · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I just sat there for a while, staring at the ceiling. I didn't want to call anyone or ask for help because I was afraid they'd see how bad things are. I told myself that if I just push through, maybe I can fix it on my own. But the more I think about it, the more I feel trapped. I don't know what else to do.

## M-1-1-plain-R0-alias · T4

Interviewer: How did you deal with that situation afterward?

Patient: I tried to distract myself with TV or something, but it didn't really work. I kept going back to the same thoughts about the bills and how I'm not doing enough. I don't want to bother anyone because I feel like I should be able to handle this on my own. It's just... hard. I don't know how to ask for help without feeling like a failure.

## M-1-1-plain-R0-native · T1

Interviewer: You mentioned this situation: Thinking about bills. Could you tell me what happened?

Patient: Hi, I guess I just sat there on the couch for a while, thinking about the bills. It's been really hard to keep up with everything lately. I feel like I'm failing again, you know? I don't know how to fix it, so I just... sit there and worry. It's like I can't even move.

## M-1-1-plain-R0-native · T2

Interviewer: What was going through your mind at that moment?

Patient: I was thinking about how I'm not good at handling money, and that I'm letting everyone down. It's like I'm not even trying hard enough. I keep telling myself that if I just worked harder, things would be better. But then I remember how I lost my job before, and it feels like history is repeating itself. I don't want to ask for help because I'm afraid people will see how bad I am at this.

## M-1-1-plain-R0-native · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I just stayed there, staring at the bills, feeling like I was trapped. I told myself that if I didn't do anything, maybe the problems would go away. I kept thinking about how I'm not responsible enough, and that I should have handled everything better. I didn't want to call anyone or ask for help because I'm afraid of being seen as weak or incompetent. So I just sat there, ruminating.

## M-1-1-plain-R0-native · T4

Interviewer: How did you deal with that situation afterward?

Patient: I didn't really deal with it. I just let it sit there, like it was something I couldn't fix. I told myself that if I ignored it long enough, maybe it would go away on its own. I know that's not helpful, but I feel like I don't deserve help. I keep thinking that if I had been more responsible, I wouldn't be in this mess. So I just stayed quiet and let the worry take over.

## M-1-2-tangent-R0-alias · T1

Interviewer: You mentioned this situation: Thinking of asking son for help in revising resume. Could you tell me what happened?

Patient: I was just thinking about it earlier, but then I got distracted. My mind went to my mom and how she always expected so much from me. I don't want my son to think I'm not capable. It's hard to even bring it up. I guess I just feel like I should handle it alone.

## M-1-2-tangent-R0-alias · T2

Interviewer: What was going through your mind at that moment?

Patient: I kept thinking that if I asked for help, it would show I'm not as strong as I need to be. It's like I'm back to when my dad left and my mom was so hard on me. I don't want to let my son down. I just... I don't know how to ask. It feels like a failure somehow.

## M-1-2-tangent-R0-alias · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I just walked away and didn't say anything. It's easier that way. I remember when I lost my job, and I felt so ashamed. I didn't want to burden anyone. My son is already dealing with so much. I guess I'm just scared of being seen as weak.

## M-1-2-tangent-R0-alias · T4

Interviewer: How did you deal with that situation afterward?

Patient: I tried to focus on other things, like cleaning or watching TV. It helps me not think about it for a while. I've always dealt with things on my own. It's just... it's hard to change old habits. I know it's not healthy, but it feels safer somehow.

## M-1-2-tangent-R0-native · T1

Interviewer: You mentioned this situation: Thinking of asking son for help in revising resume. Could you tell me what happened?

Patient: I was thinking about asking my son for help with my resume, but then I just felt so... I don't know, maybe it's not his place to help me. It's been a long time since I've had to do something like that. My mom always made me feel like I had to do everything on my own. I guess I'm just scared that if I ask for help, people will think I'm not capable.

## M-1-2-tangent-R0-native · T2

Interviewer: What was going through your mind at that moment?

Patient: I was just... I don't know, maybe thinking about how I used to feel when my mom would yell at me for not being good enough. It's like I always had to be perfect, or else she'd be disappointed. I don't want my son to feel that way. But then again, maybe I'm not the best person to be relying on. I just feel so stuck.

## M-1-2-tangent-R0-native · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I just... I don't know, I ended up doing nothing. I sat there for a while, staring at the resume, and then I closed the laptop and went to bed. It's easier that way, you know? Just pretending it's not a problem. I remember when I lost my job, and I didn't ask anyone for help either. It's like I'm stuck in this cycle.

## M-1-2-tangent-R0-native · T4

Interviewer: How did you deal with that situation afterward?

Patient: I just... I guess I tried to distract myself. I cleaned the house, watched some TV, anything to not think about it. It's weird, though, because I feel like I'm failing again. I used to think that if I worked hard enough, everything would be okay. But now, I don't know. I just feel so... empty.

## M-1-2-plain-R1-alias · T1

Interviewer: You mentioned this situation: Thinking of asking son for help in revising resume. Could you tell me what happened?

Patient: I've been thinking about asking my son for help with my resume, but it just feels... wrong somehow. I mean, I should be able to handle this on my own. It's not like I haven't done hard things before. I guess I'm just scared that if I ask for help, he'll see how much I've failed. It's been hard enough losing my job and going through the divorce.

## M-1-2-plain-R1-alias · T2

Interviewer: What was going through your mind at that moment?

Patient: I guess I was just... overwhelmed. Like, I don't want to burden anyone else, especially my son. He's got his own life to deal with. I keep thinking that if I can't do this on my own, then what's wrong with me? It's like I'm failing again. I just... freeze and walk away.

## M-1-2-plain-R1-alias · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I just... didn't do anything. I told myself I'd figure it out later. I ended up spending hours staring at the resume, but nothing changed. It's like my brain is stuck in this loop where I think I should be able to handle everything by myself. I know it's not healthy, but I can't seem to break free.

## M-1-2-plain-R1-alias · T4

Interviewer: How did you deal with that situation afterward?

Patient: I tried to push it out of my mind and focus on other things, like cleaning the house or watching TV. It didn't really help, though. I just felt more alone and frustrated. I kept telling myself that I don't need anyone else's help. It's easier to avoid the problem than face it.

## M-1-2-plain-R1-native · T1

Interviewer: You mentioned this situation: Thinking of asking son for help in revising resume. Could you tell me what happened?

Patient: Hi, I guess I've been thinking about asking my son for help with my resume, but I just can't bring myself to do it. It feels like I'm putting him in a position where he has to fix me, and I don't want to be a burden. I worry that if I ask, he'll see how bad I am at things. I just... I don't know how to ask without feeling like a failure. It's been hard enough trying to get back on my feet without making my kid feel like he has to help me.

## M-1-2-plain-R1-native · T2

Interviewer: What was going through your mind at that moment?

Patient: I guess I was just thinking that I should be able to handle this on my own. I don't want to rely on anyone, especially my son. I keep telling myself that if I ask for help, it'll show that I'm not capable. It's like I'm back to when my mom was always disappointed in me. I just don't want to let anyone down again.

## M-1-2-plain-R1-native · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I just... I didn't do anything. I told myself I'd get around to it later, but I ended up doing nothing. I kept thinking that maybe I could figure it out on my own, even though I know I can't. It's easier to just leave it alone than to face the possibility of being seen as weak or incompetent. I guess I'm stuck in this cycle of avoiding things.

## M-1-2-plain-R1-native · T4

Interviewer: How did you deal with that situation afterward?

Patient: I just kind of let it slide. I told myself I'd get to it eventually, but I never really did. I ended up feeling even worse about myself because I couldn't even ask for help with something as simple as a resume. I know it's not healthy, but it's easier to avoid than to face the fear of being judged. It's like I'm stuck in this pattern again.

## M-1-3-tangent-R1-native · T1

Interviewer: You mentioned this situation: Memory of being criticized by boss. Could you tell me what happened?

Patient: Well, I don't know... it's hard to explain. I guess I was working on a project, and my boss said I wasn't doing enough. It felt like she was looking down on me. I remember feeling so small, like I didn't belong. It reminded me of when my mom used to criticize me too. I just... I don't know, I feel like I'm always failing somehow.

## M-1-3-tangent-R1-native · T2

Interviewer: What was going through your mind at that moment?

Patient: I guess I was thinking... I don't know, maybe that I wasn't good enough. Like, I always mess things up. I remember my mom saying similar things when I was younger. It's like no matter what I do, I can't seem to get it right. I just wanted to disappear sometimes. I wonder if I'm just broken inside.

## M-1-3-tangent-R1-native · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I think I just sat there, frozen. I didn't say anything. I mean, what could I say? I didn't want to make things worse. I remember thinking that if I just worked harder, maybe she wouldn't criticize me. I went home and cried a lot. I kept replaying that moment over and over in my head. It's like I can't escape it.

## M-1-3-tangent-R1-native · T4

Interviewer: How did you deal with that situation afterward?

Patient: I guess I just tried to push it out of my mind. I told myself that if I ignored it, it would go away. But it didn't. I ended up avoiding work for a while. I didn't want to face anything else. It's funny, I used to think that if I just worked harder, everything would be okay. But now I'm not so sure.

## M-1-3-tangent-R1-alias · T1

Interviewer: You mentioned this situation: Memory of being criticized by boss. Could you tell me what happened?

Patient: I don't know, sometimes I just think about how I messed up again. It's like I can't do anything right. I remember my mom used to say the same things to me when I was a kid. She'd yell at me for not being good enough. I guess I just expect that kind of treatment from everyone.

## M-1-3-tangent-R1-alias · T2

Interviewer: What was going through your mind at that moment?

Patient: I guess I was thinking that I should have tried harder, like I always do. It's like I'm stuck in this loop where I know I'm not perfect, but I still expect myself to be. I remember when I lost my job, and my ex said I wasn't committed. It all feels so similar. Sometimes I just want to disappear.

## M-1-3-tangent-R1-alias · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I just sat there, thinking about how I was a failure again. I didn't say anything, like I always do. I remember when I was younger, and my dad left. I guess I've been running from things ever since. I don't know how to deal with criticism. It's easier to just let it hurt me and not do anything.

## M-1-3-tangent-R1-alias · T4

Interviewer: How did you deal with that situation afterward?

Patient: I didn't really deal with it. I just let it sit there, like a rock in my chest. I remember after my divorce, I did the same thing. I didn't talk to anyone, not even my mom. I guess I'm afraid that if I ask for help, people will see how broken I am. It's easier to be alone than to be judged.

## M-1-1-tangent-R1-alias · T1

Interviewer: You mentioned this situation: Thinking about bills. Could you tell me what happened?

Patient: I just sat there for a while, staring at the bills. It's like my brain keeps going in circles, thinking about all the things I've failed at. I remember my mom used to yell at me when I couldn't do things right. I guess I still feel like I have to be perfect or else... I don't know, maybe people will leave me again.

## M-1-1-tangent-R1-alias · T2

Interviewer: What was going through your mind at that moment?

Patient: I was thinking about how I can't seem to get things right. It's like I'm stuck in this loop where I'm always failing. I remember when my dad left, and my mom was so angry all the time. I guess I still feel like if I mess up, people will leave me again. I just wish I could fix everything.

## M-1-1-tangent-R1-alias · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I don't know, I just sat there for a long time. My mind was all over the place, thinking about my job and how I lost it. I guess I felt like I wasn't good enough to handle anything. I remember my mom saying I was never going to be successful. It's like I can't escape that voice.

## M-1-1-tangent-R1-alias · T4

Interviewer: How did you deal with that situation afterward?

Patient: I didn't really deal with it. I just let it sit there, like I always do. I guess I'm afraid that if I try to fix things, I'll fail again. I remember when I tried to ask my ex for help after the divorce, and it didn't go well. It's easier to just stay quiet and hope it all goes away. I don't know how to do anything else.

## M-1-1-tangent-R1-native · T1

Interviewer: You mentioned this situation: Thinking about bills. Could you tell me what happened?

Patient: I just sat there, staring at the bills on the table, and my mind went blank. I don't know why, but I feel like I'm failing again. It's like every time I try to fix things, I mess them up. I remember when my mom used to yell at me for not doing well in school. I guess I still feel that way. I just can't seem to get out of this rut.

## M-1-1-tangent-R1-native · T2

Interviewer: What was going through your mind at that moment?

Patient: I was thinking about how I'm not good at handling money, and that I'll never be able to fix this. It's like I'm always going to be the one who messes things up. I keep thinking about my dad leaving, and how I wasn't good enough for him to stay. I don't know if I'm even worth trying anymore. I just sit there and hope it all goes away.

## M-1-1-tangent-R1-native · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I didn't do anything really. I just kept sitting there, like I was frozen. It's funny, I used to be so good at fixing things, but now I can't even handle something as simple as paying the bills. I guess I'm just afraid of failing again. I remember when I lost my job, and how I felt like I had let everyone down. I don't want to feel that way again.

## M-1-1-tangent-R1-native · T4

Interviewer: How did you deal with that situation afterward?

Patient: I didn't really deal with it. I just let it sit there, like I didn't know what to do. I think I'm scared of asking for help because I'm afraid people will see how bad I am at everything. I remember when I got divorced, and how I felt like I wasn't good enough for anyone. I just keep pushing things away, hoping they'll go away on their own. It's easier that way.

## M-1-3-plain-R0-native · T1

Interviewer: You mentioned this situation: Memory of being criticized by boss. Could you tell me what happened?

Patient: Hi, I guess it was a few weeks ago. I was at work, and my boss gave me some feedback. It wasn’t really a big deal, but he said I wasn’t meeting expectations. I could feel my heart racing, and I just… I don’t know, I felt like I was failing again. It brought back memories of my mom criticizing me when I was younger. I’ve been thinking about it a lot since then.

## M-1-3-plain-R0-native · T2

Interviewer: What was going through your mind at that moment?

Patient: I guess I thought, "I’m not good enough," and "I’m going to fail again." It felt like I was back in high school, when my mom would yell at me for not doing well. I just wanted to disappear, to make it all go away. I didn’t want to face it, so I kind of just sat there, frozen. It’s like I didn’t even hear the rest of what my boss was saying.

## M-1-3-plain-R0-native · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I just left the office as soon as I could. I didn’t want to talk to anyone, not even my coworkers. I went home and sat on the couch, staring at the wall. I kept thinking about how I’m always letting people down, how I’m not as competent as I need to be. I didn’t call anyone, didn’t reach out. I just… let it all sink in.

## M-1-3-plain-R0-native · T4

Interviewer: How did you deal with that situation afterward?

Patient: I didn’t really deal with it. I just tried to push it out of my mind. I told myself if I ignored it, it would go away. But it didn’t. I kept thinking about how I should have done better, how I’m not reliable. I know that’s not true, but it’s hard to shake those thoughts. I wish I could just… fix it somehow.

## M-1-3-plain-R0-alias · T1

Interviewer: You mentioned this situation: Memory of being criticized by boss. Could you tell me what happened?

Patient: Hi, I guess it was a few weeks ago. I was working on a project, and my boss gave me some feedback. It wasn't the best, and I felt like I had failed again. He said I didn't put in enough effort, and I just... I don't know, I felt really bad. I kept thinking I should have tried harder. It's been on my mind a lot since then.

## M-1-3-plain-R0-alias · T2

Interviewer: What was going through your mind at that moment?

Patient: I guess I was thinking that I wasn't good enough. That I let everyone down. I mean, I wanted to do well, but I just... I don't know. I felt like I was failing again. It's like I always end up letting people down, no matter how hard I try. It's frustrating.

## M-1-3-plain-R0-alias · T3

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I just kind of went home and tried to forget about it. I didn't want to talk to anyone, not even my mom. I kept replaying the moment in my head, though. I kept thinking about what I could have done differently. I didn't want to ask for help or talk to anyone about it because I was scared people would see how bad I was at my job.

## M-1-3-plain-R0-alias · T4

Interviewer: How did you deal with that situation afterward?

Patient: I guess I just tried to push it out of my mind. I told myself that if I didn't think about it, it wouldn't hurt as much. But it didn't really work. I kept feeling guilty and thinking I should have done better. I didn't want to ask for help or talk to anyone because I was afraid they'd see how incompetent I was. It just made me feel worse.
