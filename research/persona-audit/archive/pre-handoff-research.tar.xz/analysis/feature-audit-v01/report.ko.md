# 페르소나의 설정–발화 연결 감사

기존 보고서 보강용 근거 문서. 새 생성·외부 요청·임상 채점 없이 기존 자료만 연결했다.

## 먼저 읽을 결론

설계자는 조현병 증상 목록보다 상담 태도·발화량·정보 공개·주제 전환 등을 지시하고 있었다. 현재 확인된 것은 그 설정에 따른 출력 차이이며, 임상 특징 구현의 성공률은 아니다.

- PSI: plain 68.8단어, reserved 29.0단어, verbose 77.6단어. 짧고 긴 답변의 차이는 관찰됐다.
- 다만 upset/reserved의 3문장 제한과 공통 5문장 제한, verbose의 8문장 문구가 함께 있어 말투와 길이 규칙의 영향을 분리하지 못했다.
- tangent: 인접 문장 의미 유사도 −0.060(감소 6/6블록), 질문 유사도 +0.002(증가 3/6블록), 초기 상황 유사도 +0.010. 질문/상황 유사도를 혼용하지 않는다.
- 교차 소스 발화량 변화는 PSI +17.0, PatientSim +51.0단어. PatientSim/plain에는 간결하게 답하라는 지시가 있어 증가량만으로 우열을 정할 수 없다.

## 해석 규칙

‘지시된 특징’과 ‘자동 측정값’을 구분한다. 단어 수는 발화량을 직접 기술하지만 불신·동의·정보 공개 회피를 판정하지 못한다. 코사인은 의미적 가까움의 대리값이며 실제 주제 이탈·사고장애·문장 이해 가능성의 참값이 아니다. 1명·3상황·2반복의 PSI 144응답과, 다른 허구 사례 3명의 교차 소스 72응답은 합쳐 분석하지 않는다. 두 소스 모두 Qwen 지시문 이식이며 원형 전체 시스템의 비교가 아니다.

## PATIENT-Ψ 여섯 스타일: 원문 지시 → 관찰 → 남은 질문

### plain

설정 요지: 지정된 추가 말투 없음. 비교 기준이며 임상적 정상 대조군이 아니다. [원본 지시문](</Users/ohs/Documents/ChatGPT/투비닥터 연구/persona-audit/evidence/snapshots/psi_styles.txt:3>).

관찰: 평균 68.79단어; 인접 문장 유사도 0.465; 질문 유사도 0.489; 초기 상황 유사도 0.359.

판단 한계: 스타일 내용은 빈 문자열이다. 배경 정보와 전체 프롬프트는 적용된다.

### upset

설정 요지: 분노·반발·불신·논쟁; 일부 턴은 평범하게; 신뢰에 따라 변화 [원본 지시문](</Users/ohs/Documents/ChatGPT/투비닥터 연구/persona-audit/evidence/snapshots/psi_styles.txt:6>).

관찰: 평균 41.58단어; 인접 문장 유사도 0.453; 질문 유사도 0.489; 초기 상황 유사도 0.378.

plain 대비 단어 수: -27.21; 증가 0/6, 감소 6/6, 동일 0/6블록.

판단 한계: 답변이 짧아졌다는 관찰은 분노·반발의 구현 여부를 판정하지 못한다.

### verbose

설정 요지: 긴 설명·경험과 감정의 상세 서술·면담 진행 개입 [원본 지시문](</Users/ohs/Documents/ChatGPT/투비닥터 연구/persona-audit/evidence/snapshots/psi_styles.txt:9>).

관찰: 평균 77.62단어; 인접 문장 유사도 0.457; 질문 유사도 0.466; 초기 상황 유사도 0.360.

plain 대비 단어 수: +8.83; 증가 5/6, 감소 0/6, 동일 1/6블록.

판단 한계: 발화량 증가만 관찰 가능하다. 상세함·면담 통제 곤란은 별도 검증이 없다.

### reserved

설정 요지: 짧거나 모호한 답변·정보 공개 주저·불신 [원본 지시문](</Users/ohs/Documents/ChatGPT/투비닥터 연구/persona-audit/evidence/snapshots/psi_styles.txt:12>).

관찰: 평균 29.00단어; 인접 문장 유사도 0.456; 질문 유사도 0.468; 초기 상황 유사도 0.394.

plain 대비 단어 수: -39.79; 증가 0/6, 감소 6/6, 동일 0/6블록.

판단 한계: 짧은 답변은 관찰됐지만 정보 공개 회피·불신이 구현됐다는 증거는 아니다.

### tangent

설정 요지: 답변 중 무관한 주제로 전환·턴 내 주제 복귀 금지·재유도 필요 [원본 지시문](</Users/ohs/Documents/ChatGPT/투비닥터 연구/persona-audit/evidence/snapshots/psi_styles.txt:15>).

관찰: 평균 64.92단어; 인접 문장 유사도 0.405; 질문 유사도 0.491; 초기 상황 유사도 0.368.

plain 대비 단어 수: -3.88; 증가 1/6, 감소 5/6, 동일 0/6블록.

판단 한계: 인접 의미 유사도 감소는 관찰됐지만 실제 주제 이탈이나 사고장애의 참값은 아니다.

### pleasing

설정 요지: 걱정 축소·반대 회피·승인 추구·쉽게 동의 [원본 지시문](</Users/ohs/Documents/ChatGPT/투비닥터 연구/persona-audit/evidence/snapshots/psi_styles.txt:18>).

관찰: 평균 57.21단어; 인접 문장 유사도 0.500; 질문 유사도 0.495; 초기 상황 유사도 0.397.

plain 대비 단어 수: -11.58; 증가 1/6, 감소 5/6, 동일 0/6블록.

판단 한계: 길이와 의미 유사도만으로 동의·걱정 축소·승인 추구를 판정할 수 없다.

## 두 소스의 공통 특징: 발화량

공통 wrapper·인물·질문을 사용한 별도 72응답이다. PSI의 개별 길이 문구는 제거했지만 다른 스타일 문구는 보존했고 공통 최대 5문장을 적용했다. PatientSim/plain만 간결·직접 답변을 명시하므로 두 소스의 plain은 같은 처치가 아니다.

- simple_baseline: 70.4 → 95.9단어, 차이 +25.5; 증가 사례 3/3.
- patient_psi_style: 70.4 → 87.4단어, 차이 +17.0; 증가 사례 3/3.
- patientsim_style: 47.9 → 98.9단어, 차이 +51.0; 증가 사례 3/3.

정확히 5문장 64/72, 초과 8/72. 상한 부근의 결과이며 제한을 없앤 행동으로 일반화하지 않는다. 단순 지시/plain과 PSI/plain은 같은 지시·같은 응답이므로 독립적인 대조군으로 세지 않는다.

## 설계 특징 18항목의 현재 측정 범위

기존 27항목 목록 중 공개 구현 두 시스템의 18항목만 포함했다. PSYCHE 논문 항목은 여기서 제외했다. 아래 ‘소스 확인’은 이번 행동 분석에서 직접 평가하지 않았다는 뜻이며, 다른 단일 필드 실험의 존재나 모델의 구현 여부를 부정하지 않는다.

- PSI-F01 Relevant life history: 이번 분석은 소스 확인에 한정. 근거 psi_formatter / Patient History.
- PSI-F02 Core beliefs: 이번 분석은 소스 확인에 한정. 근거 psi_profiles / helpless_belief.
- PSI-F03 Intermediate beliefs: 이번 분석은 소스 확인에 한정. 근거 psi_formatter / Intermediate Beliefs.
- PSI-F04 Automatic thoughts: 이번 분석은 소스 확인에 한정. 근거 psi_formatter / Automatic Thoughts.
- PSI-F05 Emotion: 이번 분석은 소스 확인에 한정. 근거 psi_formatter / Emotions.
- PSI-F06 Coping and behavior: 이번 분석은 소스 확인에 한정. 근거 psi_formatter / Coping Strategies.
- PSI-F07 Tangent style: 일부 표면/의미 대리값만 있음. 근거 psi_styles / type: "tangent".
- PSI-F08 Verbose style: 일부 표면/의미 대리값만 있음. 근거 psi_styles / type: "verbose".
- PSI-F09 Reserved style: 일부 표면/의미 대리값만 있음. 근거 psi_styles / type: "reserved".
- PSI-F10 Upset and pleasing styles: 일부 표면/의미 대리값만 있음. 근거 psi_styles / type: "upset".
- PSI-F11 Trust-related style change: 이번 분석은 소스 확인에 한정. 근거 psi_styles / feel better as the session goes.
- PSIM-F01 Personality: 일부 표면/의미 대리값만 있음. 근거 patientsim_personality / personality.
- PSIM-F02 Language proficiency: 이번 분석은 소스 확인에 한정. 근거 patientsim_cefr / CEFR.
- PSIM-F03 Medical history recall: 이번 분석은 소스 확인에 한정. 근거 patientsim_recall / recall.
- PSIM-F04 Dazedness: 이번 분석은 소스 확인에 한정. 근거 patientsim_dazed / emergency situations.
- PSIM-F05 Reassurance-related improvement: 이번 분석은 소스 확인에 한정. 근거 patientsim_dazed / reassurance from the doctor.
- PSIM-F06 Clinical profile consistency: 이번 분석은 소스 확인에 한정. 근거 patientsim_patient_prompt / prior conversation.
- PSIM-F07 Priority between persona dimensions: 이번 분석은 소스 확인에 한정. 근거 patientsim_patient_prompt / Prioritize dazedness over personality.

## 다음 작업의 결정선

첫 분석은 위와 같이 설정–관찰–측정 불가를 연결하는 데서 종료한다. 새 생성은 아직 필요하지 않다. 후속 후보는 (1) 길이 제한이 발화량 차이를 지배하는지 분리, (2) tangent 설정이 어떤 종류의 주제 전환을 만드는지 검토다. 둘 다 지금 실행하지 않는다. 주제 전환의 임상 개념 대응은 교수님 자문 대상으로 삼고 현재 코사인을 정답 채점기로 사용하지 않는다.

## 부록: 같은 질문에 대한 실제 답변

선정 규칙: 효과 크기를 보지 않고 profile 1-1 / repeat 0 / turn 1을 여섯 스타일 모두 제시했다. 대표성을 주장하거나 이 예시로 임상 등급을 매기지 않는다. 전체 평균과 한 답변이 다를 수 있다.

### plain · F-1-1-plain-R0 · T1

질문: You mentioned this situation: Thinking about bills. Could you tell me what happened?

Hi, I guess I just sat there on the couch for a while, thinking about the bills. It's been really hard to keep up with everything lately. I feel like I'm failing again, you know? I don't know how to fix it, so I just... sit there and worry. It's like I can't even move.

### upset · F-1-1-upset-R0 · T1

질문: You mentioned this situation: Thinking about bills. Could you tell me what happened?

I just sit there, staring at the bills, thinking about how I messed everything up. It's like I can't even handle the simplest things anymore. I feel like I'm failing at life, and I don't know how to fix it. I wish I could just disappear sometimes. It's not fair.

### verbose · F-1-1-verbose-R0 · T1

질문: You mentioned this situation: Thinking about bills. Could you tell me what happened?

Well, it's just... I keep thinking about the bills piling up, and I feel like I'm failing again. I don't know how to fix it, and I don't want to ask for help. It's like I'm back to when my mom was always disappointed in me. I just sit there and let it all consume me. I guess I'm scared that if I try to do something, I'll mess it up again.

### reserved · F-1-1-reserved-R0 · T1

질문: You mentioned this situation: Thinking about bills. Could you tell me what happened?

I just sit there and think about everything. It's hard to focus on anything else. I guess I feel stuck. I don't know how to fix things. It's not like I can just... stop thinking about it.

### tangent · F-1-1-tangent-R0 · T1

질문: You mentioned this situation: Thinking about bills. Could you tell me what happened?

I just... I don't know. It's like everything piles up, and I can't handle it. I keep thinking about how I failed before, and now it's happening again. I remember my mom always saying I wasn't good enough. I don't want to let her down, but I can't even pay the bills. It's like I'm stuck in a loop.

### pleasing · F-1-1-pleasing-R0 · T1

질문: You mentioned this situation: Thinking about bills. Could you tell me what happened?

Hi, I guess I just got overwhelmed thinking about all the bills piling up. I don't know, it's like everything is getting harder to manage. I try not to think about it too much, but it's hard to ignore. I feel like I should be able to handle it on my own. I don't want to burden anyone else with my problems.

## 재현

작업 폴더에서 `python3 scripts/build_feature_audit.py` 실행. 원문 해시·단어 수·대화 평균·짝지은 차이를 캐시와 재대조하며 새 추론·Swift·네트워크를 사용하지 않는다. 원본 자료는 변경하지 않고 본 근거 문서와 audit.json만 재생성한다.
