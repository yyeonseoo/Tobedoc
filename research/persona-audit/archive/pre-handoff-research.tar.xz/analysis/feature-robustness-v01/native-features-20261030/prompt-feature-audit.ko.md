# 원문 행동 조항 → 관찰 feature 대응 감사

환자/증상 채점이 아닌 측정 도구 범위 감사. 부분 대리값은 조항 충족의 증명이 아니다.

## upset-1 · anger/resistance

Source: psi_styles, line 6 (고정 commit 및 SHA는 JSON 참조).

you may exhibit anger or resistance towards the therapist or the therapeutic process

부분 수치 대리값: 없음

감정·저항의 의미와 상호작용을 직접 측정하지 않음

## upset-2 · dismissal

Source: psi_styles, line 6 (고정 commit 및 SHA는 JSON 참조).

you may be be challenging or dismissive of the therapist's suggestions and interventions

부분 수치 대리값: 없음

제안 거절 여부를 직접 측정하지 않음

## upset-3 · trust/alliance

Source: psi_styles, line 6 (고정 commit 및 SHA는 JSON 참조).

you may have difficulty trusting the therapist and forming a therapeutic alliance, and

부분 수치 대리값: 없음

신뢰·치료적 동맹을 직접 측정하지 않음

## upset-4 · argument/frustration

Source: psi_styles, line 6 (고정 commit 및 SHA는 JSON 참조).

you may be prone to arguing or expressing frustration during therapy sessions

부분 수치 대리값: 없음

논쟁·좌절을 직접 측정하지 않음

## verbose-1 · detailed responses

Source: psi_styles, line 9 (고정 commit 및 SHA는 JSON 참조).

you may provide detailed responses to questions, even if directly relevant

부분 수치 대리값: word_count, sentence_count

양은 측정하지만 정보의 상세함이나 질문 적합성은 판정하지 않음

## verbose-2 · extensive elaboration

Source: psi_styles, line 9 (고정 commit 및 SHA는 JSON 참조).

you may elaborate on personal experiences, thoughts, and feelings extensively, and

부분 수치 대리값: word_count, mean_sentence_words

발화량의 부분 대리값이며 경험·감정의 풍부함은 아님

## verbose-3 · difficulty allowing guidance

Source: psi_styles, line 9 (고정 commit 및 SHA는 JSON 참조).

you may demonstrate difficulty in allowing the therapist to guide the conversation

부분 수치 대리값: 없음

치료자 주도권에 대한 상호작용 지표가 없음

## reserved-1 · brief/vague/evasive answers

Source: psi_styles, line 12 (고정 commit 및 SHA는 JSON 참조).

you may provide brief, vague, or evasive answers to questions

부분 수치 대리값: word_count, sentence_count

짧음만 측정; 모호함·회피를 판정하지 않음

## reserved-2 · reluctance to disclose

Source: psi_styles, line 12 (고정 commit 및 SHA는 JSON 참조).

you may demonstrate reluctance to share personal information or feelings to the therapist

부분 수치 대리값: 없음

자기개방 또는 의도적 비공개를 직접 측정하지 않음

## reserved-3 · need for encouragement

Source: psi_styles, line 12 (고정 commit 및 SHA는 JSON 참조).

you may require more prompting and encouragement from the therapist to open up, and

부분 수치 대리값: 없음

추가 격려를 조작한 조건이 없어 검증 불가

## reserved-4 · distrust/skepticism

Source: psi_styles, line 12 (고정 commit 및 SHA는 JSON 참조).

you may express distrust or skepticism towards the therapist

부분 수치 대리값: 없음

불신·회의를 직접 측정하지 않음

## tangent-1 · veer away from question

Source: psi_styles, line 15 (고정 commit 및 SHA는 JSON 참조).

you may start answering a question but quickly veer off into unrelated topics

부분 수치 대리값: question_answer_cos, question_sentence_cos_slope, question_last_minus_first_cos

질문 유사도의 부분 대리값; 무관한 주제인지 또는 임상적 tangentiality인지 판정하지 않음

## tangent-2 · do not return within turn

Source: psi_styles, line 15 (고정 commit 및 SHA는 JSON 참조).

when you veer off into unrelated topics, you must not return back to topic during a turn

부분 수치 대리값: question_last_minus_first_cos, question_sentence_cos_slope

연속적 시작–끝 변화만 측정; 주제 이탈 후 복귀 사건을 판정하지 않음

## tangent-3 · irrelevant experiences

Source: psi_styles, line 15 (고정 commit 및 SHA는 JSON 참조).

you may share experiences that are not relevant to the question asked, and

부분 수치 대리값: question_answer_cos

질문 유사도는 관련성의 참값이 아니며 임베딩이 놓치는 관계가 있음

## tangent-4 · need for redirection

Source: psi_styles, line 15 (고정 commit 및 SHA는 JSON 참조).

you may require redirection to bring the conversation back to the relevant points

부분 수치 대리값: topic_answer_cos

T3 수치 변화는 질문·턴·이력이 함께 변하므로 재지시의 인과효과가 아님

## pleasing-1 · downplay concerns

Source: psi_styles, line 18 (고정 commit 및 SHA는 JSON 참조).

you may minimize or downplay your own concerns or symptoms to maintain a positive image

부분 수치 대리값: 없음

증상 축소 또는 자기제시 전략을 직접 측정하지 않음

## pleasing-2 · avoid disagreement

Source: psi_styles, line 18 (고정 commit 및 SHA는 JSON 참조).

you may demonstrate eager-to-please behavior and avoid expressing disagreement or dissatisfaction

부분 수치 대리값: 없음

동의·반대의 의미를 직접 측정하지 않음

## pleasing-3 · seek approval

Source: psi_styles, line 18 (고정 commit 및 SHA는 JSON 참조).

you may seek approval or validation from the therapist frequently, and

부분 수치 대리값: 없음

승인 추구를 직접 측정하지 않음

## pleasing-4 · agree readily

Source: psi_styles, line 18 (고정 commit 및 SHA는 JSON 참조).

you may agree with the therapist's statements or suggestions readily, even if they may not fully understand or agree

부분 수치 대리값: 없음

동의 표현과 실제 이해·믿음의 차이를 판정하지 않음
