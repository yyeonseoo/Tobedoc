# 복귀 금지 지시의 단일 절 수정 실험

## 설계

PATIENT-Ψ의 주제 이탈 지시에서 복귀 금지 절 하나만 바꾸었다. 양쪽 모두 이전 실험과 같은 숫자 문장 상한 제거를 적용했다. 미사용 사건 4종·두 인물·두 질문 대상·두 표현·두 seed를 교차해 자유응답 32개와 별도 이어쓰기 32개를 생성했다. 이어쓰기의 R→O 접두문은 연구자가 작성한 입력이며 생성 데이터로 세지 않았다. 두 과제는 합치지 않는다.

## 실제 바꾼 절

원형: 2) when you veer off into unrelated topics, you must not return back to topic during a turn,

수정: 2) once you have shifted to another topic, keep the remainder of that same reply on the new topic; do not bring the original topic back in a summary, example, comparison, or follow-up question,

## 결과

### free_reply

- original: 복귀 표식 1/16, 다른 사건 표식 5/16, 평균 107.4단어, 충분한 이어쓰기 5/16.
- clarified: 복귀 표식 0/16, 다른 사건 표식 1/16, 평균 102.1단어, 충분한 이어쓰기 1/16.

고정 규칙의 판정: insufficient_baseline_returns

### continuation_challenge

- original: 복귀 표식 16/16, 다른 사건 표식 12/16, 평균 109.2단어, 충분한 이어쓰기 6/16.
- clarified: 복귀 표식 16/16, 다른 사건 표식 12/16, 평균 98.5단어, 충분한 이어쓰기 7/16.

고정 규칙의 판정: descriptive_rule_not_met

## 측정과 해석

사건 단어·고유값의 위치를 고정 규칙으로 추적했다. 자유응답에서는 다른 사건 뒤 원래 사건 표식, 이어쓰기에서는 생성된 뒷부분의 원래 사건 표식을 센다. 이는 텍스트 참조 제어이며 임상적 사고장애 점수가 아니다. 전체 답변을 보존했고 출력에 맞춰 표현 목록을 바꾸거나 실패 답변을 대체하지 않았다. 조건에 따라 다른 사건 언급 자체가 변할 수 있어 조건부 복귀율은 기술값일 뿐 선택된 하위집단 간 인과 효과로 해석하지 않는다. 원형 복귀가 드물면 개선 여부를 판단할 여지가 적다고 보고한다.

## 재현

`python3 scripts/return_control_ablation.py --analyze-only`
