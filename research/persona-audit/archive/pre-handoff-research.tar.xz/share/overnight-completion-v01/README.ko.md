# 실행 완료 인계

2026년 10월 31일 기준, 요청한 두 단계와 통합 보고를 완료했다. 새 로컬 응답 72개(발견 40 + 미사용 사례 후속 32)를 생성했고 모두 정상 종료했다. 유료 API·자동 LLM judge·설치·다운로드·원격 Mac 작업은 없었다. 실행 중에만 적용한 `caffeinate -i`도 생성 프로세스와 함께 종료됐다. 구독 대화의 추론까지 로컬이거나 무료 토큰이라고 주장하지 않는다.

## 결과를 읽는 순서

1. 같은 폴더의 **페르소나 특징 비교와 수치 보존 후속 실험 보고서.docx** — 기존 세 특징과 새 pleasing 비교를 3쪽으로 통합했다.
2. `analysis/pleasing-discovery-v01/transcripts.md`, `analysis/pleasing-factlock-v01/transcripts.md` — 이번 72개 원문 전체다.
3. 각 실험 폴더의 `results.json`, `response-metrics.json` — 생성 전에 고정한 원래 규칙의 결과다. 사후 수정하지 않았다.
4. `numeric-expression-audit.json`, `numeric-expression-details.json`, `assistant-source-review.json` — 범위·시간 환산·문맥을 점검한 **별도 사후 보조 분석**이다. 전문가 임상 평가나 독립 검증이 아니다.
5. `analysis/integrated-checkpoint-v05/results.json` — 네 특징의 결과와 후속 선택을 연결한 기계 판독 자료다. 이전의 80·40·48응답과 이번 72응답은 서로 다른 과제의 **응답 기록 240개**이며, 같은 문자열의 반복과 같은 인물의 seed 반복을 포함한다. 독립 환자 수나 고유 문장 수가 아니다.

## 결론

같은 pleasing이라는 이름이어도 PSI의 승인 추구·모호한 보고와 PatientSim의 명시적 underreporting은 다르다. 수치 보존 한 문장을 넣은 후 단일 중심값 일치는 보조 분석에서 PSI 12→18/24개, PatientSim 7→13/24개였다. 하지만 세 항목을 모두 유지한 답변은 각각 3/8·1/8뿐이었다. 사전의 좁은 규칙상 PSI가 기술적 기준을 통과한 사실과, 실제 수치 표현의 보존이 여전히 불완전하다는 판단을 구분했다. **두 소스 모두 안정적인 기본 수치 보존 모드로 채택하지 않는다.** PSI는 탐색용 후보로만 보존했다.

원래 수치 규칙은 `almost every day`를 7일로 세거나 `an hour and a quarter`를 60분으로 읽는 등 실제 출력에서 문제가 있었다. 원점수를 보존하고 별도의 보조 분석을 만들었다. 원문 72개와 추출된 값을 어시스턴트가 읽어 대조했지만 독립 사람·전문가 평가를 만들었다고 보고하지 않았다. 근사 시간의 중심값 차이를 모두 의도적 축소로 간주하지 않는다. low energy의 정도와 energy level은 척도 방향이 달라질 수 있어 숫자 일치와 임상 의미 일치도 구분한다.

## 오프라인 재현

프로젝트 `persona-audit` 폴더에서 아래 순서로 실행한다. 전부 저장된 원문만 사용하므로 **새 생성 없이** 재현할 수 있다.

```bash
python3 scripts/pleasing_study.py analyze-discovery
python3 scripts/pleasing_study.py analyze-followup
python3 scripts/pleasing_reported_values_audit.py
python3 scripts/finalize_pleasing_review.py
python3 scripts/integrate_persona_checkpoint.py
python3 scripts/verify_pleasing_study.py --report
```

단순 코드 검사는 `python3 -m unittest discover -s tests -q`다. 실행 환경은 기존 bundled Python 3.12이다. 패키지를 새로 설치할 필요가 없다. `run-all`은 생성용 명령이므로 재검산 때는 실행할 필요가 없다. 모델 digest, 옵션, 조건, 두 단계의 생성 전 계획과 발동 결정은 `pilot/runs/pleasing-discovery-v01`, `pilot/runs/pleasing-factlock-v01`에 보존한다.

## 여기서 자동 확장하지 않고 끝낸 이유

핵심 네 특징의 첫 감사와 단일 제약의 미사용 사례 비교까지 마쳤다. 추가 seed를 늘리거나 다른 모델을 내려받아 결론을 만들지 않았다. 다음에는 팀과 교수님이 관찰 feature의 임상 대응 범위와 논문 주장을 정해야 한다. 이후 필요하다면 사실 상태와 보고 정책을 분리한 구조를 설계하고, 독립 조건에서 새로 검증한다. 그 구조는 아직 구현하거나 성공했다고 보고한 성과가 아니다.
