# PSYCHE 로컬 제어 진단 실행 안내

이번 실행 단위는 사전 고정 → 기존 응답 재사용 → 새 로컬 생성 → 기술통계 → 사전 기준에 따른 결정 → 보고서다. 환자 모델의 임상적 타당도 검증과는 구분한다.

## 설계

하나의 동일한 가상 사례에 질문 2개, 시드 2개, 발화량 설정 2개, 지시 방식 4개를 적용한다. 총 32개 답변 중 이전 실험과 요청 전체가 정확히 같은 4개는 모델 해시·템플릿·서버 버전·옵션을 검증한 뒤 재사용한다. 신규 생성은 28회로 제한한다. 과거 생성 결과를 새 독립 반복으로 세지 않는다.

지시 방식은 간단한 환자 역할 프롬프트와 숫자 지시, 기존 공개 프롬프트와 MFC 설정 이름, MFC에 추가한 실험용 숫자 지시 필드, 시스템 끝에 덧붙인 숫자 지시다. 마지막 두 방식은 연구자 작성 확장이며 PSYCHE 원형으로 부르지 않는다. JSON 내부와 시스템 끝의 비교는 위치와 표현 형식이 함께 달라져 단일 원인을 확정하는 실험은 아니다.

20~40단어와 100~140단어는 분명히 떨어진 공학적 목표다. 실제 환자의 정상/증가 발화량 기준이 아니다. 숫자 지시를 받은 세 방식에만 목표 준수율을 계산한다. 숫자를 주지 않은 기존 프롬프트는 발화량 방향과 크기를 기술할 뿐, 주지 않은 숫자 지시를 따르지 않았다고 평가하지 않는다.

각 숫자 지시 방식의 통과 기준은 8개 중 6개 이상 목표 범위 충족, 같은 질문/시드의 비교 4쌍 모두 장문 쪽이 더 김, 평균 길이 차이 50단어 이상이다. 이는 실험 전 고정한 실용적 판정 기준이며 통계적 유의성이나 임상 기준이 아니다. 간단한 지시 방식이 통과하고 페르소나 확장 방식도 통과하면 Qwen을 제한적 출력 제어 작업에 계속 쓸 수 있다고 판단한다. 사전 우선순위는 시스템 끝 지시, 그다음 JSON 확장이다. 원형보다 임상적으로 낫다는 모델 선택은 하지 않는다.

## 재현

이 Mac의 이미 설치된 런타임을 사용한다. 설치나 다운로드는 하지 않는다. 프로젝트 루트에서 다음을 실행한다.

```sh
/Users/ohs/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 scripts/psyche_controls.py
/Users/ohs/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -m unittest discover -s tests -p 'test_psyche*.py' -v
```

첫 명령은 생성 없이 고정된 요청을 준비한다. Ollama가 준비된 경우에만 실제 실행한다.

```sh
/Users/ohs/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 scripts/psyche_controls.py --execute
```

완료 후 분석·검증은 모델 호출 없이 재실행한다.

```sh
/Users/ohs/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 scripts/psyche_controls.py --analyze
/Users/ohs/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 scripts/verify_psyche_controls.py
```

일부 정상 완료 응답이 있는 중단 실행은 동일 설정에서 `--execute --resume`으로만 재개한다. 전송 여부가 불명확하거나 실패한 요청은 자동 재전송하지 않는다. 이번 v01의 입력/코드는 덮어쓰지 말고 새 연구 질문은 새 버전으로 고정한다.

## 자료

전체 실제 요청, 재사용 출처와 해시, 실행 옵션, 전송 시도, 원응답, 측정값과 판정 근거는 `analysis/psyche-controls-v01/`에 있다. 조건을 제거한 원문은 `영어발화원문.md`, 대응 키는 분석 폴더에 따로 있다. 임상 사고장애 점수나 자동 LLM 평가자의 점수는 생성하지 않는다. 기존 실험들은 그대로 보존했다.

최종 결과는 `PSYCHE 발화량 제어 실험 보고서.docx` 2쪽과 `결과요약.md`에 정리했다. 기본 숫자 지시는 6/8개, MFC 내부 숫자 지시는 7/8개, 시스템 끝 숫자 지시는 4/8개가 목표 범위를 충족했다. 기존 범주형 조건은 Increased가 더 긴 경우가 1/4쌍이었다. 사전 기준에 따라 MFC 내부 지시를 제한적 길이 통제에 채택했으며 실제 요청 8개를 `selected-engineering-requests.json`으로 내보냈다. 이 파일은 추가 생성 결과나 임상 검증 모델이 아니다. 최종 문서는 두 페이지 전체를 렌더링해 시각적으로 확인했다.
