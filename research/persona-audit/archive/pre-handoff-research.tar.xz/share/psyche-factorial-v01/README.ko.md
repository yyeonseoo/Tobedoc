# PSYCHE 특징 분리 파일럿: 실행 안내

## 무엇을 확인하는가

‘말이 많다’와 ‘사고의 연결성이 떨어진다’는 같은 설정이 아니다. 그런데 잠근 PatientHub 영어 프롬프트의 Increased 설명은 발화량과 주제 이탈을 한 문장에 묶는다. 이 문장을 그대로 쓰는 조건과 주제 이탈 구절만 삭제한 조건을 비교한다. 이는 PSYCHE 원저 전체의 성능 평가가 아니라, 공개 재구현을 로컬 모델로 옮길 때 발생할 수 있는 설정 혼선을 점검하는 실험이다.

조건은 원문/수정문 2 × 발화량 Normal/Increased 2 × 사고과정 Normal/Derailment 2 × 시드 2 = 16개 응답이다. 질문과 인물 배경은 전부 같다. 한 명의 연구자 작성 가상 인물을 이용하므로 16명의 환자나 16개의 독립 임상 사례로 세지 않는다. 사고장애 유무가 조현병 환자 전체를 대표한다고 가정하지 않는다.

## 사전에 고정한 것

- 공개 코드 commit: `54d5c8761a9055a1e86d153715607ef9fa26358a`.
- 변경은 단 하나다. `Answers tend to be long and detailed, with difficulty stopping or staying on topic.`에서 뒤의 구절만 삭제한다. 이것이 임상적으로 개선되었다고 미리 가정하지 않는다.
- 배경, 지각 경험, 병식, 협조도 등은 고정하고 MFC의 Verbal productivity와 Thought process만 바꾼다. 생성된 답을 다음 조건의 대화 이력에 재사용하지 않는다.
- 모든 조건에서 `Tell me about your usual morning, from waking up until you get to work.`라고 한 번 묻는다. 추가 발화 유도 효과는 이번 실험에 섞지 않는다.
- 설치된 `qwen3:14b`, Q4_K_M만 사용한다. 원래 PSYCHE의 GPT-4o와 다른 백본이므로 native replication으로 부르지 않는다. 모델 해시·템플릿·실행 옵션은 `runtime.json`에 기록한다.
- 요청 16개와 코드/입력/논문 스냅샷 해시를 첫 생성 전에 고정한다. 좋은 답만 뽑거나 자동 재시도하지 않는다. 잘림·빈 답·오류는 남기고 중단한다.

## 실행법

프로젝트 루트 `persona-audit`에서 실행한다. `python3`는 설치된 Pydantic을 사용할 수 있어야 한다. 이 Mac에서는 아래 런타임이 이미 준비되어 있다.

```sh
/Users/ohs/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 scripts/psyche_factorial.py
/Users/ohs/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -m unittest discover -s tests -p 'test_psyche*.py' -v
```

첫 명령은 요청 고정만 수행하며 LLM을 호출하지 않는다. 로컬 Ollama가 실행 중이고 지정 모델이 설치되어 있을 때만 생성한다. 자동 모델 다운로드는 없다.

```sh
python3 scripts/psyche_factorial.py --execute
```

실행 완료 후 분석만 다시 계산하려면 다음을 쓴다. 이미 완료된 실행에 `--execute`를 다시 주지 않아도 된다.

```sh
python3 scripts/psyche_factorial.py --analyze
```

정상 완료된 일부 응답 이후 중단된 경우 `--execute --resume`으로 동일 결과를 재사용한다. 전송 여부가 불명확한 요청이나 실패 기록이 있으면 자동 재개하지 않는다. 입력/코드를 바꾸고 싶으면 기존 v01을 덮어쓰지 말고 새 버전을 만든다. 세션을 강제 종료해 `.running`이 남았을 때는 실제 실행이 종료되었는지 먼저 확인한다.

## 산출물과 해석 범위

`analysis/psyche-factorial-v01/`에 요청 원문, 모델 메타데이터, 전송 시도, 응답 원문, 측정값, 조건별 요약과 해시를 저장한다. `measurements.json`은 응답별 단어 수·근사 문장 수·지정 임상 용어의 문자상 출현·입력과의 연속 6단어 정확 중복을 담는다. 모두 텍스트 기술통계이지 사고장애 진단 점수가 아니다. 단어 수의 paired difference는 같은 설정/시드를 짝지은 기술량이며 p-value는 계산하지 않는다.

`블라인드발화.md`에는 조건 이름 없이 영어 원문을 담는다. 블라인드 키는 분석 폴더에 따로 보관한다. 이 자료를 읽는 것과 임상적 신뢰도·사고장애 타당도 검증은 구분한다. 뒤의 두 항목은 나중에 교수님 자문에서 평가 질문과 준거를 정해야 한다.

이번 실험만으로 ‘수정문이 더 실제 환자 같다’거나 ‘어느 모델이 더 우수하다’고 결론내리지 않는다. 일차 판단은 비교 실험이 기술적으로 실행되는지, 입력 설정 변화가 어떤 관찰 가능한 출력 변화와 연결되는지다. Roleplay-doh의 전체 원칙 기반 비교는 정식 접근한 개별 전문가 원칙 파일이 확보될 때까지 별도로 보류한다. 임의로 만든 규칙을 원저 모델로 대신 부르지 않는다.

## 논문과 구현의 연결

[PSYCHE 원저](https://arxiv.org/html/2501.01594v1)는 SP-Prompt-3에서 발화량 지시를 구체화하고, Table 11에서 조증의 flight of ideas 구현에 지시/예시를 제공했다고 설명한다. 이 근거는 명시적 구현 지침의 필요성을 보여주지만, 그 예시를 조현병의 derailment 정답으로 가져오지는 않았다. 정확한 원저 환자 프롬프트 전체를 확보하지 못했으므로 이번 한 구절 삭제를 ‘원저 복원’으로 부르지 않는다.

[PatientHub의 잠근 영어 프롬프트](https://github.com/Sahandfer/PatientHub/blob/54d5c8761a9055a1e86d153715607ef9fa26358a/data/prompts/client/psyche.yaml)를 원문 조건으로 사용한다. 공개 인물 예시는 스키마는 통과하지만 첫 번째 예시의 Profile은 40세 여성이고 Behavior에는 40대 후반 남성이라는 기술이 있어, 그대로 이번 통제 입력으로 쓰지 않았다. 별도로 작성한 가상 입력 역시 전문가 검증 사례는 아니다.
