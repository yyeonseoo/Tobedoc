# PSYCHE 주력 전환 뒤 첫 분석

특징추출과구현점검.md에 이번 결과와 다음 결정을 정리했다. 실제 생성 발화의 성능 실험은 하지 않았다.

재현은 프로젝트 폴더에서 아래 명령으로 가능하다. 기존 번들 Python과 Pydantic만 사용하며 네트워크 연결이 필요 없다.

```bash
cd '/Users/ohs/Documents/ChatGPT/투비닥터 연구/persona-audit'
/Users/ohs/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 scripts/audit_psyche_roleplay_sources.py
/Users/ohs/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -m unittest discover -s tests -p test_psyche_roleplay_sources.py -v
```

구조화된 결과는 analysis/psyche-roleplay-source-audit-v01의 feature-inventory.json, offline-checks.json, implementation-findings.json, source-verification.json에 있다. 원칙의 전체 개별 파일은 확보하지 않았다. 초기 리터럴 블록 추출기의 공백 줄 처리 문제를 수정했으며 수정 전 진단 기록을 offline-checks.initial-parser.json에 보존하고 회귀 테스트를 추가했다.
