# Final report QA

All three final page images in `render-qa/` were inspected at original resolution. Korean/English text, numeric tables, examples, references, and page numbers are readable, with no clipping, split example explanation, extra overflow page, or missing glyphs.

Final DOCX SHA-256: `f19ce68b02c765b09a70a6e64f384fc62e8b2f5a4f892cd60d158f463b480d7a`.

The initial four-page rendering is preserved in `render-qa-initial/`. Narrative duplication was shortened rather than shrinking body type. The initial verifier exposed a single-sentence denominator oversight in the verifier/report wording; the already-frozen analysis had correctly stored null local metrics for that reply. The final report states 47 eligible local-metric replies, including 15 plain replies, and distinguishes 12 two-sentence plain replies from the one single-sentence reply. No frozen metric or source output was changed.

Final offline report verification reproduced all stored values and passed 126 implementation tests. These checks establish computational reproducibility, not independent clinical validity.
