# 팀 공유용 프로토타입 안내

2026-10-29 · 별도 유료 API 없음 · 모델 다운로드 없음

## 읽는 순서

1. `team-report.ko.md`: 오늘 공유할 한국어 2~3쪽 분량의 본문.
2. `transcripts.en.md`: 6조건·24응답 전체. 편집·선별·번역 없이 생성 원문을 수록.
3. `turn-metrics.csv` 및 `metrics.json`: 로컬 계산한 기술량과 원본 파일 해시.
4. `qualitative-review.json`: 조건을 아는 어시스턴트의 근거 인용과 해석 한계. 임상가 채점이 아님.

환자자료·전문의 평가·조현병 진단 정확도는 포함하지 않는다. 기본 비교는 같은 한 사람/한 상황에서 수행한 개발용 비교다. `metrics.regex-v1.json`은 문장 분리 보정 전 기록이며, 최종 본문은 보정 후 `metrics.json`을 사용한다.

## 계산만 재현하기

공유 ZIP을 풀면 이 폴더에 보고서가 있고, 같은 폴더 아래에 `scripts/`, `pilot/`, `evidence/`, `config/`가 있다. 해당 폴더를 작업 디렉터리로 삼는다. Python 3.10 이상 표준 라이브러리만 필요하다. 실제 생성은 다시 하지 않는다.

```bash
python3 scripts/summarize_local_pilot.py --run-id team-prototype-20261029
```

묶음에서 재집계하면 결과는 `share/team-prototype-20261029/`에 저장된다. 원본 프로젝트에서는 `persona-audit/`에서 같은 명령을 실행한다. 숫자와 원문을 검증하는 데 Ollama·API 키·인터넷은 필요 없다.

## 새로 생성하려면

실험은 Ollama에 **같은 digest의 `qwen3:14b`가 이미 설치된 기기**에서만 재개/재실행할 수 있다. 누락 모델을 자동 다운로드하지 않는다. 모델 로딩은 약 11GB로 표시됐지만, 이것을 피크 메모리 측정이나 모든 24GB Mac에서의 속도 보장으로 해석하지 않는다.

새로운 실행은 고유한 ID를 지정한다. 최초 1대화로 설정을 확인하고 같은 설정으로 재개한다. 기존 응답은 다시 생성하지 않는다. 오류 또는 응답 없는 요청이 남으면 자동 재시도하지 않고 검토를 요구한다.

```bash
python3 scripts/run_local_pilot.py --run-id my-new-prototype --max-dialogues 1
python3 scripts/run_local_pilot.py --run-id my-new-prototype --resume --max-dialogues 6
python3 scripts/summarize_local_pilot.py --run-id my-new-prototype
```

다른 기기·버전에서는 seed가 같아도 완전히 같은 출력은 보장하지 않는다. 생성 전 다른 작업의 메모리·GPU 여유를 확인한다. 한 작업씩 실행하며 서버 설정을 변경하지 않는다.

## 출처와 재현 범위

PATIENT-Ψ commit `de72a768e5366d3e94f7d8c711c563fb4a5b4d26`. 프로필·스타일·formatter의 고정 사본과 MIT 라이선스만 필요한 범위에서 포함한다. 나머지 임상 논문의 원문 캐시는 묶음에 넣지 않는다. 이식한 프롬프트, 필드 재연결, Ollama 요청 방식은 원 저자들의 공식 수정이나 논문 실험의 재현이 아니다.

Ollama 인터페이스는 [chat 문서](https://docs.ollama.com/api/chat), [thinking 문서](https://docs.ollama.com/capabilities/thinking), [생성 파라미터 문서](https://docs.ollama.com/modelfile)를 확인했다. 실제 실행 설정과 버전은 `pilot/runs/team-prototype-20261029/run-config.json` 및 `runtime.json`이 기준이다.

묶음은 오늘의 결과 재집계와 같은 소규모 생성에 필요한 부분만 담는다. 전체 프로젝트의 23개 출처 검증을 실행하려면 전체 프로젝트 사본 또는 별도의 출처 수집이 필요하다. 모든 임상 자료를 이 묶음이 포함한다고 가정하지 않는다.
