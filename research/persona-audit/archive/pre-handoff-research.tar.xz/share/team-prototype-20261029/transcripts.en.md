# Actual local prototype transcripts

PATIENT-Ψ prompt port on Qwen3-14B; English generated text. Development example, not clinical validation.
Run: `team-prototype-20261029`. Source requests/responses and hashes are retained in the run folder.

All recorded replies are included below. No best-of selection, spelling correction or translation.

## plain / native_demo_mapping

### Turn 1 · completed

Interviewer: You mentioned this situation: Thinking about bills. Could you tell me what happened?

Patient: Hi, I guess it's been really hard to think about the bills lately. I just feel so overwhelmed, like I can't handle it. I keep sitting on the couch, staring at the TV, but nothing helps. I don't know why I can't just get up and do something about it. It's like I'm stuck in my head, thinking about all the things I've failed at.

Record: `A-1-1-native_demo_mapping-plain-T1`. Words: 65; sentence heuristic: 5; wall time: 13.13 s.

### Turn 2 · completed

Interviewer: What was going through your mind at that moment?

Patient: I guess I was thinking that I should have been able to handle everything better. Like, if I had just worked harder or been more responsible, maybe things wouldn't be so bad. I feel like I'm failing again, and I don't want anyone to see how bad I am. It's like I'm stuck in this loop where I can't escape my own thoughts. I just want it all to go away.

Record: `A-1-1-native_demo_mapping-plain-T2`. Words: 71; sentence heuristic: 5; wall time: 6.92 s.

### Turn 3 · completed

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I don't know, I just stayed there. I kept telling myself that if I didn't do anything, maybe the problems would just go away. I was scared that if I tried to fix things, I'd fail again, and then everyone would see how useless I am. I guess I was hoping that if I ignored it long enough, the bills wouldn't matter anymore. It's not helpful, but it's the only thing that feels safe to me.

Record: `A-1-1-native_demo_mapping-plain-T3`. Words: 76; sentence heuristic: 5; wall time: 7.76 s.

### Turn 4 · completed

Interviewer: How did you deal with that situation afterward?

Patient: I didn't really deal with it. I just let it sit there, in the back of my mind. I told myself that if I didn't act, I wouldn't have to face the embarrassment of failing again. It's easier to pretend everything's okay than to actually try and fix it. I know it's not good, but I don't know how to change it. It feels like no matter what I do, I'm going to mess things up.

Record: `A-1-1-native_demo_mapping-plain-T4`. Words: 76; sentence heuristic: 6; wall time: 7.93 s.

## plain / repaired_demo_mapping

### Turn 1 · completed

Interviewer: You mentioned this situation: Thinking about bills. Could you tell me what happened?

Patient: Hi, I guess it's been really hard thinking about the bills lately. I keep worrying that I might not have enough money to cover everything. It feels like I'm failing again, just like when I lost my job. I don't know what to do, so I just sit there and think about everything that went wrong. It's overwhelming.

Record: `A-1-1-repaired_demo_mapping-plain-T1`. Words: 58; sentence heuristic: 5; wall time: 6.63 s.

### Turn 2 · completed

Interviewer: What was going through your mind at that moment?

Patient: I guess I was thinking about how I'm not good with money, and that I should have been more responsible. I keep telling myself that if I had worked harder, I wouldn't be in this situation. It's like I'm failing again, and I don't want anyone to see how bad I am. I just want it all to go away. I feel so trapped.

Record: `A-1-1-repaired_demo_mapping-plain-T2`. Words: 64; sentence heuristic: 5; wall time: 6.37 s.

### Turn 3 · completed

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I didn't do anything really. I just stayed on the couch, staring at the ceiling. I couldn't bring myself to look at the bills or even think about paying them. It felt too much, like if I tried, I'd fail again. I told myself that if I just ignored them, maybe the problem would go away. But I know that's not true. I just don't know how to fix it.

Record: `A-1-1-repaired_demo_mapping-plain-T3`. Words: 70; sentence heuristic: 7; wall time: 7.09 s.

### Turn 4 · completed

Interviewer: How did you deal with that situation afterward?

Patient: I didn't really deal with it. I just kept telling myself that I wasn't ready to face it yet. I think I was hoping that if I waited long enough, things would somehow get better on their own. But deep down, I know that's not going to happen. I feel like I'm stuck in this cycle of avoiding and failing. It's so frustrating.

Record: `A-1-1-repaired_demo_mapping-plain-T4`. Words: 63; sentence heuristic: 6; wall time: 6.68 s.

## reserved / native_demo_mapping

### Turn 1 · completed

Interviewer: You mentioned this situation: Thinking about bills. Could you tell me what happened?

Patient: I don't know, it's just... things have been really hard lately. I guess I've been thinking about money a lot. It's not really anything specific, just stress, I guess.

Record: `A-1-1-native_demo_mapping-reserved-T1`. Words: 29; sentence heuristic: 3; wall time: 4.90 s.

### Turn 2 · completed

Interviewer: What was going through your mind at that moment?

Patient: I don't know, maybe I just felt like I wasn't doing enough. Like I should be able to handle this on my own. It's not like anyone else can help me, really.

Record: `A-1-1-native_demo_mapping-reserved-T2`. Words: 32; sentence heuristic: 3; wall time: 3.47 s.

### Turn 3 · completed

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I just sat there for a while. I didn't really know what to do. I guess I felt like if I tried to do something, I'd mess it up. So I just let it go.

Record: `A-1-1-native_demo_mapping-reserved-T3`. Words: 35; sentence heuristic: 4; wall time: 3.65 s.

### Turn 4 · completed

Interviewer: How did you deal with that situation afterward?

Patient: I didn't really deal with it. I just kind of let it sit there. I guess I figured if I ignored it long enough, it would go away. It's not like I had any other options, really.

Record: `A-1-1-native_demo_mapping-reserved-T4`. Words: 37; sentence heuristic: 4; wall time: 3.89 s.

## reserved / repaired_demo_mapping

### Turn 1 · completed

Interviewer: You mentioned this situation: Thinking about bills. Could you tell me what happened?

Patient: I guess I just got overwhelmed thinking about all the bills piling up. I don't know, it's hard to focus on anything else when that happens. I just sit there and let my mind wander.

Record: `A-1-1-repaired_demo_mapping-reserved-T1`. Words: 35; sentence heuristic: 3; wall time: 5.78 s.

### Turn 2 · completed

Interviewer: What was going through your mind at that moment?

Patient: I guess I was worried about not being able to pay them. It's like I always end up failing at things like this. I don't know if I can handle it all.

Record: `A-1-1-repaired_demo_mapping-reserved-T2`. Words: 32; sentence heuristic: 3; wall time: 3.24 s.

### Turn 3 · completed

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I just sat there for a while, not really doing anything. I didn't want to deal with it, honestly. It felt easier to just let it all sit there.

Record: `A-1-1-repaired_demo_mapping-reserved-T3`. Words: 29; sentence heuristic: 3; wall time: 3.06 s.

### Turn 4 · completed

Interviewer: How did you deal with that situation afterward?

Patient: I tried to push it out of my head. I know that's not helpful, but it's what I do. I guess I just feel like I should handle everything on my own.

Record: `A-1-1-repaired_demo_mapping-reserved-T4`. Words: 32; sentence heuristic: 3; wall time: 3.26 s.

## tangent / native_demo_mapping

### Turn 1 · completed

Interviewer: You mentioned this situation: Thinking about bills. Could you tell me what happened?

Patient: I was just sitting here, you know, staring at the ceiling. It's been so long since I've been able to focus on anything. I keep thinking about all the bills piling up, and it's like... it's like I'm failing again. I can't even remember the last time I felt in control. My mom always said I had to be responsible, but now I'm just... I'm just stuck.

Record: `A-1-1-native_demo_mapping-tangent-T1`. Words: 67; sentence heuristic: 5; wall time: 8.71 s.

### Turn 2 · completed

Interviewer: What was going through your mind at that moment?

Patient: I don't know, it's just... it's like everything I do is never enough. I remember when I was younger, my mom would get so angry if I didn't do well in school. She said I had to be the best, but what if I'm not? What if I'm just... broken? I keep thinking I should be able to fix this, but I can't. It's like I'm failing again, and I don't know how to stop it.

Record: `A-1-1-native_demo_mapping-tangent-T2`. Words: 76; sentence heuristic: 6; wall time: 8.09 s.

### Turn 3 · completed

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I just sat there, frozen. I couldn't even move. It's like my brain was stuck in this loop, repeating the same thoughts over and over. I kept thinking about how I used to be able to handle things, but now... now I can't. I don't know why I feel like this. I just wanted to disappear sometimes.

Record: `A-1-1-native_demo_mapping-tangent-T3`. Words: 57; sentence heuristic: 6; wall time: 6.26 s.

### Turn 4 · completed

Interviewer: How did you deal with that situation afterward?

Patient: I didn't really deal with it. I just let it sit there, like a weight on my chest. I tried to ignore it, but the more I ignored it, the worse it got. I remember thinking, "If I don't face it, maybe it'll go away." But it didn't. I just kept telling myself I'd figure it out later. I'm not sure why I do that. It's like I'm afraid of failing again.

Record: `A-1-1-native_demo_mapping-tangent-T4`. Words: 72; sentence heuristic: 8; wall time: 7.75 s.

## tangent / repaired_demo_mapping

### Turn 1 · completed

Interviewer: You mentioned this situation: Thinking about bills. Could you tell me what happened?

Patient: I don't know, sometimes I just sit there and think about everything. It's like my mind goes into this spiral. I used to be able to handle things, but now... I feel like I'm failing at everything. I remember when my dad left, and my mom was so stressed. She always expected so much from me. I guess I never really felt like I could live up to that.

Record: `A-1-1-repaired_demo_mapping-tangent-T1`. Words: 69; sentence heuristic: 6; wall time: 8.34 s.

### Turn 2 · completed

Interviewer: What was going through your mind at that moment?

Patient: I just keep thinking, "What if I can't pay the bills? What if I end up on the street?" It's like I'm stuck in this loop. I used to be able to work, but now I can't even find a job. I feel like I'm not good enough for anything. Sometimes I think about my mom, how she always pushed me so hard. I guess I never felt like I could measure up.

Record: `A-1-1-repaired_demo_mapping-tangent-T2`. Words: 73; sentence heuristic: 7; wall time: 7.39 s.

### Turn 3 · completed

Interviewer: Returning to the situation I first asked about, what did you do next?

Patient: I just sat there, staring at the ceiling. I didn't want to move, didn't want to face anything. I remember my ex-wife saying something about me being unreliable. I guess I always feared that people would see me as a failure. I don't know, maybe I should have asked for help, but I just... I didn't. I always thought I had to do it alone.

Record: `A-1-1-repaired_demo_mapping-tangent-T3`. Words: 65; sentence heuristic: 6; wall time: 6.81 s.

### Turn 4 · completed

Interviewer: How did you deal with that situation afterward?

Patient: I didn't really deal with it. I just let it sit there, like a weight on my chest. I think I told myself that if I ignored it, it would go away. But it didn't. I kept thinking about my old job, how I messed things up. I guess I always thought I had to be perfect. I don't know, maybe I'm just broken. I feel like I don't deserve help or support.

Record: `A-1-1-repaired_demo_mapping-tangent-T4`. Words: 73; sentence heuristic: 8; wall time: 7.55 s.
