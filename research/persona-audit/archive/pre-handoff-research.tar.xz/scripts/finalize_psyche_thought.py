"""Verify development artifacts and write a compact protocol/results handoff.

No model calls, embeddings, automatic clinical ratings or holdout release.
"""
from collections import defaultdict
import json
from pathlib import Path
import random
import statistics

from common import ROOT, digest, write_json
import psyche_thought as p

SHARE = ROOT / 'share/psyche-thought-v01'


def main():
    spec, requests, plan = p.prepare()
    responses = p.read(p.OUT / 'measurements.json')
    pairs = p.read(p.OUT / 'matched-pairs.json')
    assert len(responses) == 16 and all(r['status'] == 'completed' and r['split'] == 'development' for r in responses)
    assert len(pairs) == 8 and all(r['split'] == 'development' for r in pairs)
    lookup = {r['id']: r for r in requests}
    hashes = {}
    for row in responses:
        request = lookup[row['id']]
        path = p.OUT / 'responses' / (row['id'] + '.json')
        record = p.read(path)
        raw = record['raw']
        assert record['request_sha256'] == p.base.fingerprint(request['payload'])
        assert record['status'] == p.base.classify(raw, p.read(ROOT / spec['previous_case_spec'])) == 'completed'
        assert record['origin'] == 'new_local_call'
        assert row['text'] == raw['message']['content']
        assert all(row[k] == v for k, v in p.describe(row['text'], spec['word_target']).items())
        assert p.read(p.OUT / 'attempts' / (row['id'] + '.json'))['request_sha256'] == record['request_sha256']
        hashes[str(path.relative_to(ROOT))] = digest(path.read_bytes())
    assert len(list((p.OUT / 'responses').glob('*.json'))) == len(list((p.OUT / 'attempts').glob('*.json'))) == 16
    assert not (p.OUT / '.running').exists()
    assert not any((p.OUT / 'responses' / (r['id'] + '.json')).exists() for r in requests if r['split'] == 'holdout')
    runtime = p.read(p.OUT / 'runtime.json')
    assert p.controls.stable_runtime(runtime) == p.controls.stable_runtime(p.read(p.base.OUT / 'runtime.json'))
    summary = []
    for arm in spec['arms']:
        rows = [r for r in responses if r['arm'] == arm]
        matched = [r for r in pairs if r['arm'] == arm]
        # Independently recheck pair equality and length arithmetic from exact raw texts.
        indexed = {r['id']: r for r in rows}
        for pair in matched:
            a, b = indexed[pair['normal_id']], indexed[pair['derailment_id']]
            assert pair['exact_text_equal'] == (a['text'] == b['text'])
            assert pair['word_difference'] == b['words']-a['words']
            mismatch = abs(a['words']-b['words']) / max(a['words'], b['words'], 1)
            assert pair['relative_length_mismatch'] == mismatch
            assert pair['in_length_sensitivity_subset'] == (a['within_target'] and b['within_target'] and mismatch <= .20)
        summary.append({'arm': arm, 'responses': len(rows), 'target_hits': sum(r['within_target'] for r in rows),
                        'normal_mean_words': statistics.mean(r['words'] for r in rows if r['thought'] == 'Normal'),
                        'derailment_mean_words': statistics.mean(r['words'] for r in rows if r['thought'] == 'Derailment'),
                        'exact_equal_pairs': sum(r['exact_text_equal'] for r in matched),
                        'pairs': len(matched), 'length_sensitivity_pairs': sum(r['in_length_sensitivity_subset'] for r in matched),
                        'segmentation_errors': sum(r['segmentation_error'] is not None for r in rows),
                        'answers_with_literal_label': sum(bool(r['literal_labels']) for r in rows)})
    result = {'development_complete': True, 'development_responses': 16, 'holdout_responses': 0,
              'holdout_requests_sealed': 32, 'clinical_ratings_obtained': 0, 'clinical_improvement_claim': False,
              'automatic_scores_are_not_thought_disorder_scores': True, 'arms': summary}
    write_json(p.OUT / 'development-summary.json', result)
    SHARE.mkdir(parents=True, exist_ok=True)
    blind = list(responses)
    random.Random(20261108).shuffle(blind)
    lines = ['# 개발 발화 블라인드 검토 자료', '', '연구용 가상 인물의 생성 발화이며 실제 환자 자료가 아니다. 아직 전문가 판정은 없다.', '',
             '각 발화를 읽고 사고 전환의 근거 구간과 대안적 설명을 검토한다. 임상 중증도 숫자를 붙이지 않는다.', '']
    key = []
    advice = ['# 자문 우선 검토 발화 네 개', '',
              '같은 가상 인물과 질문의 생성 응답이다. 조건 이름은 가렸으며 실제 환자 발화나 전문가 검증 자료가 아니다.', '',
              '연속되는 생각의 연결이 불명확한 전환이 관찰되는지, 그렇다면 어느 구간인지 근거를 확인한다. '
              '질문 자체에 빗나간 답이나 문장 내부의 이해 불가, 단순 장황함과 구별 가능한지도 검토한다. '
              '판단이 어려우면 불확실로 남긴다. 중증도 점수나 정답은 아직 부여하지 않았다.', '']
    for row in blind:
        ident = 'T-' + digest(row['id'].encode())[:8]
        key.append({'blind_id': ident, 'condition_id': row['id'], 'limited_advice_subset': lookup[row['id']]['review_subset']})
        lines.extend(['## ' + ident, '', lookup[row['id']]['payload']['messages'][1]['content'], '', row['text'], ''])
        if lookup[row['id']]['review_subset']:
            advice.extend(['## ' + ident, '', lookup[row['id']]['payload']['messages'][1]['content'], '', row['text'], ''])
    (SHARE / '개발발화블라인드.md').write_text('\n'.join(lines), encoding='utf-8')
    (SHARE / '자문우선4개.md').write_text('\n'.join(advice), encoding='utf-8')
    write_json(p.OUT / 'blinding-key.json', key)
    rationale = ['# 사고과정 비교 프로토콜과 개발 실행', '', '## 무엇을 고정하고 실행했는가', '',
                 '이제 발화량을 늘리는 실험에서 사고과정 설정을 비교하는 실험으로 넘어왔다. '
                 '개발용 기존 사례 1개와 최종 검증용 새 사례 2개에서 총 48개 요청을 고정했다. '
                 '개발용 16개만 실행했고, 검증용 32개는 아직 생성하지 않았다. '
                 '새 직업과 일상 배경은 임상적으로 다양한 환자 코호트가 아니라 연구자 작성 입력이다.', '',
                 '기존 범주형 지시와 출처 기반 구체 지시를 비교하며 각 방식에서 Normal과 Derailment를 바꾼다. '
                 '두 방식 모두 같은 길이 제어 필드와 100~140단어 목표, Normal 발화량 설정, 동일 질문과 시드를 쓴다. '
                 '길이 범위 충족이 실제 길이의 완전 일치를 의미하지 않으므로 모든 원문을 보존하고 대응 길이 차이를 따로 보고한다.', '',
                 '## 임상 용어와 측정의 경계', '',
                 '[TLC 원저](https://cssh.northeastern.edu/cali/wp-content/uploads/sites/57/2022/09/Scale-for-the-assessment-of-thought-language-and-communication.pdf)의 '
                 '항목 5·6·7을 구분해 사고 전환을 주 표적으로 삼았다. 단일 답변에 면담 전체 빈도 기반 중증도 점수를 옮기지 않는다. '
                 '[TLI 부록](https://www.cambridge.org/core/journals/the-british-journal-of-psychiatry/article/thought-and-language-index-an-instrument-for-assessing-thought-and-language-in-schizophrenia/FEFB9ADC871CDFE528B4B87F99A4F054)도 관련 구분의 참고 근거로 연결했다. '
                 '구체 지시는 연구자 작성 가설이지 원형 PSYCHE 프롬프트나 전문가 검증 개선안이 아니다.', '',
                 '기존 외부 검증에서 인접 코사인과 전문가 연결성 평가의 Spearman 상관은 약 0.032였다 '
                 '(SummEval 적격 1542개, 임상 자료 아님). 따라서 이 수치를 임상 점수나 개선 판정 기준으로 다시 사용하지 않는다. '
                 '이번 자동 계측은 실제 문구의 동일성, 길이, 문장 수와 임상 라벨 노출에 한정한다. '
                 '두 답이 달라도 사고장애를 잘 구현했다는 뜻은 아니다.', '', '## 개발 실행 수치', '']
    names = {'hub_category': '길이를 통제한 기존 범주형 지시', 'source_operationalized': '출처 기반 구체 지시 추가'}
    for r in summary:
        rationale.append(f'- {names[r["arm"]]}: 길이 범위 {r["target_hits"]}/8개 충족; Normal 평균 {r["normal_mean_words"]:.1f}단어, '
                         f'Derailment 평균 {r["derailment_mean_words"]:.1f}단어; 동일 출력 {r["exact_equal_pairs"]}/4쌍; '
                         f'사전 길이 민감도 조건을 충족한 비교 {r["length_sensitivity_pairs"]}/4쌍.')
    rationale.extend(['', '이번 개발 자료에서는 두 방식 모두 동일 출력이 0/4쌍이었다. 따라서 문자열이 달라지는지만으로 두 방식의 우열을 나눌 수 없다. '
                      '예전 파일럿의 동일 응답 사례가 이번 조건에서도 반드시 재현된다고 전제하지 않는다. '
                      '지시 방식에 따라 문구가 달라지는 것과 목표 임상 현상이 관찰되는 것은 별도 결과다.', '',
                      '이 수치는 임상적 효과 크기나 정확도가 아니다. 길이 민감도 조건은 두 답 모두 범위 내이고 상대 길이 차이가 20% 이하인 경우이며, '
                      '해당 부분집합의 결과로 전체 결과를 대신하지 않는다. S/L/G나 자동 LLM 판정은 생성하지 않았다.', '',
                      '## 다음 판정 절차', '',
                      '교수님 자문용 후보 질문과 출처를 고정했다. 확인 가능한 사고 전환이 있는지, 있다면 어느 구간인지, '
                      '질문 부적합성이나 문장 내부 불가해성과 혼동한 것은 아닌지를 검토한다. 이 체크리스트는 TLC 정식 척도 대체물이 아니다. '
                      '시간이 제한되면 개발 자료 중 사전 지정한 4개부터 검토할 수 있다. '
                      '추후 검증 자료까지 생성하면 사전 지정한 전체 자문 표본은 12개다. 팀원이나 생성 모델의 판단을 전문가 정답으로 넣지 않는다.', '',
                      '최종 검증용 32개는 프롬프트나 평가 기준을 바꾸는 동안 열지 않는다. 임상 개선 여부는 전문가 관찰 없이 판정하지 않는다. '
                      '자문으로 기준을 수정하면 변경 시점과 내용을 별도 버전에 기록하고 검증 결과를 본 뒤 기준을 고르지 않는다.', '',
                      '## 재현', '',
                      '프로토콜은 config/psyche-thought-v01.json, 정의 근거는 catalog/thought-constructs-v01.json, '
                      '모든 고정 요청과 개발 원응답은 analysis/psyche-thought-v01에 있다.', '',
                      '준비만  `python3 scripts/psyche_thought.py`', '',
                      '개발 실행  `python3 scripts/psyche_thought.py --execute --split development`', '',
                      '이미 완료된 개발 원문 분석만  `python3 scripts/psyche_thought.py --analyze`', '',
                      '검증과 자료 생성  `python3 scripts/finalize_psyche_thought.py`', '',
                      '사용 런타임은 이전 README와 같은 번들 Python이다. 완료된 실행은 자동 반복하지 않는다. '
                      'holdout 실행에는 개발 완료와 --release-holdout, 동일 런타임의 --resume가 필요하다. 이번 작업에서는 release하지 않았다.', ''])
    report = SHARE / '프로토콜과개발결과.md'
    report.write_text('\n'.join(rationale), encoding='utf-8')
    write_json(p.OUT / 'verification.json', {'passed': True, 'requests_verified': 48, 'new_development_calls': 16,
              'holdout_generated': 0, 'source_manifest_sha256': p.base.fingerprint(plan), 'raw_response_sha256': hashes,
              'report_sha256': digest(report.read_bytes()), 'finalizer_sha256': digest(Path(__file__).read_bytes()),
              'test_sha256': digest((ROOT / 'tests/test_psyche_thought.py').read_bytes())})
    write_json(ROOT / 'config/research-checkpoint-v10.json', {
        'date': '2026-11-01', 'previous': 'config/research-checkpoint-v09.json',
        'status': 'Source-grounded thought protocol fixed; development 16 responses completed; holdout 32 not generated',
        'protocol': str(p.SPEC.relative_to(ROOT)), 'development_summary': str((p.OUT / 'development-summary.json').relative_to(ROOT)),
        'clinical_review': 'candidate procedure prepared, zero expert ratings obtained',
        'clinical_improvement_claim': False, 'new_paid_api_calls': 0, 'old_experiments_preserved': True,
        'next': 'Review development evidence and fix the clinical observation procedure before assessing sealed holdout outcomes',
        'report': str(report.relative_to(ROOT))})
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
