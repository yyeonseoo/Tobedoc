"""Concise Korean three-page team report from already verified local results."""
import json
import argparse
from pathlib import Path

from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT

from common import ROOT

OUTPUT=ROOT/"share/final-report-20261030/환자 페르소나 정량 분석 보고서.docx"


def font(run,size=None,bold=None):
    run.font.name="Arial Unicode MS"
    fonts=run._element.get_or_add_rPr().get_or_add_rFonts()
    for key in list(fonts.attrib):
        if "theme" in key.lower(): del fonts.attrib[key]
    for key in ["ascii","hAnsi","eastAsia","cs"]: fonts.set(qn("w:"+key),"Arial Unicode MS")
    run.font.color.rgb=RGBColor(0,0,0)
    if size: run.font.size=Pt(size)
    if bold is not None: run.bold=bold


def paragraph(doc,text,bold=False,small=False):
    p=doc.add_paragraph()
    p.paragraph_format.space_after=Pt(5 if not small else 3)
    p.paragraph_format.line_spacing=Pt(16 if not small else 13)
    p.paragraph_format.widow_control=True
    font(p.add_run(text),9.5 if small else 11,bold)
    return p


def heading(doc,text,level=1):
    p=doc.add_paragraph(text,style=f"Heading {level}")
    p.paragraph_format.keep_with_next=True
    p.paragraph_format.space_before=Pt(10)
    p.paragraph_format.space_after=Pt(5)
    p.paragraph_format.line_spacing=Pt(19 if level==1 else 17)
    for r in p.runs: font(r,13 if level==1 else 11.5,True)
    return p


def table(doc,headers,rows,widths,numeric=()):
    t=doc.add_table(rows=1,cols=len(headers))
    t.alignment=WD_TABLE_ALIGNMENT.CENTER
    t.autofit=False
    for i,w in enumerate(widths): t.columns[i].width=Inches(w)
    for j,text in enumerate(headers): t.rows[0].cells[j].text=text
    for row in rows:
        cells=t.add_row().cells
        for j,text in enumerate(row): cells[j].text=str(text)
    for i,row in enumerate(t.rows):
        trpr=row._tr.get_or_add_trPr()
        no_split=OxmlElement("w:cantSplit");trpr.append(no_split)
        if i==0:
            repeat=OxmlElement("w:tblHeader");trpr.append(repeat)
        for j,cell in enumerate(row.cells):
            cell.width=Inches(widths[j]);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            pr=cell._tc.get_or_add_tcPr()
            margins=OxmlElement("w:tcMar")
            for edge in ["top","left","bottom","right"]:
                el=OxmlElement("w:"+edge);el.set(qn("w:w"),"95");el.set(qn("w:type"),"dxa");margins.append(el)
            pr.append(margins)
            borders=OxmlElement("w:tcBorders")
            for edge in ["top","left","bottom","right"]:
                el=OxmlElement("w:"+edge);el.set(qn("w:val"),"single");el.set(qn("w:sz"),"4");el.set(qn("w:color"),"D9D9D9");borders.append(el)
            pr.append(borders)
            if i==0:
                shading=OxmlElement("w:shd");shading.set(qn("w:fill"),"E8EEF3");pr.append(shading)
            for p in cell.paragraphs:
                p.paragraph_format.space_after=Pt(0)
                p.paragraph_format.line_spacing=Pt(14.5)
                p.alignment=WD_ALIGN_PARAGRAPH.RIGHT if j in numeric and i>0 else WD_ALIGN_PARAGRAPH.LEFT
                for r in p.runs: font(r,10.3,i==0)
    doc.add_paragraph().paragraph_format.space_after=Pt(0)
    return t


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--replace",action="store_true",help="Replace only this generated report during layout repair")
    args=parser.parse_args()
    a=ROOT/"analysis"
    original=json.loads((a/"automatic-features-v01/native-features-20261030/paired-contrasts.json").read_text())
    alias=json.loads((a/"thought-alias-v01/thought-alias-20261030/results.json").read_text())
    cross=json.loads((a/"framework-pilot-v01/framework-pilot-20261030/results.json").read_text())
    delta=lambda f:next(r["mean_difference_from_plain"] for r in original if r["style"]=="tangent" and r["feature"]==f)
    contrasts=cross["dialogue_mean_matched_contrasts"]
    doc=Document()
    sec=doc.sections[0]
    sec.page_width=Inches(8.5);sec.page_height=Inches(11)
    sec.top_margin=Inches(.67);sec.bottom_margin=Inches(.67)
    sec.left_margin=Inches(.75);sec.right_margin=Inches(.75)
    sec.footer_distance=Inches(.3)
    for name in ["Normal","Title","Subtitle","Heading 1","Heading 2"]:
        s=doc.styles[name]
        s.font.name="Arial Unicode MS";s.font.size=Pt(11);s.font.color.rgb=RGBColor(0,0,0)
        fonts=s._element.get_or_add_rPr().get_or_add_rFonts()
        for key in list(fonts.attrib):
            if "theme" in key.lower(): del fonts.attrib[key]
        for key in ["ascii","hAnsi","eastAsia","cs"]: fonts.set(qn("w:"+key),"Arial Unicode MS")
    for border in list(doc.styles.element.iter(qn("w:pBdr"))): border.getparent().remove(border)
    for fonts in doc.styles.element.iter(qn("w:rFonts")):
        for key in list(fonts.attrib):
            if "theme" in key.lower(): del fonts.attrib[key]
    doc.core_properties.title="환자 페르소나 발화의 정량 분석"
    doc.core_properties.subject="프로토타입 연구 결과와 후속 검증 계획"
    doc.core_properties.author="연구팀"
    doc.core_properties.comments=""
    p=doc.add_paragraph("환자 페르소나 발화의 정량 분석",style="Title")
    p.paragraph_format.space_after=Pt(5)
    p.paragraph_format.line_spacing=Pt(26)
    for r in p.runs: font(r,19,True)
    paragraph(doc,"프로토타입 연구 결과와 후속 검증 계획",bold=True)
    paragraph(doc,"2026년 10월 30일  |  팀 논의용 연구 보고",small=True)

    heading(doc,"연구 목적")
    paragraph(doc,"실제 조현병 환자의 발화 자료를 확보하기 어려워, 기존 환자 페르소나가 어떤 특징을 지시하고 그 특징이 실제 발화에서 어떻게 나타나는지 먼저 분석했다. 이번 목표는 조현병 모사의 정확도를 평가하는 것이 아니라, 기존 시스템의 출력 특성을 정량화하고 측정·구현상의 한계를 찾는 것이다.")
    paragraph(doc,"분석 도구와 개발 파일럿을 완료했다. 말투 지시에 따른 수치 차이는 관찰됐지만, 문장 간 의미 유사도·질문 관련성·입력 내용 반영은 서로 다르게 움직였다. 이를 하나의 임상 점수로 합치지 않고 각각 보고했다.")

    heading(doc,"분석 방법")
    paragraph(doc,"공개 코드를 고정 버전으로 보존하고 프롬프트를 로컬 Ollama의 Qwen3-14B에 이식했다. PATIENT-Ψ 원 논문의 GPT-4 실험이나 원형 앱 전체를 재현한 것은 아니다. 영어로 발화를 생성했고, 질문은 네 개로 고정했다. 각 조건은 새 대화로 시작하며 다음 질문에 실제 이전 응답을 포함했다.")
    paragraph(doc,"Python과 macOS NaturalLanguage로 17개 feature를 추출했다. 발화량은 단어 수·문장 수·문장 길이, 어휘 특성은 고정 20단어 창의 다양도와 반복 비율, 의미 관계는 인접 문장·질문·초기 상황과의 코사인 유사도로 기술했다. 자동 품사·어휘 겹침 등은 보조 지표로 남겼다. 임베딩은 영어 512차원 revision 1을 고정했다.")
    paragraph(doc,"전문가 등급, S/L/G 점수, LLM judge는 사용하지 않았다. 조건 차이는 동일 상황·질문을 대응시켜 계산했으며, 턴들을 독립 환자로 간주한 유의확률은 제시하지 않았다.")

    heading(doc,"수행한 주요 실험")
    table(doc,["실험","생성 규모","비교 내용"],[
        ["원형 스타일 분석","36대화 144응답","Abe 한 인물의 세 상황과 여섯 말투"],
        ["단일 필드 연결 실험","24대화 96응답","자동사고 필드 하나만 연결해 원형과 비교"],
        ["말투 모듈 비교","18대화 72응답","허구 인물 세 명에서 단순 지시와 두 출처 모듈 비교"]
    ],[1.65,1.5,3.85])
    paragraph(doc,"모든 대화는 4턴이다. 앞의 두 실험은 같은 인물의 반복·상황별 출력이며, 마지막 실험도 실제 환자 자료가 아니다. 서로 다른 실행의 응답을 합쳐 독립 표본 수로 세지 않았다.",small=True)

    doc.add_page_break()
    heading(doc,"주요 결과")
    heading(doc,"문장 사이 유사도와 주제 관련성은 달랐다",2)
    paragraph(doc,f"원형 분석에서 tangent의 인접 문장 유사도는 plain보다 평균 {delta('adjacent_cos_mean'):+.3f} 낮았고, 세 상황과 두 반복의 여섯 대응 블록에서 모두 같은 방향이었다. 그러나 초기 상황과 응답의 유사도는 {delta('topic_answer_cos'):+.3f}로 낮아지지 않았다. 문장끼리 덜 비슷하다는 것만으로 주제를 더 많이 이탈했다고 결론 내릴 수 없었다.")
    paragraph(doc,"지표 점검에서는 문장 순서를 뒤집어도 인접 유사도 평균이 그대로였고, 첫 문장을 복제하면 오히려 높아졌다. 이 값은 임베딩 유사도이며 논리적 연결성·사고장애의 검증된 점수가 아니다. 문장 내부의 해석 가능성 역시 이번 지표로 입증하지 않았다.[3]")

    heading(doc,"입력 전달 수정이 모든 지표를 높이지는 않았다",2)
    pa=alias["primary_T1_by_style"]["plain"]["alias_minus_native"]
    ta=alias["primary_T1_by_style"]["tangent"]["alias_minus_native"]
    paragraph(doc,f"공개 예제의 자동사고 필드명이 formatter와 달라 실제 입력에 undefined가 전달되는 문제를 확인했다. 다른 지시는 그대로 두고 이 필드만 연결한 결과, 첫 응답과 해당 자동사고 문구의 유사도 변화는 plain {pa:+.3f}, tangent {ta:+.3f}였다. 증가한 블록은 각각 4/6, 2/6이었다. 입력 누락 수정과 출력의 일괄적인 향상을 같은 것으로 볼 수 없었다.")
    paragraph(doc,"이 유사도는 제공 문구와의 가까움만 측정한다. 실제 믿음의 구현을 판정하지 않으며, undefined 제거 효과와 의미 정보 추가 효과도 분리하지 못했다.")

    heading(doc,"같은 verbose 지시도 변화의 양상이 달랐다",2)
    paragraph(doc,"단순 지시, PATIENT-Ψ 스타일 지시, PatientSim 성격 지시를 같은 사례·질문·기반 LLM 위에서 비교했다. 원형 시스템 전체의 비교가 아니다. 개별 문장 상한은 공통 5문장으로 맞췄고, PatientSim의 응급실·언어능력·회상·혼란 모듈은 넣지 않았다.[1,2]")
    table(doc,["지시 조건","plain","verbose","차이"],[
        [label,f"{contrasts[p]['word_count']['plain_mean']:.1f}",f"{contrasts[p]['word_count']['verbose_mean']:.1f}",f"+{contrasts[p]['word_count']['verbose_minus_plain']:.1f}"]
        for p,label in [("simple_baseline","단순 지시"),("patient_psi_style","PATIENT-Ψ 말투"),("patientsim_style","PatientSim 말투")]
    ],[2.65,1.45,1.45,1.45],numeric=(1,2,3))
    paragraph(doc,"단위는 응답당 평균 단어 수다. 세 인물의 대화별 평균을 동일 가중했으며 조건별 반복은 한 번이다. 모든 조건에서 verbose의 발화량이 증가했지만, PatientSim의 큰 차이는 plain이 더 짧았던 영향도 컸다. 더 우수한 모델이라는 뜻은 아니다.",small=True)
    sim=contrasts["patientsim_style"]
    paragraph(doc,f"PatientSim 말투에서 인접 문장 유사도는 {sim['adjacent_cos_mean']['verbose_minus_plain']:+.3f} 증가한 반면 질문 유사도는 {sim['question_answer_cos']['verbose_minus_plain']:+.3f} 낮아졌다. 또 전체 72응답 중 64개가 정확히 5문장이었고 8개는 제한을 넘었다. 발화량 차이를 문장 수가 상한에 집중된 조건의 결과로 해석해야 한다.")

    doc.add_page_break()
    heading(doc,"현재 결론과 검증하지 못한 부분")
    paragraph(doc,"현재 확보한 결과는 공개 지시가 만드는 언어적 특성에 대한 개발 파일럿이다. 동일한 말투 명칭도 출처별 지시가 다르고, 발화량·문장 간 유사도·질문 관련성이 함께 좋아지거나 나빠지는 것은 아니었다. 향후 비교에서도 원문 지시, 실제 입력, 출력 feature를 구분해 추적할 필요가 있다.")
    paragraph(doc,"해석 범위는 다음과 같이 제한된다.")
    for text in [
        "실제 조현병 환자 발화나 정식 전문가 평가와 비교하지 않았다. 조현병 재현 정확도·진단 성능·교육 효과를 주장할 수 없다.",
        "기반 모델은 Qwen3-14B 하나이고 사례 수가 적다. 교차 모듈 파일럿은 허구 인물 세 명과 조건당 seed 하나에 한정되며, 평가용 인물은 아직 생성하지 않았다.",
        "코사인 유사도는 임상적 coherence가 아니다. 대명사 비율은 지시 대상의 모호함을, 어휘 다양도는 의미의 풍부함을 직접 판정하지 않는다.",
        "원문 행동 요구 19개 중 7개에만 부분적인 수치 대리값을 연결했고 12개는 직접 측정하지 못했다. 미측정 항목을 모델의 구현 실패로 세어서는 안 된다."
    ]: paragraph(doc,"• "+text)

    heading(doc,"후속 연구에서 할 수 있는 일")
    paragraph(doc,"우선 현재 자료로 보고를 마감하고, 공통 5문장 지시 아래의 출력 특성과 측정 한계를 결과로 남긴다. 추가 실험은 원하는 주장에 필요한 것만 선택한다.")
    heading(doc,"출력 제한의 영향 확인",2)
    paragraph(doc,"문장 수 제한과 무관한 말투 효과를 보려면, 단순 지시 조건에서 plain/verbose와 5문장 제한 유무를 교차한 작은 실험을 할 수 있다. 기존 개발 사례 세 개와 4턴을 사용하면 12대화·48응답이다. 모델·질문·seed·토큰 상한은 고정하고 문장 제한 문구만 바꾼다. 출력 잘림도 기록한다. 이 실험은 아직 수행하지 않았고, 현재 조건에 한정해 보고한다면 생략할 수 있다.")
    heading(doc,"임상 개념 대응과 새 사례 확인",2)
    paragraph(doc,"교수님 자문에서는 문장 내부의 해석 가능성과 문장 간 조직을 구분할 기준, 현재 지표를 임상 개념과 연결할 수 있는 범위를 확인한다. 자문을 전체 출력의 임상 검증으로 표현하지 않는다. 이후 필요한 지표와 출력 정책을 고정한 뒤, 미사용 인물에서 재확인하고 반복 수를 늘릴 수 있다. 개선안은 여러 사례에서 같은 문제가 확인될 때 한 요소씩 시험한다.")

    heading(doc,"출처와 재현 기록")
    paragraph(doc,"[1] PATIENT-Ψ 공개 코드  ruiyiw/patient-psi  고정 커밋 de72a768.\n[2] PatientSim 공개 코드  dek924/PatientSim  고정 커밋 9c262e69.\n[3] He 등. Reduced linguistic coherence in psychosis defies semantic similarity accounts. Scientific Reports 2026;16:7799. doi:10.1038/s41598-026-39025-1.",small=True)
    paragraph(doc,"원문·프롬프트·모델 설정·코드·feature 파일은 persona-audit 연구 폴더에 보존했다. 원형 분석, 단일 필드 실험, 교차 모듈 결과는 각각 automatic-features-v01, thought-alias-v01, framework-pilot-v01에 있다. 최신 파일럿은 테스트 58개와 캐시 기반 수치 재계산을 통과했다. 이는 계산 재현성 확인이며 임상 타당도 검증은 아니다.",small=True)

    footer=sec.footer.paragraphs[0]
    footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    r=footer.add_run();font(r,9)
    f=OxmlElement("w:fldSimple");f.set(qn("w:instr"),"PAGE");r._r.addnext(f)
    OUTPUT.parent.mkdir(parents=True,exist_ok=True)
    if OUTPUT.exists() and not args.replace: raise FileExistsError("Preserve an existing report; choose a new version")
    doc.save(OUTPUT)
    print(OUTPUT)


if __name__=="__main__": main()
