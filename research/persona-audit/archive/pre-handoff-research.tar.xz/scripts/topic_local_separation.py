"""Separate task-topic association and local semantic arrangement using cache only.

All outputs are descriptive posthoc measurements. No LLM, embeddings, installs,
network calls, clinical labels, or modifications to previous results.
"""
import itertools
import json
import math
from statistics import mean

from common import ROOT, digest, write_json
from run_local_pilot import fingerprint, now
from extract_automatic_features import cosine, words, text_id
from analyze_topic_trajectory import verify_sources, exact_utf16, make_controls, other_topic
from topic_selection_probe import event_metrics, paired

SPEC = ROOT/'config/topic-local-separation-v01.json'
OUT = ROOT/'analysis/topic-local-separation-v01'
CACHE = ROOT/'analysis/topic-trajectory-v01'
METRICS = ('requested_refs','topic_association','topic_margin','adjacent_cos',
           'all_pairs_cos','adjacency_excess','word_count','sentence_count')


def read(path):
    return json.loads(path.read_text())


def checked_cos(a, b):
    for v in (a,b):
        if v is None or not v or not all(math.isfinite(x) for x in v) or not any(x != 0 for x in v):
            raise ValueError('Missing, zero, or non-finite vector')
    value = cosine(a,b)
    if value is None:
        raise ValueError('Undefined cosine')
    return value


def local_metrics(vectors):
    if len(vectors)<2:
        return dict(adjacent_cos=None,all_pairs_cos=None,adjacency_excess=None)
    adjacent = mean(checked_cos(a,b) for a,b in zip(vectors,vectors[1:]))
    background = mean(checked_cos(a,b) for a,b in itertools.combinations(vectors,2))
    return dict(adjacent_cos=adjacent,all_pairs_cos=background,adjacency_excess=adjacent-background)


def association(vectors, prototypes):
    if not vectors or not prototypes:
        raise ValueError('Empty association input')
    return mean(max(checked_cos(v,p) for p in prototypes) for v in vectors)


def measure(sentences, vectors, requested, other):
    r,o=association(vectors,requested),association(vectors,other)
    return {**local_metrics(vectors),'topic_association':r,'other_topic_association':o,
            'topic_margin':r-o,'word_count':sum(len(words(s)) for s in sentences),
            'sentence_count':len(sentences)}


def load():
    source,cases,files=verify_sources()
    # Verify every source file recorded by the earlier trajectory analysis.
    trajectory=read(CACHE/'results.json')
    for item in trajectory['provenance']['source_files']:
        assert digest((ROOT/item['path']).read_bytes())==item['sha256'],item['path']
    inputs=read(CACHE/'native-input.json')
    native,lock=read(CACHE/'native-output.json'),read(CACHE/'native-cache.json')
    swift=ROOT/'scripts/NativeFeatures.swift'
    assert fingerprint({'inputs':inputs,'swift_sha256':digest(swift.read_bytes())})==lock['key']
    assert digest((CACHE/'native-output.json').read_bytes())==lock['output_sha256']
    assert native['embeddingDimension']==512 and native['embeddingRevision']==1
    indexed={r['id']:r for r in native['records']}
    assert set(indexed)=={r['id'] for r in inputs}
    for item in inputs:
        assert item['id']==text_id(item['text'])
        for sentence in indexed[item['id']]['sentences']:
            assert exact_utf16(item['text'],sentence['utf16Start'],sentence['utf16Length'])==sentence['text']
            assert len(sentence['vector'])==512
            checked_cos(sentence['vector'],sentence['vector'])
    spec=read(ROOT/'config/topic-trajectory-v01.json')
    prototypes={t:[indexed[text_id(p)]['vector'] for p in info['prototypes']]
                for t,info in spec['topics'].items()}
    files += [CACHE/name for name in ('results.json','native-input.json','native-output.json','native-cache.json')]
    files += [ROOT/'config/topic-trajectory-v01.json',SPEC,swift]
    return source,cases,spec,indexed,prototypes,files,native


def calculate():
    source,cases,spec,indexed,prototypes,files,native=load()
    case_by_id={c['condition_id']:c for c in cases}
    controls=make_controls(spec)
    sentences_by_id={}
    rows,swaps,insertions,order_checks=[],[],[],[]
    for original in source['responses']:
        cid=original['condition_id']
        case=case_by_id[cid]
        topic=next(t for t,i in spec['topics'].items() if i['case']==original['profile_id'] and i['event']==original['target_event'])
        other=other_topic(spec,topic)
        record=indexed[text_id(original['response_text'])]
        sentences=[s['text'] for s in record['sentences']]
        vectors=[s['vector'] for s in record['sentences']]
        scores=measure(sentences,vectors,prototypes[topic],prototypes[other])
        facts=event_metrics(original['response_text'],case['facts'],original['target_event'])
        assert facts['requested_count']==original['requested_count']
        assert facts['other_count']==original['other_count']
        row={k:original[k] for k in ('condition_id','profile_id','target_event','variant_id','repeat_index','style_id','question','response_text')}
        row.update(scores,topic=topic,other_topic=other,requested_refs=facts['requested_count'],
                   other_refs=facts['other_count'],sentences=sentences,
                   sentence_topic_association=[association([v],prototypes[topic]) for v in vectors],
                   adjacent_pair_cos=[checked_cos(a,b) for a,b in zip(vectors,vectors[1:])])
        rows.append(row)
        sentences_by_id[cid]=(sentences,vectors)
        swapped_scores=measure(sentences,vectors,prototypes[other],prototypes[topic])
        swaps.append({'condition_id':cid,'requested_refs_original':facts['requested_count'],
                      'requested_refs_swapped':facts['other_count'],
                      'topic_association_original':scores['topic_association'],
                      'topic_association_swapped':scores['other_topic_association'],
                      'association_drop':scores['topic_margin'],
                      'adjacent_cos_change':swapped_scores['adjacent_cos']-scores['adjacent_cos'] if len(vectors)>=2 else None,
                      'scope':'Same answer, other requested event; not new generated reply'})
        reversed_scores=measure(list(reversed(sentences)),list(reversed(vectors)),prototypes[topic],prototypes[other])
        order_checks.append({'condition_id':cid,**{key+'_absolute_delta':abs(scores[key]-reversed_scores[key])
                                                  if scores[key] is not None else None
                                                  for key in ('adjacent_cos','all_pairs_cos','adjacency_excess','topic_association')}})
        insertion={}
        for kind in ('requested','other'):
            control=next(c for c in controls if c['id']==f'holdout-{topic}-{kind}_elaboration')
            v=indexed[text_id(control['text'])]['vector']
            pos=len(vectors)//2
            measured=measure(sentences[:pos]+[control['text']]+sentences[pos:],vectors[:pos]+[v]+vectors[pos:],prototypes[topic],prototypes[other])
            insertion[kind]={'control_id':control['id'],'text':control['text'],**measured}
        insertions.append({'condition_id':cid,'insertion_position_zero_based':len(vectors)//2,**insertion,
                           'other_minus_requested':{m:insertion['other'][m]-insertion['requested'][m] for m in METRICS if m!='requested_refs'}})
    summaries=[]
    for style in read(SPEC)['styles']:
        group=[r for r in rows if r['style_id']==style]
        summaries.append({'style':style,'replies':len(group),'requested_refs_total':sum(r['requested_refs'] for r in group),
                          'other_refs_total':sum(r['other_refs'] for r in group),
                          'at_least_three_sentences':sum(r['sentence_count']>=3 for r in group),
                          **{m:mean(r[m] for r in group if r[m] is not None) for m in METRICS}})
    prefixes=[]
    for tangent in [r for r in rows if r['style_id']=='tangent']:
        base=next(r for r in rows if r['style_id']=='verbose' and all(r[k]==tangent[k] for k in ('profile_id','target_event','variant_id','repeat_index')))
        n=min(tangent['sentence_count'],base['sentence_count'])
        entry={'tangent_id':tangent['condition_id'],'verbose_id':base['condition_id'],'matched_sentence_count':n}
        for label,row in (('tangent',tangent),('verbose',base)):
            texts,vectors=sentences_by_id[row['condition_id']]
            entry[label]=measure(texts[:n],vectors[:n],prototypes[row['topic']],prototypes[row['other_topic']])
        entry['relative_word_difference']=abs(entry['tangent']['word_count']-entry['verbose']['word_count'])/max(entry['tangent']['word_count'],entry['verbose']['word_count'])
        entry['differences']={m:entry['tangent'][m]-entry['verbose'][m] for m in METRICS if m!='requested_refs'}
        prefixes.append(entry)
    control_scores=[]
    for c in controls:
        if c['kind']!='requested':
            continue
        v=indexed[text_id(c['text'])]['vector']
        r,o=association([v],prototypes[c['topic']]),association([v],prototypes[c['other_topic']])
        control_scores.append({**c,'requested_association':r,'other_association':o,'margin':r-o,'positive_direction':r>o})
    eligible=[r for r in prefixes if r['matched_sentence_count']>=3]
    result={'analysis_id':read(SPEC)['analysis_id'],'status':'posthoc_descriptive_measurement_audit',
            'existing_replies':48,'sentences':sum(r['sentence_count'] for r in rows),
            'summaries':summaries,'tangent_minus_verbose':{m:paired(rows,'tangent','verbose',m) for m in METRICS},
            'subgroups':{key:{value:{m:paired([r for r in rows if r[key]==value],'tangent','verbose',m) for m in ('topic_margin','adjacent_cos','adjacency_excess')}
                              for value in sorted({r[key] for r in rows})} for key in ('profile_id','target_event','variant_id','repeat_index')},
            'question_swaps':{'count':48,'mean_association_drop':mean(r['association_drop'] for r in swaps),
                              'positive_direction':sum(r['association_drop']>0 for r in swaps),
                              'adjacent_change_max':max(abs(r['adjacent_cos_change']) for r in swaps if r['adjacent_cos_change'] is not None),
                              'requested_refs_original_total':sum(r['requested_refs_original'] for r in swaps),
                              'requested_refs_swapped_total':sum(r['requested_refs_swapped'] for r in swaps)},
            'authored_controls':{'count':len(control_scores),'positive_direction':sum(c['positive_direction'] for c in control_scores),
                                 'mean_margin':mean(c['margin'] for c in control_scores),'failures':[c for c in control_scores if not c['positive_direction']]},
            'insertion_summary':{'count':48,**{m:{'mean_other_minus_requested':mean(r['other_minus_requested'][m] for r in insertions),
                                                     'negative':sum(r['other_minus_requested'][m]<0 for r in insertions),
                                                     'positive':sum(r['other_minus_requested'][m]>0 for r in insertions)}
                                                 for m in ('topic_association','adjacent_cos','adjacency_excess','word_count')}},
            'prefix_summary':{'blocks':len(prefixes),'eligible_at_least_three_sentences':len(eligible),
                              'word_difference_at_most_10_percent':sum(r['relative_word_difference']<=.1 for r in eligible),
                              'mean_relative_word_difference':mean(r['relative_word_difference'] for r in eligible),
                              'mean_tangent_minus_verbose':{m:mean(r['differences'][m] for r in eligible) for m in ('adjacent_cos','adjacency_excess','topic_margin')}},
            'reversal_recheck':{'scope':'Known algebraic property, not a novel coherence experiment',
                                'count':len(order_checks),'max_absolute_delta':max(v for r in order_checks for k,v in r.items() if k!='condition_id' and v is not None)},
            'embedding_backend':{k:v for k,v in native.items() if k!='records'},
            'cost':{'new_generation_calls':0,'new_embedding_calls':0,'paid_api_calls':0,'llm_judge_calls':0,'downloads':0},
            'provenance':{str(p.relative_to(ROOT)):digest(p.read_bytes()) for p in files}}
    return result,{'responses':rows,'question_swap_controls':swaps,'insertion_controls':insertions,
                   'prefix_pairs':prefixes,'authored_controls':control_scores,'reversal_checks':order_checks}


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    plan={'spec':read(SPEC),'spec_sha256':digest(SPEC.read_bytes()),
          'script_sha256':digest((ROOT/'scripts/topic_local_separation.py').read_bytes()),
          'scope':'Existing outputs already examined previously. Frozen implementation before this recalculation; not preregistration.',
          'prepared_at_utc':now()}
    path=OUT/'measurement-plan.json'
    if path.exists():
        prior=read(path)
        assert all(prior[k]==plan[k] for k in ('spec','spec_sha256','script_sha256')),'Preserve changed plan under new version'
    else:
        write_json(path,plan)
    result,details=calculate()
    write_json(OUT/'results.json',result)
    write_json(OUT/'response-details.json',details)
    print(json.dumps({k:v for k,v in result.items() if k in ('existing_replies','sentences','summaries','authored_controls','insertion_summary','prefix_summary','question_swaps')},ensure_ascii=False))


if __name__=='__main__':
    main()
