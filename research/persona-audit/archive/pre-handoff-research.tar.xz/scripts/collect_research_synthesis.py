"""Read existing results into a provenance ledger. No inference or reruns.

This checks selected summary values, not every raw response or clinical claim.
Team presentation numbers remain explicitly presentation-reported.
"""
import json
from pathlib import Path
from common import ROOT, digest, write_json

OUT = ROOT / 'analysis/research-synthesis-v01'


def read(relative):
    return json.loads((ROOT / relative).read_text())


def main():
    sources = ['analysis/integrated-checkpoint-v05/results.json',
               'analysis/disclosure-transfer-v01/results.json',
               'analysis/topic-local-separation-v01/results.json',
               'analysis/measurement-external-v03/results.json',
               'analysis/psyche-controls-v01/summary.json',
               'analysis/psyche-thought-v01/development-summary.json',
               'config/research-checkpoint-v06.json',
               'config/research-checkpoint-v07.json',
               'share/overnight-completion-v01/README.ko.md']
    integrated, disclosure, topic, external, controls, thought = [read(p) for p in sources[:6]]
    axes = {r['axis']: r for r in integrated['axes']}
    assert integrated['distinct_replies_across_four_main_tasks'] == 240
    assert disclosure['actual_replies'] == 32
    assert external['eligible_records'] == 1542
    assert controls['origins'] == {'new_local_call': 28, 'exact_cache': 4}
    assert thought['development_responses'] == 16 and thought['holdout_responses'] == 0
    deck = Path('/Users/ohs/Downloads/투비닥터_중간보고서_MindCraft.pptx')
    ledger = {
        'date': '2026-11-01',
        'verification_level': 'Selected existing result artifacts read and checked; NOT a new full raw-data replay or clinical validation',
        'team_reported_not_recomputed': {
            'source': str(deck), 'source_sha256': digest(deck.read_bytes()),
            'classification_auroc': [0.782, 0.594],
            'generation': {'reported_answers_per_generator': 114, 'generators': ['Claude', 'GPT-4.1'],
                           'intended_vs_blind_llm_severity_rho': .89,
                           'no_metric_passed_both_tracking_and_control_discrimination': True},
            'localization': {'reported_overlap': .41, 'reported_chance': .25, 'reported_p': .001,
                             'status': 'exploratory; raw spans, null model, clustering and selection procedure not linked in this synthesis'}
        },
        'local_persona_instruction_audit': {
            'response_records_in_four_main_tasks_including_followup': 240,
            'not_independent_patients_or_unique_texts': True,
            'backbone_scope': 'Prompt modules ported to Qwen, not native-framework efficacy',
            'verbosity': axes['verbal_productivity']['facts'],
            'disclosure': axes['disclosure_and_skepticism']['facts'],
            'downplaying_scope': axes['downplaying']['meaning_ko'],
            'numeric_repair_not_reliable_default': {
                k: v['adopt_as_reliable_default'] for k, v in integrated['followup_adoption'].items()}
        },
        'disclosure_transfer': {
            'responses': 32, 'cases': 2, 'primary_interaction': disclosure['primary']['mean_interaction'],
            'prewritten_descriptive_rule_met': disclosure['decision_rule_met'],
            'meaning': 'Source-value alias identification changed with question order and instruction; not proof of clinical guardedness'} ,
        'topic_measurement': {
            'responses_reused': topic['existing_replies'],
            'requested_refs': {r['style']: [r['requested_refs_total'], 48] for r in topic['summaries']},
            'adjacent_cos_tangent_minus_verbose': topic['tangent_minus_verbose']['adjacent_cos']['mean'],
            'other_vs_requested_insertion_adjacent_increased': topic['insertion_summary']['adjacent_cos']['positive'],
            'insertion_comparisons': topic['insertion_summary']['count']
        },
        'external_measurement': {
            'source_records': external['source_records'], 'eligible': external['eligible_records'],
            'articles': external['articles'], 'systems': external['systems'],
            'adjacent_cos': external['correlations']['adjacent_cos'],
            'scope': 'One OS embedding backend, general-news summaries, posthoc boundary amendment; not all semantic metrics or psychiatric validation'} ,
        'psyche_controls': {'effective_responses': 32, 'origins': controls['origins'],
            'arms': [{k: r[k] for k in ['arm', 'target_hits', 'positive_pairs', 'mean_long_minus_short_words']} for r in controls['arms']],
            'decision': controls['decision']},
        'psyche_thought_development': thought,
        'cost_this_synthesis': {'new_generation': 0, 'new_judge_calls': 0, 'installs': 0, 'downloads': 0,
                               'old_data_deleted': 0, 'experiments_automatically_resumed': False},
        'source_hashes': {p: digest((ROOT / p).read_bytes()) for p in sources}
    }
    write_json(OUT / 'evidence-ledger.json', ledger)
    write_json(OUT / 'verification.json', {'selected_assertions_passed': True,
               'ledger_sha256': digest((OUT / 'evidence-ledger.json').read_bytes()),
               'collector_sha256': digest(Path(__file__).read_bytes()),
               'raw_team_corpus_recomputed': False})
    print(json.dumps({'local_main_task_response_records': 240, 'disclosure_transfer_responses': 32,
        'external_eligible': 1542, 'team_raw_corpus_recomputed': False, 'new_generation': 0}))


if __name__ == '__main__':
    main()
