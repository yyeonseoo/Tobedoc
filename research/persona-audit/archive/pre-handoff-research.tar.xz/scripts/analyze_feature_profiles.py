"""CPU-only descriptive profiling and exploratory known-style discrimination."""
import argparse
from collections import Counter
import json
import math
from pathlib import Path
import statistics

from common import ROOT, digest, write_json
from extract_automatic_features import STYLES, mean


def nearest_centroid(train, test, features):
    # All learned preprocessing is restricted to the training situations.
    locations, scales = {}, {}
    for feature in features:
        observed = [r["feature_means"][feature] for r in train if r["feature_means"][feature] is not None]
        locations[feature] = mean(observed) if observed else 0.0
        imputed = [r["feature_means"][feature] if r["feature_means"][feature] is not None else locations[feature] for r in train]
        scales[feature] = statistics.pstdev(imputed) or 1.0
    def vector(row):
        return [((row["feature_means"][f] if row["feature_means"][f] is not None else locations[f])-locations[f])/scales[f] for f in features]
    centers = {}
    for style in STYLES:
        values = [vector(r) for r in train if r["style_id"] == style]
        if not values:
            raise ValueError("Missing training class")
        centers[style] = [mean([v[i] for v in values]) for i in range(len(features))]
    predictions = []
    for row in test:
        v = vector(row)
        predicted = min(STYLES, key=lambda style: sum((x-y)**2 for x, y in zip(v, centers[style])))
        predictions.append({"condition_id": row["condition_id"], "true_style": row["style_id"], "predicted_style": predicted})
    return predictions


def performance(predictions):
    confusion = {style: {other: 0 for other in STYLES} for style in STYLES}
    for row in predictions:
        confusion[row["true_style"]][row["predicted_style"]] += 1
    f1 = []
    for style in STYLES:
        tp = confusion[style][style]
        fp = sum(confusion[s][style] for s in STYLES if s != style)
        fn = sum(confusion[style][s] for s in STYLES if s != style)
        f1.append(2*tp/(2*tp+fp+fn) if 2*tp+fp+fn else 0.0)
    return {"n_dialogues": len(predictions),
            "accuracy": sum(r["true_style"] == r["predicted_style"] for r in predictions)/len(predictions),
            "macro_f1": mean(f1), "confusion": confusion}


def eta_squared(rows, feature):
    valid = [r for r in rows if r["feature_means"][feature] is not None]
    overall = mean([r["feature_means"][feature] for r in valid])
    if overall is None:
        return None
    total = sum((r["feature_means"][feature]-overall)**2 for r in valid)
    if total == 0:
        return 0.0
    between = 0.0
    for style in STYLES:
        values = [r["feature_means"][feature] for r in valid if r["style_id"] == style]
        if values:
            between += len(values)*(mean(values)-overall)**2
    return between/total


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", default="native-features-20261030")
    args = parser.parse_args()
    out = ROOT / "analysis/automatic-features-v01" / args.run_id
    rows = json.loads((out / "dialogue-features.json").read_text())
    if len(rows) != 36 or any(r["turns"] != 4 or r["arm"] != "native_demo_mapping" for r in rows):
        raise ValueError("Requires the complete frozen 36-dialogue original-mapping corpus")
    plan_path = ROOT / "config/feature-profile-analysis-v01.json"
    plan = json.loads(plan_path.read_text())
    sets = dict(plan["feature_sets"])
    sets["all_17"] = sets["surface_8"] + sets["similarity_9"]
    results = {}
    situations = sorted({r["profile_id"] for r in rows})
    for set_name, features in sets.items():
        predictions, folds = [], []
        for heldout in situations:
            train = [r for r in rows if r["profile_id"] != heldout]
            test = [r for r in rows if r["profile_id"] == heldout]
            predicted = nearest_centroid(train, test, features)
            predictions += predicted
            folds.append({"heldout_situation": heldout, **performance(predicted)})
        results[set_name] = {**performance(predictions), "folds": folds, "predictions": predictions, "feature_ids": features}
    importance = [{"feature": f, "descriptive_eta_squared": eta_squared(rows, f)} for f in sets["all_17"]]
    importance.sort(key=lambda r: r["descriptive_eta_squared"] if r["descriptive_eta_squared"] is not None else -1, reverse=True)
    write_json(out / "style-discrimination.json", {
        "target": "known original prompt style, NOT disease/clinical rating",
        "method": plan, "analysis_plan_sha256": digest(plan_path.read_bytes()),
        "majority_baseline_accuracy": 1/6, "independent_people": 1,
        "feature_sets": results, "descriptive_feature_variance": importance,
        "warning": "Development data only. Same fictional person, 3 situations. No patient-population inference or clinical validity claim."
    })
    print(json.dumps({name: {k: r[k] for k in ["n_dialogues", "accuracy", "macro_f1"]} for name, r in results.items()}, indent=2))
    print("Top descriptive feature separations:", json.dumps(importance[:6]))


if __name__ == "__main__":
    main()
