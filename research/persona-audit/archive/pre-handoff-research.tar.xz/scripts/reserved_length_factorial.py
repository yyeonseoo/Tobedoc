"""Local 2x2 instruction experiment, 24 first replies; no clinical scoring.

Factors: remaining reserved instruction bundle vs none; extra three-sentence
clause vs none. Original enclosing five-sentence cap stays in every cell.
"""
import argparse
import json
import random
import re
import time
import uuid
from collections import defaultdict
from statistics import mean

from audit_sources import extract_template, parse_styles
from common import ROOT, digest, read_source, write_json
from local_preflight import MODEL, local_metadata
from prepare_pilot import build_conditions, render_prompt
from run_feature_batch import payload
from run_local_pilot import OPTIONS, chat, classify, fingerprint, now
from summarize_local_pilot import text_metrics, verify_turn

RUN = "reserved-length-factorial-v01"
FOLDER = ROOT / "pilot/runs" / RUN
OUT = ROOT / "analysis" / RUN
CAP = "But you must not exceed 3 sentences each turn. "


def conditions():
    template = extract_template(read_source("psi_formatter"))
    styles = parse_styles(read_source("psi_styles"))
    if styles["reserved"].count(CAP) != 1:
        raise ValueError("Unexpected source cap")
    uncapped_style = styles["reserved"].replace(CAP, "")
    bases = [c for c in build_conditions() if c["arm"] == "native_demo_mapping" and c["style_id"] == "plain"]
    if len(bases) != 3:
        raise ValueError("Expected three situations for one demo person")
    rng = random.Random(20261030)
    blocks = [(b, repeat) for b in bases for repeat in range(2)]
    rng.shuffle(blocks)
    rows = []
    for base, repeat in blocks:
        cells = []
        for reserved in (False, True):
            for cap in (5, 3):
                style = uncapped_style if reserved else ""
                if cap == 3:
                    style += "\n" + CAP.strip()
                prompt, missing = render_prompt(template, base["profile"], style)
                if prompt.count("maximum of 5 sentences") != 1:
                    raise ValueError("Common enclosing cap changed")
                cells.append({**base, "condition_id": f"L-{base['profile_id']}-R{repeat}-S{int(reserved)}-C{cap}",
                              "style_id": "reserved" if reserved else "plain", "arm": f"sentence_cap_{cap}",
                              "repeat_index": repeat, "reserved_bundle": reserved, "sentence_cap": cap,
                              "system_prompt": prompt, "missing_fields": missing,
                              "interview": base["interview"][:1], "stage": "instruction_length_factorial"})
        rng.shuffle(cells)
        rows.extend(cells)
    for row in rows:
        row["prompt_sha256"] = fingerprint({"system_prompt": row["system_prompt"], "interview": row["interview"]})
    if len(rows) != 24:
        raise ValueError("Request ceiling changed")
    return rows


def prepare():
    rows = conditions()
    plan = {"run_id": RUN, "scope": "One Abe demo person, three situations, two seeds; first turn only; Qwen prompt port",
            "question": "How much do the reserved instruction bundle and numeric sentence clause separately change response length?",
            "factors": {"reserved_bundle": "Source reserved text minus its numeric cap; retains brief/vague/guarded/trust instructions",
                        "sentence_cap": "Common maximum five remains; extra source maximum-three clause on/off"},
            "planned_responses": 24, "primary_outcome": "regex word_count",
            "secondary_outcomes": ["character_count", "sentence_count_heuristic", "cap_exceeded_heuristic"],
            "aggregation": "Six situation-by-seed blocks; paired effects per block, then equal-weight block mean. No population p-values.",
            "contrasts": ["reserved_minus_plain_at_cap5", "reserved_minus_plain_at_cap3", "cap3_minus_cap5_plain",
                          "cap3_minus_cap5_reserved", "interaction_reserved_effect_cap3_minus_cap5"],
            "interpretation": "Tests length effects of instruction bundles, NOT guardedness, alogia or schizophrenia validity",
            "hypotheses_before_generation": "Three-sentence clause may reduce words; remaining reserved bundle may also reduce words; interaction can be either direction",
            "stopping": "Exactly 24 first-turn requests maximum; preserve failed/truncated outputs and stop, no automatic retries or best-of",
            "options": OPTIONS, "think": False, "seed_rule": "20261030 + 100*repeat_index + 1, matched across four cells",
            "backbone_digest": json.loads((ROOT / "evidence/local-runtime.json").read_text())["ollama"]["candidate_metadata"]["digest"],
            "conditions_sha256": fingerprint(rows)}
    for name, obj in [("plan.json", plan), ("conditions.json", rows)]:
        path = FOLDER / name
        if path.exists():
            if json.loads(path.read_text()) != obj:
                raise ValueError("Frozen experiment differs; never overwrite")
        else:
            write_json(path, obj)
    if not (FOLDER / "prepared-at.json").exists():
        write_json(FOLDER / "prepared-at.json", {"prepared_at_utc": now(), "plan_sha256": fingerprint(plan)})
    return plan, rows


def run(resume=False):
    plan, rows = prepare()
    policy = json.loads((ROOT / "config/compute-policy.json").read_text())
    if policy["paid_model_api_allowed"] or policy["automatic_model_download_allowed"]:
        raise ValueError("Compute policy changed")
    model = next((m for m in local_metadata("/api/tags")["models"] if m["name"] == MODEL), None)
    if not model or model["digest"] != plan["backbone_digest"]:
        raise ValueError("Pinned installed model absent/changed; no pull")
    if (FOLDER / "responses").exists() and not resume:
        raise ValueError("Existing responses require --resume")
    if not (FOLDER / "runtime.json").exists():
        write_json(FOLDER / "runtime.json", {"checked_at_utc": now(), "model": model,
            "version": local_metadata("/api/version"), "show": local_metadata("/api/show", {"model": MODEL})})
    for name in ("requests", "responses"):
        (FOLDER / name).mkdir(exist_ok=True)
    lock = FOLDER / ".running"
    with lock.open("x") as handle:
        handle.write(now())
    try:
        for index, case in enumerate(rows, 1):
            request = payload(case, [], 1)
            request_hash = fingerprint(request)
            rp = FOLDER / "requests" / (case["condition_id"] + ".json")
            sp = FOLDER / "responses" / (case["condition_id"] + ".json")
            if sp.exists():
                response = json.loads(sp.read_text())
                verify_turn(response, json.loads(rp.read_text()), {**case, "_model_digest": model["digest"]}, [])
                if response["status"] != "completed":
                    raise ValueError("Previous failure preserved; no silent retry")
            else:
                if rp.exists():
                    raise ValueError("Saved unfinished request requires inspection")
                started = now()
                write_json(rp, {"started_at_utc": started, "request_sha256": request_hash, "payload": request})
                begin = time.monotonic()
                raw, error = {}, None
                try:
                    raw = chat(request)
                    status = classify(raw)
                except Exception as exc:
                    status, error = "transport_error", {"type": type(exc).__name__, "message": str(exc)}
                response = {"run_id": RUN, **{k: case[k] for k in ("condition_id", "profile_id", "style_id", "arm", "repeat_index")},
                    "turn": 1, "probe": case["interview"][0]["probe"], "interviewer_text": case["interview"][0]["text"],
                    "prompt_sha256": case["prompt_sha256"], "request_sha256": request_hash, "request_id": str(uuid.uuid4()),
                    "started_at_utc": started, "ended_at_utc": now(), "wall_seconds": time.monotonic()-begin,
                    "model_digest": model["digest"], "status": status, "response_text": raw.get("message", {}).get("content", ""),
                    "raw_response": raw, "error": error, "is_fixture": False, "clinical_rating": None,
                    "is_schizophrenia_case": False}
                write_json(sp, response)
            print(f"{index}/24 {case['condition_id']}: {response['status']}", flush=True)
            write_json(FOLDER / "progress.json", {"planned_requests": 24, "processed_cells": index,
                       "complete": index == 24 and response["status"] == "completed", "updated_at_utc": now()})
            if response["status"] != "completed":
                raise ValueError("Failed output preserved; experiment stopped")
    finally:
        lock.unlink(missing_ok=True)
    analyze()


def summarize(blocks):
    effects = defaultdict(list)
    for block in blocks.values():
        if set(block) != {(False, 5), (False, 3), (True, 5), (True, 3)}:
            raise ValueError("Incomplete factorial block")
        p5, p3, r5, r3 = [block[k] for k in [(False, 5), (False, 3), (True, 5), (True, 3)]]
        for name, value in [("reserved_minus_plain_at_cap5", r5-p5), ("reserved_minus_plain_at_cap3", r3-p3),
                            ("cap3_minus_cap5_plain", p3-p5), ("cap3_minus_cap5_reserved", r3-r5),
                            ("interaction_reserved_effect_cap3_minus_cap5", (r3-p3)-(r5-p5))]:
            effects[name].append(value)
    return {k: {"block_differences": v, "mean": mean(v), "positive_blocks": sum(x > 0 for x in v),
                "negative_blocks": sum(x < 0 for x in v), "zero_blocks": sum(x == 0 for x in v)} for k, v in effects.items()}


def question_paragraph_flag(text):
    """Mechanical QC flag, not a validated role-leak or clinical classifier."""
    paragraphs = [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]
    return any(p.endswith("?") for p in paragraphs[:-1])


def analyze():
    plan, cases = prepare()
    rows, files = [], [FOLDER / "plan.json", FOLDER / "conditions.json", FOLDER / "runtime.json"]
    blocks, cell_words, cap_flags = defaultdict(dict), defaultdict(list), defaultdict(list)
    for case in cases:
        rp = FOLDER / "requests" / (case["condition_id"] + ".json")
        sp = FOLDER / "responses" / (case["condition_id"] + ".json")
        raw, request = json.loads(sp.read_text()), json.loads(rp.read_text())
        verify_turn(raw, request, {**case, "_model_digest": plan["backbone_digest"]}, [])
        if request["payload"] != payload(case, [], 1) or raw["status"] != "completed":
            raise ValueError("Incomplete or changed experiment")
        metrics = text_metrics(raw["response_text"])
        cell = (case["reserved_bundle"], case["sentence_cap"])
        blocks[(case["profile_id"], case["repeat_index"])][cell] = metrics["word_count"]
        cell_words[cell].append(metrics["word_count"])
        cap_flags[cell].append(metrics["sentence_count_heuristic"] > cell[1])
        rows.append({"condition_id": case["condition_id"], "reserved_bundle": cell[0], "sentence_cap": cell[1],
                     "profile_id": case["profile_id"], "repeat_index": case["repeat_index"],
                     "question": raw["interviewer_text"], "response_text": raw["response_text"], "metrics": metrics,
                     "standalone_question_paragraph_flag": question_paragraph_flag(raw["response_text"])})
        files += [rp, sp]
    if len(rows) != 24 or len(blocks) != 6:
        raise ValueError("Incomplete experiment")
    flagged_blocks = {(r["profile_id"], r["repeat_index"]) for r in rows if r["standalone_question_paragraph_flag"]}
    clean_blocks = {k: v for k, v in blocks.items() if k not in flagged_blocks}
    result = {"plan": plan, "completed_responses": len(rows), "block_order": list(blocks),
              "word_count_contrasts": summarize(blocks),
              "posthoc_quality_sensitivity": {
                  "status": "Added after inspecting outputs, not prespecified; primary analysis still includes all 24 replies",
                  "rule": "Flag a standalone paragraph ending in a question mark followed by another nonempty paragraph; exclude whole matched block only for sensitivity",
                  "not_a_role_leak_gold_standard": True,
                  "flagged_condition_ids": [r["condition_id"] for r in rows if r["standalone_question_paragraph_flag"]],
                  "retained_blocks": len(clean_blocks), "contrasts": summarize(clean_blocks) if clean_blocks else None},
              "cells": [{"reserved_bundle": s, "sentence_cap": cap, "word_count_mean": mean(v),
                         "word_counts": v, "cap_exceeded_heuristic": sum(cap_flags[(s, cap)])} for (s, cap), v in sorted(cell_words.items())],
              "responses": rows, "clinical_validation": False,
              "provenance": [{"path": str(p.relative_to(ROOT)), "sha256": digest(p.read_bytes())} for p in files]}
    write_json(OUT / "results.json", result)
    lines = ["# 경계적 말투와 문장 제한의 분리 실험", "", "실제 24응답 완료. 같은 예제 인물의 3상황×2seed×4조건, 첫 답변만 사용했다.", "",
             "질문: 짧은 답변은 숫자로 정한 문장 제한 때문인가, 남은 말투 지시 때문인가?", "",
             "경계적 설정은 원문 reserved에서 3문장 문구만 제거한 지시 묶음이다. ‘짧고 모호하게 답하기’ 등의 지시도 남아 있으므로 순수한 심리적 경계심의 효과가 아니다. "
             "모든 조건에 원래 공통 5문장 제한이 있고, 절반에 추가 3문장 문구를 넣었다. 무제한 조건은 없다.", "", "## 조건별 평균 단어 수", ""]
    for c in result["cells"]:
        lines.append(f"- {'경계적 설정' if c['reserved_bundle'] else '말투 설정 없음'} / 최대 {c['sentence_cap']}문장: {c['word_count_mean']:.2f}단어; 자동 문장 분절상 상한 초과 {c['cap_exceeded_heuristic']}/6.")
    lines += ["", "## 같은 상황·seed 안의 차이", ""]
    labels = {"reserved_minus_plain_at_cap5": "최대 5문장으로 맞췄을 때, 경계적 지시 묶음의 추가 효과",
              "reserved_minus_plain_at_cap3": "최대 3문장으로 맞췄을 때, 경계적 지시 묶음의 추가 효과",
              "cap3_minus_cap5_plain": "말투 설정 없이, 상한을 5→3문장으로 강화한 효과",
              "cap3_minus_cap5_reserved": "경계적 설정에서, 상한을 5→3문장으로 강화한 효과",
              "interaction_reserved_effect_cap3_minus_cap5": "상한 강화에 따라 경계적 지시 묶음의 효과가 달라진 정도"}
    for name, stat in result["word_count_contrasts"].items():
        lines.append(f"- {labels[name]}: {stat['mean']:+.2f}단어; 증가 {stat['positive_blocks']}/6, 감소 {stat['negative_blocks']}/6, 동일 {stat['zero_blocks']}/6.")
    style5 = result["word_count_contrasts"]["reserved_minus_plain_at_cap5"]["mean"]
    lines += ["", "## 이번 실험이 답한 것", "",
              f"추가 3문장 문구가 없는 조건에서도 남은 경계적 지시 묶음을 넣었을 때 평균 단어 수 차이는 {style5:+.2f}였다. "
              + ("따라서 이 조건에서 관찰된 짧은 답변을 숫자 3문장 제한만으로 설명할 수는 없다. " if style5 < 0 else "이 조건에서는 남은 지시 묶음만으로 평균 답변이 더 짧아지지는 않았다. ")
              + "다만 남은 묶음에도 ‘짧게 답하라’는 직접 지시가 있으므로, 이것이 경계심이라는 심리적 특성을 재현했다는 뜻은 아니다.", ""]
    quality = result["posthoc_quality_sensitivity"]
    lines += ["## 출력 형식 점검과 사후 민감도 분석", "",
              f"별도 질문 문단 뒤에 다른 문단이 이어지는 응답 {len(quality['flagged_condition_ids'])}/24개를 표시했다: "
              + ", ".join(quality["flagged_condition_ids"]) + ". 환자 응답 안에 면담자 질문과 추가 답변이 섞였을 가능성이 있지만, 이 규칙은 역할 이탈의 검증된 판정기가 아니다.", "",
              "주 분석은 이 응답까지 포함한 24개 그대로다. 출력 확인 후 추가한 사후 점검으로만, 해당 응답이 속한 상황×seed의 네 조건을 함께 제외했다. "
              "유리한 개별 응답만 골라 버리거나 다시 생성하지 않았다.", ""]
    if quality["contrasts"]:
        lines += [f"남은 {quality['retained_blocks']}블록에서 {labels[k]}: {v['mean']:+.2f}단어."
                  for k, v in quality["contrasts"].items() if k != "interaction_reserved_effect_cap3_minus_cap5"]
        lines += [""]
    lines += ["", "이는 이 Qwen·프롬프트·첫 답변 조건의 기술 결과다. 같은 사람의 상황·seed를 독립 환자로 세거나 모집단 p값을 계산하지 않는다. "
              "주 분석은 단어 수이며 문장 수는 정규식 분절의 보조값이다. 문장 상한 준수 여부를 임상 판정으로 쓰지 않는다. "
              "불신·정보 공개 회피가 구현됐는지, 조현병 언어를 재현하는지는 이 실험으로 판단하지 않는다.", "", "## 고정 사례의 실제 답변", "",
              "효과 크기와 무관하게 profile 1-1 / seed 반복 0의 네 조건을 모두 제시한다.", ""]
    for r in sorted(rows, key=lambda x: x["condition_id"]):
        if r["profile_id"] == "1-1" and r["repeat_index"] == 0:
            lines += [f"### {r['condition_id']}", "", r["response_text"], ""]
    (OUT / "report.ko.md").write_text("\n".join(lines))
    print(json.dumps({"completed": len(rows), "contrasts": {k: v["mean"] for k, v in result["word_count_contrasts"].items()}}, ensure_ascii=False), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--run", action="store_true")
    mode.add_argument("--analyze-only", action="store_true")
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if args.run:
        run(args.resume)
    elif args.analyze_only:
        analyze()
    else:
        p, _ = prepare()
        print(json.dumps(p, ensure_ascii=False))
