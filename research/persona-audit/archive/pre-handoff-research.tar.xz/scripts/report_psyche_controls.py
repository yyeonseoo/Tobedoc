"""Concise Korean DOCX/Markdown report from verified control results only."""
from pathlib import Path
import argparse

from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

from common import ROOT, digest, write_json
import psyche_controls as controls

OUTPUT = controls.SHARE / 'PSYCHE 발화량 제어 실험 보고서.docx'
NAMES = {'direct_numeric': '간단한 역할과 숫자 지시', 'hub_label': '기존 PSYCHE 설정',
         'hub_json_numeric': 'MFC 내부 숫자 지시', 'hub_tail_numeric': '시스템 끝 숫자 지시'}


def apply_font(run, size=11, bold=False):
    run.font.name = 'Apple SD Gothic Neo'
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = RGBColor(0, 0, 0)
    fonts = run._element.get_or_add_rPr().get_or_add_rFonts()
    for key in list(fonts.attrib):
        if 'theme' in key.lower():
            del fonts.attrib[key]
    for name in ('ascii', 'hAnsi', 'eastAsia', 'cs'):
        fonts.set(qn('w:' + name), 'Apple SD Gothic Neo')


def paragraph(doc, text, size=11, bold=False):
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = 1.18
    p.paragraph_format.space_after = Pt(7)
    p.paragraph_format.widow_control = True
    apply_font(p.add_run(text), size, bold)
    return p


def heading(doc, text):
    p = doc.add_paragraph(text, 'Heading 1')
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(6)
    for run in p.runs:
        apply_font(run, 13, True)


def table(doc, headers, rows, widths):
    t = doc.add_table(rows=1, cols=len(headers))
    t.autofit = False
    for i, width in enumerate(widths):
        t.columns[i].width = Inches(width)
    for cell, text in zip(t.rows[0].cells, headers):
        cell.text = text
    for row in rows:
        for cell, text in zip(t.add_row().cells, row):
            cell.text = str(text)
    for i, row in enumerate(t.rows):
        for j, cell in enumerate(row.cells):
            cell.width = Inches(widths[j])
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            pr = cell._tc.get_or_add_tcPr()
            border = OxmlElement('w:tcBorders')
            for edge in ('top', 'left', 'bottom', 'right'):
                item = OxmlElement('w:' + edge)
                for key, value in [('val', 'single'), ('sz', '4'), ('color', 'D9D9D9')]:
                    item.set(qn('w:' + key), value)
                border.append(item)
            pr.append(border)
            margins = OxmlElement('w:tcMar')
            for edge in ('top', 'left', 'bottom', 'right'):
                item = OxmlElement('w:' + edge)
                item.set(qn('w:w'), '95')
                item.set(qn('w:type'), 'dxa')
                margins.append(item)
            pr.append(margins)
            if i == 0:
                shading = OxmlElement('w:shd')
                shading.set(qn('w:fill'), 'E8EEF3')
                pr.append(shading)
                repeat = OxmlElement('w:tblHeader')
                row._tr.get_or_add_trPr().append(repeat)
            for p in cell.paragraphs:
                p.paragraph_format.space_after = Pt(0)
                p.paragraph_format.line_spacing = 1.12
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT if j == 0 else WD_ALIGN_PARAGRAPH.CENTER
                for run in p.runs:
                    apply_font(run, 10.5, i == 0)
    paragraph(doc, '', size=2).paragraph_format.space_after = Pt(1)


def main(replace=False):
    if OUTPUT.exists() and not replace:
        raise ValueError('Do not overwrite an existing report without --replace')
    spec = controls.read(controls.SPEC)
    summary = controls.read(controls.OUT / 'summary.json')
    verification = controls.read(controls.OUT / 'verification.json')
    assert verification['passed'] and summary['complete']
    arms = {r['arm']: r for r in summary['arms']}
    direct = arms['direct_numeric']
    selected = summary['selected_engineering_arm']
    if summary['decision'] == 'retain_for_bounded_output_control_only':
        conclusion = (f'기본 숫자 지시는 {direct["target_hits"]}/8개, {NAMES[selected]}는 {arms[selected]["target_hits"]}/8개가 목표 범위를 충족했다. '
                      f'기존 조건은 Increased가 더 긴 경우가 {arms["hub_label"]["positive_pairs"]}/4쌍이었다. '
                      'Qwen3 14B는 이번 과제에서 명시적 길이 제어가 가능했으나, 기존 범주형 설정의 방향은 일관되지 않았다. '
                      f'사전 기준과 우선순위에 따라 {NAMES[selected]}를 후속 실험의 길이 통제 도구로 채택한다. '
                      '숫자 제어 성공을 환자 모사 정확도로 해석하지 않는다.')
        action = ('백본을 바로 교체하지 않고, 채택된 방식으로 응답 길이를 통제하는 실험 기반을 유지한다. '
                  '길이를 독립적인 통제 변수로 두는 후속 설계에 활용하되, 모든 응답이 범위를 지키는 것은 아니므로 실제 길이를 기록한다. '
                  '새 사례에서의 재검증 없이 일반화하지 않으며 20~40 및 100~140단어를 실제 환자의 증상 기준으로 적용하지 않는다.')
    elif summary['decision'] == 'direct_control_failed_do_not_declare_backbone_controllable':
        conclusion = ('간단한 숫자 지시 대조군이 사전 판정 기준을 통과하지 못했다. '
                      '따라서 이번 결과만으로 기본 백본의 안정적 출력 제어가 확보됐다고 선언할 수 없다. '
                      'PSYCHE 자체의 임상적 실패로 결론내리지 않고, 현재 설정에서 대규모 후속 생성을 보류한다.')
        action = ('현재 고정 설정에서는 출력 제어가 충분히 확보되지 않았으므로 대규모 생성은 진행하지 않는다. '
                  '후속 비교는 다른 설치 백본 또는 출력 제어 방식의 변경을 별도로 결정한 뒤 새 프로토콜로 수행해야 한다. '
                  '이번 결과에 맞춰 기준을 낮추거나 같은 요청을 반복해 좋은 답만 골라내지는 않았다.')
    else:
        conclusion = ('간단한 지시 대조군은 통과했지만, 페르소나 프롬프트에 숫자 지시를 넣은 두 방식은 사전 기준을 통과하지 못했다. '
                      '이는 모델이 전혀 지시를 수행하지 못한다기보다, 이 복합 프롬프트 안에서 충분한 제어가 확보되지 않았다는 결과다.')
        action = ('현재 복합 프롬프트의 대규모 생성을 보류한다. 임상 설정과 출력 형식을 분리하는 경량 구조를 새 프로토콜로 비교해야 한다. '
                  '현재 결과만으로 두 복합 방식 중 하나를 검증된 개선안으로 채택하지 않는다.')
    origin = summary['origins']
    setup = ('같은 가상 인물 1명에서 사고과정은 Normal로 유지했다. 발화량 설정 2개, 질문 2개, 시드 2개, 지시 방식 4개를 교차해 32개 응답을 비교했다. '
             f'요청 전체와 모델 환경이 일치하는 기존 {origin.get("exact_cache", 0)}개는 재사용하고, {origin.get("new_local_call", 0)}개만 새로 생성했다. '
             '시드 반복과 재사용 응답을 독립 환자로 세지 않았다.')
    method = ('명시적 숫자 지시를 받은 조건의 목표는 20~40단어와 100~140단어다. 임상적 발화량 기준이 아니라 서로 떨어진 공학적 목표다. '
              '생성 전 판정선을 8개 중 6개 이상 범위 충족, 4쌍 모두 장문 쪽이 더 김, 평균 차이 50단어 이상으로 고정했다. '
              '숫자 지시가 없는 기존 조건에는 목표 준수율을 적용하지 않았다.')
    scope = ('공개 PatientHub의 PSYCHE 영어 프롬프트를 로컬 Qwen3 14B Q4_K_M으로 옮긴 실험이다. '
             '원저 GPT-4o 모델 재현이나 실제 조현병 환자 특징 검증은 아니다. MFC 내부의 실험용 추가 필드와 시스템 끝 지시는 연구자 작성 확장이다.')
    evidence = ('요청과 모델 환경, 코드와 출처 해시를 생성 전에 고정했다. 32개 모두 정상 완료됐고 잘림과 전송 오류는 없었다. '
                '단위 테스트 26개와 독립 재계산 검증을 통과했다. 유료 API와 자동 평가자 호출, 추가 설치와 다운로드는 0회다.')
    interpretation = ('기본 대조군이 통과했으므로 Qwen이 전혀 길이를 조절하지 못한다는 설명은 지지되지 않았다. '
                      '기존 조건도 범주 이름과 간단한 발화량 설명을 포함하지만 숫자 범위는 주지 않았다. '
                      '숫자 제어 성공은 임상 증상 재현의 근거가 아니다. JSON과 시스템 끝 비교는 위치와 표현 형식이 함께 달라져 단일 원인을 확정하지 않는다.')
    clinical = ('사고과정의 임상적 검증은 별도로 남는다. 조건을 가린 대표 발화와 원저 정의를 교수님과 검토해 관찰 준거를 정하고, '
                '길이와 질문을 통제한 상태에서 Normal과 Derailment 구현을 비교해야 한다. 임의의 S/L/G나 단일 코사인 값을 임상 정답으로 쓰지 않는다. '
                'Roleplay-doh 전체 비교는 정식 접근한 개별 전문가 원칙 확보 후 진행한다.')
    result_rows = []
    for arm in spec['arms']:
        r = arms[arm]
        result_rows.append([NAMES[arm], f'{r["normal_mean_words"]:.1f}', f'{r["increased_mean_words"]:.1f}',
                            f'{r["mean_long_minus_short_words"]:+.1f}',
                            '-' if r['target_hits'] is None else f'{r["target_hits"]}/8',
                            f'{r["positive_pairs"]}/4'])
    doc = Document()
    section = doc.sections[0]
    section.page_width, section.page_height = Inches(8.5), Inches(11)
    section.left_margin = section.right_margin = Inches(.72)
    section.top_margin = section.bottom_margin = Inches(.65)
    for name in ('Normal', 'Title', 'Heading 1', 'Heading 2'):
        style = doc.styles[name]
        style.font.name = 'Apple SD Gothic Neo'
        style.font.color.rgb = RGBColor(0, 0, 0)
        style.font.size = Pt(11)
    for border in list(doc.styles.element.iter(qn('w:pBdr'))):
        border.getparent().remove(border)
    doc.core_properties.title = 'PSYCHE 발화량 제어 실험 결과'
    doc.core_properties.author = '연구팀'
    doc.core_properties.subject = '기본 모델과 페르소나 지시 방식의 구분'
    doc.core_properties.comments = ''
    p = doc.add_paragraph('PSYCHE 발화량 제어 실험 결과', 'Title')
    p.paragraph_format.space_after = Pt(7)
    for run in p.runs:
        apply_font(run, 19, True)
    paragraph(doc, '2026년 11월 1일  연구팀 공유 보고', size=10)
    heading(doc, '이번 실험의 결론')
    paragraph(doc, conclusion)
    heading(doc, '왜 이 실험을 했는가')
    paragraph(doc, '앞선 실험에서는 발화량을 Normal에서 Increased로 바꿔도 평균 단어 수가 거의 늘지 않았다. '
              '이를 기존 페르소나의 실패라고 바로 결론내릴 수는 없었다. 모델 자체가 길이를 조절하지 못하는지, '
              '임상 특징 이름이 충분히 구체적이지 않은지, 복합 프롬프트 안에서 지시가 잘 전달되지 않는지 구분할 대조군이 필요했다.')
    heading(doc, '무엇을 어떻게 비교했는가')
    paragraph(doc, setup)
    table(doc, ['지시 방식', '임상 배경', '숫자 지시 위치'], [
        [NAMES['direct_numeric'], '동일 사례', '짧은 역할 프롬프트 끝'],
        [NAMES['hub_label'], '동일 사례와 MFC', '없음'],
        [NAMES['hub_json_numeric'], '동일 사례와 MFC', 'MFC에 추가한 실험용 필드'],
        [NAMES['hub_tail_numeric'], '동일 사례와 MFC', '전체 시스템 프롬프트 끝']
    ], [2.25, 1.55, 3.25])
    paragraph(doc, method)
    paragraph(doc, scope, size=10)
    doc.add_page_break()
    heading(doc, '실제 관찰한 결과')
    table(doc, ['지시 방식', '짧은 설정\n평균 단어', '긴 설정\n평균 단어', '차이\n단어', '범위\n충족', '길이 방향\n충족'], result_rows,
          [2.15, 1.0, 1.0, .8, .85, 1.25])
    paragraph(doc, '평균은 각 설정의 응답 4개에서 계산했다. 차이는 같은 질문과 시드를 짝지은 긴 설정 빼기 짧은 설정이다. '
              '범위 충족은 숫자를 지시한 8개 응답 중 해당 범위에 든 수, 길이 방향 충족은 4쌍 중 긴 설정이 실제로 더 긴 쌍의 수다. '
              '기존 조건의 대시는 숫자 지시를 주지 않아 그 준수율을 평가하지 않았다는 뜻이다.', size=10)
    heading(doc, '결과가 의미하는 것')
    paragraph(doc, interpretation)
    heading(doc, '현재 단계에서 내린 결정')
    paragraph(doc, action)
    paragraph(doc, clinical)
    heading(doc, '검증과 재현 자료')
    paragraph(doc, evidence, size=10)
    paragraph(doc, '실행 및 원문  share/psyche-controls-v01. 측정값과 원응답  analysis/psyche-controls-v01. '
              'README.ko.md의 분석·검증 명령은 새 모델 호출 없이 실행된다.', size=10)
    paragraph(doc, '근거  PSYCHE arXiv:2501.01594v1 SP-Prompt-3 및 Table 11. PatientHub commit 54d5c8761a90 고정본. '
              '전체 해시와 원문 위치는 별도 기록에 보존했다.', size=9.5)
    controls.SHARE.mkdir(parents=True, exist_ok=True)
    doc.save(OUTPUT)
    lines = ['# PSYCHE 발화량 제어 실험 결과', '', '## 결론', '', conclusion, '', '## 설계', '', setup, '', method, '', scope, '', '## 결과', '']
    for row in result_rows:
        lines.append(f'- {row[0]}: 짧은 설정 평균 {row[1]}단어 / 긴 설정 평균 {row[2]}단어 / 차이 {row[3]}단어 / 범위 충족 {row[4]} / 방향 충족 {row[5]}.')
    lines.extend(['', '기존 설정에는 숫자 지시를 주지 않았으므로 범위 준수율을 평가하지 않았다.', '', '## 해석과 결정', '', interpretation, '', action, '', clinical, '', '## 검증', '', evidence, ''])
    markdown = controls.SHARE / '결과요약.md'
    markdown.write_text('\n'.join(lines), encoding='utf-8')
    selected_export = {'decision': summary['decision'], 'selected_arm': selected,
                       'engineering_only': True, 'targets_not_clinical_thresholds': True,
                       'requests': [r for r in controls.read(controls.OUT / 'requests.json') if r['arm'] == selected] if selected else []}
    write_json(controls.OUT / 'selected-engineering-requests.json', selected_export)
    write_json(controls.OUT / 'report-manifest.json', {
        'inputs': {str(p.relative_to(ROOT)): digest(p.read_bytes()) for p in [controls.OUT / 'summary.json', controls.OUT / 'verification.json', controls.SPEC]},
        'docx_sha256': digest(OUTPUT.read_bytes()), 'markdown_sha256': digest(markdown.read_bytes()),
        'builder_sha256': digest(Path(__file__).read_bytes()), 'clinical_validation': False})
    checkpoint = {'date': '2026-11-01', 'previous_checkpoint': 'config/research-checkpoint-v08.json',
                  'status': 'Bounded engineering-control workflow completed through generation, independent verification, decision and report',
                  'old_experiments_preserved': True, 'old_generation_and_metric_experiments_remain_paused': True,
                  'new_protocol': 'config/psyche-controls-v01.json', 'effective_responses': 32,
                  'new_local_calls': origin.get('new_local_call', 0), 'exact_cache_reuses': origin.get('exact_cache', 0),
                  'clinical_judge_calls': 0, 'paid_api_calls': 0, 'related_unit_tests_passed': 26,
                  'decision': summary['decision'], 'selected_engineering_arm': selected,
                  'meaning': conclusion, 'next_scientific_question': 'Thought-process implementation with output length treated as a control, not a clinical score',
                  'report': str(OUTPUT.relative_to(ROOT)), 'docx_visual_QA': 'pending until render is inspected'}
    write_json(ROOT / 'config/research-checkpoint-v09.json', checkpoint)
    print(str(OUTPUT))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--replace', action='store_true')
    main(parser.parse_args().replace)
