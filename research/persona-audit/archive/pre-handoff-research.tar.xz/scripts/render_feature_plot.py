"""Render descriptive feature profiles with local AppKit; no package download."""
import argparse
import json
import subprocess

from common import ROOT, write_json
from extract_automatic_features import STYLES


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    folder = ROOT / "analysis/automatic-features-v01" / args.run_id
    rows = [r for r in json.loads((folder / "dialogue-features.json").read_text()) if r["arm"] == "native_demo_mapping"]
    styles = [s for s in STYLES if any(r["style_id"] == s for r in rows)]
    panels = []
    for feature, title, unit in [
        ("word_count", "Response length", "words per reply; mean within dialogue"),
        ("adjacent_cos_mean", "Adjacent sentence similarity", "cosine; mean within dialogue"),
        ("topic_answer_cos", "Situation-reply similarity", "cosine; mean within dialogue"),
        ("mattr20", "Fixed-window lexical diversity", "MATTR20; mean within dialogue")]:
        panels.append({"title": title, "unit": unit,
                       "values": [[r["feature_means"][feature] for r in rows if r["style_id"] == s and r["feature_means"][feature] is not None] for s in styles]})
    subtitle = f"{len(rows)} dialogues, one person; dots = dialogue means; bars = mean of dots. No clinical ratings."
    write_json(folder / "plot-input.json", {"styles": styles, "panels": panels, "subtitle": subtitle,
               "caption": f"Source: {args.run_id}; Apple English embedding rev.1. Cosine is not clinical coherence; no population error bars."})
    binary = "/private/tmp/persona-plot-features-v01"
    subprocess.run(["/usr/bin/swiftc", "-module-cache-path", "/private/tmp/persona-feature-swift-cache", str(ROOT / "scripts/PlotFeatures.swift"), "-o", binary], check=True)
    subprocess.run([binary, str(folder / "plot-input.json"), str(folder / "feature-profiles.png")], check=True)


if __name__ == "__main__":
    main()
