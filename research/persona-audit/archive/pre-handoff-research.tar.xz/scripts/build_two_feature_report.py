"""Three-page Korean report joining reserved and topic-selection audits."""
import argparse
import json

from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH

from build_integrated_report import font, paragraph, heading, table
from common import ROOT, digest, write_json

OUT = ROOT / "share/two-feature-audit-v01"
OUTPUT = OUT / "페르소나 특징 구현 분석 통합 보고서.docx"


def configure(doc):
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Inches(8.5), Inches(11)
    sec.top_margin, sec.bottom_margin = Inches(.67), Inches(.67)
    sec.left_margin, sec.right_margin = Inches(.75), Inches(.75)
    sec.footer_distance = Inches(.3)
    for name in ["Normal", "Title", "Subtitle", "Heading 1", "Heading 2"]:
        style = doc.styles[name]
        style.font.name, style.font.size, style.font.color.rgb = "Arial Unicode MS", Pt(11), RGBColor(0, 0, 0)
        fonts = style._element.get_or_add_rPr().get_or_add_rFonts()
        for key in list(fonts.attrib):
            if "theme" in key.lower():
                del fonts.attrib[key]
        for key in ["ascii", "hAnsi", "eastAsia", "cs"]:
            fonts.set(qn("w:"+key), "Arial Unicode MS")
    for border in list(doc.styles.element.iter(qn("w:pBdr"))):
        border.getparent().remove(border)
    for fonts in doc.styles.element.iter(qn("w:rFonts")):
        for key in list(fonts.attrib):
            if "theme" in key.lower():
                del fonts.attrib[key]
    footer = sec.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = footer.add_run()
    font(run, 9)
    field = OxmlElement("w:fldSimple")
    field.set(qn("w:instr"), "PAGE")
    run._r.addnext(field)


def build(replace=False):
    paths = {
        "native": ROOT / "analysis/topic-selection-probe-v01/native-review.json",
        "length": ROOT / "analysis/reserved-length-factorial-v01/results.json",
        "disclosure": ROOT / "analysis/fact-disclosure-probe-v01/results.json",
        "followup": ROOT / "analysis/fact-disclosure-order-followup-v01/results.json",
        "transfer": ROOT / "analysis/disclosure-transfer-v01/results.json",
        "topic": ROOT / "analysis/topic-selection-probe-v01/results.json"}
    data = {k: json.loads(p.read_text()) for k, p in paths.items()}
    native, length, transfer, topic = [data[k] for k in ["native", "length", "transfer", "topic"]]
    assert length["completed_responses"] == 24 and transfer["actual_replies"] == 32 and topic["actual_replies"] == 48
    doc = Document()
    configure(doc)
    doc.core_properties.title = "환자 페르소나 말하기 특징 구현 분석"
    doc.core_properties.subject = "경계적 말투와 주제 전환 지시의 정량적 점검"
    doc.core_properties.author = "연구팀"
    doc.core_properties.comments = ""
    p = doc.add_paragraph("환자 페르소나 말하기 특징 구현 분석", style="Title")
    p.paragraph_format.line_spacing, p.paragraph_format.space_after = Pt(25), Pt(5)
    for run in p.runs:
        font(run, 18, True)
    paragraph(doc, "경계적 말투와 주제 전환 지시의 정량적 점검", bold=True)
    paragraph(doc, "연구팀 공유 보고", small=True)

    heading(doc, "연구의 출발점과 범위")
    paragraph(doc, "기존 환자 페르소나가 실제로 어떤 특징을 구현하는지 확인하지 않은 채 조현병 연구에 사용해도 되는가라는 의구심에서 출발했다. 실제 환자 발화 자료를 확보하기 어려운 상황에서, 먼저 제작자가 명시한 특징과 실제 생성 행동을 연결해 분석했다. 이번에는 PATIENT-Ψ의 경계적 말투와 주제 이탈 말투를 집중적으로 점검했다.")
    paragraph(doc, "두 시스템의 설계 특징 18항목에 대한 출처 목록을 만들었지만, 아래 행동 실험은 PATIENT-Ψ 지시를 로컬 Qwen3-14B에 이식한 결과다. 원형 GPT-4 시스템이나 PatientSim 전체의 성능 비교가 아니다. 두 말투를 조현병 증상과 동일시하거나 실제 환자의 재현 정확도를 평가하지 않았다.[1,2]")

    heading(doc, "어떻게 분석했나")
    paragraph(doc, "설정에 대한 원문 지시, 실제 입력, 생성 답변, 측정값을 연결했다. 먼저 기존 영어 응답 144개에서 추출한 17개 길이·어휘·의미 유사도 수치를 재검증했다. 이후 말투와 문장 제한을 분리하고, 정해진 정보가 답변에 나타나는지 직접 추적하는 통제 과제를 구성했다.")
    paragraph(doc, "새 과제는 허구 사례와 고정 질문을 사용했고, 말투·문장 제한·질문 순서 등 관심 변수를 계획에 따라 교차했다. 각 대응 비교에서는 나머지 조건을 유지했다. 단어 수와 사전 표현 목록의 일치를 Python으로 계산했다. 전문가 등급·S/L/G·LLM judge는 사용하지 않았고, 반복 답변이나 한 답변 안의 정보 항목을 독립 환자로 세지 않았다.")
    table(doc, ["분석 단계", "응답 수", "확인하려던 내용"], [
        ["기존 여섯 말투 재분석", "144", "기본·장황함·주제 이탈의 수치가 어떻게 다른가"],
        ["경계적 말투와 길이 제한", "24", "짧은 답변이 3문장 제한만의 영향인가"],
        ["정보 언급과 질문 순서", "24", "간결함과 정보 생략은 다른가  초기 18개와 후속 6개"],
        ["미사용 기록과 표현 검증", "32", "새 기록·표현·seed에서도 순서 효과가 유지되는가"],
        ["질문한 사건과 다른 사건", "48", "tangent는 verbose보다 다른 사건 정보를 더 말하는가"]
    ], [1.9, .65, 4.45], numeric=(1,))
    paragraph(doc, "기존 144개는 Abe 한 인물의 세 상황에 대한 4턴 대화다. 이후 실험은 첫 답변만 비교했다. 각 실험은 별도 자료로 분석했고, 재사용한 응답을 새로운 표본으로 중복 계산하지 않았다.", small=True)

    doc.add_page_break()
    heading(doc, "경계적 말투는 말수와 정보 공개를 함께 바꿨다")
    heading(doc, "숫자 문장 제한만으로 짧은 답변을 설명할 수 없었다", 2)
    cells = {(c["reserved_bundle"], c["sentence_cap"]): c for c in length["cells"]}
    paragraph(doc, f"원본 reserved 지시는 짧고 모호한 답변, 정보 공개 주저, 불신과 3문장 상한을 함께 포함한다. 이를 분리한 24개 답변에서 공통 최대 5문장으로 맞춰도, 말투 설정 없음은 평균 {cells[(False,5)]['word_count_mean']:.1f}단어, 경계적 지시 묶음은 {cells[(True,5)]['word_count_mean']:.1f}단어였다. 반대로 말투 설정 없이 상한만 3문장으로 강화해도 {cells[(False,3)]['word_count_mean']:.1f}단어로 줄었다. 말투 지시와 숫자 제한이 모두 발화량에 영향을 줬다.")
    paragraph(doc, "다만 숫자 제한을 뺀 reserved에도 짧게 답하라는 지시가 남아 있다. 이 결과만으로 경계심이나 정보 회피가 구현됐다고 해석하지 않고, 다음 과제에서 실제 정보 언급을 별도로 측정했다.")

    heading(doc, "질문 순서가 정보의 구체성을 바꿨다", 2)
    paragraph(doc, "행사 정보와 개인 청구서 정보를 각각 세 항목씩 제공하고 모두 질문했다. 초기 24개 답변에서 나타난 순서 민감성을 확인하기 위해, 미사용 기록 2개·새 질문 표현 2종·새 seed 2개·순서 2종·말투 2종을 완전 교차한 32개 답변을 추가로 생성했다. 두 질문은 하나의 메시지에 묶었으며, 임상 면담의 신뢰 형성 과정을 시험한 것은 아니다.")
    table(doc, ["말투와 질문 순서", "개인 정보값", "행사 정보값", "평균 단어 수"], [
        [f"{'간결' if c['style']=='brief_only' else '경계적'}  {'행사 먼저' if c['order']=='event_first' else '청구서 먼저'}",
         f"{c['personal_mentions']}/24", f"{c['event_mentions']}/24", f"{c['mean_words']:.1f}"] for c in transfer["cells"]
    ], [2.65, 1.4, 1.4, 1.55], numeric=(1,2,3))
    paragraph(doc, "각 칸은 8개 답변에 설정된 정보 3개씩, 총 24항목 중 사전 표현 목록으로 식별한 항목 수다. 의미적 정답률이나 임상적 공개 의향 점수가 아니다. 같은 정보의 다른 표현을 놓칠 수 있다.", small=True)
    paragraph(doc, "간결 대조군은 순서와 무관하게 정보값을 모두 언급했지만, 경계적 지시는 청구서를 먼저 물었을 때 정확한 개인 정보값을 덜 언급했다. 두 사례와 두 질문 표현에서 같은 방향이 나타나 사전에 정한 기술적 결정선을 충족했다. 단위 환산 표현 한 건을 인정한 사후 점검에서도 방향은 유지됐다.")
    paragraph(doc, "이때 경계적 답변은 오히려 길어졌다. 따라서 짧은 답변과 구체적 정보값의 감소는 같은 현상이 아니었다. 원문에는 정보 공개 거절뿐 아니라 모호함·근사값·불확실한 표현도 섞여 있어, 식별되지 않은 값을 모두 의도적 회피로 세지 않았다.")

    doc.add_page_break()
    heading(doc, "주제 이탈 지시를 장황함과 비교했다")
    original = {r["style"]: r for r in native["styles"]}
    tangent = original["tangent"]
    paragraph(doc, f"기존 144개 답변에서 tangent의 인접 문장 의미 유사도는 plain 대비 {tangent['paired_change']['adjacent_cos_mean']['mean']:+.3f} 낮았지만 질문 유사도 차이는 {tangent['paired_change']['question_answer_cos']['mean']:+.3f}였다. 같은 인물의 기억이 겹치는 자료여서, 다른 상황을 언급했다는 이유만으로 주제 이탈의 정답표를 만들지 않았다.")
    paragraph(doc, "새 통제 과제에서는 인물별로 서로 다른 날의 사건 두 개에 고유 장소·금액·동행인 이름을 부여하고 한 사건의 정보만 질문했다. 두 인물·두 질문 대상·두 표현·두 seed·세 말투를 교차했다. verbose와 tangent의 원본 숫자 문장 상한만 제거하고 나머지 지시를 유지했다. 아래 표는 48개 새 답변의 결과다.")
    table(doc, ["말투", "질문한 사건", "다른 사건", "평균 단어 수"], [
        [s["style"], f"{s['requested_mentions']}/48", f"{s['other_mentions']}/48", f"{s['mean_words']:.1f}"] for s in topic["summaries"]
    ], [1.6, 1.8, 1.8, 1.8], numeric=(1,2,3))
    paragraph(doc, "말투별 16개 답변에서 사건당 정보 3개씩을 식별했다. 다른 사건의 정해진 값이 나왔다는 뜻이며, 논리적 연결성이나 임상적 탈선의 정답 판정은 아니다. 주어지지 않은 새로운 이야기로의 전환도 이 표식으로는 측정하지 못한다.", small=True)
    primary = topic["primary"]
    paragraph(doc, f"다른 사건 정보 언급 비율의 tangent−verbose 대응 차이는 {primary['mean']:+.3f}였다. 사전에 정한 평균 +1/3 이상과 인물·표현·질문 대상별 방향 일치 조건은 {'충족했다' if topic['decision_rule_met'] else '충족하지 못했다'}. "
              + ("이 과제에서 장황한 말투와 구분되는 다른 사건 정보 증가가 관찰됐다." if topic["decision_rule_met"] else "이 과제에서 tangent가 장황함과 구분되는 일관된 다른 사건 정보 증가를 만든다고 결론 내리지 않았다."))
    paragraph(doc, "원문에서는 표식이 0인 답변에도 프로필에 없던 고양이 Miso의 이야기가 있었다. 또 다른 사건을 말한 뒤 도예 이야기로 돌아가자는 표현이 있었지만, 도예의 고유 정보값을 반복하지 않아 표식 기반 복귀 값은 이를 놓쳤다. 따라서 낮은 표식 수를 주제 이탈의 부재로 해석하지 않는다.")

    heading(doc, "이번 연구의 결론과 남은 검증", 2)
    paragraph(doc, "페르소나의 이름을 임상 특징의 구현 증거로 삼지 않고, 지시와 실제 출력에서 확인되는 변화를 구분했다. 경계적 말투에서는 길이와 별개로 정보 언급의 순서 민감성을 확인했고, 주제 이탈 지시에서는 질문한 사건과 다른 사건의 표식을 나눠 장황함과 비교했다. 같은 측정값 하나로 두 특징의 구현이나 임상적 의미를 판정할 수는 없다.")
    paragraph(doc, "두 특징의 내부 구현 감사를 마쳤지만, 실제 환자와의 유사성·정식 전문가 평가·개선 효과는 검증하지 않았다. 교수님 자문으로 현재 과제와 임상 개념의 연결 범위를 확인해야 한다. 개선은 타당한 목표를 정한 뒤 개발 자료에서 시도하고, 별도의 새 자료에서 평가해야 한다.")
    paragraph(doc, "[1] PATIENT-Ψ  github.com/ruiyiw/patient-psi  고정 커밋 de72a768.\n[2] PatientSim  github.com/dek924/PatientSim  고정 커밋 9c262e69  설계 목록 분석에 한함.\n원문·조건·해시·재집계 코드 보존 위치  persona-audit/analysis 및 scripts. 새 두 특징 보고의 실행 식별자  reserved-length-factorial-v01, disclosure-transfer-v01, topic-selection-probe-v01.", small=True)

    OUT.mkdir(parents=True, exist_ok=True)
    if OUTPUT.exists() and not replace:
        raise FileExistsError("Preserve existing report; use --replace only for layout repairs")
    doc.save(OUTPUT)
    write_json(OUT / "report-inputs.json", {"output": str(OUTPUT), "inputs": [{"id": k, "path": str(p.relative_to(ROOT)), "sha256": digest(p.read_bytes())} for k,p in paths.items()]})
    print(OUTPUT)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replace", action="store_true")
    build(parser.parse_args().replace)
