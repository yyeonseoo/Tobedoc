"""Three-page Korean report; computed observations, measurement checks and next step."""
import argparse
import json
from pathlib import Path

from docx import Document
from docx.shared import Pt

from build_integrated_report import font, heading, paragraph, table
from build_two_feature_report import configure
from common import ROOT, digest, write_json

OUT = ROOT / "share/topic-trajectory-v01"
OUTPUT = OUT / "페르소나 주제 흐름 분석 보고서.docx"
PATHS = {
    "sentences": ROOT / "analysis/topic-trajectory-v01/results.json",
    "discourse": ROOT / "analysis/topic-trajectory-v01/discourse-return-results.json",
    "context": ROOT / "analysis/context-topic-labeler-v01/results.json",
    "reference_audit": ROOT / "analysis/context-topic-labeler-v01/reference-audit.json",
    "prior": ROOT / "analysis/topic-selection-probe-v01/results.json",
    "disclosure": ROOT / "analysis/disclosure-transfer-v01/results.json"
}


def pct(value):
    return f"{100*value:.1f}%"


def build(replace=False):
    data = {k: json.loads(p.read_text()) for k,p in PATHS.items()}
    sentence, discourse, context = (data[k] for k in ("sentences", "discourse", "context"))
    passed = context["control_gate"]["passed"]
    if passed and context["annotated_existing_replies"] != 48:
        raise ValueError("Do not publish an unfinished annotation run")
    if sum(s["sentences"] for s in sentence["summaries"]) != 411:
        raise ValueError("Unexpected sentence population")
    doc = Document()
    configure(doc)
    doc.core_properties.title = "페르소나 주제 흐름 분석"
    doc.core_properties.subject = "기존 생성 답변의 문장 단위 특징 정량화"
    doc.core_properties.author = "연구팀"
    doc.core_properties.comments = ""
    p = doc.add_paragraph("페르소나 주제 흐름 분석", style="Title")
    p.paragraph_format.line_spacing, p.paragraph_format.space_after = Pt(25), Pt(5)
    for run in p.runs:
        font(run, 19, True)
    paragraph(doc, "기존 생성 답변의 문장 단위 특징 정량화", bold=True)
    paragraph(doc, "2026년 10월 30일  연구팀 공유", small=True)
    heading(doc, "어떤 의문에서 출발했나")
    paragraph(doc, "기존 페르소나에 ‘주제를 이탈한다’고 적혀 있으면 실제 답변도 그렇게 달라지는가를 확인하고자 했다. 단순히 답변이 길거나, 질문과 단어가 덜 겹친다는 사실만으로는 장황함과 주제 전환을 구분하기 어려웠다. 이번에는 기존 답변을 문장별로 나누고, 무엇을 이야기하다가 어디로 옮겨가는지 추적했다.")
    paragraph(doc, "앞선 경계적 말투 과제에서는 질문 순서만 바꿔도 개인 정보값 언급이 22/24에서 9/24로 줄면서 평균 길이는 29.3에서 43.9단어로 늘었다. 발화량과 정보 공개가 별개였듯, 이번에는 장황함과 주제 흐름을 별개 특징으로 측정했다.")
    heading(doc, "무엇을 어떻게 했나")
    paragraph(doc, "PATIENT-Ψ의 기본·장황·주제 이탈 지시를 같은 로컬 Qwen3-14B에 적용해 얻은 기존 48개 첫 답변을 재사용했다. 두 허구 인물마다 서로 다른 사건 두 개를 제공하고 한 사건만 질문한 자료다. 인물 2명, 질문 대상 2종, 표현 2종, seed 2개, 말투 3종이 교차되어 말투별 16답변이다. 원형 앱 전체나 여러 시스템의 최종 비교가 아니라 지시 모듈의 행동 분석이다.")
    paragraph(doc, "원문·요청 해시를 검증하고 macOS 문장 분절기로 총 411문장을 추출했다. 고유 장소·금액·이름 외에 사건 단어를 추적하는 규칙 기반 측정과, 문맥을 포함한 로컬 모델 보조 분류를 나란히 적용했다. 문장별 원문 위치, 표식 근거, 분류 결과와 미확정 표시를 모두 보존했다.")
    table(doc, ["말투", "답변 수", "문장 수", "평균 단어 수"], [
        [{"plain": "기본", "verbose": "장황", "tangent": "주제 이탈"}[s["style"]], s["replies"], s["sentences"], f"{s['mean_words']:.1f}"]
        for s in sentence["summaries"]], [2.2, 1.4, 1.4, 2], numeric=(1,2,3))
    paragraph(doc, "새 환자 발화 생성과 유료 API 호출은 없었다. 보조 분류는 설치된 Qwen3-14B의 별도 역할이며, 생성 모델과 독립된 평가자나 임상 전문가는 아니다. 증상 등급이나 S/L/G 점수는 만들지 않았다.", small=True)

    doc.add_page_break()
    heading(doc, "어떤 결과를 얻었나")
    heading(doc, "고유값 검사가 놓친 복귀 표현을 찾았다", 2)
    table(doc, ["말투", "다른 사건 언급", "다른 사건 후 원래 사건 재언급", "담화 복귀 표현"], [
        [{"plain": "기본", "verbose": "장황", "tangent": "주제 이탈"}[s["style"]],
         f"{s['literal_other_present']}/16", f"{s['literal_other_then_requested']}/16",
         f"{next(c['narrow_discourse_cue'] for c in discourse['summaries'] if c['style']==s['style'])}/16"]
        for s in sentence["summaries"]], [1.3, 1.55, 2.25, 1.9], numeric=(1,2,3))
    paragraph(doc, "사건 단어까지 추적해도 다른 제공 사건을 언급한 답변 수는 주제 이탈 조건의 2/16으로 같았다. 달라진 점은 그중 1개에서 원래 사건을 다시 언급한 흐름을 찾아냈다는 것이다. 기존 고유값 방식은 원래 사건의 장소·금액·이름을 반복해야 복귀로 잡았으므로 이 사례를 놓쳤다.")
    paragraph(doc, "별도의 담화 복귀 표현은 ‘let’s get back to’와 ‘getting back to’처럼 대화를 되돌리는 표현을 좁게 추적했다. 일반적인 ‘back to’만 세면 차나 역으로 돌아가는 물리적 이동이 장황 조건 2개에서 오탐되어 이를 분리했다. 사후 보완 규칙의 회귀 점검 12문장 중 12문장을 맞췄으며, 모든 복귀 표현을 포괄하는 정확도로 해석하지 않았다.", small=True)
    heading(doc, "보조 분류도 실제 원문으로 검사했다", 2)
    if passed:
        summaries = context["summaries"]
        table(doc, ["말투", "모델이 새 주제로 분류한 답변", "모델의 N 문장 비율", "모델의 복귀 후보"], [
            [{"plain": "기본", "verbose": "장황", "tangent": "주제 이탈"}[s["style"]],
             f"{s['new_topic_present']}/16", pct(s["mean_new_topic_sentence_fraction"]), f"{s['return_after_away']}/16"]
            for s in summaries], [1.2, 2.05, 1.9, 1.85], numeric=(1,2,3))
        plain, verbose, tangent = summaries
        contrast = context["tangent_minus_verbose"]["new_topic_sentence_fraction"]
        audit = data["reference_audit"]
        paragraph(doc, f"위 표는 보조 분류기의 원시 출력이며 확정된 이탈률이 아니다. 모든 비R 문장 15개를 원문과 대조하자 {audit['flagged_replies']}답변 {audit['flagged_sentences']}문장에서 참조 불일치 경고를 찾았다. ‘Have you ever tried pottery?’와 ‘Do you ride a bike?’를 새 주제로 분류했고, 노래와 라디오 이야기를 다른 제공 사건인 도예로 귀속했다. 이 수치를 주 결과로 채택하지 않고 그대로 보존했다.")
        paragraph(doc, "또 고양이 이야기는 원래 사건으로, 다육식물 관리는 새 주제로 분류했다. 이는 원예라는 넓은 주제와 특정 원예 수업이라는 사건을 혼용한 경계 문제를 보여준다. 주제와 사건을 구분하는 정의가 필요하다는 구체적인 후속 과제를 얻었다.", small=True)
    else:
        paragraph(doc, "문맥 기반 로컬 보조 분류도 대조 문장 기준을 통과하지 못해 48개 답변으로 확대하지 않았다. 따라서 이 방식의 새 주제 비율이나 복귀율을 결과값으로 제시하지 않았다. 위 표의 명시 표식과 실제 원문 흐름이 이번 단계의 직접적인 관찰 결과다.")

    doc.add_page_break()
    heading(doc, "이 숫자가 실제 답변에서 뜻하는 것")
    target = next(r for r in sentence["responses"] if r["condition_id"] == "P-N1-V2-QB-R5-tangent")
    paragraph(doc, "도예 수업에 대해 물었는데, 답변은 도예 이야기에서 놓친 기차와 표값 이야기로 옮겨간 뒤 다시 도예로 돌아왔다. 아래는 같은 답변 안에서 연속한 세 문장이다.")
    for s in target["sentences"]:
        if s["index"] in (9, 10, 11):
            paragraph(doc, f"{s['index']}  {s['text'].strip()}", small=True)
    paragraph(doc, "여기서 마지막 문장은 도예의 장소·금액·이름 없이 ‘pottery class’만 다시 말한다. 따라서 정보값 단위에서 문장별 사건 단위로 측정 범위를 바꾼 효과를 직접 볼 수 있다. 원형 지시는 ‘이탈한 턴 안에서는 돌아오지 말라’고 명시하지만, 이 출력에는 복귀 표현이 나타났다.")
    heading(doc, "측정기는 어떻게 점검했나", 2)
    os_holdout = sentence["calibration"]["holdout"]
    local_holdout = context["control_gate"]["scores"]["holdout"]
    connected = context["control_gate"]["scores"]["connected_control"]
    table(doc, ["측정 방식", "개발 F1", "보류 F1", "보류 주제 재현율"], [
        ["문장 단독 OS 임베딩", f"{sentence['calibration']['development']['macro_f1']:.3f}", f"{os_holdout['macro_f1']:.3f}", pct(os_holdout["known_topic_recall"])],
        ["문맥 포함 로컬 분류", f"{context['control_gate']['scores']['development']['macro_f1']:.3f}", f"{local_holdout['macro_f1']:.3f}", pct(local_holdout["known_topic_recall"])]]
        , [2.6, 1.2, 1.2, 2], numeric=(1,2,3))
    paragraph(doc, f"작성한 개발 40조건과 보류 40조건은 각각 고유 문장 15개를 네 질문 맥락에 교차한 것이다. 연결 대조 4문단 20문장의 문맥 분류 정확도는 {pct(connected['accuracy'])}였다. 단독 임베딩은 사용 기준을 통과하지 못했다. 문맥 분류는 작성 대조 기준은 통과했지만 실제 원문의 참조 점검에서 오류가 드러났다. 개발 혼합 문장 4개도 모두 놓쳤다. 대조 점수만으로 분류기를 확정하지 않았다.", small=True)
    heading(doc, "결론과 다음 실험", 2)
    paragraph(doc, "주제 이탈 지시 조건에서 다른 제공 사건 언급은 2/16답변, 그 뒤 원래 사건의 재언급은 1/16답변이었다. 특히 ‘이탈한 턴 안에서는 돌아오지 않기’라는 지시와 실제 복귀 문장이 함께 나타난 사례를 특정했다. 따라서 말투 이름이나 답변 길이만 보는 대신, 사건 전환과 복귀를 요소별로 검사하는 실험이 가능해졌다.")
    paragraph(doc, "다음은 미사용 사건·질문에서 원형과 한 지시만 수정한 조건을 대응 비교하는 것이다. 다른 사건 언급 수와 그 뒤의 복귀를 따로 보고해, 이탈 자체가 줄어든 것을 복귀 제어의 개선으로 오인하지 않는다. 이 명시적 과제는 현재 측정으로 진행할 수 있다. 넓은 의미의 새 주제 분류는 별도로 보완하고, 교수님께는 이 과제와 임상적 사고장애의 연결을 자문한다.")
    paragraph(doc, "자료  PATIENT-Ψ 고정 커밋 de72a768의 말투 지시. 생성기 및 보조 분류기  Qwen3-14B Q4_K_M, digest bdbd181c. 분류 프롬프트·설정·전체 원문·문장 위치·실행 응답·대조 결과는 각 analysis 폴더에 보존했다. 대조 문장 성능은 임상적 타당도나 독립 모델 검증을 뜻하지 않는다.", small=True)

    OUT.mkdir(parents=True, exist_ok=True)
    if OUTPUT.exists() and not replace:
        raise FileExistsError("Preserve report; use --replace only for layout repairs")
    doc.save(OUTPUT)
    write_json(OUT / "report-inputs.json", {"output_sha256": digest(OUTPUT.read_bytes()),
               "inputs": [{"id": k, "path": str(p.relative_to(ROOT)), "sha256": digest(p.read_bytes())} for k,p in PATHS.items()]})
    print(OUTPUT)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replace", action="store_true", help="Repair this task-generated draft before delivery")
    build(parser.parse_args().replace)
