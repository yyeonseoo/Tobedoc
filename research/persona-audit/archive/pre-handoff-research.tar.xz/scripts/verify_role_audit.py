"""Offline source, span, counts, frozen-code and optional document verification."""
import argparse
from collections import Counter
import subprocess
import sys

from audit_sources import locator
from common import ROOT, digest, write_json
from role_enrichment import OUT, SPEC, read
from run_local_pilot import fingerprint


def main(report=False):
    plan = read(OUT/'plan.json')
    assert digest(SPEC.read_bytes()) == plan['spec_sha256']
    assert digest((ROOT/'scripts/role_enrichment.py').read_bytes()) == plan['code_sha256']
    assert digest((ROOT/'scripts/SentenceUnits.swift').read_bytes()) == plan['segmenter_sha256']
    assert fingerprint(read(OUT/'sentence-input.json')) == plan['input_sha256']
    for item in plan['raw_provenance']:
        assert digest((ROOT/item['path']).read_bytes()) == item['sha256']
    units = read(OUT/'sentence-units.json')
    original = {r['id']:r['text'] for r in read(OUT/'sentence-input.json')}
    assert len(units)==724 and len(original)==80
    for unit in units:
        encoded = original[unit['condition_id']].encode('utf-16-le')
        assert encoded[unit['utf16Start']*2:(unit['utf16Start']+unit['utf16Length'])*2].decode('utf-16-le')==unit['text']
    candidates = read(OUT/'candidate-audit.json')
    reviewed = read(OUT/'reviewed-candidates.json')
    assert {u['id'] for u in candidates} == {r['sentence_id'] for r in reviewed}
    by_id = {u['id']:u for u in units}
    for row in reviewed:
        assert row['sentence']==by_id[row['sentence_id']]['text']
        assert row['evidence_span'] in row['sentence']
        assert row['sentence_sha256']==digest(row['sentence'].encode())
    counts = Counter(r['label'] for r in reviewed)
    assert counts == {'profile_unspecified_explicit_role':6,'profile_specified_role_reference':20,'not_a_person_role_assertion':1}
    result = read(OUT/'audited-results.json')
    rows = read(OUT/'audited-response-metrics.json')
    for summary in result['summaries']:
        group = [r for r in rows if r['style_id']==summary['arm']]
        eligible = [r for r in group if r['eligible_unspecified_role']]
        assert len(group)==16 and len(eligible)==summary['eligible_replies']==12
        assert sum(r['audited_role_addition'] for r in eligible)==summary['role_addition_replies']
        assert sum(r['audited_specified_role_reference'] for r in group)==summary['specified_role_replies']==4
    packet, key = read(OUT/'team-review-packet.json'), read(OUT/'team-review-key.json')
    assert len(packet)==len(key)==25
    assert all(r['status']=='unrated' and r['rater_id'] is None and r['atomic_claims'] is None for r in packet)
    assert Counter(r['style_id'] for r in key)=={arm:5 for arm in ('neutral','simple_verbose','psi_verbose','sim_verbose','sim_concise')}
    assert all('style_id' not in r and 'condition_id' not in r for r in packet)
    recheck=read(OUT/'reused-metric-checks.json')
    assert recheck['status']=='reproduction_of_existing_controls_not_new_experiment'
    assert recheck['eligible_multisentence_replies']==recheck['reversal_invariant_within_1e12']==144
    assert recheck['duplication_increases_mean_similarity']==144
    assert recheck['new_generation_calls']==recheck['new_embedding_calls']==0
    for path, sha in recheck['source_files'].items():
        assert digest((ROOT/path).read_bytes())==sha
    matrix = read(ROOT/'config/feature-comparison-roadmap-v03.json')
    source_checks = []
    for axis in matrix['axes']:
        for item in axis['evidence']:
            source_checks.append({'axis':axis['id'],**locator(item['source'],item['needle'],case_sensitive=False)})
    write_json(OUT/'feature-source-locators.json',source_checks)
    tests = subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-q'],cwd=ROOT,capture_output=True,text=True)
    if tests.returncode:
        raise ValueError(tests.stdout+tests.stderr)
    record = {'reused_replies':80,'sentence_source_spans_verified':724,'reviewed_candidates':27,
              'narrow_role_additions':6,'explicit_source_role_references':20,'non_person_role_candidates':1,
              'raw_file_hash_checks':len(plan['raw_provenance']),'frozen_measurement_code_unchanged':True,
              'feature_axes':len(matrix['axes']),'source_anchors_verified':len(source_checks),
              'unrated_condition_masked_review_units':25,'independent_human_ratings':0,
              'assistant_source_span_review':True,'existing_metric_control_replies_rechecked':144,
              'new_generation_calls':0,'llm_judge_calls':0,'paid_api_calls':0,'new_model_downloads':0,
              'unit_test_output':tests.stderr.strip()}
    share = ROOT/'share/role-enrichment-v01'
    if report:
        from docx import Document
        from build_role_audit_report import OUTPUT
        manifest = read(share/'report-inputs.json')
        for path, sha in manifest['inputs'].items():
            assert digest((ROOT/path).read_bytes())==sha
        assert digest(OUTPUT.read_bytes())==manifest['output_sha256']
        pages = list((share/'render-qa').glob('page-*.png'))
        assert len(pages) in (2,3)
        doc=Document(OUTPUT)
        assert len(doc.tables)==2 and len(doc.tables[1].rows)==8
        for index, summary in enumerate(result['summaries'],1):
            assert doc.tables[0].rows[index].cells[1].text==f"{summary['role_addition_replies']}/{summary['eligible_replies']}"
            assert doc.tables[0].rows[index].cells[2].text=='4/4'
        record.update(rendered_pages=len(pages),report_sha256=digest(OUTPUT.read_bytes()),
                      visual_review='All three page PNGs inspected at original resolution; readable Korean and clean tables, no clipping.')
    write_json(share/'verification.json',record)
    print(record)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report',action='store_true')
    main(parser.parse_args().report)
