// Render four quantitative panels with macOS AppKit; no external plotting package.
import AppKit
import Foundation

struct Panel: Decodable { let title: String; let unit: String; let values: [[Double]] }
struct PlotInput: Decodable { let styles: [String]; let panels: [Panel]; let caption: String; let subtitle: String; let title: String? }
let input = try JSONDecoder().decode(PlotInput.self, from: Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1])))
let width = 1200, height = 850
let bitmap = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: width, pixelsHigh: height, bitsPerSample: 8,
                              samplesPerPixel: 4, hasAlpha: true, isPlanar: false, colorSpaceName: .deviceRGB,
                              bytesPerRow: 0, bitsPerPixel: 0)!
NSGraphicsContext.saveGraphicsState()
NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep: bitmap)
let cg = NSGraphicsContext.current!.cgContext
cg.setFillColor(NSColor.white.cgColor); cg.fill(CGRect(x: 0, y: 0, width: width, height: height))
func text(_ value: String, _ x: Double, _ y: Double, _ size: Double = 13, _ color: NSColor = .black) {
    (value as NSString).draw(at: CGPoint(x: x, y: y), withAttributes: [.font: NSFont.systemFont(ofSize: size), .foregroundColor: color])
}
text(input.title ?? "PATIENT-PSI prompt port on Qwen3-14B: automatic feature profiles", 35, 810, 21)
text(input.subtitle, 35, 783, 14)
for (index, panel) in input.panels.prefix(4).enumerated() {
    let left = Double(index % 2) * 585 + 80
    let bottom = index < 2 ? 460.0 : 105.0
    let plotW = 480.0, plotH = 230.0
    let vals = panel.values.flatMap { $0 }
    let highest = vals.max() ?? 1
    let low = min(0.0, vals.min() ?? 0)
    let high = panel.unit.contains("MATTR20") ? 1.0 : max(highest * 1.15, 0.05)
    func y(_ value: Double) -> Double { bottom + (value-low)/(high-low)*plotH }
    text(panel.title, left, bottom+plotH+38, 17)
    text(panel.unit, left, bottom+plotH+17, 13, .darkGray)
    for tick in 0...4 {
        let value = low + (high-low)*Double(tick)/4
        let yy = y(value)
        cg.setStrokeColor(NSColor(white: 0.85, alpha: 1).cgColor); cg.setLineWidth(0.7)
        cg.move(to: CGPoint(x: left, y: yy)); cg.addLine(to: CGPoint(x: left+plotW, y: yy)); cg.strokePath()
        text(String(format: high > 5 ? "%.0f" : "%.2f", value), left-46, yy-6, 12, .darkGray)
    }
    for (j, values) in panel.values.enumerated() {
        guard !values.isEmpty else { continue }
        let center = left+(Double(j)+0.5)*plotW/Double(input.styles.count)
        let average = values.reduce(0,+)/Double(values.count)
        cg.setFillColor((j == 0 ? NSColor(calibratedRed: 0.21, green: 0.36, blue: 0.48, alpha: 1) : NSColor(white: 0.77, alpha: 1)).cgColor)
        cg.fill(CGRect(x: center-20, y: y(0), width: 40, height: max(0.1, y(average)-y(0))))
        for (k, value) in values.enumerated() {
            let xx = center + (Double(k)-Double(values.count-1)/2)*4.5
            cg.setFillColor(NSColor.black.withAlphaComponent(0.75).cgColor)
            cg.fillEllipse(in: CGRect(x: xx-2.4, y: y(value)-2.4, width: 4.8, height: 4.8))
        }
        text(input.styles[j], center-29, bottom-23, 12)
    }
    text("Prompt style", left+195, bottom-45, 12, .darkGray)
}
text(input.caption, 35, 29, 12, .darkGray)
NSGraphicsContext.restoreGraphicsState()
try bitmap.representation(using: .png, properties: [:])!.write(to: URL(fileURLWithPath: CommandLine.arguments[2]))
print("Saved four-panel quantitative plot.")
