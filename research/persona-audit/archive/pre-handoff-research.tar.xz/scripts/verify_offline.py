"""Run the local, non-inference research workflow and save an honest result record."""
from datetime import datetime, timezone
import csv
import json
import subprocess
import sys

from common import ROOT, write_json


def main():
    commands = [
        [sys.executable, "scripts/audit_sources.py"],
        [sys.executable, "scripts/prepare_pilot.py"],
        [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"],
    ]
    steps = []
    for command in commands:
        result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
        steps.append({"command": command, "exit_code": result.returncode,
                      "stdout": result.stdout, "stderr": result.stderr})
        print(result.stdout, end="")
        print(result.stderr, end="", file=sys.stderr)
        if result.returncode:
            write_json(ROOT / "docs/verification.json", {
                "verified_at_utc": datetime.now(timezone.utc).isoformat(),
                "status": "failed", "steps": steps,
                "inference_executed_by_this_workflow": False})
            return result.returncode
    with (ROOT / "catalog/feature-map.csv").open(encoding="utf-8", newline="") as f:
        feature_count = len(list(csv.DictReader(f)))
    lock = json.loads((ROOT / "evidence/source-lock.json").read_text())
    findings = json.loads((ROOT / "evidence/static-findings.json").read_text())
    design = json.loads((ROOT / "pilot/design-summary.json").read_text())
    write_json(ROOT / "docs/verification.json", {
        "verified_at_utc": datetime.now(timezone.utc).isoformat(), "status": "passed",
        "steps": steps,
        "source_count": len(lock["sources"]),
        "source_ok_count": sum(x["status"] == "ok" for x in lock["sources"]),
        "static_finding_count": len(findings["findings"]),
        "feature_entry_count": feature_count, "condition_count": design["condition_count"],
        "planned_calls_per_backbone_per_repeat": design["planned_calls_per_backbone_per_repeat"],
        "inference_executed_by_this_workflow": False, "clinical_validation": False,
        "warning": "Prepared conditions and source checks are not generated patient observations or clinical results."})
    print("Saved docs/verification.json; no network or inference in this verification workflow.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
