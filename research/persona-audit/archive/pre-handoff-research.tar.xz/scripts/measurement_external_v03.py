"""Frozen, tokenized-news-aware sentence boundaries; reuse V01 statistics.

The previous native-tokenizer analysis remains intact. Rules are not selected
for correlation; V03 is explicitly a posthoc preprocessing followup.
"""
import argparse
from datetime import datetime, timezone
from pathlib import Path
import re
import subprocess
import tempfile
import time
import measurement_external as stats
import measurement_external_v02 as missing

core=stats.core
ROOT=core.ROOT
SPEC=ROOT/'config/measurement-external-v03.json'
OUT=ROOT/'analysis/measurement-external-v03'
RAW=stats.RAW
ABBREVIATIONS=set(core.read(SPEC)['abbreviations'])


def segment(text):
    spans=[]
    start=0
    for match in re.finditer(r'''[.!?]+(?:["')\]]*)?(?=\s|$)''',text):
        end=match.end()
        prefix=text[:match.start()].rstrip()
        last=re.search(r'([A-Za-z.]+)$',prefix)
        if last and last.group(1).lower().rstrip('.') in ABBREVIATIONS and text[end:].strip():
            continue
        while start<end and text[start].isspace(): start+=1
        if end>start:
            spans.append((start,end))
        start=end
    while start<len(text) and text[start].isspace(): start+=1
    if start<len(text):
        end=len(text.rstrip())
        spans.append((start,end))
    assert ''.join(text[a:b] for a,b in spans).replace(' ','')==''.join(text.split()), 'Non-whitespace loss'
    # Direct span verification, including tabs/newlines and non-BMP characters.
    for a,b in spans:
        assert text[a:b].strip()==text[a:b]
    return [{'text':text[a:b],'char_start':a,'char_end':b,
             'utf16_start':len(text[:a].encode('utf-16-le'))//2,
             'utf16_length':len(text[a:b].encode('utf-16-le'))//2} for a,b in spans]


def hashes():
    return {str(p.relative_to(ROOT)):core.sha(p) for p in (
        SPEC,ROOT/'config/measurement-external-v01.json',RAW,Path(__file__).resolve(),
        ROOT/'scripts/measurement_external.py',ROOT/'scripts/measurement_external_v02.py',
        ROOT/'scripts/measurement_audit.py',core.SWIFT)}


def check():
    seal=core.read(OUT/'seal.json')
    assert seal['source_hashes']==hashes()
    for name in ('segments.json','embedding-input.json'):
        assert seal['prepared_hashes'][name]==core.sha(OUT/name)
    return seal


def prepare():
    rows=stats.source_records()
    mapping={r['text_id']:segment(r['text']) for r in rows}
    unique=sorted({s['text'] for ss in mapping.values() for s in ss})
    core.immutable(OUT/'segments.json',mapping)
    core.immutable(OUT/'embedding-input.json',[{'id':core.ident(t),'text':t} for t in unique])
    if (OUT/'seal.json').exists(): check()
    else:
        assert not (OUT/'embedding-output.json').exists()
        core.save(OUT/'seal.json',{'created_utc':datetime.now(timezone.utc).isoformat(),
            'source_hashes':hashes(),'prepared_hashes':{n:core.sha(OUT/n) for n in ('segments.json','embedding-input.json')},
            'unique_summary_texts':len(mapping),'unique_sentence_texts':len(unique),
            'records':len(rows),'articles':100,'systems':16,
            'rule_segment_counts':{str(n):sum(len(mapping[r['text_id']])==n for r in rows)
                                   for n in sorted({len(ss) for ss in mapping.values()})},
            'scope':core.read(SPEC)['timing']})
    print({k:v for k,v in core.read(OUT/'seal.json').items() if k in ('records','unique_sentence_texts','rule_segment_counts')})


def embed():
    check()
    if (OUT/'embedding-output.json').exists():
        load_native();print('Reused verified rule-segment embedding cache');return
    start=time.monotonic()
    with tempfile.TemporaryDirectory(prefix='external-rule-',dir='/private/tmp') as tmp:
        binary=Path(tmp)/'NativeFeatures'
        subprocess.run(['/usr/bin/swiftc','-module-cache-path',str(Path(tmp)/'modules'),str(core.SWIFT),'-o',str(binary)],check=True,capture_output=True)
        subprocess.run([str(binary),str(OUT/'embedding-input.json'),str(OUT/'embedding-output.json')],check=True)
    core.save(OUT/'embedding-manifest.json',{'input_sha256':core.sha(OUT/'embedding-input.json'),
        'output_sha256':core.sha(OUT/'embedding-output.json'),'wall_seconds':time.monotonic()-start,
        'generations':0,'judges':0,'paid_apis':0,'downloads':0})
    load_native()


def load_native():
    check()
    manifest=core.read(OUT/'embedding-manifest.json')
    assert manifest['input_sha256']==core.sha(OUT/'embedding-input.json')
    assert manifest['output_sha256']==core.sha(OUT/'embedding-output.json')
    native=core.read(OUT/'embedding-output.json')
    assert native['embeddingRevision']==1 and native['embeddingDimension']==512
    inputs=core.read(OUT/'embedding-input.json')
    indexed={r['id']:r for r in native['records']}
    assert len(indexed)==len(inputs)==len(native['records'])
    assert set(indexed)=={r['id'] for r in inputs}
    vectors={}
    for item in inputs:
        assert item['id']==core.ident(item['text'])
        vector=indexed[item['id']]['vector']
        # Use whole-atom vectors; native subsegmentation does not define V03 boundaries.
        if vector is not None:
            assert len(vector)==512
            core.cosine(vector,vector)
        vectors[item['text']]=vector
    mapping=core.read(OUT/'segments.json')
    result={k:{'sentences':[{**s,'vector':vectors[s['text']]} for s in ss]} for k,ss in mapping.items()}
    for r in stats.source_records():
        encoded=r['text'].encode('utf-16-le')
        for s in result[r['text_id']]['sentences']:
            a=2*s['utf16_start'];b=a+2*s['utf16_length']
            assert encoded[a:b].decode('utf-16-le')==s['text']
    return result,{**{k:v for k,v in native.items() if k!='records'},
                   'segmentation':'frozen regex terminal-punctuation rules V03, native tokenizer not used for boundaries'}


def activate():
    stats.OUT=OUT;stats.SPEC=SPEC;stats.hashes=hashes
    stats.seal_check=check;stats.load_native=load_native;stats.features=missing.features


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('action',choices=('prepare','embed','score','verify'))
    action=p.parse_args().action
    if action in ('prepare','embed'): globals()[action]()
    else:
        activate();getattr(stats,action)()
