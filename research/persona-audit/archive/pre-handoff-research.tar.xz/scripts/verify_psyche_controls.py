"""Offline verification independently recomputes word counts, gates and decisions."""
from collections import Counter, defaultdict
import json
from pathlib import Path
import re
import statistics

from common import ROOT, digest, write_json
import psyche_controls as controls


def main():
    spec, previous, requests, plan = controls.prepare()
    out = controls.OUT
    runtime = controls.read(out / 'runtime.json')
    assert runtime['model']['digest'] == previous['model_digest']
    assert runtime['template_sha256'] == digest(runtime['show']['template'].encode())
    assert controls.stable_runtime(runtime) == controls.stable_runtime(controls.read(controls.old.OUT / 'runtime.json'))
    summary = controls.read(out / 'summary.json')
    measurements = controls.read(out / 'measurements.json')
    by_id = {r['id']: r for r in measurements}
    hashes, counts, token_counts, grouped = {}, Counter(), [], defaultdict(list)
    pattern = re.compile(r"[A-Za-z]+(?:['’-][A-Za-z]+)*|\d+(?:\.\d+)?")
    for request in requests:
        path = out / 'responses' / (request['id'] + '.json')
        response = controls.read(path)
        expected = controls.old.fingerprint(request['payload'])
        assert response['request_sha256'] == expected
        assert response['status'] == controls.old.classify(response['raw'], previous) == 'completed'
        if response['origin'] == 'exact_cache':
            source = plan['cache_sources'][request['id']]
            assert response['cache_source'] == source
            assert digest((ROOT / source['path']).read_bytes()) == source['sha256']
            assert controls.read(ROOT / source['path'])['raw'] == response['raw']
            assert not (out / 'attempts' / (request['id'] + '.json')).exists()
        else:
            assert response['origin'] == 'new_local_call'
            assert controls.read(out / 'attempts' / (request['id'] + '.json'))['request_sha256'] == expected
        counts[response['origin']] += 1
        raw = response['raw']
        text = raw['message']['content']
        words = len(pattern.findall(text))
        measured = by_id[request['id']]
        assert measured['words'] == words and measured['text'] == text
        numeric = request['numeric_instruction_provided']
        expected_hit = request['target'][0] <= words <= request['target'][1] if numeric else None
        assert measured['target_hit'] == expected_hit
        count = raw['prompt_eval_count']
        assert count > 0 and count + previous['options']['num_predict'] + 2048 < previous['options']['num_ctx']
        token_counts.append(count)
        grouped[request['arm']].append(measured)
        hashes[str(path.relative_to(ROOT))] = digest(path.read_bytes())
    assert counts == {'new_local_call': 28, 'exact_cache': 4}
    assert len(list((out / 'attempts').glob('*.json'))) == 28
    assert len(list((out / 'responses').glob('*.json'))) == len(measurements) == 32
    computed = {}
    for arm, rows in grouped.items():
        pairs = defaultdict(dict)
        for row in rows:
            pairs[(row['question'], row['seed'])][row['quantity']] = row['words']
        differences = [v['Increased']-v['Normal'] for v in pairs.values()]
        positives = sum(d > 0 for d in differences)
        mean = statistics.mean(differences)
        hits = sum(row['target_hit'] is True for row in rows) if arm != 'hub_label' else None
        passed = (len(rows) == 8 and hits >= 6 and positives >= 4 and mean >= 50) if hits is not None else None
        reported = next(a for a in summary['arms'] if a['arm'] == arm)
        assert reported['target_hits'] == hits
        assert reported['positive_pairs'] == positives
        assert reported['mean_long_minus_short_words'] == mean
        assert reported['engineering_gate_pass'] == passed
        computed[arm] = passed
    choice = None
    if not computed['direct_numeric']:
        decision = 'direct_control_failed_do_not_declare_backbone_controllable'
    else:
        choice = next((arm for arm in spec['gate']['selection_priority'] if computed[arm]), None)
        decision = 'retain_for_bounded_output_control_only' if choice else 'direct_control_passed_but_wrapper_control_failed'
    assert summary['complete'] and summary['decision'] == decision and summary['selected_engineering_arm'] == choice
    assert summary['clinical_scores'] == summary['judge_calls'] == summary['paid_api_calls'] == 0
    manifest = controls.read(out / 'analysis-manifest.json')
    assert manifest['raw_responses'] == hashes
    assert manifest['measurements_sha256'] == digest((out / 'measurements.json').read_bytes())
    assert manifest['summary_sha256'] == digest((out / 'summary.json').read_bytes())
    assert manifest['plan_sha256'] == controls.old.fingerprint(plan)
    key = controls.read(out / 'blinding-key.json')
    assert len(key) == len({r['blind_id'] for r in key}) == 32
    assert {r['condition_id'] for r in key} == {r['id'] for r in requests}
    assert not (out / '.running').exists()
    result = {'passed': True, 'effective_responses_verified': 32, 'new_local_calls_verified': 28,
              'exact_cache_reuses_verified': 4, 'engineering_decision_recomputed': decision,
              'prompt_token_range': [min(token_counts), max(token_counts)],
              'verifier_sha256': digest(Path(__file__).read_bytes()),
              'tests_sha256': digest((ROOT / 'tests/test_psyche_controls.py').read_bytes()),
              'summary_sha256': digest((out / 'summary.json').read_bytes())}
    write_json(out / 'verification.json', result)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
