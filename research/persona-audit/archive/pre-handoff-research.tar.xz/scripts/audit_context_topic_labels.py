"""Posthoc in-sample reference checks; never silently fix or delete model labels."""
import json
import re

from common import ROOT, digest, write_json

OUT = ROOT / "analysis/context-topic-labeler-v01"


def contradiction_flags(row):
    flags = []
    reply_has_other_anchor = any(s["other_anchor_hits"] for s in row["sentences"])
    for s in row["sentences"]:
        if (s["context_label"] == "N" and s["requested_anchor_hits"] and not s["other_anchor_hits"]
                and re.match(r"^\s*(?:have you ever tried|do you (?:ride|like|enjoy))\b", s["text"], re.I)):
            flags.append({"sentence_index": s["index"], "text": s["text"], "predicted": "N",
                          "check": "same_requested_topic_question",
                          "finding": "The question names only the requested activity; changing speaker direction is not changing topic."})
        if s["context_label"] == "O" and not reply_has_other_anchor:
            flags.append({"sentence_index": s["index"], "text": s["text"], "predicted": "O",
                          "check": "other_supplied_event_without_any_reply_anchor",
                          "finding": "No other-event word or value appears anywhere in the reply; inspect whether O is an unsupported event attribution."})
    return flags


def build():
    path = OUT / "results.json"
    result = json.loads(path.read_text())
    if result["annotated_existing_replies"] != 48:
        raise ValueError("Audit requires all 48 existing replies")
    flagged = [{"condition_id": r["condition_id"], "style": r["style_id"], "question": r["question"], **f}
               for r in result["responses"] for f in contradiction_flags(r)]
    non_requested = [{"condition_id": r["condition_id"], "question": r["question"], "sentence_index": s["index"],
                      "label": s["context_label"], "text": s["text"],
                      "requested_anchor_hits": s["requested_anchor_hits"], "other_anchor_hits": s["other_anchor_hits"]}
                     for r in result["responses"] for s in r["sentences"] if s["context_label"] != "R"]
    audit = {"posthoc_in_sample_audit": True,
        "constructed_control_gate_passed": result["control_gate"]["passed"],
        "automatic_semantic_rate_promoted_to_primary": False,
        "reason": "Passing authored controls did not ensure sensible labels on generated replies. Keep raw labels and model-only counts as diagnostics, not established topic-shift or return rates.",
        "flagged_sentences": len(flagged), "flagged_replies": len({f["condition_id"] for f in flagged}),
        "flags": flagged, "all_non_R_sentences": non_requested,
        "manual_reference_review": [
            {"condition_id": "P-N1-V1-QA-R5-tangent", "sentence_indices": [6,7],
             "finding": "These sentences describe singing to the radio and being in a musical. The requested event is a train trip; the other supplied event is pottery. Nothing in this reply links singing to pottery. O is an unsupported attribution; R versus N depends on how topical elaboration is defined."},
            {"condition_id": "P-N2-V2-QA-R4-tangent", "sentence_indices": [2,3,6,7,8,9],
             "finding": "The model retains the cat story as R but labels succulent care N. Gardening as a subject and the workshop as a particular episode are not interchangeable. Preserve the text; the model boundary is not ground truth."}],
        "new_model_calls": 0, "corrected_or_excluded_raw_labels": 0,
        "source_sha256": digest(path.read_bytes()), "script_sha256": digest((ROOT / "scripts/audit_context_topic_labels.py").read_bytes())}
    write_json(OUT / "reference-audit.json", audit)
    print(json.dumps({k:audit[k] for k in ("constructed_control_gate_passed", "automatic_semantic_rate_promoted_to_primary", "flagged_sentences", "flagged_replies")},ensure_ascii=False))
    return audit


if __name__ == "__main__":
    build()
