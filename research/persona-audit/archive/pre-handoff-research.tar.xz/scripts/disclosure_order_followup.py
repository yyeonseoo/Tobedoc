"""Six post-pilot crossed-order replies; not an independent confirmatory sample."""
import argparse
import copy
import json
import random
from collections import defaultdict
from statistics import mean

from common import ROOT, digest, write_json
from fact_disclosure_probe import SPEC, FOLDER as PRIMARY, conditions as primary_conditions, match_fact
from first_reply_probe_runner import run, verify_response
from run_local_pilot import OPTIONS, fingerprint, now
from summarize_local_pilot import text_metrics

RUN = "fact-disclosure-order-followup-v01"
FOLDER = ROOT / "pilot/runs" / RUN
OUT = ROOT / "analysis" / RUN


def conditions():
    spec = json.loads(SPEC.read_text())
    rows = []
    for original in primary_conditions():
        if original["style_id"] != "psi_reserved_no_numeric_cap":
            continue
        row = copy.deepcopy(original)
        row["condition_id"] = row["condition_id"].replace("D-", "X-", 1)
        questions = [spec["personal_question"], spec["event_question"]]
        if row["repeat_index"] == 1:
            questions.reverse()
        row["interview"][0]["text"] = " ".join(questions)
        row["prompt_sha256"] = fingerprint({"system_prompt": row["system_prompt"], "interview": row["interview"]})
        rows.append(row)
    random.Random(20261030).shuffle(rows)
    assert len(rows) == 6
    return rows


def prepare():
    rows = conditions()
    primary_plan = json.loads((PRIMARY / "plan.json").read_text())
    plan = {"run_id": RUN, "max_requests": 6, "scope": "Exploratory follow-up prompted by the first 18-reply pilot; not preregistration or heldout confirmation",
            "reason": "Original seed and domain question order covaried; reserve replies showed an all-or-none pattern",
            "primary": "Personal fact-mention difference between personal-first and event-first, paired within case and seed",
            "design": "Complete missing order-by-seed combinations for reserved only; combine original six reserved replies with six new replies",
            "hypothesis_before_followup": "Could be order, seed, or interaction; no direction is selected as success",
            "analysis": "Twelve reserved replies, three fictional cases x two seeds x two orders; six paired order differences, descriptive only",
            "limits": "No new plain/brief arms, so this is not a full style-by-order interaction experiment; no independent replication",
            "stopping": "Exactly six additional requests; no retries or selected replacements; frozen primary aliases unchanged",
            "options": OPTIONS, "think": False, "seed_rule": primary_plan["seed_rule"],
            "model_digest": primary_plan["model_digest"], "primary_plan_sha256": digest((PRIMARY / "plan.json").read_bytes()),
            "spec_sha256": digest(SPEC.read_bytes()), "conditions_sha256": fingerprint(rows)}
    for name, obj in [("plan.json", plan), ("conditions.json", rows)]:
        path = FOLDER / name
        if path.exists():
            if json.loads(path.read_text()) != obj:
                raise ValueError("Frozen follow-up changed")
        else:
            write_json(path, obj)
    if not (FOLDER / "prepared-at.json").exists():
        write_json(FOLDER / "prepared-at.json", {"prepared_at_utc": now(), "plan_sha256": fingerprint(plan)})
    return plan, rows


def analyze():
    plan, new_cases = prepare()
    old_cases = [r for r in primary_conditions() if r["style_id"] == "psi_reserved_no_numeric_cap"]
    spec = json.loads(SPEC.read_text())
    rows, provenance = [], [SPEC, FOLDER / "plan.json", FOLDER / "conditions.json", FOLDER / "runtime.json", PRIMARY / "runtime.json"]
    for folder, cases in [(PRIMARY, old_cases), (FOLDER, new_cases)]:
        for case in cases:
            rp = folder / "requests" / (case["condition_id"] + ".json")
            sp = folder / "responses" / (case["condition_id"] + ".json")
            raw, request = json.loads(sp.read_text()), json.loads(rp.read_text())
            verify_response(raw, request, case, plan["model_digest"])
            hits = [match_fact(raw["response_text"], f) for f in case["facts"]]
            order = "event_first" if case["interview"][0]["text"].startswith(spec["event_question"]) else "personal_first"
            rows.append({"condition_id": case["condition_id"], "profile_id": case["profile_id"], "repeat_index": case["repeat_index"],
                         "order": order, "count": {d: sum(f["recognized_mention"] for f in hits if f["domain"] == d) for d in ["personal", "event"]},
                         "fact_matches": hits, "response_text": raw["response_text"], "text_metrics": text_metrics(raw["response_text"]),
                         "source_phase": "primary_pilot" if folder == PRIMARY else "postpilot_followup"})
            provenance += [rp, sp]
    cells = []
    for repeat in (0, 1):
        for order in ("event_first", "personal_first"):
            group = [r for r in rows if r["repeat_index"] == repeat and r["order"] == order]
            assert len(group) == 3
            cells.append({"repeat_index": repeat, "order": order, "personal_mentions": sum(r["count"]["personal"] for r in group),
                          "event_mentions": sum(r["count"]["event"] for r in group), "denominator_per_domain": 9,
                          "mean_words": mean(r["text_metrics"]["word_count"] for r in group)})
    pairs = defaultdict(dict)
    for r in rows:
        pairs[(r["profile_id"], r["repeat_index"])][r["order"]] = r["count"]["personal"] / 3
    assert len(pairs) == 6 and all(len(v) == 2 for v in pairs.values())
    differences = [v["personal_first"]-v["event_first"] for v in pairs.values()]
    order_totals = []
    for order in ("event_first", "personal_first"):
        group = [r for r in rows if r["order"] == order]
        order_totals.append({"order": order, "replies": len(group), "denominator_per_domain": 3*len(group),
                             "personal_mentions": sum(r["count"]["personal"] for r in group),
                             "event_mentions": sum(r["count"]["event"] for r in group)})
    primary_result = json.loads((ROOT / "analysis/fact-disclosure-probe-v01/results.json").read_text())
    provenance.append(ROOT / "analysis/fact-disclosure-probe-v01/results.json")
    # Post-pilot literal QA note: compare an explicit generated amount to its
    # supplied fictional value. No clinical rating and no score correction.
    literal_checks = []
    for row in rows:
        if row["profile_id"] == "C3" and "Water bill. Eighteen dollars." in row["response_text"]:
            literal_checks.append({"condition_id": row["condition_id"], "fact_id": "amount",
                "expected_from_profile": "180 dollars", "observed_literal": "Eighteen dollars",
                "interpretation": "Literal amount mismatch, not evidence of intentional withholding",
                "status": "Posthoc targeted QA; primary frozen matcher and scores unchanged"})
    result = {"plan": plan, "new_responses": 6, "reused_primary_responses": 6, "reserved_total": len(rows), "cells": cells,
              "personal_first_minus_event_first": {"block_differences": differences, "mean": mean(differences)}, "responses": rows,
              "order_totals": order_totals, "posthoc_literal_checks": literal_checks,
              "provenance": [{"path": str(p.relative_to(ROOT)), "sha256": digest(p.read_bytes())} for p in provenance]}
    write_json(OUT / "results.json", result)
    lines = ["# 정보 공개를 꺼리는 페르소나는 무엇을 숨기는가?", "",
             "## 출발 질문과 전체 규모", "",
             "앞선 실험에서는 경계적 말투가 답변을 짧게 만든다는 사실만 확인했다. 이번에는 ‘짧게 말할 뿐인가, 개인 정보를 덜 말하는가’를 구분했다. "
             "모두 허구 사례이며, 초기 18개와 후속 6개를 합쳐 새로 생성한 답변은 24개다. 후속 결과에 기존 답변 6개를 재사용했으므로 중복을 새 표본으로 세지 않는다.", "",
             "## 1. 단순한 간결함과 비교한 18개 답변", "",
             "허구 인물 3명에게 행사 정보 3개(장소·입장료·좌석 수)와 개인 청구서 정보 3개(종류·금액·연체 일수)를 제공하고 모두 질문했다. "
             "두 종류의 질문을 하나의 user 메시지에 묶어 첫 답변만 받았다. "
             "같은 Qwen·사례·질문에서 말투 없음 / 간결하게 답하기 / PSI reserved에서 숫자 문장 제한만 제거한 지시를 비교했다. 별도 문장 수 제한은 없었다.", ""]
    labels = {"plain": "말투 설정 없음", "brief_only": "간결하게 답하기", "psi_reserved_no_numeric_cap": "경계적 말투 지시 묶음"}
    for summary in primary_result["summaries"]:
        lines.append(f"- {labels[summary['style']]}: 개인 정보 표현 {summary['personal_mentions']}/18, 행사 정보 표현 {summary['event_mentions']}/18 식별; 평균 {summary['mean_words']:.1f}단어.")
    lines += ["", "단순 간결 조건에서는 정보를 모두 언급했다. 경계적 조건에서는 개인 정보뿐 아니라 행사 정보도 함께 줄었다. "
              "그러나 초기 설계에서 질문 순서와 seed가 함께 바뀌었으므로 이 결과만으로 어느 쪽의 영향인지 구분하지 않았다.", "",
             "## 2. 질문 순서와 seed를 엇갈리게 한 추가 6개", "",
             "첫 18응답의 패턴을 본 뒤 설계한 탐색적 후속 실험이다. 같은 사례를 재사용했으며 독립 검증이라고 부르지 않는다. "
             "기존 reserved 6개에 순서만 반대로 바꾼 새 답변 6개를 더해, 사례 3개×seed 2개×질문 순서 2개의 12조건을 완성했다.", "",
             "동일한 seed에서도 질문 순서를 바꿔 비교할 수 있도록 했다. seed를 고정해도 서버·구현 차이를 포함한 완전한 결정론적 재현이 보장되는 것은 아니다.", ""]
    for c in cells:
        lines.append(f"- seed 반복 {c['repeat_index']}, {c['order']}: 개인 정보 {c['personal_mentions']}/9, 행사 정보 {c['event_mentions']}/9 식별; 평균 {c['mean_words']:.1f}단어.")
    lines += ["", f"같은 사례·seed 안에서 개인 질문 먼저−행사 질문 먼저의 개인 정보 언급 비율 차이: {mean(differences):+.3f}.", "",
              "## 3. 이번 결과의 의미", ""]
    for total in order_totals:
        lines.append(f"- {'행사를 먼저 질문' if total['order'] == 'event_first' else '개인 청구서를 먼저 질문'}: 개인 정보 {total['personal_mentions']}/{total['denominator_per_domain']}, 행사 정보 {total['event_mentions']}/{total['denominator_per_domain']} 식별({total['replies']}개 답변).")
    lines += ["", "이 자료에서는 ‘개인 정보만 골라 숨기는 반응’보다 질문 순서에 따라 두 종류의 정보를 함께 답하거나 함께 생략하는 반응이 두드러졌다. "
              "따라서 단일 질문 순서에서 얻은 평균 답변 길이나 정보 누락률을 페르소나의 고정된 특성으로 해석하기 어렵다. "
              "이는 지시문 이식의 질문 순서 민감성에 대한 관찰이지, 원형 시스템의 실패나 실제 환자와의 불일치를 입증한 결론은 아니다.", ""]
    if literal_checks:
        lines += ["추가 원문 점검: C3의 행사 우선 후속 답변 한 건에서 프로필의 180달러 대신 ‘Eighteen dollars’가 출력됐다. "
                  "이 금액 불일치는 의도적인 정보 회피와 구분한다. 이를 보고 표현 목록을 늘리거나 답변을 다시 생성하지 않았다.", ""]
    lines += ["## 한계와 다음 검증", "",
              "문자적 정보 언급만 측정한다. 이 차이가 있더라도 주제 민감성·임상적 경계심의 참값을 입증하지 않는다. "
              "사전에 고정한 숫자·표현 목록으로 검색하므로 다른 표현을 놓치거나 부정 문구 안의 값을 셀 수 있다. "
              "모든 원문과 일치 구간을 저장했다. 행사와 개인 청구서는 사실 유형도 다르므로 민감성의 검증된 척도가 아니다. "
              "reserved 지시는 일부 턴에서 평범하게 행동하는 것도 허용한다. 변동 자체를 원형 설계의 실패로 간주하지 않는다. "
              "이번 추가 생성에는 plain/brief 조건이 없으므로 전체 스타일×순서 상호작용의 검증도 아니다.", "",
              "이번 단계는 여기서 종료한다. 후속 검증은 인물·표현이 다른 미사용 사례와 질문 순서를 미리 교차한 설계에서 같은 현상이 유지되는지 확인하는 것이다. "
              "반복된다면 두 질문을 분리했을 때도 전체 응답 거부가 유지되는지를 검토할 수 있다. 현재 자료만으로 프롬프트 개선의 성공이나 임상적 타당도를 주장하지 않는다.", "",
              "## 같은 사례의 2×2 원문", "", "효과 크기를 보지 않고 C1의 네 조합을 모두 제시한다.", ""]
    for row in sorted(rows, key=lambda r: (r["repeat_index"], r["order"])):
        if row["profile_id"] == "C1":
            lines += [f"### 반복 {row['repeat_index']} · {row['order']} · {row['source_phase']}", "", row["response_text"], ""]
    (OUT / "report.ko.md").write_text("\n".join(lines))
    print(json.dumps({"cells": cells, "paired_order_difference": mean(differences)}, ensure_ascii=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--run", action="store_true")
    mode.add_argument("--analyze-only", action="store_true")
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if args.analyze_only:
        analyze()
    elif args.run:
        plan, cases = prepare()
        run(plan, cases, FOLDER, args.resume)
        analyze()
    else:
        plan, _ = prepare()
        print(json.dumps(plan, ensure_ascii=False))
