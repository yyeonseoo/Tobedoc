"""One bounded control pipeline: freeze -> exact-cache reuse -> local run -> analyze.

Default prepares only. --execute performs at most 28 NEW loopback Ollama calls.
No downloads, installs, paid APIs, remote jobs, model judges or automatic retries.
"""
from __future__ import annotations

import argparse
from collections import defaultdict, Counter
from copy import deepcopy
from datetime import datetime, timezone
import json
from pathlib import Path
import random
import statistics

from common import ROOT, digest, write_json
import psyche_factorial as old
from audit_psyche_roleplay_sources import source_text, yaml_english_block, verify_sources, LOCK

SPEC = ROOT / 'config/psyche-controls-v01.json'
OUT = ROOT / 'analysis/psyche-controls-v01'
SHARE = ROOT / 'share/psyche-controls-v01'


def read(path):
    return json.loads(path.read_text())


def build(spec, previous):
    template = yaml_english_block(source_text('data/prompts/client/psyche.yaml'), 'system_prompt')
    rows = []
    for arm in spec['arms']:
        for quantity in spec['quantity']:
            for question in spec['questions']:
                for seed in spec['seeds']:
                    case = deepcopy(previous['case'])
                    case['MFC-Behavior']['Verbal productivity'] = quantity
                    case['MFC-Behavior']['Thought process'] = 'Normal'
                    low, high = spec['targets'][quantity]
                    instruction = spec['instruction'].format(low=low, high=high)
                    if arm == 'hub_json_numeric':
                        case[spec['json_extension_key']] = instruction
                    encoded = json.dumps(case, ensure_ascii=False, indent=2)
                    if arm == 'direct_numeric':
                        prompt = 'You are a simulated patient. Answer as this patient, not as a clinician. Use this fictional case as background and retain its facts.\n' + encoded + '\n\n' + instruction
                    else:
                        prompt = template.replace('{{data.mfc}}', encoded)
                        if arm == 'hub_tail_numeric':
                            prompt += '\n\n' + instruction
                        elif arm not in ('hub_label', 'hub_json_numeric'):
                            raise ValueError('Unknown arm')
                    if '{{' in prompt or '}}' in prompt:
                        raise ValueError('Unresolved prompt template')
                    payload = {'model': previous['model'], 'stream': False, 'think': False,
                               'keep_alive': '5m', 'messages': [{'role': 'system', 'content': prompt},
                                                              {'role': 'user', 'content': question['text']}],
                               'options': {**previous['options'], 'seed': seed}}
                    if sum(len(m['content'].encode()) for m in payload['messages']) + previous['options']['num_predict'] + 2048 >= previous['options']['num_ctx']:
                        raise ValueError('Conservative context guard exceeded')
                    rows.append({'id': f'{arm}-{quantity.lower()}-{question["id"]}-{seed}',
                                 'arm': arm, 'quantity': quantity, 'question': question['id'], 'seed': seed,
                                 'target': [low, high], 'numeric_instruction_provided': arm != 'hub_label',
                                 'case': case, 'payload': payload})
    random.Random(20261103).shuffle(rows)
    return rows


def cache_candidates(rows, previous):
    """Exact-payload cache, never a fuzzy or same-condition-name match."""
    previous_rows = read(old.OUT / 'requests.json')
    lookup = {old.fingerprint(r['payload']): r for r in previous_rows}
    result = {}
    for row in rows:
        match = lookup.get(old.fingerprint(row['payload']))
        if match is None:
            continue
        path = old.OUT / 'responses' / (match['id'] + '.json')
        response = read(path)
        if response['request_sha256'] != old.fingerprint(row['payload']) or old.classify(response['raw'], previous) != 'completed':
            raise ValueError('Cache source integrity failure')
        result[row['id']] = {'path': str(path.relative_to(ROOT)), 'sha256': digest(path.read_bytes())}
    return result


def prepare():
    spec, previous = read(SPEC), read(old.SPEC)
    verify_sources(read(LOCK))
    rows = build(spec, previous)
    caches = cache_candidates(rows, previous)
    if len(rows) != spec['planned_effective_answers'] or len(caches) != spec['expected_exact_cache_reuses']:
        raise ValueError('Unexpected design/cache size; review rather than expand inference')
    if len(rows)-len(caches) > spec['maximum_new_model_calls']:
        raise ValueError('Call cap exceeded')
    plan = {'spec_sha256': digest(SPEC.read_bytes()), 'previous_spec_sha256': digest(old.SPEC.read_bytes()),
            'script_sha256': digest(Path(__file__).read_bytes()), 'reused_helper_sha256': digest(Path(old.__file__).read_bytes()),
            'source_lock_sha256': digest(LOCK.read_bytes()), 'previous_plan_sha256': digest((old.OUT / 'plan.json').read_bytes()),
            'requests_sha256': old.fingerprint(rows), 'cache_sources': caches,
            'effective_answers': len(rows), 'new_call_cap': len(rows)-len(caches),
            'thought_process_fixed': 'Normal', 'clinical_validation': False}
    old.save_once(OUT / 'plan.json', plan)
    old.save_once(OUT / 'requests.json', rows)
    return spec, previous, rows, plan


def stable_runtime(value):
    return {key: value[key] for key in ('model', 'version', 'show', 'template_sha256', 'parameters_sha256', 'options', 'think')}


def execute(spec, previous, rows, plan, resume=False):
    policy = read(ROOT / 'config/compute-policy.json')
    if policy['paid_model_api_allowed'] or policy['automatic_model_download_allowed']:
        raise ValueError('Unexpected policy change')
    current = old.runtime(previous)
    if old.fingerprint(stable_runtime(current)) != old.fingerprint(stable_runtime(read(old.OUT / 'runtime.json'))):
        raise ValueError('Runtime changed from cached experiment; cannot reuse as matched controls')
    runtime_path = OUT / 'runtime.json'
    if runtime_path.exists():
        if not resume or read(runtime_path) != current:
            raise ValueError('Use explicit resume with identical runtime only')
    else:
        write_json(runtime_path, current)
    lock = OUT / '.running'
    with lock.open('x') as handle:
        handle.write(datetime.now(timezone.utc).isoformat())
    try:
        for index, row in enumerate(rows, 1):
            path = OUT / 'responses' / (row['id'] + '.json')
            request_hash = old.fingerprint(row['payload'])
            if path.exists():
                record = read(path)
                if record['request_sha256'] != request_hash or record['status'] != 'completed':
                    raise ValueError('Cannot silently retry inconsistent/failed response')
                continue
            cached = plan['cache_sources'].get(row['id'])
            if cached:
                source_path = ROOT / cached['path']
                if digest(source_path.read_bytes()) != cached['sha256']:
                    raise ValueError('Cached response changed')
                source = read(source_path)
                record = {'id': row['id'], 'request_sha256': request_hash, 'status': source['status'],
                          'origin': 'exact_cache', 'cache_source': cached, 'raw': source['raw']}
            else:
                attempt = OUT / 'attempts' / (row['id'] + '.json')
                if attempt.exists():
                    raise ValueError('Ambiguous prior attempt; inspect, never automatically resend')
                write_json(attempt, {'started_at_utc': datetime.now(timezone.utc).isoformat(), 'request_sha256': request_hash})
                try:
                    raw = old.chat(row['payload'])
                    record = {'id': row['id'], 'request_sha256': request_hash,
                              'status': old.classify(raw, previous), 'origin': 'new_local_call', 'raw': raw}
                except Exception as error:
                    write_json(path, {'id': row['id'], 'request_sha256': request_hash, 'origin': 'new_local_call',
                                      'status': 'transport_error', 'error': str(error)})
                    raise
            write_json(path, record)
            count = record['raw'].get('prompt_eval_count')
            print(json.dumps({'recorded': index, 'planned': len(rows), 'id': row['id'], 'status': record['status'],
                              'origin': record['origin'], 'words': len(old.WORDS.findall(record['raw'].get('message', {}).get('content', '')))}), flush=True)
            if record['status'] != 'completed':
                raise ValueError('Technical gate failed; preserve output and stop')
            if not isinstance(count, int) or count + previous['options']['num_predict'] + 2048 >= previous['options']['num_ctx']:
                raise ValueError('Returned prompt-token safety gate failed')
    finally:
        lock.unlink()


def analysis(spec, previous, rows, plan):
    records, hashes = [], {}
    for row in rows:
        path = OUT / 'responses' / (row['id'] + '.json')
        if not path.exists():
            continue
        response = read(path)
        if response['request_sha256'] != old.fingerprint(row['payload']):
            raise ValueError('Request/response mismatch')
        raw = response.get('raw', {})
        text = raw.get('message', {}).get('content', '')
        words = len(old.WORDS.findall(text))
        hit = row['target'][0] <= words <= row['target'][1] if row['numeric_instruction_provided'] and response['status'] == 'completed' else None
        records.append({k: row[k] for k in ('id', 'arm', 'quantity', 'question', 'seed', 'target', 'numeric_instruction_provided')} | {
            'origin': response['origin'], 'status': response['status'], 'text': text,
            'words': words, 'target_hit': hit, 'prompt_tokens': raw.get('prompt_eval_count'),
            'output_tokens': raw.get('eval_count'), 'total_seconds': raw.get('total_duration', 0)/1e9})
        hashes[str(path.relative_to(ROOT))] = digest(path.read_bytes())
    arms = []
    for arm in spec['arms']:
        values = [r for r in records if r['arm'] == arm and r['status'] == 'completed']
        groups = defaultdict(dict)
        for value in values:
            groups[(value['question'], value['seed'])][value['quantity']] = value
        differences = [{'question': key[0], 'seed': key[1],
                        'short_words': pair['Normal']['words'], 'long_words': pair['Increased']['words'],
                        'difference': pair['Increased']['words']-pair['Normal']['words']}
                       for key, pair in sorted(groups.items()) if set(pair) == set(spec['quantity'])]
        numeric = arm != 'hub_label'
        hits = sum(r['target_hit'] is True for r in values) if numeric else None
        positive = sum(r['difference'] > 0 for r in differences)
        difference = statistics.mean(r['difference'] for r in differences) if differences else None
        passed = (len(values) == 8 and hits >= spec['gate']['minimum_target_hits']
                  and positive >= spec['gate']['minimum_positive_length_pairs']
                  and difference >= spec['gate']['minimum_mean_long_minus_short_words']) if numeric else None
        arms.append({'arm': arm, 'completed': len(values), 'target_hits': hits,
                     'target_denominator': 8 if numeric else None,
                     'normal_mean_words': statistics.mean(r['words'] for r in values if r['quantity'] == 'Normal') if any(r['quantity'] == 'Normal' for r in values) else None,
                     'increased_mean_words': statistics.mean(r['words'] for r in values if r['quantity'] == 'Increased') if any(r['quantity'] == 'Increased' for r in values) else None,
                     'positive_pairs': positive, 'pairs': differences, 'mean_long_minus_short_words': difference,
                     'engineering_gate_pass': passed})
    by_arm = {r['arm']: r for r in arms}
    complete = len(records) == 32 and all(r['status'] == 'completed' for r in records)
    choice = None
    if not complete:
        decision = 'incomplete_run_no_scientific_selection'
    elif not by_arm['direct_numeric']['engineering_gate_pass']:
        decision = 'direct_control_failed_do_not_declare_backbone_controllable'
    else:
        choice = next((a for a in spec['gate']['selection_priority'] if by_arm[a]['engineering_gate_pass']), None)
        decision = 'retain_for_bounded_output_control_only' if choice else 'direct_control_passed_but_wrapper_control_failed'
    result = {'complete': complete, 'planned_answers': 32, 'recorded_answers': len(records),
              'origins': dict(Counter(r['origin'] for r in records)), 'statuses': dict(Counter(r['status'] for r in records)),
              'arms': arms, 'decision': decision, 'selected_engineering_arm': choice,
              'selection_is_not_clinical_validation': True, 'judge_calls': 0, 'paid_api_calls': 0,
              'clinical_scores': 0, 'independent_authored_cases': 1}
    write_json(OUT / 'measurements.json', records)
    write_json(OUT / 'summary.json', result)
    write_json(OUT / 'analysis-manifest.json', {'plan_sha256': old.fingerprint(plan), 'raw_responses': hashes,
        'measurements_sha256': digest((OUT / 'measurements.json').read_bytes()), 'summary_sha256': digest((OUT / 'summary.json').read_bytes())})
    SHARE.mkdir(parents=True, exist_ok=True)
    blind = list(records)
    random.Random(20261104).shuffle(blind)
    key, lines = [], ['# 조건을 가린 발화 자료', '', '임상 평가 결과가 아니라 실제 영어 응답 원문이다. 질문별로 보되 조건 키는 별도로 보관했다.', '']
    for row in blind:
        label = 'C-' + digest(row['id'].encode())[:8]
        key.append({'blind_id': label, 'condition_id': row['id']})
        question = next(q['text'] for q in spec['questions'] if q['id'] == row['question'])
        lines.extend(['## ' + label, '', question, '', row['text'] or '[No answer]', ''])
    (SHARE / '영어발화원문.md').write_text('\n'.join(lines), encoding='utf-8')
    write_json(OUT / 'blinding-key.json', key)
    print(json.dumps({k: result[k] for k in ('complete', 'origins', 'decision', 'selected_engineering_arm')}, ensure_ascii=False), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--analyze', action='store_true')
    args = parser.parse_args()
    spec, previous, rows, plan = prepare()
    print(json.dumps({'prepared': len(rows), 'exact_cache': len(plan['cache_sources']), 'max_new_calls': plan['new_call_cap']}), flush=True)
    try:
        if args.execute:
            execute(spec, previous, rows, plan, args.resume)
    finally:
        if args.execute or args.analyze:
            analysis(spec, previous, rows, plan)


if __name__ == '__main__':
    main()
