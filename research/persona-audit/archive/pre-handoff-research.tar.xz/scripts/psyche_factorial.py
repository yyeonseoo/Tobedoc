"""Frozen bounded local prompt-port experiment. Default: prepare, no inference.

No downloads, installs, external hosts, paid APIs, LLM judges or retries.
The amended prompt is a researcher-authored deletion, NOT original PSYCHE.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import itertools
import json
from pathlib import Path
import random
import re
import statistics
import urllib.request

from common import ROOT, digest, write_json
from audit_psyche_roleplay_sources import BASE, LOCK, source_text, verify_sources, yaml_english_block
from local_preflight import local_metadata

SPEC = ROOT / 'config/psyche-factorial-v01.json'
OUT = ROOT / 'analysis/psyche-factorial-v01'
SHARE = ROOT / 'share/psyche-factorial-v01'
WORDS = re.compile(r"[A-Za-z]+(?:['’-][A-Za-z]+)*|\d+(?:\.\d+)?")
LABELS = ['schizophrenia', 'derailment', 'thought process', 'verbal productivity', 'MFC', 'PSYCHE-SP']


def fingerprint(value):
    return digest(json.dumps(value, sort_keys=True, ensure_ascii=False).encode())


def read(path):
    return json.loads(path.read_text())


def save_once(path, value):
    """Identical deterministic preparation may replay; mismatches never overwrite."""
    if path.exists():
        if read(path) != value:
            raise ValueError(f'Frozen artifact differs: {path}')
    else:
        write_json(path, value)


def build(spec):
    template = yaml_english_block(source_text('data/prompts/client/psyche.yaml'), 'system_prompt')
    if template.count('{{data.mfc}}') != 1 or template.count(spec['edit']['old']) != 1:
        raise ValueError('Unexpected source template; review before rendering')
    rows = []
    for arm, quantity, thought, seed in itertools.product(spec['prompt_variants'], spec['productivity'], spec['thought_process'], spec['seeds']):
        case = deepcopy(spec['case'])
        case['MFC-Behavior']['Verbal productivity'] = quantity
        case['MFC-Behavior']['Thought process'] = thought
        actual = template
        if arm == 'quantity_clause_only':
            actual = actual.replace(spec['edit']['old'], spec['edit']['new'])
        elif arm != 'hub_unchanged':
            raise ValueError('Unknown prompt arm')
        prompt = actual.replace('{{data.mfc}}', json.dumps(case, ensure_ascii=False, indent=2))
        if '{{' in prompt or '}}' in prompt:
            raise ValueError('Unresolved template syntax')
        messages = [{'role': 'system', 'content': prompt}, {'role': 'user', 'content': spec['interviewer_question']}]
        # Byte upper-bound on content tokens plus reserved chat-template overhead.
        if sum(len(m['content'].encode()) for m in messages) + spec['options']['num_predict'] + 2048 >= spec['options']['num_ctx']:
            raise ValueError('Conservative context guard exceeded; never silently truncate')
        ident = f'{arm}-{quantity.lower()}-{thought.lower()}-{seed}'
        rows.append({'id': ident, 'arm': arm, 'quantity': quantity, 'thought': thought, 'seed': seed,
                     'case': case, 'prompt_sha256': digest(prompt.encode()),
                     'payload': {'model': spec['model'], 'stream': False, 'think': False,
                                 'keep_alive': '5m', 'messages': messages,
                                 'options': {**spec['options'], 'seed': seed}}})
    random.Random(20261101).shuffle(rows)
    if len(rows) != 16:
        raise ValueError('This version is fixed to 16 calls')
    return rows


def prepare():
    spec = read(SPEC)
    verified = verify_sources(read(LOCK))
    rows = build(spec)
    manifest = {'spec_sha256': digest(SPEC.read_bytes()), 'script_sha256': digest(Path(__file__).read_bytes()),
                'source_lock_sha256': digest(LOCK.read_bytes()), 'sources_verified': len(verified),
                'paper_snapshot_sha256': digest((ROOT / 'evidence/snapshots/psyche_paper_v1.txt').read_bytes()),
                'requests_sha256': fingerprint(rows), 'calls_planned': len(rows),
                'unique_factor_cells': 8, 'seeds_per_cell': 2, 'authored_cases': 1,
                'native_replication': False, 'clinical_gold': False, 'scope': spec['scope']}
    save_once(OUT / 'plan.json', manifest)
    save_once(OUT / 'requests.json', rows)
    # Fully rendered requests are fixed BEFORE the first inference.
    return spec, rows, manifest


def classify(raw, spec):
    if raw.get('error') or not raw.get('done'):
        return 'provider_error_or_incomplete'
    if raw.get('model') != spec['model']:
        return 'model_mismatch'
    if raw.get('done_reason') == 'length' or raw.get('eval_count', 0) >= spec['options']['num_predict']:
        return 'truncated'
    if not raw.get('message', {}).get('content', '').strip():
        return 'empty'
    return 'completed'


def runtime(spec):
    tags = local_metadata('/api/tags').get('models', [])
    selected = next((r for r in tags if r.get('name') == spec['model']), None)
    if not selected or selected['digest'] != spec['model_digest']:
        raise ValueError('Required installed model/digest absent; no pull or substitution')
    show = local_metadata('/api/show', {'model': spec['model']})
    return {'model': selected, 'version': local_metadata('/api/version'), 'show': show,
            'template_sha256': digest(show.get('template', '').encode()),
            'parameters_sha256': digest(show.get('parameters', '').encode()),
            'options': spec['options'], 'think': False, 'context_policy': spec['history_policy']}


def chat(payload):
    request = urllib.request.Request('http://127.0.0.1:11434/api/chat', data=json.dumps(payload).encode(),
                                     headers={'Content-Type': 'application/json'})
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(request, timeout=240) as response:
        raw = response.read(2_000_001)
    if len(raw) > 2_000_000:
        raise ValueError('Oversized response')
    return json.loads(raw)


def run(spec, rows, resume=False):
    policy = read(ROOT / 'config/compute-policy.json')
    if policy['paid_model_api_allowed'] or policy['automatic_model_download_allowed']:
        raise ValueError('Unexpected policy change')
    current = runtime(spec)
    if (OUT / 'runtime.json').exists():
        previous = read(OUT / 'runtime.json')
        if fingerprint(previous) != fingerprint(current):
            raise ValueError('Runtime changed; stop rather than mix conditions')
        if not resume:
            raise ValueError('Run exists; explicitly --resume to reuse exact completed results')
    else:
        write_json(OUT / 'runtime.json', current)
    lock = OUT / '.running'
    with lock.open('x') as handle:
        handle.write(datetime.now(timezone.utc).isoformat())
    try:
        for index, row in enumerate(rows, 1):
            path = OUT / 'responses' / (row['id'] + '.json')
            attempt = OUT / 'attempts' / (row['id'] + '.json')
            request_hash = fingerprint(row['payload'])
            if path.exists():
                record = read(path)
                if record['request_sha256'] != request_hash or record['status'] != 'completed':
                    raise ValueError('Cannot resume a changed/failed response')
                continue
            if attempt.exists():
                raise ValueError('Ambiguous previous attempt; inspect manually, no silent retry')
            write_json(attempt, {'started_at_utc': datetime.now(timezone.utc).isoformat(), 'request_sha256': request_hash})
            try:
                raw = chat(row['payload'])
                record = {'id': row['id'], 'request_sha256': request_hash, 'status': classify(raw, spec), 'raw': raw}
            except Exception as error:
                write_json(path, {'id': row['id'], 'request_sha256': request_hash, 'status': 'transport_error', 'error': str(error)})
                raise
            write_json(path, record)
            print(json.dumps({'recorded': index, 'planned': len(rows), 'id': row['id'], 'status': record['status'],
                              'words': len(WORDS.findall(raw.get('message', {}).get('content', '')))}, ensure_ascii=False), flush=True)
            if record['status'] != 'completed':
                raise ValueError('Technical gate failed; retain output and stop without retries')
            count = raw.get('prompt_eval_count')
            if not isinstance(count, int) or count + spec['options']['num_predict'] + 2048 >= spec['options']['num_ctx']:
                raise ValueError('Returned prompt token count failed context safety gate')
    finally:
        lock.unlink()


def describe(text, case):
    words = WORDS.findall(text)
    source = WORDS.findall(json.dumps(case, ensure_ascii=False))
    sixgrams = {tuple(source[i:i+6]) for i in range(max(0, len(source)-5))}
    overlap = sum(tuple(words[i:i+6]) in sixgrams for i in range(max(0, len(words)-5)))
    return {'words': len(words), 'approx_sentence_units': len(re.findall(r'[^.!?]+(?:[.!?]+|$)', text.strip())),
            'literal_labels': [label for label in LABELS if re.search(r'(?<!\w)' + re.escape(label) + r'(?!\w)', text, re.I)],
            'exact_sixgram_overlap_windows': overlap}


def analyze(spec, rows, plan):
    result = []
    provenance = {}
    for row in rows:
        path = OUT / 'responses' / (row['id'] + '.json')
        if not path.exists():
            continue
        record = read(path)
        if record['request_sha256'] != fingerprint(row['payload']):
            raise ValueError('Response request mismatch')
        raw = record.get('raw', {})
        text = raw.get('message', {}).get('content', '')
        result.append({k: row[k] for k in ('id', 'arm', 'quantity', 'thought', 'seed')} | {
            'status': record['status'], 'text': text, **describe(text, row['case']),
            'prompt_tokens': raw.get('prompt_eval_count'), 'output_tokens': raw.get('eval_count'),
            'generation_seconds': raw.get('eval_duration', 0) / 1e9})
        provenance[str(path.relative_to(ROOT))] = digest(path.read_bytes())
    complete = [r for r in result if r['status'] == 'completed']
    cells = defaultdict(list)
    for row in complete:
        cells[(row['arm'], row['quantity'], row['thought'])].append(row['words'])
    cell_summary = [{'arm': k[0], 'quantity': k[1], 'thought': k[2], 'n': len(v), 'words_each': v,
                     'mean_words': statistics.mean(v)} for k, v in sorted(cells.items())]
    contrasts = []
    for factor, levels, matching in [('quantity', spec['productivity'], ('arm', 'thought', 'seed')),
                                      ('thought', spec['thought_process'], ('arm', 'quantity', 'seed')),
                                      ('arm', spec['prompt_variants'], ('quantity', 'thought', 'seed'))]:
        pairs = defaultdict(dict)
        for row in complete:
            pairs[tuple(row[k] for k in matching)][row[factor]] = row['words']
        differences = [v[levels[1]]-v[levels[0]] for v in pairs.values() if all(l in v for l in levels)]
        contrasts.append({'factor': factor, 'word_difference': f'{levels[1]} minus {levels[0]}',
                          'matched_pairs': len(differences), 'differences': differences,
                          'mean_difference': statistics.mean(differences) if differences else None})
    summary = {'planned': len(rows), 'recorded': len(result), 'completed': len(complete),
               'status_counts': dict(Counter(r['status'] for r in result)), 'authored_cases': 1,
               'cells': cell_summary, 'paired_word_count_descriptors': contrasts,
               'answers_with_literal_labels': sum(bool(r['literal_labels']) for r in complete),
               'clinical_scores_computed': 0, 'judge_calls': 0, 'paid_api_calls': 0,
               'caution': 'Word-count differences cannot establish semantic derailment or clinical improvement.'}
    write_json(OUT / 'measurements.json', result)
    write_json(OUT / 'summary.json', summary)
    write_json(OUT / 'analysis-manifest.json', {'plan': plan, 'raw_response_sha256': provenance,
                                              'measurements_sha256': digest((OUT / 'measurements.json').read_bytes())})
    blind = list(result)
    random.Random(20261103).shuffle(blind)
    key = []
    booklet = ['# 발화 검토용 블라인드 자료', '', '임상 평가 결과가 아니라 원문 검토 자료다. 설정 이름은 별도 키에 보관했다.', '',
               '질문: ' + spec['interviewer_question'], '']
    for row in blind:
        ident = 'B-' + hashlib.sha256(row['id'].encode()).hexdigest()[:8]
        key.append({'blind_id': ident, 'condition_id': row['id']})
        booklet.extend(['## ' + ident, '', row['text'] or '[No answer; see technical status]', ''])
    SHARE.mkdir(parents=True, exist_ok=True)
    (SHARE / '블라인드발화.md').write_text('\n'.join(booklet), encoding='utf-8')
    write_json(OUT / 'blinding-key.json', key)
    print(json.dumps({k: summary[k] for k in ('planned', 'recorded', 'completed', 'status_counts')}, ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true', help='Use installed local Ollama; maximum 16 calls')
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--analyze', action='store_true', help='Recompute descriptors locally without inference')
    args = parser.parse_args()
    spec, rows, plan = prepare()
    print(json.dumps({'prepared_requests': len(rows), 'execute': args.execute, 'plan_sha256': fingerprint(plan)}), flush=True)
    if args.execute:
        run(spec, rows, args.resume)
    if args.execute or args.analyze:
        analyze(spec, rows, plan)


if __name__ == '__main__':
    main()
