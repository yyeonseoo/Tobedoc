"""Frozen 32-reply transfer check: new fictional records, phrasings and seeds."""
import argparse
import json
import random
import re
from collections import defaultdict
from statistics import mean

from audit_sources import parse_styles
from common import ROOT, digest, read_source, source_records, write_json
from fact_disclosure_probe import match_fact, normalize
from first_reply_probe_runner import run, verify_response
from reserved_length_factorial import question_paragraph_flag
from run_feature_batch import payload
from run_local_pilot import OPTIONS, fingerprint, now
from summarize_local_pilot import text_metrics

SPEC = ROOT / "config/disclosure-transfer-v01.json"
RUN = "disclosure-transfer-v01"
FOLDER = ROOT / "pilot/runs" / RUN
OUT = ROOT / "analysis" / RUN
ARMS = ["brief_only", "psi_reserved_no_numeric_cap"]


def conditions():
    spec = json.loads(SPEC.read_text())
    reserved, n = re.subn(r"But you must not exceed 3 sentences each turn\.\s*", "", parse_styles(read_source("psi_styles"))["reserved"])
    if n != 1:
        raise ValueError("Source cap changed")
    styles = {"brief_only": "Give brief, concise answers.", "psi_reserved_no_numeric_cap": reserved}
    rng, blocks, rows = random.Random(20261030), [], []
    for case in spec["fictional_cases"]:
        for variant in spec["question_variants"]:
            for repeat in spec["repeat_indices"]:
                blocks.append((case, variant, repeat))
    rng.shuffle(blocks)
    for case, variant, repeat in blocks:
        group = []
        for order in ["event_first", "personal_first"]:
            question = " ".join([variant["event"], variant["personal"]] if order == "event_first" else [variant["personal"], variant["event"]])
            for style in spec["style_arms"]:
                # Same common wrapper as the development probe; only new facts,
                # question wording/order and new seeds are introduced.
                prompt = (f"You are {case['name']}, a fictional adult. This is a simulation, not a real patient or a diagnosis.\n"
                          "These supplied facts describe the community event and your household situation:\n"
                          + "\n".join(f["description"] for f in case["facts"]) + "\nConversation style:\n" + styles[style]
                          + "\nUse only the supplied facts. Do not invent facts or a diagnosis. Respond in natural English as this person. "
                          "Write only this person's reply, not interviewer turns or stage directions.")
                row = {"condition_id": f"T-{case['id']}-{variant['id']}-R{repeat}-{order}-{style}", "profile_id": case["id"],
                       "variant_id": variant["id"], "repeat_index": repeat, "order": order, "style_id": style, "arm": style,
                       "system_prompt": prompt, "facts": case["facts"], "interview": [{"turn": 1, "probe": "event_and_bill_facts", "text": question}]}
                row["prompt_sha256"] = fingerprint({"system_prompt": prompt, "interview": row["interview"]})
                group.append(row)
        rng.shuffle(group)
        rows.extend(group)
    if len(rows) != spec["max_requests"] or len(rows) != 32:
        raise ValueError("Transfer request ceiling changed")
    return rows


def prepare():
    rows = conditions()
    plan = {"run_id": RUN, "max_requests": 32,
            "scope": "Transfer of a development finding to two previously unused fictional fact records, two new phrasings and two new seeds; not clinical external validation",
            "design": "2 cases x 2 phrasings x 2 seeds x 2 orders x 2 styles; one reply per cell; all factors crossed from the start",
            "primary": "Mean within-block [(personal-first minus event-first personal mention fraction)_reserved minus the same order contrast_brief]",
            "secondary": "Order contrast per style; event mention fractions; word counts; exact per-case/per-wording summaries",
            "direction_before_generation": "Expected negative primary contrast if the prior style-specific order sensitivity transfers; positive or zero is retained as contrary evidence",
            "decision_rule_before_generation": {
                "primary_at_most": -1/3,
                "reserved_order_effect_negative_in_each_case": True,
                "reserved_order_effect_negative_in_each_wording": True,
                "meaning": "All conditions required to label directionally consistent transfer within this probe. The one-fact/three threshold is a pragmatic descriptive decision boundary, not a validated clinical threshold or powered test."},
            "analysis": "Eight case-by-phrasing-by-seed matched blocks, four cells per block; equal weights, no population p-values; no mixing development outputs",
            "measurement": "Unchanged finite-alias mention matcher from development; not factual correctness, refusal intent or clinical guardedness. All completed outputs included; QC flags do not remove samples.",
            "limits": "Only two invented records in the same event/bill template; profile fact ordering stays event-first; no independent backend or real patients. Reserved permits normal behavior in some turns.",
            "stopping": "Exactly 32 requests maximum; stop/preserve on error or truncation; no regeneration, replacement, alias expansion or prompt tuning after results",
            "options": OPTIONS, "think": False, "seed_rule": "20261030 + 100*repeat_index + 1; repeat_index 2 and 3; matched across style, order and wording",
            "model_digest": json.loads((ROOT / "evidence/local-runtime.json").read_text())["ollama"]["candidate_metadata"]["digest"],
            "spec_sha256": digest(SPEC.read_bytes()), "conditions_sha256": fingerprint(rows),
            "matcher_file_sha256": digest((ROOT / "scripts/fact_disclosure_probe.py").read_bytes()),
            "source_url": source_records()["psi_styles"]["citation_url"]}
    for name, obj in [("plan.json", plan), ("conditions.json", rows)]:
        path = FOLDER / name
        if path.exists():
            if json.loads(path.read_text()) != obj:
                raise ValueError("Frozen transfer design changed; never overwrite")
        else:
            write_json(path, obj)
    if not (FOLDER / "prepared-at.json").exists():
        write_json(FOLDER / "prepared-at.json", {"prepared_at_utc": now(), "plan_sha256": fingerprint(plan)})
    return plan, rows


def contrasts(rows, domain="personal"):
    blocks = defaultdict(dict)
    for row in rows:
        key = (row["profile_id"], row["variant_id"], row["repeat_index"])
        blocks[key][(row["style_id"], row["order"])] = row["count"][domain]/3
    values = []
    for key, cells in blocks.items():
        if set(cells) != {(s, o) for s in ARMS for o in ["event_first", "personal_first"]}:
            raise ValueError("Incomplete crossed block")
        effects = {s: cells[(s, "personal_first")]-cells[(s, "event_first")] for s in ARMS}
        values.append({"profile_id": key[0], "variant_id": key[1], "repeat_index": key[2],
                       "reserved_order_effect": effects[ARMS[1]], "brief_order_effect": effects[ARMS[0]],
                       "interaction": effects[ARMS[1]]-effects[ARMS[0]]})
    if not values:
        raise ValueError("Empty comparison")
    return {"blocks": values, "mean_interaction": mean(v["interaction"] for v in values),
            "mean_reserved_order_effect": mean(v["reserved_order_effect"] for v in values),
            "mean_brief_order_effect": mean(v["brief_order_effect"] for v in values)}


def analyze():
    plan, cases = prepare()
    rows, files, week_candidates = [], [SPEC, FOLDER / "plan.json", FOLDER / "conditions.json", FOLDER / "prepared-at.json", FOLDER / "runtime.json"], []
    for case in cases:
        rp = FOLDER / "requests" / (case["condition_id"] + ".json")
        sp = FOLDER / "responses" / (case["condition_id"] + ".json")
        raw, request = json.loads(sp.read_text()), json.loads(rp.read_text())
        verify_response(raw, request, case, plan["model_digest"])
        hits = [match_fact(raw["response_text"], f) for f in case["facts"]]
        rows.append({**{k: case[k] for k in ["condition_id", "profile_id", "variant_id", "repeat_index", "order", "style_id"]},
                     "count": {d: sum(f["recognized_mention"] for f in hits if f["domain"] == d) for d in ["personal", "event"]},
                     "fact_matches": hits, "response_text": raw["response_text"], "text_metrics": text_metrics(raw["response_text"]),
                     "question_paragraph_flag": question_paragraph_flag(raw["response_text"])})
        # Post-result measurement audit: frozen primary scores are untouched.
        # A literal 'two weeks' can refer to the supplied fourteen-day value.
        day_fact = next(f for f in case["facts"] if f["id"] == "days_late")
        day_hit = next(f for f in hits if f["fact_id"] == "days_late")
        if (re.search(r"\b14 days\b", day_fact["description"]) and not day_hit["recognized_mention"]
                and re.search(r"\btwo weeks\b", normalize(raw["response_text"]))):
            week_candidates.append(case["condition_id"])
        files += [rp, sp]
    primary = contrasts(rows)
    if len(rows) != 32 or len(primary["blocks"]) != 8:
        raise ValueError("Incomplete transfer check")
    by_case = {key: contrasts([r for r in rows if r["profile_id"] == key]) for key in sorted({r["profile_id"] for r in rows})}
    by_wording = {key: contrasts([r for r in rows if r["variant_id"] == key]) for key in sorted({r["variant_id"] for r in rows})}
    rule = plan["decision_rule_before_generation"]
    passed = (primary["mean_interaction"] <= rule["primary_at_most"]
              and all(v["mean_reserved_order_effect"] < 0 for v in by_case.values())
              and all(v["mean_reserved_order_effect"] < 0 for v in by_wording.values()))
    adjusted = json.loads(json.dumps(rows))
    for row in adjusted:
        if row["condition_id"] in week_candidates:
            row["count"]["personal"] += 1
    sensitivity = contrasts(adjusted)
    sensitivity_by_case = {key: contrasts([r for r in adjusted if r["profile_id"] == key]) for key in by_case}
    sensitivity_by_wording = {key: contrasts([r for r in adjusted if r["variant_id"] == key]) for key in by_wording}
    sensitivity_passed = (sensitivity["mean_interaction"] <= rule["primary_at_most"]
                          and all(v["mean_reserved_order_effect"] < 0 for v in sensitivity_by_case.values())
                          and all(v["mean_reserved_order_effect"] < 0 for v in sensitivity_by_wording.values()))
    cells = []
    for style in ARMS:
        for order in ["event_first", "personal_first"]:
            subset = [r for r in rows if r["style_id"] == style and r["order"] == order]
            cells.append({"style": style, "order": order, "replies": len(subset), "denominator_per_domain": 3*len(subset),
                          "personal_mentions": sum(r["count"]["personal"] for r in subset), "event_mentions": sum(r["count"]["event"] for r in subset),
                          "mean_words": mean(r["text_metrics"]["word_count"] for r in subset)})
    result = {"plan": plan, "actual_replies": len(rows), "decision_rule_met": passed,
              "primary": primary, "event_secondary": contrasts(rows, "event"), "by_case": by_case, "by_wording": by_wording,
              "cells": cells, "responses": rows,
              "posthoc_week_reference_sensitivity": {
                  "status": "Added after output inspection; exploratory measurement audit, not the primary or a validated semantic scorer",
                  "rule": "If fourteen-day fact was unmatched but reply literally contains two weeks, credit one candidate equivalent reference; no original aliases or scores changed",
                  "candidate_condition_ids": week_candidates, "primary_interaction_if_credited": sensitivity["mean_interaction"],
                  "decision_rule_met_if_credited": sensitivity_passed},
              "provenance": [{"path": str(p.relative_to(ROOT)), "sha256": digest(p.read_bytes())} for p in files]}
    write_json(OUT / "results.json", result)
    lines = ["# 질문 순서 효과: 새 사례·질문 표현에서의 전이 검증", "",
             "## 무엇을 검증했나", "",
             "개발 실험에서 경계적 말투의 정보 언급이 두 질문의 순서에 따라 달라졌다. 이번에는 미사용 허구 기록 2개, 새 질문 표현 2종, 새 seed 2개에 "
             "질문 순서와 말투(간결/경계적)를 처음부터 모두 교차했다. 8개 대응 블록·32개 첫 답변이며 기존 개발 응답은 분석에 섞지 않았다. "
             "원형 PSI 실행이나 임상적 경계심 검증이 아니라 동일 Qwen에 이식한 지시의 행동 점검이다.", "",
             "## 조건별 실제 결과", ""]
    labels = {ARMS[0]: "간결하게 답하기", ARMS[1]: "경계적 말투 지시 묶음"}
    for c in cells:
        order = "행사 먼저" if c["order"] == "event_first" else "개인 청구서 먼저"
        lines.append(f"- {labels[c['style']]} / {order}: 개인 정보 표현 {c['personal_mentions']}/{c['denominator_per_domain']}, "
                     f"행사 정보 표현 {c['event_mentions']}/{c['denominator_per_domain']} 식별; 평균 {c['mean_words']:.1f}단어.")
    lines += ["", "## 사전에 정한 판단", "",
              "주 비교는 경계적 말투의 ‘개인 먼저−행사 먼저’ 정보 언급 비율 차이에서, 간결 대조군의 같은 차이를 뺀 값이다. "
              "그 값이 −1/3 이하이고, 두 사례 각각 및 두 질문 표현 각각에서 경계적 말투의 순서 효과가 모두 음수일 때만 이 소규모 검증에서 방향이 유지됐다고 판정하기로 했다. "
              "이 기준은 정보 3개 중 1개 차이라는 기술적 결정선이지 임상 기준·유의성 검정·검정력 계산이 아니다.", "",
              f"주 비교값: {primary['mean_interaction']:+.3f}. 경계적 말투 순서 효과 {primary['mean_reserved_order_effect']:+.3f}, "
              f"간결 대조군 순서 효과 {primary['mean_brief_order_effect']:+.3f}. 사전 결정선 충족: {'예' if passed else '아니오'}.", ""]
    for title, groups in [("사례별", by_case), ("질문 표현별", by_wording)]:
        for key, value in groups.items():
            lines.append(f"- {title} {key}: 경계적 말투 순서 효과 {value['mean_reserved_order_effect']:+.3f}, 조건 간 차이 {value['mean_interaction']:+.3f}.")
    lines += ["", "## 결론과 한계", "",
              ("사전 결정선에 따라, 기존 순서 민감성의 방향은 이번 새 기록·표현에서도 유지됐다. " if passed else
               "사전 결정선을 충족하지 못했으므로 기존 현상이 새 기록·표현에서 일관되게 재현됐다고 결론 내리지 않는다. "),
              "이전 개발 사례에서는 두 영역을 함께 거절하는 패턴이 두드러졌지만, 새 기록에서는 일부 정보만 말하거나 근삿값·불확실한 표현으로 답한 경우도 있었다. "
              "따라서 ‘항상 전부 답하거나 전부 거절한다’는 규칙으로 확대하지 않는다. 경계적 말투는 개인 우선 조건에서 오히려 평균 답변이 더 길었으므로, "
              "정확한 프로필값의 언급 감소를 단순한 답변 길이 감소와 동일시하지 않는다.", "",
              "같은 행사/청구서 템플릿의 새 기록 2개뿐이며 기반 모델·프롬프트 wrapper는 같다. 사례와 표현을 동시에 바꿨으므로 "
              "실패할 경우 어느 변화가 원인인지 단정할 수 없다. 프로필에는 행사 사실이 먼저 제시되어 있어 질문 순서와 프로필 순서의 정합성은 분리하지 못했다. "
              "단일 user 메시지의 두 질문 순서를 조작했으며 실제 면담의 신뢰 형성 과정을 측정하지 않았다. "
              "유한 표현 목록의 문자적 일치만 집계해 재표현·부정·금액 오류를 임상적 정보 회피와 구분해야 한다. "
              "결과가 어느 방향이든 같은 평가 자료에 맞춘 프롬프트 수정이나 추가 생성은 하지 않는다.", "",
              "## 측정 방법의 사후 점검", "",
              f"프로필의 14일을 ‘two weeks’로 말해 기본 검색에서 놓친 후보가 {len(week_candidates)}개 있었다. "
              "원래 표현 목록과 주 분석은 바꾸지 않고 이 단위 환산 표현을 한 항목의 언급으로 인정하는 사후 민감도 분석만 추가했다. "
              f"이때 주 비교값은 {sensitivity['mean_interaction']:+.3f}, 기존 결정선 충족 여부는 {'예' if sensitivity_passed else '아니오'}였다. "
              "이 점검은 출력 후 추가했으며 검증된 의미 판정기가 아니다. 프로필의 290달러를 약 300달러로 말하는 등 근사화도 있어, "
              "고정값 미식별을 모두 의도적인 정보 회피로 해석할 수 없다.", "",
              "## 고정 규칙으로 고른 실제 답변", "",
              "T1 / V1 / repeat 2의 네 조건을 모두 제시한다. 결과가 큰 사례를 골라 보여 주지 않았다.", ""]
    for row in sorted(rows, key=lambda r: (r["style_id"], r["order"])):
        if (row["profile_id"], row["variant_id"], row["repeat_index"]) == ("T1", "V1", 2):
            lines += [f"### {labels[row['style_id']]} · {row['order']}", "", row["response_text"], ""]
    lines += ["## 재현", "", "`python3 scripts/disclosure_transfer.py --analyze-only`는 저장된 요청·응답만 검증·재집계한다. "
              "기존 생성 파일을 덮어쓰지 않으며 새 추론을 하지 않는다.", ""]
    (OUT / "report.ko.md").write_text("\n".join(lines))
    print(json.dumps({"actual_replies": len(rows), "cells": cells, "primary_interaction": primary["mean_interaction"], "decision_rule_met": passed}, ensure_ascii=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--run", action="store_true")
    mode.add_argument("--analyze-only", action="store_true")
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if args.analyze_only:
        analyze()
    elif args.run:
        plan, cases = prepare()
        run(plan, cases, FOLDER, args.resume)
        analyze()
    else:
        plan, _ = prepare()
        print(json.dumps(plan, ensure_ascii=False))
