"""Build a literature-only review without launching experimental pipelines."""
import argparse
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path

from docx import Document
from docx.shared import Pt
from docx.oxml.ns import qn
from build_two_feature_report import configure
from build_integrated_report import font, paragraph, heading
from build_role_audit_report import reference

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'share/literature-reassessment-v01'
CATALOG = ROOT / 'catalog/literature-decisions-v04.json'
CONTENT = ROOT / 'config/literature-reassessment-v01.json'
GROUPS = {
    'audit': '시뮬레이터와 페르소나의 직접 평가',
    'simulation': '정신건강 및 임상 환자 시뮬레이션',
    'thought_disorder': '조현병 언어와 사고장애의 생성 및 측정',
    'clinical_anchor': '임상 현상의 정의와 범위',
    'psychiatric_application': '정신과 환자 시뮬레이션의 임상 교육 사례',
    'psychometrics': '성격 및 심리검사의 타당성',
    'reviews': '분야 전반을 확인하는 문헌고찰',
    'adjacent': '직접 경쟁과 구분해야 할 인접 벤치마크',
}


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def main(replace=False):
    catalog = json.loads(CATALOG.read_text())
    report = json.loads(CONTENT.read_text())
    entries = catalog['sources']
    assert len({p['id'] for p in entries}) == len(entries) == 46
    assert len(report['pages']) == 3
    assert all(p['url'].startswith('https://') for p in entries)
    OUT.mkdir(parents=True, exist_ok=True)
    output = OUT / '선행연구 검토와 연구 방향 재설정.docx'
    if output.exists() and not replace:
        raise FileExistsError('Use --replace only for editorial or layout repair')
    by_id = {p['id']: p for p in entries}
    by_id['dataset'] = {
        'title': 'PSI-Bench 공개 생성 대화 뷰어',
        'url': 'https://huggingface.co/datasets/anonymous201102/psibench-PsyCoPref'}
    doc = Document()
    configure(doc)
    doc.core_properties.title = report['title']
    doc.core_properties.author = '연구팀'
    doc.core_properties.subject = '기존 실험 중단 후 수행한 선행연구 및 공개 자원 검토'
    doc.core_properties.comments = ''
    title = doc.add_paragraph(report['title'], style='Title')
    title.paragraph_format.line_spacing = Pt(24)
    title.paragraph_format.space_after = Pt(6)
    for run in title.runs:
        font(run, 17, True)
    paragraph(doc, '2026년 11월 1일  팀 논의를 위한 문헌 검토', small=True)
    md = ['# ' + report['title'], '', '2026년 11월 1일', '']
    for i, page in enumerate(report['pages']):
        if i:
            doc.add_page_break()
        for kind, value in page:
            if kind == 'heading':
                heading(doc, value)
                md.extend(['## ' + value, ''])
            elif kind == 'references':
                heading(doc, '주요 출처')
                md.extend(['## 주요 출처', ''])
                for n, key in enumerate(value, 1):
                    source = by_id[key]
                    label = f"[{n}] {key if key != 'dataset' else '공개 대화'}"
                    reference(doc, label, source['url'])
                    md.extend([f"[{n}] [{source['title']}]({source['url']})", ''])
            else:
                paragraph(doc, value)
                md.extend([value, ''])
    # The macOS bundled renderer lacks automatic CJK fallback for Arial Unicode MS.
    # Use an already installed Korean font; no font install or model download.
    for part in (doc.styles.element, doc.element, doc.sections[0].footer._element):
        for fonts in part.iter(qn('w:rFonts')):
            for key in ('ascii', 'hAnsi', 'eastAsia', 'cs'):
                fonts.set(qn('w:' + key), 'Apple SD Gothic Neo')
    doc.save(output)
    (OUT / '검토보고서.md').write_text('\n'.join(md))

    bib = ['# 환자 페르소나와 사고장애 연구의 주석 문헌 지도', '',
           '검토일 2026년 11월 1일', '',
           '46개 핵심 문헌 및 프레임워크와 초기 비논문 후보 2개를 분류했다. '
           '이 목록의 수는 체계적 검색에서 얻은 총 검색 건수나 최종 포함 논문 수가 아니다. '
           '모든 본문을 읽었다는 의미도 아니다. 각 항목의 확인 범위를 먼저 확인한다.', '',
           '## 검색 범위와 확인 수준', '',
           '검색은 웹을 통한 PubMed 및 PMC, ACL Anthology, arXiv, 출판사, '
           '저자 공식 GitHub 및 Hugging Face 자료와 관련 논문의 인용문헌을 중심으로 진행했다. '
           '뉴스와 자동 논문 요약은 후보 발견에만 사용하고 결론의 근거로 삼지 않았다. '
           '등록 프로토콜, 전체 데이터베이스 내보내기, 두 명의 독립 문헌 선별은 하지 않았다.', '',
           '검색 주제는 환자 시뮬레이션 충실도, 정신과 내담자와 동적 저항, '
           '조현병 합성 언어와 사고장애, 의미 유사도와 문맥별 perplexity, '
           '페르소나 심리측정학, 가상 환자 교육 문헌고찰, 코드와 자료 접근 조건이다.', '',
           '확인 수준의 methods는 해당 원저의 관련 방법 일부, abstract는 원저 초록, '
           'screened는 1차 문헌의 검색 및 서지 확인이다. repo와 data는 추가로 저장소 또는 '
           '공개 데이터 메타데이터를 직접 확인했다는 뜻이며 실행 재현을 뜻하지 않는다. '
           'indexed는 직접 본문 열람이 막힌 경우 검색 색인에 나타난 본문 구간만 확인한 것이다. '
           'prior_record는 이전에 보존한 검토 기록을 함께 사용했다는 뜻이다.', '']
    for group, name in GROUPS.items():
        bib.extend(['## ' + name, ''])
        for p in entries:
            if p['group'] != group:
                continue
            bib.extend([f"### {p['id']}  {p['year']}  {p['title']}", '',
                        f"[1차 출처]({p['url']})  확인 범위 `{p['read_scope']}`", '',
                        p['finding'], '', '우리 연구에 주는 판단  ' + p['implication'], '',
                        '접근과 재사용  ' + p['resource'], ''])
            if p.get('resource_url'):
                bib.extend([f"[공식 자료 또는 추가 원문]({p['resource_url']})", ''])
    bib.extend(['## 논문과 구분한 초기 저장소 후보', ''])
    for p in catalog['nonpaper_candidates']:
        bib.extend([f"### {p['id']}", '', f"[저장소]({p['url']})", '',
                    p['finding'], '', p['decision'], ''])
    bib.extend(['## 버전과 재사용에 관한 중요 주의점', ''])
    bib.extend(['- ' + s for s in [
        'PSI-Bench는 최신 v2의 인간 참조 자료 설명을 따른다.',
        'Plausible Patients v2가 철회한 v1 결과를 사용하지 않는다.',
        'PSYCHE의 표적 질환에 관한 판단은 실제 확인한 v1에 한정한다.',
        'Eval4Sim은 최신 v2 초록과 v1 방법의 확인 범위를 구분했다.',
        'SCI의 6개 시뮬레이터 결과를 원형 전체의 임상적 무효 판정으로 확대하지 않는다.',
        '웹 공개 열람과 이용권 허가 및 재현 실행 완료는 다르다.',
        'preprint의 주장과 동료심사를 거친 결과를 같은 확증 수준으로 다루지 않는다.']])
    (OUT / '주석문헌목록.md').write_text('\n'.join(bib) + '\n')
    (OUT / 'README.ko.md').write_text(
        '# 선행연구 검토와 연구 방향 재설정\n\n'
        '기존 실험은 사용자 요청으로 중단했다. 이 폴더는 문헌과 공개 자원 접근의 검토 결과이며 새 실험 결과가 아니다.\n\n'
        '- 선행연구 검토와 연구 방향 재설정.docx  짧은 팀 공유 보고서\n'
        '- 검토보고서.md  같은 본문의 검색 가능한 버전\n'
        '- 주석문헌목록.md  46개 핵심 문헌 및 프레임워크의 확인 수준과 재사용 조건\n'
        '- report-inputs.json  입력 및 결과 파일 해시\n\n'
        '원자료 목록은 catalog/literature-decisions-v04.json, 실험 중단 상태는 '
        'config/research-pause-20261101.json에 있다. 이전 버전과 실험 자료는 수정하거나 삭제하지 않았다.\n')
    files = [CATALOG, CONTENT, Path(__file__).resolve(), output,
             OUT / '검토보고서.md', OUT / '주석문헌목록.md']
    manifest = {'created_utc': datetime.now(timezone.utc).isoformat(),
                'review_entries': len(entries),
                'reading_levels': dict(Counter(p['read_scope'] for p in entries)),
                'new_generation_or_scoring_runs': 0,
                'inputs_and_outputs_sha256': {str(p.relative_to(ROOT)): digest(p) for p in files}}
    (OUT / 'report-inputs.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'output': str(output), 'entries': len(entries), 'status': 'built'}, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--replace', action='store_true')
    main(parser.parse_args().replace)
