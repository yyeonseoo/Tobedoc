"""Bounded five-arm local instruction comparison; frozen surface cues and references."""
import argparse
from collections import defaultdict
import json
import random
import re
from statistics import mean

from audit_sources import parse_styles
from common import ROOT, digest, read_source, source_records, write_json
from disclosure_cues import cues, check_controls
from fact_disclosure_probe import match_fact
from first_reply_probe_runner import run, verify_response
from run_local_pilot import OPTIONS, fingerprint, now
from summarize_local_pilot import text_metrics

RUN='disclosure-comparison-v02'
SPEC=ROOT/'config'/ (RUN+'.json')
FOLDER=ROOT/'pilot/runs'/RUN
OUT=ROOT/'analysis'/RUN


def read(path):
    return json.loads(path.read_text())


def freeze(path,obj):
    if path.exists():
        if read(path)!=obj:
            raise ValueError('Frozen input changed: '+str(path))
    else:
        write_json(path,obj)


def styles():
    reserved=parse_styles(read_source('psi_styles'))['reserved']
    reserved,count=re.subn(r'But you must not exceed 3 sentences each turn\.\s*','',reserved)
    if count!=1:
        raise ValueError('Unexpected source sentence cap')
    return {'neutral':'','brief':'Give brief, concise answers.',
            'skeptic_only':'Express distrust or skepticism toward the interviewer.',
            'psi_reserved':reserved,
            'sim_distrust':json.loads(read_source('patientsim_personality'))['distrust']}


def conditions():
    spec,modules=read(SPEC),styles()
    rows,rng=[],random.Random(20261104)
    blocks=[(case,order,seed) for case in spec['fictional_cases'] for order in spec['orders'] for seed in spec['repeat_indices']]
    rng.shuffle(blocks)
    for case,order,seed in blocks:
        q=[spec['event_question'],spec['personal_question']]
        if order=='personal_first':
            q.reverse()
        group=[]
        for arm in spec['arms']:
            prompt=(f"You are {case['name']}, a fictional adult talking with an interviewer. This is a simulation, not a real patient or diagnosis.\n"
                    "These supplied facts describe a community event and your household situation:\n"
                    +'\n'.join(f['description'] for f in case['facts'])+'\nConversation style:\n'+modules[arm]
                    +"\nUse only the supplied facts. Do not invent facts or a diagnosis. Respond in natural English as this person. "
                    "Write only this person's reply, not interviewer turns or stage directions.")
            row={'condition_id':f'DC-{case["id"]}-{order}-R{seed}-{arm}', 'profile_id':case['id'],
                 'order':order,'repeat_index':seed,'arm':arm,'style_id':arm,'system_prompt':prompt,'facts':case['facts'],
                 'interview':[{'turn':1,'probe':'event_and_personal_disclosure','text':' '.join(q)}]}
            row['prompt_sha256']=fingerprint({'system_prompt':prompt,'interview':row['interview']})
            group.append(row)
        rng.shuffle(group)
        rows.extend(group)
    if len(rows)!=40 or len(rows)!=spec['max_requests']:
        raise ValueError('Request limit changed')
    return rows


def prepare():
    spec,rows=read(SPEC),conditions()
    controls=check_controls()
    if not all(c['passed'] for c in controls):
        raise ValueError('Cue implementation controls failed before generation')
    files=['scripts/disclosure_comparison.py','scripts/disclosure_cues.py','scripts/fact_disclosure_probe.py',
           'scripts/first_reply_probe_runner.py','scripts/run_feature_batch.py','scripts/run_local_pilot.py','scripts/summarize_local_pilot.py']
    lock=source_records()
    plan={'run_id':RUN,'max_requests':40,'model_digest':spec['model_digest'],'analysis_contract':spec['analysis_contract'],
          'options':OPTIONS,'think':False,'seed_rule':'20261030+100*repeat_index+1; indices 10 and 11, matched across order and arm',
          'scope':'Extracted style bundles on common Qwen, not original frameworks or clinical severity',
          'adaptation':'PSI reserved source numeric cap removed only. Remaining normal-turn/trust/reluctance clauses retained; PatientSim distrust verbatim.',
          'spec_sha256':digest(SPEC.read_bytes()),'conditions_sha256':fingerprint(rows),
          'code_at_preparation':{p:digest((ROOT/p).read_bytes()) for p in files},
          'controls_sha256':fingerprint(controls),
          'controls_status':'40 authored regression controls, not independent validation; H04 contraction grammar was repaired before freezing or generation.',
          'source_provenance':[{k:lock[s][k] for k in ('id','commit','sha256','text_sha256','citation_url')}
                               for s in ('psi_styles','patientsim_personality')],
          'paid_api_calls_allowed':False,'downloads_allowed':False,'automated_llm_judge_allowed':False}
    freeze(FOLDER/'plan.json',plan)
    freeze(FOLDER/'conditions.json',rows)
    freeze(FOLDER/'cue-controls.json',controls)
    if not (FOLDER/'prepared-at.json').exists():
        write_json(FOLDER/'prepared-at.json',{'prepared_at_utc':now(),'plan_sha256':fingerprint(plan)})
    return plan,rows


def measure(case,raw):
    text=raw['response_text']
    found=[match_fact(text,f) for f in case['facts']]
    counts={d:sum(m['recognized_mention'] for m in found if m['domain']==d) for d in ('event','personal')}
    speech=cues(text)
    return {**{k:case[k] for k in ('condition_id','profile_id','order','repeat_index','style_id')},
            'event_refs':counts['event'],'personal_refs':counts['personal'],
            'personal_minus_event':counts['personal']-counts['event'],
            **{k:int(v['present']) for k,v in speech.items()},
            'nondisclosure_with_all_personal':int(speech['nondisclosure']['present'] and counts['personal']==3),
            'word_count':text_metrics(text)['word_count'], 'fact_matches':found,'cue_matches':speech,
            'response_text':text,'output_tokens':raw['raw_response']['eval_count']}


def contrast(rows,arm,baseline):
    blocks=defaultdict(dict)
    for row in rows:
        blocks[(row['profile_id'],row['order'],row['repeat_index'])][row['style_id']]=row
    result={}
    for metric in ('personal_refs','event_refs','personal_minus_event','nondisclosure','uncertainty','skepticism',
                   'privacy_boundary','word_count','nondisclosure_with_all_personal'):
        differences=[{'block':list(k),'difference':v[arm][metric]-v[baseline][metric]} for k,v in sorted(blocks.items())]
        result[metric]={'mean_difference':mean(d['difference'] for d in differences),
                        'block_differences':differences,
                        'by_case':{case:mean(d['difference'] for d in differences if d['block'][0]==case)
                                   for case in ('DC1','DC2')},
                        'by_order':{order:mean(d['difference'] for d in differences if d['block'][1]==order)
                                    for order in ('event_first','personal_first')}}
    return result


def analyze():
    plan,cases=prepare()
    rows,raws,provenance=[],[],[SPEC,FOLDER/'plan.json',FOLDER/'conditions.json',FOLDER/'prepared-at.json',FOLDER/'runtime.json',FOLDER/'cue-controls.json']
    for case in cases:
        stem=case['condition_id']+'.json'
        rp,sp=FOLDER/'requests'/stem,FOLDER/'responses'/stem
        raw,request=read(sp),read(rp)
        verify_response(raw,request,case,plan['model_digest'])
        if raw['raw_response'].get('done_reason')!='stop':
            raise ValueError('Incomplete technical completion')
        rows.append(measure(case,raw))
        raws.append(raw)
        provenance += [rp,sp]
    summaries=[]
    for arm in read(SPEC)['arms']:
        group=[r for r in rows if r['style_id']==arm]
        summaries.append({'arm':arm,'replies':len(group),'reference_denominator_per_domain':24,
                          'event_references':sum(r['event_refs'] for r in group),
                          'personal_references':sum(r['personal_refs'] for r in group),
                          **{k:sum(r[k] for r in group) for k in ('nondisclosure','uncertainty','skepticism','privacy_boundary','nondisclosure_with_all_personal')},
                          'mean_words':mean(r['word_count'] for r in group),
                          'personal_by_order':{o:sum(r['personal_refs'] for r in group if r['order']==o)
                                               for o in ('event_first','personal_first')}})
    pairs=[('psi_reserved','brief'),('sim_distrust','skeptic_only'),('sim_distrust','psi_reserved')]+[(a,'neutral') for a in read(SPEC)['arms'] if a!='neutral']
    contrasts={a+'_minus_'+b:contrast(rows,a,b) for a,b in pairs}
    consistency={}
    for name in read(SPEC)['analysis_contract']['primary_contrasts']:
        c=contrasts[name]['personal_refs']
        consistency[name]={'mean_difference':c['mean_difference'],
                           'negative_in_both_cases_and_orders':all(v<0 for v in list(c['by_case'].values())+list(c['by_order'].values()))}
    order_effects=[]
    for arm in read(SPEC)['arms']:
        matched=defaultdict(dict)
        for row in rows:
            if row['style_id']==arm:
                matched[(row['profile_id'],row['repeat_index'])][row['order']]=row['personal_refs']
        diffs=[{'block':list(k),'difference':v['personal_first']-v['event_first']} for k,v in sorted(matched.items())]
        order_effects.append({'arm':arm,'mean_personal_first_minus_event_first':mean(d['difference'] for d in diffs),'pairs':diffs})
    audit=[r for r in rows if r['personal_refs']<3 or any(r[k] for k in ('nondisclosure','uncertainty','skepticism','privacy_boundary'))
           or (r['style_id']=='neutral' and r['order']=='event_first' and r['repeat_index']==10)]
    result={'run_id':RUN,'plan':plan,'completed_replies':len(rows),'summaries':summaries,
            'contrasts':contrasts,'consistency':consistency,'order_effects':order_effects,
            'audit_selected_replies':len(audit),
            'cost':{'wall_seconds':sum(r['wall_seconds'] for r in raws),
                    'input_tokens':sum(r['raw_response']['prompt_eval_count'] for r in raws),
                    'output_tokens':sum(r['raw_response']['eval_count'] for r in raws),
                    'paid_api_calls':0,'automated_judge_calls':0,'new_downloads':0},
            'provenance':[{'path':str(p.relative_to(ROOT)),'sha256':digest(p.read_bytes())} for p in provenance]}
    for name,obj in [('results.json',result),('response-metrics.json',rows),('audit-candidates.json',audit)]:
        write_json(OUT/name,obj)
    lines=['# Complete disclosure comparison transcripts','','All forty raw first replies, without selection or edits.','']
    for case,row in zip(cases,rows):
        lines += ['## '+row['condition_id'],'',case['interview'][0]['text'],'',row['response_text'],'']
    (OUT/'transcripts.md').write_text('\n'.join(lines))
    print(json.dumps({'summaries':summaries,'consistency':consistency,'cost':result['cost'],'audit_selected':len(audit)},ensure_ascii=False))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=('prepare','run','analyze'))
    parser.add_argument('--resume',action='store_true')
    args=parser.parse_args()
    if args.action=='analyze':
        analyze()
    else:
        plan,rows=prepare()
        if args.action=='run':
            run(plan,rows,FOLDER,resume=args.resume)
        else:
            print({'prepared':len(rows),'controls_passed':len(check_controls())})
