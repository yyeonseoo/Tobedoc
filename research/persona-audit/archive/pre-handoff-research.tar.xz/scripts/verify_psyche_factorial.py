"""Independent offline integrity checks for the frozen 16-response local port."""
from collections import Counter
from pathlib import Path
import json

from common import ROOT, digest, write_json
import psyche_factorial as experiment


def main():
    out = experiment.OUT
    plan = experiment.read(out / 'plan.json')
    spec = experiment.read(experiment.SPEC)
    rows = experiment.read(out / 'requests.json')
    assert plan['spec_sha256'] == digest(experiment.SPEC.read_bytes())
    assert plan['script_sha256'] == digest((ROOT / 'scripts/psyche_factorial.py').read_bytes())
    assert plan['source_lock_sha256'] == digest(experiment.LOCK.read_bytes())
    assert plan['paper_snapshot_sha256'] == digest((ROOT / 'evidence/snapshots/psyche_paper_v1.txt').read_bytes())
    assert plan['requests_sha256'] == experiment.fingerprint(rows)
    assert rows == experiment.build(spec)
    assert len(rows) == 16 and len({r['id'] for r in rows}) == 16
    assert set(Counter((r['arm'], r['quantity'], r['thought']) for r in rows).values()) == {2}
    runtime = experiment.read(out / 'runtime.json')
    assert runtime['model']['digest'] == spec['model_digest']
    assert runtime['template_sha256'] == digest(runtime['show']['template'].encode())
    assert runtime['parameters_sha256'] == digest(runtime['show'].get('parameters', '').encode())
    assert not runtime['think']
    measurements = experiment.read(out / 'measurements.json')
    by_id = {r['id']: r for r in measurements}
    tokens = []
    raw_hashes = {}
    for row in rows:
        path = out / 'responses' / (row['id'] + '.json')
        attempt = experiment.read(out / 'attempts' / (row['id'] + '.json'))
        record = experiment.read(path)
        expected = experiment.fingerprint(row['payload'])
        assert record['id'] == row['id']
        assert attempt['request_sha256'] == record['request_sha256'] == expected
        raw = record['raw']
        assert record['status'] == experiment.classify(raw, spec) == 'completed'
        count = raw['prompt_eval_count']
        assert count > 0 and count + spec['options']['num_predict'] + 2048 < spec['options']['num_ctx']
        assert by_id[row['id']]['text'] == raw['message']['content']
        observed = experiment.describe(raw['message']['content'], row['case'])
        assert all(by_id[row['id']][k] == value for k, value in observed.items())
        tokens.append(count)
        raw_hashes[str(path.relative_to(ROOT))] = digest(path.read_bytes())
    assert len(list((out / 'responses').glob('*.json'))) == 16
    assert experiment.read(out / 'analysis-manifest.json')['raw_response_sha256'] == raw_hashes
    assert experiment.read(out / 'analysis-manifest.json')['measurements_sha256'] == digest((out / 'measurements.json').read_bytes())
    key = experiment.read(out / 'blinding-key.json')
    assert {r['condition_id'] for r in key} == {r['id'] for r in rows}
    assert len({r['blind_id'] for r in key}) == 16
    summary = experiment.read(out / 'summary.json')
    assert summary['completed'] == summary['recorded'] == summary['planned'] == 16
    assert summary['clinical_scores_computed'] == summary['judge_calls'] == summary['paid_api_calls'] == 0
    assert all(r['matched_pairs'] == 8 for r in summary['paired_word_count_descriptors'])
    assert not (out / '.running').exists()
    verification = {'passed': True, 'source_files_verified': 15, 'responses_verified': 16,
                    'independent_authored_cases': 1, 'factor_cells': 8,
                    'prompt_token_range': [min(tokens), max(tokens)],
                    'model_digest': runtime['model']['digest'],
                    'test_file_sha256': digest((ROOT / 'tests/test_psyche_factorial.py').read_bytes()),
                    'verifier_sha256': digest(Path(__file__).read_bytes()),
                    'summary_sha256': digest((out / 'summary.json').read_bytes())}
    write_json(out / 'verification.json', verification)
    print(json.dumps(verification, ensure_ascii=False))


if __name__ == '__main__':
    main()
