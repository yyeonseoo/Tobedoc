// OS sentence segmentation only; no embeddings, downloads, model inference or networking.
import Foundation
import NaturalLanguage
struct Input: Decodable { let id: String; let text: String }
struct Unit: Encodable { let index: Int; let text: String; let utf16Start: Int; let utf16Length: Int }
struct Record: Encodable { let id: String; let sentences: [Unit] }
struct Export: Encodable { let os: String; let method: String; let records: [Record] }
guard CommandLine.arguments.count == 3 else { fatalError("Usage: SentenceUnits input.json output.json") }
let inputs = try JSONDecoder().decode([Input].self, from: Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1])))
var records: [Record] = []
for input in inputs {
    let tokenizer = NLTokenizer(unit: .sentence)
    tokenizer.setLanguage(.english)
    tokenizer.string = input.text
    var units: [Unit] = []
    tokenizer.enumerateTokens(in: input.text.startIndex..<input.text.endIndex) { range, _ in
        let text = String(input.text[range])
        if !text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let span = NSRange(range, in: input.text)
            units.append(Unit(index: units.count, text: text, utf16Start: span.location, utf16Length: span.length))
        }
        return true
    }
    records.append(Record(id: input.id, sentences: units))
}
let result = Export(os: ProcessInfo.processInfo.operatingSystemVersionString,
                    method: "macOS NLTokenizer English sentence units, UTF16 source spans", records: records)
let encoder = JSONEncoder()
encoder.outputFormatting = [.sortedKeys]
try encoder.encode(result).write(to: URL(fileURLWithPath: CommandLine.arguments[2]), options: .atomic)
print("Segmented \(records.count) replies without inference or asset requests.")
