"""Link cached source instructions, observations and limits. No inference/network."""
import csv
import json
import math
from collections import defaultdict
from statistics import mean

from audit_sources import parse_styles
from common import ROOT, digest, read_source, source_records, write_json
from summarize_local_pilot import text_metrics

OUT = ROOT / "analysis/feature-audit-v01"
NATIVE = ROOT / "analysis/automatic-features-v01/native-features-20261030"
CROSS = ROOT / "analysis/framework-pilot-v01/framework-pilot-20261030"
STYLES = ["plain", "upset", "verbose", "reserved", "tangent", "pleasing"]
METRICS = ["word_count", "sentence_count", "mattr20", "adjacent_cos_mean",
           "question_answer_cos", "topic_answer_cos"]
INTERPRETATION = {
    "plain": ("지정된 추가 말투 없음. 비교 기준이며 임상적 정상 대조군이 아니다.",
              "스타일 내용은 빈 문자열이다. 배경 정보와 전체 프롬프트는 적용된다."),
    "upset": ("분노·반발·불신·논쟁; 일부 턴은 평범하게; 신뢰에 따라 변화",
              "답변이 짧아졌다는 관찰은 분노·반발의 구현 여부를 판정하지 못한다."),
    "verbose": ("긴 설명·경험과 감정의 상세 서술·면담 진행 개입",
                "발화량 증가만 관찰 가능하다. 상세함·면담 통제 곤란은 별도 검증이 없다."),
    "reserved": ("짧거나 모호한 답변·정보 공개 주저·불신",
                 "짧은 답변은 관찰됐지만 정보 공개 회피·불신이 구현됐다는 증거는 아니다."),
    "tangent": ("답변 중 무관한 주제로 전환·턴 내 주제 복귀 금지·재유도 필요",
                "인접 의미 유사도 감소는 관찰됐지만 실제 주제 이탈이나 사고장애의 참값은 아니다."),
    "pleasing": ("걱정 축소·반대 회피·승인 추구·쉽게 동의",
                 "길이와 의미 유사도만으로 동의·걱정 축소·승인 추구를 판정할 수 없다."),
}


def close(a, b):
    if not math.isclose(a, b, abs_tol=1e-10):
        raise ValueError(f"Cached numeric mismatch: {a} != {b}")


def build():
    tracked = []

    def load(path):
        tracked.append(path)
        return json.loads(path.read_text())

    styles = parse_styles(read_source("psi_styles"))
    read_source("psi_formatter")
    sim_styles = json.loads(read_source("patientsim_personality"))
    features_path = NATIVE / "features.jsonl"
    tracked.append(features_path)
    rows = [json.loads(line) for line in features_path.read_text().splitlines()]
    contrasts = {(r["style"], r["feature"]): r for r in load(NATIVE / "paired-contrasts.json")}
    profiles = {(r["style"], r["feature"]): r for r in load(NATIVE / "style-profiles.json")}
    assert len(rows) == 144
    grouped = defaultdict(list)
    for row in rows:
        grouped[(row["profile_id"], row["repeat_index"], row["style_id"])].append(row)
        raw_path = ROOT / "pilot/runs/native-features-20261030/responses" / f'{row["condition_id"]}-T{row["turn"]}.json'
        raw = load(raw_path)
        assert raw["status"] == "completed" and not raw["is_fixture"]
        assert raw["response_text"] == raw["raw_response"]["message"]["content"]
        assert digest(raw["response_text"].encode()) == row["response_sha256"]
        assert raw["request_sha256"] == row["request_sha256"]
        close(text_metrics(raw["response_text"])["word_count"], row["features"]["word_count"])
    assert len(grouped) == 36 and all(len(v) == 4 for v in grouped.values())
    result = []
    for style in STYLES:
        means, changes = {}, {}
        for metric in METRICS:
            blocks = {}
            for (profile, repeat, s), values in grouped.items():
                if s == style or s == "plain":
                    nums = [r["features"][metric] for r in values if r["features"][metric] is not None]
                    blocks[(profile, repeat, s)] = mean(nums)
            means[metric] = mean(v for k, v in blocks.items() if k[2] == style)
            close(means[metric], profiles[(style, metric)]["mean"])
            if style != "plain":
                delta = [v - blocks[(p, r, "plain")] for (p, r, s), v in blocks.items() if s == style]
                cached = contrasts[(style, metric)]
                close(mean(delta), cached["mean_difference_from_plain"])
                assert sum(x > 0 for x in delta) == cached["positive_blocks"]
                assert sum(x < 0 for x in delta) == cached["negative_blocks"]
                changes[metric] = {"mean": mean(delta), "positive": sum(x > 0 for x in delta),
                                   "negative": sum(x < 0 for x in delta), "zero": sum(x == 0 for x in delta), "blocks": 6}
        example = load(ROOT / "pilot/runs/native-features-20261030/responses" / f"F-1-1-{style}-R0-T1.json")
        result.append({"style": style, "declared": INTERPRETATION[style][0],
                       "source_instruction": styles[style], "mean": means, "paired_change": changes,
                       "interpretation_limit": INTERPRETATION[style][1],
                       "example": {k: example[k] for k in ["condition_id", "turn", "interviewer_text", "response_text"]}})
    cross = load(CROSS / "results.json")
    flat_path = CROSS / "features-flat.csv"
    tracked.append(flat_path)
    with flat_path.open(newline="") as handle:
        flat = list(csv.DictReader(handle))
    assert len(flat) == 72
    cross_checked = 0
    for program, metrics in cross["dialogue_mean_matched_contrasts"].items():
        for metric, cached in metrics.items():
            pairs = defaultdict(dict)
            for row in flat:
                if row["arm"] == program and row[metric] != "":
                    pairs[(row["profile_id"], row["turn"])][row["style_id"]] = float(row[metric])
            case_pairs = defaultdict(list)
            for (case, _), pair in pairs.items():
                if set(pair) == {"plain", "verbose"}:
                    case_pairs[case].append(pair)
            close(mean(mean(p["plain"] for p in ps) for ps in case_pairs.values()), cached["plain_mean"])
            close(mean(mean(p["verbose"] for p in ps) for ps in case_pairs.values()), cached["verbose_mean"])
            close(mean(mean(p["verbose"] - p["plain"] for p in ps) for ps in case_pairs.values()), cached["verbose_minus_plain"])
            cross_checked += 1
    inventory_path = ROOT / "catalog/feature-map.csv"
    tracked.append(inventory_path)
    with inventory_path.open(newline="") as handle:
        inventory = [r for r in csv.DictReader(handle) if r["system"] in ("PATIENT-PSI", "PatientSim")]
    assert len(inventory) == 18
    evidence = {r["feature_id"]: r["evidence"] for r in load(ROOT / "evidence/feature-evidence.json")["features"]}
    # These are measurement-coverage labels, never model success/failure labels.
    proxy_ids = {"PSI-F07", "PSI-F08", "PSI-F09", "PSI-F10", "PSIM-F01"}
    for row in inventory:
        anchor = evidence[row["feature_id"]]
        source = read_source(anchor["source_id"])
        offset = source.index(anchor["search_string"])
        assert source[:offset].count("\n") + 1 == anchor["text_line"]
        row["source_evidence"] = anchor
        row["current_coverage"] = "partial_proxy_only" if row["feature_id"] in proxy_ids else "source_audit_only_in_this_report"
    source_ids = sorted({r["source_id"] for r in inventory} | {"psi_styles", "psi_formatter", "patientsim_personality"})
    records = source_records()
    style_source = read_source("psi_styles")
    for item in result:
        marker = f'type: "{item["style"]}"'
        item["source_file"] = str(ROOT / records["psi_styles"]["local_text"])
        item["source_line"] = style_source[:style_source.index(marker)].count("\n") + 1
    audit = {"scope": "Existing-data feature audit supporting the Korean report; not native-framework or clinical validation",
             "new_generation_calls": 0, "network_calls": 0, "llm_judge_calls": 0,
             "inventory": inventory, "styles": result,
             "cross_source": {"instructions": {"patient_psi_style": {s: styles[s] for s in ("plain", "verbose")},
                                                "patientsim_style": {s: sim_styles[s] for s in ("plain", "verbose")}},
                              "results": cross["dialogue_mean_matched_contrasts"]},
             "verification": {"inventory_source_anchors_checked": len(inventory), "native_responses_hash_checked": len(rows), "native_style_metric_means_checked": len(STYLES) * len(METRICS),
                              "native_paired_metrics_checked": (len(STYLES)-1)*len(METRICS), "cross_source_metric_contrasts_checked": cross_checked},
             "example_selection": "Fixed profile 1-1, repeat 0, turn 1 for all six styles; not selected by observed effect, not evidence of representativeness",
             "provenance": [{"path": str(p.relative_to(ROOT)), "sha256": digest(p.read_bytes())} for p in sorted(set(tracked))],
             "sources": [{k: records[s][k] for k in ("id", "commit", "citation_url", "sha256")} for s in source_ids]}
    return audit


def report(audit):
    lines = ["# 페르소나의 설정–발화 연결 감사", "",
             "기존 보고서 보강용 근거 문서. 새 생성·외부 요청·임상 채점 없이 기존 자료만 연결했다.", "",
             "## 먼저 읽을 결론", "",
             "설계자는 조현병 증상 목록보다 상담 태도·발화량·정보 공개·주제 전환 등을 지시하고 있었다. "
             "현재 확인된 것은 그 설정에 따른 출력 차이이며, 임상 특징 구현의 성공률은 아니다.", "",
             "- PSI: plain 68.8단어, reserved 29.0단어, verbose 77.6단어. 짧고 긴 답변의 차이는 관찰됐다.",
             "- 다만 upset/reserved의 3문장 제한과 공통 5문장 제한, verbose의 8문장 문구가 함께 있어 말투와 길이 규칙의 영향을 분리하지 못했다.",
             "- tangent: 인접 문장 의미 유사도 −0.060(감소 6/6블록), 질문 유사도 +0.002(증가 3/6블록), 초기 상황 유사도 +0.010. 질문/상황 유사도를 혼용하지 않는다.",
             "- 교차 소스 발화량 변화는 PSI +17.0, PatientSim +51.0단어. PatientSim/plain에는 간결하게 답하라는 지시가 있어 증가량만으로 우열을 정할 수 없다.", "",
             "## 해석 규칙", "",
             "‘지시된 특징’과 ‘자동 측정값’을 구분한다. 단어 수는 발화량을 직접 기술하지만 불신·동의·정보 공개 회피를 판정하지 못한다. "
             "코사인은 의미적 가까움의 대리값이며 실제 주제 이탈·사고장애·문장 이해 가능성의 참값이 아니다. "
             "1명·3상황·2반복의 PSI 144응답과, 다른 허구 사례 3명의 교차 소스 72응답은 합쳐 분석하지 않는다. "
             "두 소스 모두 Qwen 지시문 이식이며 원형 전체 시스템의 비교가 아니다.", "",
             "## PATIENT-Ψ 여섯 스타일: 원문 지시 → 관찰 → 남은 질문", ""]
    for item in audit["styles"]:
        s, m = item["style"], item["mean"]
        lines += [f"### {s}", "", f"설정 요지: {item['declared']} [원본 지시문](<{item['source_file']}:{item['source_line']}>).", "",
                  f"관찰: 평균 {m['word_count']:.2f}단어; 인접 문장 유사도 {m['adjacent_cos_mean']:.3f}; "
                  f"질문 유사도 {m['question_answer_cos']:.3f}; 초기 상황 유사도 {m['topic_answer_cos']:.3f}.", ""]
        if item["paired_change"]:
            change = item["paired_change"]["word_count"]
            lines += [f"plain 대비 단어 수: {change['mean']:+.2f}; 증가 {change['positive']}/6, 감소 {change['negative']}/6, 동일 {change['zero']}/6블록.", ""]
        lines += [f"판단 한계: {item['interpretation_limit']}", ""]
    lines += ["## 두 소스의 공통 특징: 발화량", "",
              "공통 wrapper·인물·질문을 사용한 별도 72응답이다. PSI의 개별 길이 문구는 제거했지만 다른 스타일 문구는 보존했고 공통 최대 5문장을 적용했다. "
              "PatientSim/plain만 간결·직접 답변을 명시하므로 두 소스의 plain은 같은 처치가 아니다.", ""]
    for p, metrics in audit["cross_source"]["results"].items():
        w = metrics["word_count"]
        lines += [f"- {p}: {w['plain_mean']:.1f} → {w['verbose_mean']:.1f}단어, 차이 {w['verbose_minus_plain']:+.1f}; 증가 사례 {w['positive_cases']}/3."]
    lines += ["", "정확히 5문장 64/72, 초과 8/72. 상한 부근의 결과이며 제한을 없앤 행동으로 일반화하지 않는다. "
              "단순 지시/plain과 PSI/plain은 같은 지시·같은 응답이므로 독립적인 대조군으로 세지 않는다.", "",
              "## 설계 특징 18항목의 현재 측정 범위", "",
              "기존 27항목 목록 중 공개 구현 두 시스템의 18항목만 포함했다. PSYCHE 논문 항목은 여기서 제외했다. "
              "아래 ‘소스 확인’은 이번 행동 분석에서 직접 평가하지 않았다는 뜻이며, 다른 단일 필드 실험의 존재나 모델의 구현 여부를 부정하지 않는다.", ""]
    for r in audit["inventory"]:
        label = "일부 표면/의미 대리값만 있음" if r["current_coverage"] == "partial_proxy_only" else "이번 분석은 소스 확인에 한정"
        lines += [f"- {r['feature_id']} {r['declared_feature']}: {label}. 근거 {r['source_id']} / {r['locator']}."]
    lines += ["", "## 다음 작업의 결정선", "",
              "첫 분석은 위와 같이 설정–관찰–측정 불가를 연결하는 데서 종료한다. 새 생성은 아직 필요하지 않다. "
              "후속 후보는 (1) 길이 제한이 발화량 차이를 지배하는지 분리, (2) tangent 설정이 어떤 종류의 주제 전환을 만드는지 검토다. "
              "둘 다 지금 실행하지 않는다. 주제 전환의 임상 개념 대응은 교수님 자문 대상으로 삼고 현재 코사인을 정답 채점기로 사용하지 않는다.", "",
              "## 부록: 같은 질문에 대한 실제 답변", "",
              "선정 규칙: 효과 크기를 보지 않고 profile 1-1 / repeat 0 / turn 1을 여섯 스타일 모두 제시했다. "
              "대표성을 주장하거나 이 예시로 임상 등급을 매기지 않는다. 전체 평균과 한 답변이 다를 수 있다.", ""]
    for item in audit["styles"]:
        e = item["example"]
        lines += [f"### {item['style']} · {e['condition_id']} · T{e['turn']}", "",
                  f"질문: {e['interviewer_text']}", "", e["response_text"], ""]
    lines += ["## 재현", "", "작업 폴더에서 `python3 scripts/build_feature_audit.py` 실행. "
              "원문 해시·단어 수·대화 평균·짝지은 차이를 캐시와 재대조하며 새 추론·Swift·네트워크를 사용하지 않는다. "
              "원본 자료는 변경하지 않고 본 근거 문서와 audit.json만 재생성한다.", ""]
    return "\n".join(lines)


def main():
    audit = build()
    write_json(OUT / "audit.json", audit)
    (OUT / "report.ko.md").write_text(report(audit))
    print(json.dumps({"output": str(OUT), "inventory_items": len(audit["inventory"]),
                      "verification": audit["verification"], "new_generation_calls": 0}, ensure_ascii=False))


if __name__ == "__main__":
    main()
