"""Reproduce previously completed reversal/duplication checks from cached vectors.

This is a recheck, not a new experiment or an independent clinical validation set.
"""
from statistics import mean
from common import ROOT, digest, write_json
from extract_automatic_features import load_verified, adjacent, mean as valid_mean, text_id
from role_enrichment import OUT, read


def main():
    run = ROOT/'pilot/runs/native-features-20261030'
    data = ROOT/'analysis/automatic-features-v01/native-features-20261030'
    _, _, raw, provenance = load_verified(run)
    cached = read(data/'native-output.json')
    indexed = {r['id']:r for r in cached['records']}
    controls = {(r['condition_id'],r['turn']):r for r in read(data/'metric-controls.json')['rows']}
    checks = []
    for row in raw:
        vectors = [s['vector'] for s in indexed[text_id(row['response_text'])]['sentences']]
        if len(vectors)<2:
            continue
        original, reversed_value = valid_mean(adjacent(vectors)), valid_mean(adjacent(list(reversed(vectors))))
        duplicated = valid_mean(adjacent([vectors[0]]+vectors))
        if any(v is None for v in (original,reversed_value,duplicated)):
            continue
        saved = controls[(row['condition_id'],row['turn'])]
        assert abs(original-saved['original_adjacent_cos'])<1e-12
        assert abs(reversed_value-saved['reversed_adjacent_cos'])<1e-12
        assert abs((duplicated-original)-saved['first_sentence_duplication_delta'])<1e-12
        checks.append({'condition_id':row['condition_id'],'turn':row['turn'],
                       'reversal_absolute_difference':abs(original-reversed_value),
                       'first_sentence_duplication_difference':duplicated-original})
    result = {'status':'reproduction_of_existing_controls_not_new_experiment', 'existing_replies':len(raw),
              'eligible_multisentence_replies':len(checks),
              'reversal_invariant_within_1e12':sum(r['reversal_absolute_difference']<1e-12 for r in checks),
              'max_reversal_difference':max(r['reversal_absolute_difference'] for r in checks),
              'duplication_increases_mean_similarity':sum(r['first_sentence_duplication_difference']>0 for r in checks),
              'mean_duplication_difference':mean(r['first_sentence_duplication_difference'] for r in checks),
              'interpretation':'Mean symmetric adjacent cosine cannot distinguish complete sentence-order reversal. Duplicating a sentence can raise it. These are algebraic properties, not labels declaring the original or reversed utterance clinically coherent/incoherent.',
              'cached_embedding_metadata':{k:v for k,v in cached.items() if k!='records'},
              'raw_request_and_response_hashes_verified':len(provenance), 'new_generation_calls':0,'new_embedding_calls':0,
              'source_files':{str((data/p).relative_to(ROOT)):digest((data/p).read_bytes()) for p in ('native-output.json','metric-controls.json')},
              'checks':checks}
    write_json(OUT/'reused-metric-checks.json',result)
    print({k:v for k,v in result.items() if k not in ('checks','source_files','cached_embedding_metadata','interpretation')})


if __name__=='__main__':
    main()
