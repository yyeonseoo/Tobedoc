"""Offline sentence trajectories, controls, abstention and exact source provenance.

No persona generation, model download, external service or clinical grading.
The semantic layer is evaluated before it is applied to the existing replies.
"""
import argparse
from collections import Counter
import itertools
import json
from pathlib import Path
import re
from statistics import mean
import subprocess
import tempfile

from common import ROOT, digest, write_json
from extract_automatic_features import cosine, words
from fact_disclosure_probe import match_fact
from first_reply_probe_runner import verify_response
from run_local_pilot import fingerprint, now
from topic_selection_probe import paired

SPEC = ROOT / "config/topic-trajectory-v01.json"
OUT = ROOT / "analysis/topic-trajectory-v01"
SOURCE = ROOT / "analysis/topic-selection-probe-v01/results.json"
LABELS = ("R", "O", "D", "U", "B")
STYLES = ("plain", "verbose", "tangent")


def read(path):
    return json.loads(path.read_text())


def freeze(path, value):
    if path.exists():
        if read(path) != value:
            raise ValueError(f"Frozen measurement input changed: {path}")
    else:
        write_json(path, value)


def text_id(text):
    return digest(text.encode())


def other_topic(spec, topic):
    case = spec["topics"][topic]["case"]
    return next(t for t, info in spec["topics"].items() if info["case"] == case and t != topic)


def make_controls(spec):
    controls = []
    for split in ("development", "holdout"):
        for topic, info in spec["topics"].items():
            other = other_topic(spec, topic)
            for item in spec["controls"][split]:
                kind = item["kind"]
                text = (item["texts"][topic if kind == "requested" else other]
                        if kind in ("requested", "other") else item["texts"][info["case"]]
                        if kind == "mixed" else item["text"])
                controls.append({"id": f"{split}-{topic}-{item['id']}", "split": split,
                                 "topic": topic, "other_topic": other, "kind": kind,
                                 "expected": item["expected"], "text": text})
    return controls


def verify_sources():
    folder = ROOT / "pilot/runs/topic-selection-probe-v01"
    source = read(SOURCE)
    plan, cases = read(folder / "plan.json"), read(folder / "conditions.json")
    if len(cases) != 48 or len(source["responses"]) != 48:
        raise ValueError("Expected exactly 48 existing responses")
    indexed = {r["condition_id"]: r for r in source["responses"]}
    if len(indexed) != 48 or set(indexed) != {c["condition_id"] for c in cases}:
        raise ValueError("Response IDs do not match frozen conditions")
    files = [SOURCE, folder / "plan.json", folder / "conditions.json", folder / "runtime.json"]
    for case in cases:
        request_path = folder / "requests" / (case["condition_id"] + ".json")
        raw_path = folder / "responses" / (case["condition_id"] + ".json")
        raw, request = read(raw_path), read(request_path)
        verify_response(raw, request, case, plan["model_digest"])
        if raw["response_text"] != indexed[case["condition_id"]]["response_text"]:
            raise ValueError("Analysis text differs from original generated output")
        files += [request_path, raw_path]
    return source, cases, files


def native_embeddings(inputs, cached_only):
    swift = ROOT / "scripts/NativeFeatures.swift"
    key = fingerprint({"inputs": inputs, "swift_sha256": digest(swift.read_bytes())})
    output, cache_path = OUT / "native-output.json", OUT / "native-cache.json"
    reused = output.exists() and cache_path.exists()
    if reused:
        cache = read(cache_path)
        if cache["key"] != key or cache["output_sha256"] != digest(output.read_bytes()):
            raise ValueError("Native cache mismatch; preserve and investigate")
    else:
        if cached_only:
            raise ValueError("No native cache available for offline replay")
        write_json(OUT / "native-input.json", inputs)
        with tempfile.TemporaryDirectory(prefix="persona-trajectory-") as temp:
            binary = str(Path(temp) / "native-features")
            subprocess.run(["/usr/bin/swiftc", "-module-cache-path", str(Path(temp) / "modules"),
                            str(swift), "-o", binary], check=True, capture_output=True)
            subprocess.run([binary, str(OUT / "native-input.json"), str(output)], check=True)
        write_json(cache_path, {"key": key, "output_sha256": digest(output.read_bytes()),
                               "created_at_utc": now(), "new_llm_calls": 0})
    native = read(output)
    if native["embeddingRevision"] != 1 or native["embeddingDimension"] != 512:
        raise ValueError("Unexpected OS embedding backend")
    records = {r["id"]: r for r in native["records"]}
    if set(records) != {i["id"] for i in inputs}:
        raise ValueError("Missing/extra native records")
    return records, {k: native[k] for k in native if k != "records"}, reused


def anchors(text, spec, topic, facts=()):
    info = spec["topics"][topic]
    hits = [{"kind": "topic_word", "value": word, "start": m.start(), "end": m.end()}
            for word in info["anchors"]
            for m in re.finditer(r"\b" + re.escape(word) + r"\b", text, re.I)]
    for fact in facts:
        if fact["domain"] == info["event"]:
            matched = match_fact(text, fact)
            if matched["recognized_mention"]:
                hits.append({"kind": "supplied_fact_value", "value": fact["id"],
                             "normalized_matches": matched["matches"]})
    return hits


def evidence(text, vector, spec, topic, prototypes, facts=()):
    other = other_topic(spec, topic)
    r, o = anchors(text, spec, topic, facts), anchors(text, spec, other, facts)
    literal = "B" if r and o else "R" if r else "O" if o else "U"
    def score(which):
        scores = [cosine(vector, v) for v in prototypes[which]]
        return max(scores) if scores and all(s is not None for s in scores) else None
    return {"text": text, "literal_label": literal, "requested_anchor_hits": r,
            "other_anchor_hits": o, "requested_cos": score(topic), "other_cos": score(other),
            "word_count": len(words(text))}


def classify(item, params, short_max=4):
    if item["literal_label"] != "U":
        return item["literal_label"]
    r, o = item["requested_cos"], item["other_cos"]
    if item["word_count"] <= short_max or r is None or o is None:
        return "U"
    if max(r, o) < params["low"]:
        return "D"
    if max(r, o) >= params["high"] and abs(r-o) >= params["margin"]:
        return "R" if r > o else "O"
    return "U"


def classification_metrics(items):
    matrix = {a: {b: 0 for b in LABELS} for a in LABELS}
    for item in items:
        matrix[item["expected"]][item["predicted"]] += 1
    classes = {}
    for label in LABELS:
        tp = matrix[label][label]
        actual = sum(matrix[label].values())
        predicted = sum(matrix[a][label] for a in LABELS)
        precision, recall = (tp/predicted if predicted else 0), (tp/actual if actual else 0)
        classes[label] = {"actual": actual, "predicted": predicted, "precision": precision,
                          "recall": recall, "f1": 2*precision*recall/(precision+recall) if precision+recall else 0}
    known = [i for i in items if i["expected"] in ("R", "O")]
    semantic_known = [i for i in known if i["literal_label"] == "U"]
    return {"items": len(items), "unique_texts": len({i["text"] for i in items}),
            "accuracy": mean(i["expected"] == i["predicted"] for i in items),
            "macro_f1": mean(c["f1"] for c in classes.values()), "classes": classes,
            "known_topic_recall": mean(i["expected"] == i["predicted"] for i in known) if known else None,
            "anchorless_known_topic_recall": mean(i["expected"] == i["predicted"] for i in semantic_known) if semantic_known else None,
            "confusion_matrix": matrix,
            "errors": [i for i in items if i["expected"] != i["predicted"]]}


def evaluate_controls(controls, params, short_max):
    return classification_metrics([{**c, "predicted": classify(c, params, short_max)} for c in controls])


def calibrate(controls, spec):
    grid, short = spec["calibration"], spec["calibration"]["short_anchorless_words_max"]
    dev = [c for c in controls if c["split"] == "development"]
    holdout = [c for c in controls if c["split"] == "holdout"]
    candidates = []
    for high, low, margin in itertools.product(grid["high_grid"], grid["low_grid"], grid["margin_grid"]):
        if low >= high:
            continue
        params = {"high": high, "low": low, "margin": margin}
        result = evaluate_controls(dev, params, short)
        candidates.append((result["macro_f1"], high, -low, margin, params, result))
    chosen = max(candidates, key=lambda c: c[:4])
    params, dev_result = chosen[4:]
    tested = evaluate_controls(holdout, params, short)
    gate = grid["holdout_gate"]
    passed = (tested["macro_f1"] >= gate["macro_f1_min"] and
              tested["classes"]["D"]["precision"] >= gate["distant_precision_min"] and
              tested["known_topic_recall"] >= gate["known_topic_recall_min"])
    return {"parameters": params, "development": dev_result, "holdout": tested,
            "gate_passed": passed, "candidates_evaluated": len(candidates),
            "semantic_rates_status": "control-gated exploratory" if passed else "failed control gate; not a validated topic rate"}


def sequence_metrics(labels):
    other_then_r = any(x == "O" and "R" in labels[i+1:] for i, x in enumerate(labels))
    r_away_r = any(x == "R" and any(y in ("O", "D") and "R" in labels[j+1:]
                                         for j, y in enumerate(labels) if j > i)
                   for i, x in enumerate(labels))
    definite = [x for x in labels if x in ("R", "O", "D")]
    return {"other_then_requested": other_then_r, "requested_away_requested": r_away_r,
            "definite_label_changes": sum(a != b for a, b in zip(definite, definite[1:]))}


def exact_utf16(text, start, length):
    return text.encode("utf-16-le")[2*start:2*(start+length)].decode("utf-16-le")


def build(cached_only=False):
    spec = read(SPEC)
    source, cases, source_files = verify_sources()
    by_id = {c["condition_id"]: c for c in cases}
    controls = make_controls(spec)
    texts = {text_id(r["response_text"]): r["response_text"] for r in source["responses"]}
    texts.update({text_id(c["text"]): c["text"] for c in controls})
    texts.update({text_id(p): p for topic in spec["topics"].values() for p in topic["prototypes"]})
    inputs = [{"id": key, "text": texts[key]} for key in sorted(texts)]
    freeze(OUT / "measurement-plan.json", {"spec": spec, "spec_sha256": digest(SPEC.read_bytes()),
           "source_analysis_sha256": digest(SOURCE.read_bytes()), "native_inputs_sha256": fingerprint(inputs),
           "note": "Posthoc development plan; original outputs and two examples had already been seen. Not preregistered.",
           "new_generation": 0, "clinical_labels": 0})
    if not (OUT / "prepared-at.json").exists():
        write_json(OUT / "prepared-at.json", {"prepared_at_utc": now(), "plan_sha256": digest((OUT / "measurement-plan.json").read_bytes())})
    native, backend, reused = native_embeddings(inputs, cached_only)
    prototypes = {topic: [native[text_id(p)]["vector"] for p in info["prototypes"]]
                  for topic, info in spec["topics"].items()}
    control_evidence = [{**c, **evidence(c["text"], native[text_id(c["text"])]["vector"], spec, c["topic"], prototypes)} for c in controls]
    calibration = calibrate(control_evidence, spec)
    # This file is produced and locked BEFORE classifying any of the 48 replies.
    freeze(OUT / "calibration-lock.json", {"spec_sha256": digest(SPEC.read_bytes()), **calibration})
    params = calibration["parameters"]
    short = spec["calibration"]["short_anchorless_words_max"]
    rows = []
    for row in source["responses"]:
        case = by_id[row["condition_id"]]
        topic = next(t for t, info in spec["topics"].items()
                     if info["case"] == row["profile_id"] and info["event"] == row["target_event"])
        sentences = []
        for index, s in enumerate(native[text_id(row["response_text"])]["sentences"]):
            if exact_utf16(row["response_text"], s["utf16Start"], s["utf16Length"]) != s["text"]:
                raise ValueError("Exact source sentence span mismatch")
            item = evidence(s["text"], s.get("vector"), spec, topic, prototypes, case["facts"])
            label = classify(item, params, short)
            cue = bool(item["requested_anchor_hits"] and re.search(r"\b(?:back to|return(?:ing)? to)\b", s["text"], re.I))
            sentences.append({"index": index+1, "utf16_start": s["utf16Start"], "utf16_length": s["utf16Length"],
                              **item, "semantic_label": label, "explicit_requested_return_cue": cue})
        if not sentences:
            raise ValueError("Empty sentence segmentation")
        literal = [s["literal_label"] for s in sentences]
        semantic = [s["semantic_label"] for s in sentences]
        counts = Counter(semantic)
        item = {k: row[k] for k in ("condition_id", "profile_id", "target_event", "variant_id", "repeat_index", "style_id", "word_count", "question", "response_text")}
        item.update(topic=topic, sentence_count=len(sentences), sentences=sentences,
                    literal_sequence=" ".join(literal), semantic_sequence=" ".join(semantic),
                    literal_other_present=any(x in ("O", "B") for x in literal),
                    literal_other_then_requested=sequence_metrics(literal)["other_then_requested"],
                    semantic_return=sequence_metrics(semantic)["requested_away_requested"],
                    semantic_label_change_count=sequence_metrics(semantic)["definite_label_changes"],
                    explicit_requested_return_cue=any(s["explicit_requested_return_cue"] for s in sentences),
                    distant_candidate_fraction=counts["D"]/len(sentences),
                    unresolved_fraction=counts["U"]/len(sentences),
                    literal_unanchored_fraction=literal.count("U")/len(sentences),
                    old_other_present=row["other_count"] > 0,
                    old_other_then_requested=row["other_then_requested_marker"],
                    distant_sensitivity={str(delta): mean(classify(s, {**params, "low": params["low"]+delta}, short) == "D" for s in sentences)
                                           for delta in (-.05, 0, .05)})
        rows.append(item)
    summaries = []
    for style in STYLES:
        group = [r for r in rows if r["style_id"] == style]
        summaries.append({"style": style, "replies": len(group), "sentences": sum(r["sentence_count"] for r in group),
                          "mean_words": mean(r["word_count"] for r in group),
                          "mean_sentences": mean(r["sentence_count"] for r in group),
                          **{metric: sum(r[metric] for r in group) for metric in
                             ("literal_other_present", "literal_other_then_requested", "explicit_requested_return_cue", "semantic_return", "old_other_present", "old_other_then_requested")},
                          **{"mean_"+metric: mean(r[metric] for r in group) for metric in
                             ("distant_candidate_fraction", "unresolved_fraction", "literal_unanchored_fraction", "semantic_label_change_count")}})
    metrics = ("distant_candidate_fraction", "unresolved_fraction", "literal_other_present", "literal_other_then_requested", "explicit_requested_return_cue", "semantic_return", "semantic_label_change_count")
    contrasts = {metric: paired(rows, "tangent", "verbose", metric) for metric in metrics}
    subgroups = {field: {value: paired([r for r in rows if r[field] == value], "tangent", "verbose", "distant_candidate_fraction")
                        for value in sorted({r[field] for r in rows})} for field in ("profile_id", "variant_id", "target_event")}
    sensitivity = {str(delta): paired([{**r, "sensitivity": r["distant_sensitivity"][str(delta)]} for r in rows],
                                    "tangent", "verbose", "sensitivity") for delta in (-.05, 0, .05)}
    controls_scored = [{**c, "predicted": classify(c, params, short)} for c in control_evidence]
    write_json(OUT / "controls-scored.json", controls_scored)
    result = {"analysis_id": spec["analysis_id"], "existing_replies": len(rows), "new_replies": 0,
              "label_definitions": spec["label_definitions"], "calibration": calibration,
              "summaries": summaries, "tangent_minus_verbose": contrasts, "subgroups": subgroups,
              "threshold_sensitivity": sensitivity, "responses": rows, "backend": backend,
              "provenance": {"source_files": [{"path": str(p.relative_to(ROOT)), "sha256": digest(p.read_bytes())} for p in source_files],
                             "spec_sha256": digest(SPEC.read_bytes()), "script_sha256": digest(Path(__file__).read_bytes()),
                             "swift_sha256": digest((ROOT / "scripts/NativeFeatures.swift").read_bytes()),
                             "native_output_sha256": digest((OUT / "native-output.json").read_bytes()),
                             "new_llm_calls": 0, "clinical_ratings": 0, "native_cache_reused": reused}}
    write_json(OUT / "results.json", result)
    # Flat inspectable records, without promoting unresolved labels to expert judgments.
    flat = [{"condition_id": r["condition_id"], "style": r["style_id"], "topic": r["topic"], **s} for r in rows for s in r["sentences"]]
    with (OUT / "sentences.jsonl").open("w") as stream:
        for item in flat:
            stream.write(json.dumps(item, ensure_ascii=False) + "\n")
    write_report(result)
    print(json.dumps({"existing_replies": len(rows), "sentences": len(flat), "new_llm_calls": 0,
                      "control_gate": calibration["gate_passed"], "parameters": params,
                      "holdout_macro_f1": calibration["holdout"]["macro_f1"], "summaries": summaries}, ensure_ascii=False))
    return result


def write_report(result):
    cal = result["calibration"]
    lines = ["# 기존 답변의 문장 단위 주제 추적", "",
             "## 무엇을 했나", "", "기존 48개 첫 답변의 원문과 요청 해시를 검증하고 문장 단위로 분해했다. 새로운 발화는 생성하지 않았다. "
             "사전에 제공한 사건의 고유값 외에 train·pottery·gardening·bicycle 등 사건 단어도 추적했다. "
             "명시적 표식이 없는 문장은 기존 macOS 영어 임베딩 revision 1의 사건 설명 유사도로 분류하되, 짧거나 모호하면 U로 남겼다.", "",
             "## 측정기 점검", "",
             f"작성한 대조 문장은 개발 {cal['development']['items']}조건, 보류 {cal['holdout']['items']}조건이다. "
             "같은 문장을 네 질문 맥락에 교차 사용하므로 독립 표본 수가 아니다. 실제 환자 발화나 전문가 증상 판정이 아니다. "
             f"개발에서 고른 기준은 {cal['parameters']}이며 보류 문장의 macro F1은 {cal['holdout']['macro_f1']:.3f}, "
             f"D 정밀도는 {cal['holdout']['classes']['D']['precision']:.3f}, 알려진 주제 재현율은 {cal['holdout']['known_topic_recall']:.3f}였다. "
             f"미리 고정한 자동 분류 사용 기준은 {'통과' if cal['gate_passed'] else '미통과'}했다.", "",
             "R은 질문한 사건, O는 다른 제공 사건, B는 두 사건의 명시 표식이 한 문장에 함께 나옴, D는 양쪽 사건과 유사도가 낮은 후보, "
             "U는 미확정이다. R/O도 임상 판단이나 문장 전체의 의미적 정답이 아니며, D를 확정된 이탈률로 바꾸지 않는다.", "",
             "## 말투별 결과", ""]
    for s in result["summaries"]:
        lines += [f"- {s['style']}: 16답변 / {s['sentences']}문장 / 평균 {s['mean_words']:.1f}단어. "
                  f"다른 사건 표식 {s['old_other_present']}→{s['literal_other_present']}답변, "
                  f"다른 사건 뒤 질문한 사건 표식 {s['old_other_then_requested']}→{s['literal_other_then_requested']}답변. "
                  f"명시적 복귀 표현 {s['explicit_requested_return_cue']}답변. "
                  f"D 후보 평균 {100*s['mean_distant_candidate_fraction']:.1f}%, U 평균 {100*s['mean_unresolved_fraction']:.1f}%."]
    lines += ["", "## 원문과 문장 경로", ""]
    chosen = ["P-N2-V2-QA-R4-tangent", "P-N1-V2-QB-R5-tangent"]
    for key in chosen:
        r = next(r for r in result["responses"] if r["condition_id"] == key)
        lines += [f"### {key}", "", r["question"], "", f"표식 경로 `{r['literal_sequence']}` / 자동 보조 경로 `{r['semantic_sequence']}`", ""]
        lines += [f"{s['index']}. [{s['literal_label']} / {s['semantic_label']}] {s['text']}" for s in r["sentences"]]
        lines.append("")
    lines += ["## 해석과 다음 결정", "",
              "고유값만 보는 기존 측정과 사건 단어까지 추적한 측정을 같은 원문에 적용해 탐지 범위를 비교했다. "
              "표식의 O→R은 다른 사건을 언급한 뒤 질문한 사건을 다시 명명했다는 관찰이다. ‘back to’ 표현도 별도로 기록해 실제 이탈·복귀와 구분한다. "
              "문장 하나에 두 사건이 섞이거나 대명사로만 이어지는 문장은 강제로 한 주제로 정하지 않았다.", "",
              "대조 문장 기준을 통과한 경우에도 D 비율은 기술적 후보값이다. 기준을 통과하지 못하면 이 비율을 주제 이탈 빈도로 해석하지 않고, "
              "명시 표식 경로와 누락 사례를 다음 측정기 개선의 근거로 사용한다. 모델 개선 실험은 탐지 범위를 고정한 뒤 개발 조건에서 한 지시만 바꾸고 "
              "미사용 사건·표현에서 원형과 비교하는 순서가 적절하다.", "",
              "## 재현", "", "`python3 scripts/analyze_topic_trajectory.py --cached-only`", "",
              "원문·문장 위치·표식 근거·유사도·미확정 표시: `sentences.jsonl`. "
              "대조 문장별 오분류: `controls-scored.json`. 원래 생성 파일은 수정하지 않았다.", ""]
    (OUT / "report.ko.md").write_text("\n".join(lines))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cached-only", action="store_true")
    build(parser.parse_args().cached_only)
