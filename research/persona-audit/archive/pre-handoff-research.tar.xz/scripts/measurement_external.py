"""External general-language validation on the official SummEval release.

No downloads in this script, no training, no new LLM calls or ratings. The raw
official JSONL is obtained separately and hash-locked before feature scoring.
"""
import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import itertools
import json
from pathlib import Path
from statistics import mean
import subprocess
import tempfile
import time
import numpy as np
import measurement_audit as core

ROOT=core.ROOT
SPEC=ROOT/'config/measurement-external-v01.json'
RAW=ROOT/'catalog/summeval-official/model_annotations.aligned.jsonl'
OUT=ROOT/'analysis/measurement-external-v01'
METRICS=('adjacent_cos','all_pairs_cos','adjacency_excess','lexical_adjacent',
         'duplicate_fraction','type_token_ratio','word_count','sentence_count')


def hashes():
    return {str(p.relative_to(ROOT)):core.sha(p) for p in
            (SPEC,RAW,Path(__file__).resolve(),ROOT/'scripts/measurement_audit.py',core.SWIFT)}


def source_records():
    rows=[]
    for i,line in enumerate(RAW.read_text().splitlines()):
        r=json.loads(line)
        ratings=r['expert_annotations']
        assert len(ratings)==3
        assert isinstance(r['decoded'],str) and r['decoded'].strip()
        for annotation in ratings:
            for key in ('coherence','consistency','fluency','relevance'):
                assert isinstance(annotation[key],(int,float)) and 1<=annotation[key]<=5
        rows.append({'row':i,'article_id':r['id'],'model_id':r['model_id'],
                     'text':r['decoded'],'text_id':core.ident(r['decoded']),
                     'expert_coherence':mean(a['coherence'] for a in ratings),
                     'expert_ratings':[a['coherence'] for a in ratings]})
    assert len(rows)==1600
    assert len({(r['article_id'],r['model_id']) for r in rows})==1600
    assert len({r['article_id'] for r in rows})==100
    assert len({r['model_id'] for r in rows})==16
    assert set(Counter(r['article_id'] for r in rows).values())=={16}
    assert set(Counter(r['model_id'] for r in rows).values())=={100}
    return rows


def seal_check():
    seal=core.read(OUT/'seal.json')
    assert seal['source_hashes']==hashes(),'External frozen source changed'
    assert seal['embedding_input_sha256']==core.sha(OUT/'embedding-input.json')
    return seal


def prepare():
    assert RAW.stat().st_size==core.read(SPEC)['expected_size_bytes']
    rows=source_records()
    unique={r['text_id']:r['text'] for r in rows}
    core.immutable(OUT/'embedding-input.json',[{'id':k,'text':unique[k]} for k in sorted(unique)])
    if (OUT/'seal.json').exists():
        seal_check()
    else:
        assert not (OUT/'embedding-output.json').exists()
        core.save(OUT/'seal.json',{'created_utc':datetime.now(timezone.utc).isoformat(),
            'source_hashes':hashes(),'embedding_input_sha256':core.sha(OUT/'embedding-input.json'),
            'schema':{'summary':'decoded','source_article':'id','system':'model_id',
                      'outcome':'mean(expert_annotations[0:3].coherence)'},
            'records':len(rows),'unique_summary_texts':len(unique),'articles':100,'systems':16,
            'scope':'External-followup freeze after authored audit, before local SummEval scores; no metric fitting'})
    print(json.dumps({k:v for k,v in core.read(OUT/'seal.json').items() if k in ('records','unique_summary_texts','articles','systems')}))


def embed():
    seal_check()
    output=OUT/'embedding-output.json'
    if output.exists():
        load_native()
        print('Reused verified external cache')
        return
    start=time.monotonic()
    with tempfile.TemporaryDirectory(prefix='external-measurement-',dir='/private/tmp') as tmp:
        binary=Path(tmp)/'NativeFeatures'
        subprocess.run(['/usr/bin/swiftc','-module-cache-path',str(Path(tmp)/'modules'),str(core.SWIFT),'-o',str(binary)],check=True,capture_output=True)
        subprocess.run([str(binary),str(OUT/'embedding-input.json'),str(output)],check=True)
    core.save(OUT/'embedding-manifest.json',{'input_sha256':core.sha(OUT/'embedding-input.json'),
        'output_sha256':core.sha(output),'wall_seconds':time.monotonic()-start,
        'backend':'OS Apple NaturalLanguage English sentence embedding revision 1, 512D',
        'generations':0,'llm_judges':0,'paid_apis':0,'model_downloads':0})
    load_native()


def load_native():
    seal_check()
    manifest=core.read(OUT/'embedding-manifest.json')
    assert manifest['input_sha256']==core.sha(OUT/'embedding-input.json')
    assert manifest['output_sha256']==core.sha(OUT/'embedding-output.json')
    data=core.read(OUT/'embedding-output.json')
    assert data['embeddingRevision']==1 and data['embeddingDimension']==512
    index={r['id']:r for r in data['records']}
    inputs=core.read(OUT/'embedding-input.json')
    assert len(index)==len(data['records'])==len(inputs)
    assert set(index)=={r['id'] for r in inputs}
    for item in inputs:
        assert item['id']==core.ident(item['text'])
        encoded=item['text'].encode('utf-16-le')
        ends=0
        for s in index[item['id']]['sentences']:
            a,b=2*s['utf16Start'],2*(s['utf16Start']+s['utf16Length'])
            assert a>=ends and encoded[a:b].decode('utf-16-le')==s['text']
            assert not encoded[ends:a].decode('utf-16-le').strip()
            ends=b
        assert not encoded[ends:].decode('utf-16-le').strip()
    return index,{k:v for k,v in data.items() if k!='records'}


def features(sentences):
    texts=[s['text'] for s in sentences]
    tokens=[w for t in texts for w in core.words(t)]
    if not texts or not tokens:
        raise ValueError('Empty text')
    n=len(texts)
    basic={'word_count':len(tokens),'sentence_count':n,
           'duplicate_fraction':1-len({core.normalized(t) for t in texts})/n,
           'type_token_ratio':len(set(tokens))/len(tokens)}
    reason=None
    if n<2:
        reason='fewer_than_two_sentences'
    else:
        try:
            for s in sentences:
                assert s['vector'] is not None and len(s['vector'])==512
                core.cosine(s['vector'],s['vector'])
        except (AssertionError,TypeError,ValueError):
            reason='missing_or_invalid_sentence_vector'
    if reason:
        return {**basic,**{m:None for m in METRICS if m not in basic}},reason
    vs=[s['vector'] for s in sentences]
    adjacent=mean(core.cosine(a,b) for a,b in zip(vs,vs[1:]))
    allpairs=mean(core.cosine(a,b) for a,b in itertools.combinations(vs,2))
    return {**basic,'adjacent_cos':adjacent,'all_pairs_cos':allpairs,
            'adjacency_excess':adjacent-allpairs,
            'lexical_adjacent':mean(core.jaccard(a,b) for a,b in zip(texts,texts[1:]))},None


def ranks(values):
    """One-based average ranks; NumPy only, no new dependency installation."""
    values=np.asarray(values,dtype=float)
    if values.ndim==2:
        return np.column_stack([ranks(values[:,j]) for j in range(values.shape[1])])
    if values.ndim!=1 or not np.isfinite(values).all():
        raise ValueError('Finite vector or matrix required for ranking')
    _,inverse,counts=np.unique(values,return_inverse=True,return_counts=True)
    average=np.cumsum(counts)-(counts-1)/2
    return average[inverse]


def column_correlations(x,y):
    """Spearman via average ties; constant predictors stay undefined, not zero."""
    rx=ranks(np.asarray(x,dtype=float))
    ry=ranks(np.asarray(y,dtype=float))
    rx=rx-rx.mean(axis=0)
    ry=ry-ry.mean()
    denominator=np.sqrt((rx*rx).sum(axis=0)*(ry*ry).sum())
    return np.divide((rx*ry[:,None]).sum(axis=0),denominator,
                     out=np.full(rx.shape[1],np.nan),where=denominator>0)


def number(value):
    return float(value) if np.isfinite(value) else None


def summarize_eligible(rows,repetitions=2000,seed=20261102):
    x=np.array([[r['metrics'][m] for m in METRICS] for r in rows])
    y=np.array([r['expert_coherence'] for r in rows])
    groups={key:np.array([i for i,r in enumerate(rows) if r['article_id']==key])
            for key in sorted({r['article_id'] for r in rows})}
    group_list=list(groups.values())
    pooled=column_correlations(x,y)
    within={key:column_correlations(x[idx],y[idx]) for key,idx in groups.items()}
    systems=sorted({r['model_id'] for r in rows})
    system_x=[];system_y=[];system_means=[]
    for sid in systems:
        g=[r for r in rows if r['model_id']==sid]
        mx=[mean(r['metrics'][m] for r in g) for m in METRICS]
        my=mean(r['expert_coherence'] for r in g)
        system_x.append(mx);system_y.append(my)
        system_means.append({'model_id':sid,'n':len(g),'expert_coherence':my,
                             'metrics':dict(zip(METRICS,mx))})
    system_rho=column_correlations(system_x,system_y)
    rng=np.random.default_rng(seed)
    bootstrap=[]
    for _ in range(repetitions):
        idx=np.concatenate([group_list[i] for i in rng.integers(0,len(group_list),size=len(group_list))])
        bootstrap.append(column_correlations(x[idx],y[idx]))
    boot=np.asarray(bootstrap)
    result={}
    for j,m in enumerate(METRICS):
        valid=boot[:,j][np.isfinite(boot[:,j])]
        wi=[v[j] for v in within.values() if np.isfinite(v[j])]
        result[m]={'summary_spearman':number(pooled[j]),
                   'article_cluster_ci95':[float(v) for v in np.quantile(valid,[.025,.975])] if len(valid) else None,
                   'bootstrap_valid':len(valid),'within_article_mean_spearman':float(np.mean(wi)) if wi else None,
                   'within_article_valid':len(wi),'within_article_total':len(groups),
                   'system_mean_spearman':number(system_rho[j]),'systems':len(systems)}
    return result,system_means


def score():
    seal=seal_check()
    native,backend=load_native()
    rows=[];excluded=[]
    for r in source_records():
        measurements,reason=features(native[r['text_id']]['sentences'])
        row={k:v for k,v in r.items() if k!='text'}
        row.update(metrics=measurements,exclusion=reason)
        rows.append(row)
        if reason: excluded.append(row)
    eligible=[r for r in rows if r['exclusion'] is None]
    spec=core.read(SPEC)
    correlations,system_means=summarize_eligible(eligible)
    sensitivity={}
    for m in ('duplicate_fraction','type_token_ratio','word_count','sentence_count'):
        sensitivity[m]=number(column_correlations([[r['metrics'][m]] for r in rows],
                                                  [r['expert_coherence'] for r in rows])[0])
    result={'study_id':spec['study_id'],'source_records':len(rows),'eligible_records':len(eligible),
            'articles':len({r['article_id'] for r in eligible}),'systems':len(system_means),
            'unique_summary_texts':seal['unique_summary_texts'],
            'exclusions':dict(Counter(r['exclusion'] for r in excluded)),
            'expert_coherence_mean_all':mean(r['expert_coherence'] for r in rows),
            'expert_coherence_mean_eligible':mean(r['expert_coherence'] for r in eligible),
            'expert_coherence_mean_excluded':mean(r['expert_coherence'] for r in excluded) if excluded else None,
            'correlations':correlations,'all_record_lexical_length_sensitivity':sensitivity,
            'common_set_sentence_count_distribution':dict(sorted(Counter(r['metrics']['sentence_count'] for r in eligible).items())),
            'embedding_backend':backend,'source_hashes':hashes(),
            'embedding_output_sha256':core.sha(OUT/'embedding-output.json'),
            'cost':spec['budget'],
            'scope':'External summarization expert ratings, not psychiatric validation; article-cluster uncertainty conditional on released systems'}
    core.immutable(OUT/'measurements.json',rows)
    core.immutable(OUT/'excluded-records.json',excluded)
    core.immutable(OUT/'system-means.json',system_means)
    core.immutable(OUT/'results.json',result)
    print(json.dumps({k:v for k,v in result.items() if k in ('source_records','eligible_records','articles','systems','exclusions','correlations')},ensure_ascii=False))


def verify():
    seal_check();load_native()
    r=core.read(OUT/'results.json')
    rows=core.read(OUT/'measurements.json')
    assert r['source_hashes']==hashes()
    assert r['embedding_output_sha256']==core.sha(OUT/'embedding-output.json')
    assert len(rows)==1600
    eligible=[x for x in rows if x['exclusion'] is None]
    pooled=column_correlations([[x['metrics'][m] for m in METRICS] for x in eligible],
                              [x['expert_coherence'] for x in eligible])
    for j,m in enumerate(METRICS):
        expected=r['correlations'][m]['summary_spearman']
        assert expected is None and not np.isfinite(pooled[j]) or expected is not None and abs(expected-pooled[j])<1e-12
    core.save(OUT/'verification.json',{'status':'passed','raw_records':1600,
        'raw_source_and_embedding_hashes_verified':True,'utf16_sentence_spans_verified':True,
        'document_system_pairs_unique':True,'expert_ratings_per_record':3,
        'eligible_records':len(eligible),'article_cluster_not_summary_resampling':True,
        'no_training_or_judging':True,'clinical_validation':False})
    print(json.dumps(core.read(OUT/'verification.json')))


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('action',choices=('prepare','embed','score','verify'))
    globals()[p.parse_args().action]()
