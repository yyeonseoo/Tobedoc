"""Read verified research snapshots without executing upstream code."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def source_records() -> dict:
    lock = json.loads((ROOT / "evidence/source-lock.json").read_text())
    return {item["id"]: item for item in lock["sources"]}


def read_source(source_id: str) -> str:
    record = source_records()[source_id]
    if record.get("status") != "ok":
        raise ValueError(f"Source unavailable: {source_id}")
    raw = (ROOT / record["local_raw"]).read_bytes()
    if digest(raw) != record["sha256"]:
        raise ValueError(f"Source hash mismatch: {source_id}")
    path = ROOT / record["local_text"]
    text_bytes = path.read_bytes()
    if digest(text_bytes) != record["text_sha256"]:
        raise ValueError(f"Extracted text hash mismatch: {source_id}")
    return text_bytes.decode("utf-8")


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
