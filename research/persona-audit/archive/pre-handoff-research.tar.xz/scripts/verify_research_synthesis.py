"""Check the evidence ledger and handoff without rerunning old experiments."""
from pathlib import Path
import json
from common import ROOT, digest, write_json


def read(path):
    return json.loads(path.read_text())


def main():
    out = ROOT / 'analysis/research-synthesis-v01'
    ledger = read(out / 'evidence-ledger.json')
    for path, expected in ledger['source_hashes'].items():
        assert digest((ROOT / path).read_bytes()) == expected, path
    deck = ledger['team_reported_not_recomputed']
    assert digest(Path(deck['source']).read_bytes()) == deck['source_sha256']
    assert ledger['local_persona_instruction_audit']['response_records_in_four_main_tasks_including_followup'] == 240
    assert ledger['external_measurement']['eligible'] == 1542
    assert ledger['psyche_thought_development']['holdout_responses'] == 0
    assert ledger['cost_this_synthesis']['new_generation'] == 0
    checkpoint = read(ROOT / 'config/research-checkpoint-v11.json')
    roadmap = read(ROOT / checkpoint['roadmap'])
    assert len(roadmap['sequence']) == 6
    assert checkpoint['expert_access_is_not_gate_for_all_synthetic_analyses']
    assert not checkpoint['old_paused_experiments_automatically_resumed']
    for field in ('report', 'handoff', 'evidence'):
        assert (ROOT / checkpoint[field]).is_file()
    report = (ROOT / checkpoint['report']).read_text()
    assert '240개 응답 기록' in report
    assert '미생성 검증 요청 32개' in report
    assert 'PPT만 근거' in report
    assert '0.0317' in report
    assert 'https://learn.chatgpt.com/docs/model-selection' in report
    artifacts = [ROOT / checkpoint[k] for k in ('report', 'handoff', 'evidence', 'roadmap')]
    artifacts.append(ROOT / 'config/research-checkpoint-v11.json')
    result = {'passed': True, 'source_result_files_checked': len(ledger['source_hashes']),
              'presentation_hash_checked': True, 'team_raw_results_recomputed': False,
              'new_generation': 0, 'artifacts': {str(p.relative_to(ROOT)): digest(p.read_bytes()) for p in artifacts},
              'verifier_sha256': digest(Path(__file__).read_bytes())}
    write_json(out / 'delivery-verification.json', result)
    print(json.dumps({k: result[k] for k in ('passed', 'source_result_files_checked', 'presentation_hash_checked', 'team_raw_results_recomputed', 'new_generation')}))


if __name__ == '__main__':
    main()
