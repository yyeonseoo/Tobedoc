"""Matched-turn descriptive comparisons of extracted style modules, no ratings."""
import csv
import json
from pathlib import Path

from common import ROOT, digest, write_json
from extract_automatic_features import load_verified, mean, measure
from run_framework_pilot import RUN

PROGRAMS=["simple_baseline","patient_psi_style","patientsim_style"]
OUT=ROOT/"analysis/framework-pilot-v01"/RUN


def paired_contrast(rows,program,feature,first_turn=False):
    index={(r["profile_id"],r["style_id"],r["turn"]):r for r in rows if r["arm"]==program}
    cases=[]
    for case in sorted({key[0] for key in index}):
        values=[]
        for turn in ([1] if first_turn else [1,2,3,4]):
            a,b=index[(case,"plain",turn)]["features"][feature],index[(case,"verbose",turn)]["features"][feature]
            if a is not None and b is not None:
                values.append({"turn":turn,"plain":a,"verbose":b,"difference":b-a})
        if values:
            cases.append({"case_id":case,"eligible_turn_pairs":len(values),
                "plain":mean([r["plain"] for r in values]),"verbose":mean([r["verbose"] for r in values]),
                "difference":mean([r["difference"] for r in values]),"turns":values})
    return {"eligible_cases":len(cases),"eligible_turn_pairs":sum(c["eligible_turn_pairs"] for c in cases),
            "plain_mean":mean([c["plain"] for c in cases]),"verbose_mean":mean([c["verbose"] for c in cases]),
            "verbose_minus_plain":mean([c["difference"] for c in cases]),
            "positive_cases":sum(c["difference"]>0 for c in cases),"negative_cases":sum(c["difference"]<0 for c in cases),"cases":cases}


def between_programs(rows,program,feature):
    index={(r["profile_id"],r["arm"],r["style_id"],r["turn"]):r for r in rows}
    cases=[]
    for case in sorted({r["profile_id"] for r in rows}):
        turns=[]
        for turn in [1,2,3,4]:
            keys=[(case,p,s,turn) for p in [program,"simple_baseline"] for s in ["plain","verbose"]]
            if any(k not in index for k in keys):
                continue
            values=[index[k]["features"][feature] for k in keys]
            if all(v is not None for v in values):
                a,b,c,d=values
                turns.append({"turn":turn,"difference":(b-a)-(d-c)})
        if turns:
            cases.append({"case_id":case,"difference":mean([t["difference"] for t in turns]),"turns":turns})
    return {"eligible_cases":len(cases),"eligible_turn_sets":sum(len(c["turns"]) for c in cases),
            "difference_of_style_contrasts":mean([c["difference"] for c in cases]),"cases":cases,
            "note":"Same case/question and all four cells available; selected common-valid subset, not length-adjusted or clinical"}


def n(value,digits=3):
    return "NA" if value is None else f"{value:+.{digits}f}"


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    runfolder=ROOT/"pilot/runs"/RUN
    config,cases,raw,sources=load_verified(runfolder)
    if len(cases)!=18 or len(raw)!=72 or any(r["status"]!="completed" for r in raw):
        raise ValueError("Completed analysis requires all 72 actual replies")
    if any(c["split"]!="development" or c["repeat_index"]!=0 for c in cases):
        raise ValueError("Heldout/repeat expansion not authorized by this pilot")
    planpath=ROOT/"config/framework-comparison-v01.json"
    plan=json.loads(planpath.read_text())
    if digest(planpath.read_bytes())!=config["plan_sha256"]:
        raise ValueError("Frozen comparison plan changed")
    if [{k:c[k] for k in ["condition_id","prompt_sha256"]} for c in cases]!=config["conditions"]:
        raise ValueError("Saved execution conditions differ from run configuration")
    original=ROOT/"analysis/automatic-features-v01"/RUN
    nativepath=original/"native-output.json"
    native=json.loads(nativepath.read_text())
    if digest(nativepath.read_bytes())!=json.loads((original/"native-cache-key.json").read_text())["output_sha256"]:
        raise ValueError("Embedding cache mismatch")
    nlp={r["id"]:r for r in native["records"]}
    rows=[json.loads(line) for line in (original/"features.jsonl").read_text().splitlines()]
    indexed={(r["condition_id"],r["turn"]):r for r in rows}
    previous={}
    for r in raw:
        recomputed,_,center=measure(r,nlp,previous.get(r["condition_id"]))
        saved=indexed[(r["condition_id"],r["turn"])]
        if recomputed["features"]!=saved["features"] or recomputed["response_sha256"]!=saved["response_sha256"]:
            raise ValueError("Feature values do not reproduce from verified responses/cache")
        previous[r["condition_id"]]=center
    features=plan["primary_descriptive_features"]+plan["exploratory_features"]
    contrasts={p:{f:paired_contrast(rows,p,f) for f in features} for p in PROGRAMS}
    first={p:{f:paired_contrast(rows,p,f,True) for f in features} for p in PROGRAMS}
    gates=[]
    for p in PROGRAMS:
        for style in ["plain","verbose"]:
            subset=[r for r in rows if r["arm"]==p and r["style_id"]==style]
            gates.append({"program":p,"style":style,"replies":len(subset),
                "sentence_cap_flags_OS":sum(r["features"]["sentence_count"]>5 for r in subset),
                "sentence_cap_flags_regex":sum(r["sentence_count_regex_v2"]>5 for r in subset),
                "exactly_at_cap_OS":sum(r["features"]["sentence_count"]==5 for r in subset),
                "eligible_feature_replies":{f:sum(r["features"][f] is not None for r in subset) for f in features}})
    rawindex={(r["profile_id"],r["arm"],r["style_id"],r["turn"]):r for r in raw}
    identities=[]
    for case in sorted({r["profile_id"] for r in rows}):
        for turn in [1,2,3,4]:
            a,b=rawindex[(case,"simple_baseline","plain",turn)],rawindex[(case,"patient_psi_style","plain",turn)]
            identities.append({"case_id":case,"turn":turn,"request_equal":a["request_sha256"]==b["request_sha256"],
                               "response_equal":a["response_text"]==b["response_text"]})
    result={"run_id":RUN,"scope":config["scope"],"plan_sha256":config["plan_sha256"],
        "actual_dialogues":18,"actual_replies":72,"fictional_case_families":3,"real_patient_participants":0,
        "repeat_indices":[0],"heldout_replies":0,"clinical_ratings":0,"paid_api_calls":0,
        "unique_reply_strings":len({r["response_text"] for r in raw}),
        "dialogue_mean_matched_contrasts":contrasts,"first_turn_matched_contrasts":first,
        "program_vs_baseline_contrasts":{p:{f:between_programs(rows,p,f) for f in features} for p in PROGRAMS[1:]},
        "feasibility":gates,"identical_plain_control_checks":identities,
        "generation_wall_minutes_sum":sum(r["wall_seconds"] for r in raw)/60,
        "maximum_input_tokens":max(r["usage"].get("prompt_eval_count") or 0 for r in raw),
        "all_feature_cells_recomputed":len(rows)*17,"feature_ids":features,
        "total_exactly_at_sentence_cap":sum(g["exactly_at_cap_OS"] for g in gates),
        "total_sentence_cap_flags":sum(g["sentence_cap_flags_OS"] for g in gates),
        "expansion_decision":"Hold automatic expansion: sentence-count ceiling and cap violations need a development-only sensitivity check before heldout generation",
        "warning":"Three invented development cases, one seed per condition, Qwen prompt-module ports. No native-framework ranking, clinical validity, or patient-population inference."}
    write_json(OUT/"results.json",result)
    with (OUT/"paired-effects.csv").open("w",encoding="utf-8",newline="") as file:
        writer=csv.DictWriter(file,fieldnames=["endpoint","program","feature","cases","turn_pairs","plain_mean","verbose_mean","verbose_minus_plain","positive_cases","negative_cases"])
        writer.writeheader()
        for endpoint,data in [("dialogue_matched_turns",contrasts),("T1",first)]:
            for p,values in data.items():
                for f,c in values.items():
                    writer.writerow({"endpoint":endpoint,"program":p,"feature":f,"cases":c["eligible_cases"],"turn_pairs":c["eligible_turn_pairs"],
                        **{k:c[k] for k in ["plain_mean","verbose_mean","verbose_minus_plain","positive_cases","negative_cases"]}})
    with (OUT/"features-flat.csv").open("w",encoding="utf-8",newline="") as file:
        keys=["condition_id","profile_id","arm","style_id","turn"]
        writer=csv.DictWriter(file,fieldnames=keys+features);writer.writeheader()
        for row in rows:
            writer.writerow({**{k:row[k] for k in keys},**row["features"]})
    with (OUT/"features-flat.csv").open(encoding="utf-8",newline="") as file:
        exported=list(csv.DictReader(file))
    if len(exported)!=len(rows):
        raise ValueError("CSV row-count mismatch")
    for row,flat in zip(rows,exported):
        if row["condition_id"]!=flat["condition_id"] or row["turn"]!=int(flat["turn"]):
            raise ValueError("CSV row identity mismatch")
        for f in features:
            v=row["features"][f]
            if (v is None and flat[f]!="") or (v is not None and float(flat[f])!=v):
                raise ValueError("CSV numeric-cell mismatch")
    text=["# All actual English pilot replies","","Controlled extracted style modules, not native framework outputs.",""]
    for r in raw:
        text += [f"## {r['condition_id']} · T{r['turn']}","","Interviewer: "+r["interviewer_text"],"","Participant: "+r["response_text"],""]
    (OUT/"transcripts.en.md").write_text("\n".join(text),encoding="utf-8")
    base=contrasts["simple_baseline"]["word_count"]
    sim=contrasts["patientsim_style"]["word_count"]
    lines=["# 교차 소스 말투 지시 모듈: 개발 파일럿 결과","",
        "상태: 실제 18대화·72응답 완료. 허구 인물 3명, 조건당 seed 1개. 평가 사례는 생성하지 않음.","",
        "전체 PATIENT-Ψ/PatientSim 시스템이 아니라, 공통 wrapper 위에 추출한 말투 지시를 비교했다. PatientSim의 응급실·언어능력·회상·혼란 모듈은 포함하지 않았다. 임상 점수나 전체 품질 순위는 만들지 않는다.","",
        "## 핵심 결과와 확대 판단","",
        "세 지시 프로그램 모두 세 개발 사례에서 verbose의 단어 수가 plain보다 많았다. 그러나 증가량만으로 지시 프로그램의 우열을 정할 수는 없다.","",
        f"- 단순 지시: {base['plain_mean']:.1f} → {base['verbose_mean']:.1f}단어 (차이 {n(base['verbose_minus_plain'],1)}).",
        f"- PATIENT-Ψ 말투: {contrasts['patient_psi_style']['word_count']['plain_mean']:.1f} → {contrasts['patient_psi_style']['word_count']['verbose_mean']:.1f}단어 (차이 {n(contrasts['patient_psi_style']['word_count']['verbose_minus_plain'],1)}).",
        f"- PatientSim 말투: {sim['plain_mean']:.1f} → {sim['verbose_mean']:.1f}단어 (차이 {n(sim['verbose_minus_plain'],1)}).","",
        f"PatientSim의 더 큰 증가량은 단순 지시 대비 verbose 자체가 {n(sim['verbose_mean']-base['verbose_mean'],1)}단어인 동시에 plain이 {n(sim['plain_mean']-base['plain_mean'],1)}단어인 데서 나왔다. "
        "동일한 plain 명칭도 소스별 행동 지시가 같지 않다. 특히 PatientSim/plain은 간결하고 직접적으로 답하도록 명시하는 반면 다른 두 plain 모듈은 빈 문자열이다. 이 결과를 더 우수한 임상 모사라고 해석하지 않는다.","",
        f"PatientSim 말투에서는 인접 문장 유사도가 {n(contrasts['patientsim_style']['adjacent_cos_mean']['verbose_minus_plain'])} 증가했지만, 질문 유사도는 {n(contrasts['patientsim_style']['question_answer_cos']['verbose_minus_plain'])}, 초기 상황 유사도는 {n(contrasts['patientsim_style']['topic_answer_cos']['verbose_minus_plain'])} 변했다. "
        "세 지표 모두 각 사례에서 같은 방향이었다. 즉 인접 문장끼리 더 비슷해지는 것과 질문/초기 상황에 더 가까워지는 것은 다르게 나타났다. 이것은 관련성이나 임상 coherence의 참값 판정이 아니다.","",
        f"**설계 게이트: 자동 확대 보류.** 정확히 5문장인 응답은 {result['total_exactly_at_sentence_cap']}/72개, 5문장 초과는 {result['total_sentence_cap_flags']}/72개였다. "
        "이번 자료에는 5문장 미만이 없었고 문장 수가 공통 상한 부근에 집중됐다. 발화량 차이는 문장 수가 거의 고정된 조건에서 관찰한 결과다. "
        "따라서 이 결과를 보존하고 개발 자료에서 문장 수 제한 유무/수준의 영향을 먼저 점검한다. 지금 288응답으로 늘리거나 평가 인물을 생성하는 것은 적절하지 않다. "
        "이 게이트 판단은 파일럿 관찰에 근거한 다음 설계 결정이지 사전등록된 통계 검정이 아니다.","",
        "![말투 모듈별 feature 프로파일](feature-profiles.png)","",
        "막대와 점은 개별 말투의 기술적 평균이며, 아래 대응 차이는 같은 턴의 공동 계산 가능 집합을 사용한다.","",
        "## 주 기술량: verbose−plain 변화","",
        "같은 인물·프로그램·질문에서 두 말투 모두 계산 가능한 턴만 비교하고, 차이를 인물 안에서 평균한 뒤 인물별 값을 동일 가중했다. 서로 다른 질문을 결측 때문에 섞지 않으며 결측은 0이 아니다. 아래 괄호는 계산 가능한 인물/3명·턴 쌍/12개다.",""]
    for p in PROGRAMS:
        lines += [f"### {p}",""]
        quantity=contrasts[p]["word_count"]
        lines.append(f"응답당 평균 단어 수: plain {quantity['plain_mean']:.1f} → verbose {quantity['verbose_mean']:.1f}. 아래 변화량만으로 절대 발화량이나 품질 순위를 해석하지 않는다.")
        lines.append("")
        for f in plan["primary_descriptive_features"]:
            c=contrasts[p][f]
            lines.append(f"- {f}: {n(c['verbose_minus_plain'])} ({c['eligible_cases']}/3명·{c['eligible_turn_pairs']}/12쌍).")
        lines.append("")
    lines += ["## 실행 가능성과 측정 제한",""]
    for g in gates:
        lines.append(f"- {g['program']}/{g['style']}: 5문장 초과 플래그 OS {g['sentence_cap_flags_OS']}/12, 정규식 {g['sentence_cap_flags_regex']}/12; 인접 유사도 계산 가능 {g['eligible_feature_replies']['adjacent_cos_mean']}/12.")
    lines += ["","문장 수 플래그는 자동 분절 규칙에 따른 제약 점검이며 임상 판정이 아니다. 프로그램 사이의 차이의 차이는 같은 인물·질문에서 네 셀이 모두 계산 가능한 부분집합으로 별도 산출했다. 이 조건부 부분집합은 전체 응답과 다르며 길이 보정을 한 결과도 아니다.","",
        f"simple baseline/plain과 PATIENT-Ψ/plain은 원래 지시 문자열이 같도록 설계되었다. 같은 요청 {sum(c['request_equal'] for c in identities)}/12, 같은 응답 {sum(c['response_equal'] for c in identities)}/12였다. 이 셀들을 독립적인 모델 또는 표본으로 간주하지 않는다. 전체 고유 응답 문자열은 {result['unique_reply_strings']}/72개였다.","",
        "## 해석과 다음 판단","",
        "발화량 증가가 나타나더라도 이미 지시한 목표에 대한 반응이지 임상적 모사의 증거가 아니다. 질문 관련성·문장 유사도·어휘 다양도가 같이 변하는지를 별도 기술한다. 첫 턴 결과는 paired-effects.csv에 따로 보존한다. 후속 턴은 각 말투의 실제 생성 이력을 포함하므로 질문 종류/턴 위치/이력 효과를 분리할 수 없다.","",
        "이번 파일럿은 소수 개발 사례와 한 seed의 측정 가능성 점검이다. 평가셋 자동 실행·288응답 확장·프롬프트 수정은 하지 않았다. 제약 초과·결측·길이 차이를 검토한 뒤 확장 여부를 결정해야 하며, 유리한 조건만 남겨 성공을 주장하지 않는다.","",
        f"생성 요청 시간 합계 {result['generation_wall_minutes_sum']:.2f}분, 최대 입력 {result['maximum_input_tokens']}토큰. 추가 유료 API·모델 다운로드·LLM judge·임상 채점 0회. 원문·실제 대화 이력·기존 17개 feature의 {len(rows)*17}셀을 캐시에서 재검산했다.","",
        "[전체 결과](results.json) · [대응 차이 CSV](paired-effects.csv) · [응답별 feature CSV](features-flat.csv) · [영어 원문](transcripts.en.md)","",
        "재계산: `python3 scripts/extract_automatic_features.py --run-id framework-pilot-20261030` 다음 `python3 scripts/analyze_framework_pilot.py`. 캐시가 있으면 새 추론·인터넷 없이 계산한다.",""]
    (OUT/"report.ko.md").write_text("\n".join(lines),encoding="utf-8")
    write_json(OUT/"provenance.json",{"plan_sha256":config["plan_sha256"],"request_response_files":sources,
        "native_output_sha256":digest(nativepath.read_bytes()),"analysis_script_sha256":digest(Path(__file__).read_bytes()),
        "verified_history_replies":72,"verified_feature_cells":72*17})
    # Correct a legacy progress-helper assumption (one fictional person) using
    # actual current cases; no response or request is edited.
    progress=json.loads((runfolder/"progress.json").read_text())
    progress.pop("independent_people",None)
    progress.update(fictional_case_families=3,real_patient_participants=0)
    write_json(runfolder/"progress.json",progress)
    print(json.dumps({"output":str(OUT),"word_count_changes":{p:contrasts[p]["word_count"]["verbose_minus_plain"] for p in PROGRAMS},
        "matched_adjacent_turns":{p:contrasts[p]["adjacent_cos_mean"]["eligible_turn_pairs"] for p in PROGRAMS}},ensure_ascii=False))


if __name__=="__main__":
    main()
