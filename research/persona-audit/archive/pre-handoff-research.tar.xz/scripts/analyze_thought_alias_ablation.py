"""Numeric input-delivery experiment analysis; never score mental states."""
import argparse
from collections import defaultdict
import csv
import json
from pathlib import Path
import subprocess
import tempfile

from common import ROOT, digest, write_json
from extract_automatic_features import centroid, cosine, load_verified, mean, measure, text_id, words

RUN = "thought-alias-20261030"
NATIVE = "native_demo_mapping"
ALIAS = "automatic_thought_alias_only"
STYLES = ["plain", "tangent"]


def contains_token_sequence(text, target):
    tokens, wanted = words(text), words(target)
    if not wanted:
        return None
    return float(any(tokens[i:i+len(wanted)] == wanted for i in range(len(tokens)-len(wanted)+1)))


def effect(values):
    valid = [r for r in values if r["native"] is not None and r["alias"] is not None]
    diffs = [r["alias"]-r["native"] for r in valid]
    return {"eligible_pairs": len(valid), "native_mean": mean([r["native"] for r in valid]),
            "alias_mean": mean([r["alias"] for r in valid]), "alias_minus_native": mean(diffs),
            "positive_pairs": sum(v > 1e-12 for v in diffs), "negative_pairs": sum(v < -1e-12 for v in diffs),
            "zero_pairs": sum(abs(v) <= 1e-12 for v in diffs),
            "min_difference": min(diffs) if diffs else None, "max_difference": max(diffs) if diffs else None,
            "pairs": [{**r, "difference": r["alias"]-r["native"]} for r in valid]}


def summarize(rows, feature_ids, first_turn=False):
    grouped = defaultdict(list)
    for row in rows:
        if not first_turn or row["turn"] == 1:
            grouped[(row["style_id"], row["profile_id"], row["repeat_index"], row["arm"])].append(row)
    means = {key: {f: mean([r["features"][f] for r in group]) for f in feature_ids} for key, group in grouped.items()}
    results = {}
    for style in STYLES:
        results[style] = {}
        keys = sorted({(profile, repeat) for s, profile, repeat, arm in grouped if s == style})
        for feature in feature_ids:
            values = []
            for profile, repeat in keys:
                a, b = (style, profile, repeat, NATIVE), (style, profile, repeat, ALIAS)
                if a not in means or b not in means:
                    raise ValueError("Missing matched arm; no historical substitution")
                values.append({"profile_id": profile, "repeat_index": repeat, "native": means[a][feature], "alias": means[b][feature]})
            results[style][feature] = effect(values)
    return results, means


def target_vectors(folder, thoughts, cached_only):
    inputs = [{"id": key, "text": value} for key, value in sorted(thoughts.items())]
    source = ROOT/"scripts/NativeFeatures.swift"
    key = digest(json.dumps({"inputs": inputs, "swift_sha256": digest(source.read_bytes())}, sort_keys=True).encode())
    output, cachefile = folder/"target-native-output.json", folder/"target-cache.json"
    if output.exists() and cachefile.exists():
        cache = json.loads(cachefile.read_text())
        if cache["key"] != key or digest(output.read_bytes()) != cache["sha256"]:
            raise ValueError("Target vector cache mismatch; no silent overwrite")
    else:
        if cached_only:
            raise ValueError("Missing frozen target embedding cache")
        write_json(folder/"target-native-input.json", inputs)
        with tempfile.TemporaryDirectory(prefix="persona-thought-embedding-") as tmp:
            binary = str(Path(tmp)/"embed")
            subprocess.run(["/usr/bin/swiftc", "-module-cache-path", str(Path(tmp)/"modules"), str(source), "-o", binary],
                           check=True, capture_output=True)
            subprocess.run([binary, str(folder/"target-native-input.json"), str(output)], check=True, capture_output=True)
        write_json(cachefile, {"key": key, "sha256": digest(output.read_bytes()), "thoughts": thoughts})
    native = json.loads(output.read_text())
    if native["embeddingRevision"] != 1 or native["embeddingDimension"] != 512:
        raise ValueError("Unexpected embedding backend")
    return {r["id"]: r["vector"] for r in native["records"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cached-only", action="store_true")
    args = parser.parse_args()
    folder = ROOT/"analysis/thought-alias-v01"/RUN
    folder.mkdir(parents=True, exist_ok=True)
    original = ROOT/"analysis/automatic-features-v01"/RUN
    config, cases, raw, sourcefiles = load_verified(ROOT/"pilot/runs"/RUN)
    if len(cases) != 24 or len(raw) != 96 or any(r["status"] != "completed" for r in raw):
        raise ValueError("Do not present incomplete generation as completed research")
    plan = ROOT/"config/thought-alias-ablation-v01.json"
    if config["plan_sha256"] != digest(plan.read_bytes()):
        raise ValueError("Analysis specification changed after execution")
    rows = [json.loads(line) for line in (original/"features.jsonl").read_text().splitlines()]
    base_feature_ids = [f["id"] for f in json.loads((ROOT/"config/automatic-features-v01.json").read_text())["features"]]
    if len(rows) != 96:
        raise ValueError("Missing extracted rows")
    native_path = original/"native-output.json"
    cache = json.loads((original/"native-cache-key.json").read_text())
    if cache["output_sha256"] != digest(native_path.read_bytes()):
        raise ValueError("Native feature cache integrity mismatch")
    native = {r["id"]: r for r in json.loads(native_path.read_text())["records"]}
    case_index = {c["condition_id"]: c for c in cases}
    row_index = {(r["condition_id"], r["turn"]): r for r in rows}
    previous = {}
    for r in raw:
        computed, _, center = measure(r, native, previous.get(r["condition_id"]))
        saved = row_index[(r["condition_id"], r["turn"])]
        if computed["features"] != saved["features"] or computed["response_sha256"] != saved["response_sha256"]:
            raise ValueError("Baseline feature matrix does not reproduce")
        previous[r["condition_id"]] = center
    thoughts = {c["profile_id"]: c["profile"]["auto_thought"] for c in cases}
    targets = target_vectors(folder, thoughts, args.cached_only)
    if set(targets) != set(config["plan"]["situations"]) or any(v is None for v in targets.values()):
        raise ValueError("Missing required thought-target embedding")
    for r in raw:
        row = row_index[(r["condition_id"], r["turn"])]
        center = centroid([s.get("vector") for s in native[text_id(r["response_text"])]["sentences"]])
        matched = cosine(center, targets[r["profile_id"]])
        other = mean([cosine(center, v) for k, v in targets.items() if k != r["profile_id"]])
        row["features"].update(provided_thought_cos=matched,
            thought_cos_specificity=matched-other if matched is not None and other is not None else None,
            exact_thought_token_sequence=contains_token_sequence(r["response_text"], thoughts[r["profile_id"]]))
    feature_ids = base_feature_ids+["provided_thought_cos", "thought_cos_specificity", "exact_thought_token_sequence"]
    first, _ = summarize(rows, feature_ids, True)
    whole, means = summarize(rows, feature_ids)
    if any(first[style]["provided_thought_cos"]["eligible_pairs"] != 6 for style in STYLES):
        raise ValueError("Primary endpoint requires six complete paired blocks per style")
    style_effects, interactions = {}, {}
    for feature in feature_ids:
        style_effects[feature] = {}
        for arm in [NATIVE, ALIAS]:
            differences = []
            for profile in sorted(thoughts):
                for repeat in [0, 1]:
                    a, b = means[("tangent", profile, repeat, arm)][feature], means[("plain", profile, repeat, arm)][feature]
                    if a is not None and b is not None:
                        differences.append({"profile_id": profile, "repeat_index": repeat, "difference": a-b})
            style_effects[feature][arm] = {"tangent_minus_plain": mean([r["difference"] for r in differences]), "blocks": differences}
        a = {(r["profile_id"], r["repeat_index"]): r["difference"] for r in style_effects[feature][ALIAS]["blocks"]}
        b = {(r["profile_id"], r["repeat_index"]): r["difference"] for r in style_effects[feature][NATIVE]["blocks"]}
        interactions[feature] = {"difference_in_style_contrasts": mean([a[k]-b[k] for k in a.keys() & b.keys()]),
                                "note": "Within-example factorial contrast; not clinical improvement"}
    historical = ROOT/"pilot/runs/native-features-20261030"
    _, _, prior, _ = load_verified(historical)
    prior_index = {(r["profile_id"], r["style_id"], r["repeat_index"], r["turn"]): r for r in prior}
    replay = []
    for r in raw:
        if r["arm"] == NATIVE:
            key = (r["profile_id"], r["style_id"], r["repeat_index"], r["turn"])
            old = prior_index[key]
            replay.append({"condition_id": r["condition_id"], "turn": r["turn"],
                           "request_identical": old["request_sha256"] == r["request_sha256"],
                           "response_identical": old["response_text"] == r["response_text"]})
    original_pairs = {"native": 0, "alias": 0}
    for a, b in zip(cases[::2], cases[1::2]):
        if (a["profile_id"], a["style_id"], a["repeat_index"]) != (b["profile_id"], b["style_id"], b["repeat_index"]):
            raise ValueError("Paired execution ordering changed")
        native_case = a if a["arm"] == NATIVE else b
        alias_case = b if native_case is a else a
        expected = native_case["system_prompt"].replace("Automatic Thoughts: undefined", "Automatic Thoughts: "+native_case["profile"]["auto_thought"])
        if expected != alias_case["system_prompt"] or alias_case["interview"] != native_case["interview"]:
            raise ValueError("Ablation changed an unintended prompt field")
        original_pairs["native" if a["arm"] == NATIVE else "alias"] += 1
    literal_counts = {s: {a: sum(r["features"]["exact_thought_token_sequence"] for r in rows if r["style_id"] == s and r["arm"] == a)
                         for a in [NATIVE, ALIAS]} for s in STYLES}
    result = {"run_id": RUN, "plan": config["plan"], "plan_sha256": config["plan_sha256"],
              "source_commit": cases[0]["source_commit"], "model_digest": config["model_digest"],
              "generation_options": config["options"],
              "actual_responses": len(raw), "actual_dialogues": len(cases), "independent_personas": 1,
              "feature_count": len(feature_ids), "primary_T1_by_style": {s: first[s]["provided_thought_cos"] for s in STYLES},
              "first_turn_all_features": first, "whole_dialogue_all_features": whole,
              "style_contrasts_by_arm": style_effects, "mapping_by_style_interaction": interactions,
              "literal_target_occurrences_out_of_24": literal_counts, "pair_order_counts": original_pairs,
              "historical_replay": {"compared_responses": len(replay), "identical_requests": sum(r["request_identical"] for r in replay),
                                    "identical_responses": sum(r["response_identical"] for r in replay), "rows": replay},
              "generation_wall_minutes_sum": sum(r["wall_seconds"] for r in raw)/60,
              "maximum_input_tokens": max(r["usage"].get("prompt_eval_count") or 0 for r in raw),
              "paid_api_calls": 0, "expert_or_llm_ratings": 0, "clinical_validation": False,
              "warning": "One-field input-delivery experiment in one fictional person. Similarity is not thought endorsement, clinical fidelity, or diagnosis. Later turns include arm-specific generated histories."}
    write_json(folder/"results.json", result)
    with (folder/"features-flat.csv").open("w", encoding="utf-8", newline="") as file:
        fields = ["condition_id", "profile_id", "style_id", "arm", "repeat_index", "turn"]+feature_ids
        writer = csv.DictWriter(file, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({**{f: row[f] for f in fields if f not in feature_ids}, **row["features"]})
    with (folder/"features-flat.csv").open(encoding="utf-8", newline="") as file:
        flat = list(csv.DictReader(file))
    if len(flat) != len(rows):
        raise ValueError("Feature CSV row count mismatch")
    for rich, exported in zip(rows, flat):
        if rich["condition_id"] != exported["condition_id"] or rich["turn"] != int(exported["turn"]):
            raise ValueError("Feature CSV row identity mismatch")
        for feature in feature_ids:
            value = rich["features"][feature]
            if (value is None and exported[feature] != "") or (value is not None and float(exported[feature]) != value):
                raise ValueError("Feature CSV cell mismatch")
    with (folder/"paired-effects.csv").open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=["endpoint", "style", "feature", "pairs", "native_mean", "alias_mean", "alias_minus_native", "positive_pairs", "negative_pairs", "zero_pairs"])
        writer.writeheader()
        for endpoint, summaries in [("T1", first), ("dialogue_mean", whole)]:
            for style, values in summaries.items():
                for feature, values_for_feature in values.items():
                    writer.writerow({"endpoint": endpoint, "style": style, "feature": feature, "pairs": values_for_feature["eligible_pairs"],
                        **{f: values_for_feature[f] for f in ["native_mean", "alias_mean", "alias_minus_native", "positive_pairs", "negative_pairs", "zero_pairs"]}})
    transcripts = ["# Single-field ablation: all actual English replies", "", "No editing, best-of selection, or clinical labels.", ""]
    for r in raw:
        transcripts += [f"## {r['condition_id']} · T{r['turn']}", "", "Interviewer: "+r["interviewer_text"], "", "Patient: "+r["response_text"], ""]
    (folder/"transcripts.en.md").write_text("\n".join(transcripts), encoding="utf-8")
    write_json(folder/"provenance.json", {"inputs": [{"path": str(p.relative_to(ROOT)), "sha256": digest(p.read_bytes())}
        for p in [plan, original/"features.jsonl", native_path, ROOT/"pilot/runs"/RUN/"conditions.json", ROOT/"pilot/runs"/RUN/"run-config.json"]],
        "raw_request_response_hashes": sourcefiles, "actual_histories_verified": len(raw),
        "unchanged_baseline_feature_count": 17, "single_field_only_verified_pairs": len(cases)//2,
        "csv_numeric_cells_checked": len(rows)*len(feature_ids),
        "script_sha256": digest(Path(__file__).read_bytes())})
    print(json.dumps({"output": str(folder), "primary": {s: {k: v[k] for k in ["native_mean", "alias_mean", "alias_minus_native", "positive_pairs", "negative_pairs"]}
        for s, v in result["primary_T1_by_style"].items()}, "historical_identical": result["historical_replay"]["identical_responses"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
