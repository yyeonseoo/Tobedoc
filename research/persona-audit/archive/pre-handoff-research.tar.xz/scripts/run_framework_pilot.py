"""Execute only the frozen 18-dialogue development pilot on installed Ollama."""
import argparse
import json
import random
import time
import uuid

from common import ROOT, digest, write_json
from local_preflight import MODEL, local_metadata
from prepare_framework_comparison import build, OUT, PLAN
from run_feature_batch import payload
from run_local_pilot import OPTIONS, chat, classify, fingerprint, now, refresh_progress
from summarize_local_pilot import verify_turn

RUN = "framework-pilot-20261030"


def conditions():
    _, _, expected, _, _ = build()
    prepared = json.loads((OUT/"pilot-conditions.json").read_text())
    if prepared != expected:
        raise ValueError("Prepared pilot differs from source-grounded frozen design")
    groups = {}
    for row in prepared:
        if row["split"] != "development" or row["repeat_index"] != 0:
            raise ValueError("Heldout/repeat expansion forbidden in this pilot")
        groups.setdefault((row["case_id"], row["program"]), []).append(row)
    keys = list(groups)
    rng = random.Random(20261030)
    rng.shuffle(keys)
    profiles = {c["id"]: c for c in json.loads(PLAN.read_text())["cases"]}
    result = []
    for key in keys:
        pair = list(groups[key])
        rng.shuffle(pair)
        for source in pair:
            row = dict(source)
            row.update(profile_id=source["case_id"], style_id=source["style"], arm=source["program"],
                       profile=profiles[source["case_id"]], case_family_id=source["case_family"],
                       prepared_system_sha256=source["prompt_sha256"])
            row["interview"] = [{"turn": i, "probe": ["initial_narrative","elaboration","standardized_redirection","coping_and_continuity"][i-1], "text": q}
                                for i, q in enumerate(source["interview"], 1)]
            row["prompt_sha256"] = fingerprint({"system_prompt": row["system_prompt"], "interview": row["interview"]})
            result.append(row)
    if len(result) != 18:
        raise ValueError("Unexpected pilot size")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    policy = json.loads((ROOT/"config/compute-policy.json").read_text())
    if policy["paid_model_api_allowed"] or policy["automatic_model_download_allowed"]:
        raise ValueError("Unexpected compute policy")
    cases = conditions()
    installed = local_metadata("/api/tags")["models"]
    model = next((m for m in installed if m.get("name") == MODEL), None)
    expected = json.loads((ROOT/"evidence/local-runtime.json").read_text())["ollama"]["candidate_metadata"]["digest"]
    if not model or model["digest"] != expected:
        raise ValueError("Pinned installed model absent/changed; no pull or substitution")
    config = {"run_id":RUN,"model":MODEL,"model_digest":model["digest"],"options":OPTIONS,"think":False,
              "plan_sha256":digest(PLAN.read_bytes()),"prepared_pilot_sha256":digest((OUT/"pilot-conditions.json").read_bytes()),
              "scope":"Controlled extracted style-module pilot, NOT native frameworks or clinical validity",
              "seed_rule":"20261030 + 100*repeat_index + turn; repeat zero only",
              "ordering_rule":"Shuffle nine case/program groups, then order of plain/verbose within each group; Random(20261030)",
              "user_authorization":"Proceed with the prepared development-only 18-dialogue/72-response local pilot",
              "conditions":[{k:c[k] for k in ["condition_id","prompt_sha256"]} for c in cases]}
    folder = ROOT/"pilot/runs"/RUN
    if folder.exists():
        if not args.resume or json.loads((folder/"run-config.json").read_text()) != config:
            raise ValueError("Existing run requires identical --resume configuration")
        if json.loads((folder/"conditions.json").read_text()) != cases:
            raise ValueError("Stored conditions differ")
    else:
        if args.resume:
            raise ValueError("Cannot resume nonexistent run")
        for name in ["requests","responses"]:
            (folder/name).mkdir(parents=True, exist_ok=False)
        write_json(folder/"run-config.json",config)
        write_json(folder/"conditions.json",cases)
        write_json(folder/"runtime.json",{"checked_at_utc":now(),"model":model,"version":local_metadata("/api/version"),
                                        "show":local_metadata("/api/show",{"model":MODEL})})
    lock = folder/".running"
    with lock.open("x") as file:
        file.write(now())
    try:
        for index,case in enumerate(cases,1):
            history = []
            for q in case["interview"]:
                turn=q["turn"]
                stem=f'{case["condition_id"]}-T{turn}'
                rp,sp=folder/"requests"/(stem+".json"),folder/"responses"/(stem+".json")
                request=payload(case,history,turn)
                sha=fingerprint(request)
                if sp.exists():
                    row=json.loads(sp.read_text())
                    verify_turn(row,json.loads(rp.read_text()),{**case,"_model_digest":model["digest"]},history)
                    if row["request_sha256"]!=sha or row["status"]!="completed":
                        raise ValueError("Failed/inconsistent response; no automatic retry")
                else:
                    if rp.exists():
                        raise ValueError("Unfinished saved request requires inspection")
                    started,request_id=now(),str(uuid.uuid4())
                    write_json(rp,{"request_id":request_id,"started_at_utc":started,"request_sha256":sha,"payload":request})
                    before=time.monotonic()
                    raw,error={},None
                    try:
                        raw=chat(request)
                        status=classify(raw)
                    except Exception as exc:
                        status,error="transport_error",{"type":type(exc).__name__,"message":str(exc)}
                    row={"run_id":RUN,**{k:case[k] for k in ["condition_id","profile_id","style_id","arm","repeat_index"]},
                         "turn":turn,"probe":q["probe"],"interviewer_text":q["text"],"prompt_sha256":case["prompt_sha256"],
                         "request_sha256":sha,"request_id":request_id,"started_at_utc":started,"ended_at_utc":now(),
                         "wall_seconds":time.monotonic()-before,"provider":"local_ollama","model_id_requested":MODEL,
                         "model_id_returned":raw.get("model"),"model_digest":model["digest"],"generation_settings":{"think":False,**request["options"]},
                         "status":status,"response_text":raw.get("message",{}).get("content",""),"finish_reason":raw.get("done_reason"),
                         "raw_response":raw,"error":error,"is_fixture":False,"clinical_rating":None,"is_schizophrenia_case":False,
                         "usage":{k:raw.get(k) for k in ["prompt_eval_count","eval_count","eval_duration","load_duration","total_duration"]}}
                    write_json(sp,row)
                refresh_progress(folder,cases)
                if row["status"]!="completed":
                    raise ValueError("Failed output preserved; stop rather than regenerate")
                history += [{"role":"user","content":q["text"]},{"role":"assistant","content":row["response_text"]}]
            print(f'{index}/18 {case["condition_id"]}: complete',flush=True)
    finally:
        lock.unlink(missing_ok=True)


if __name__=="__main__":
    main()
