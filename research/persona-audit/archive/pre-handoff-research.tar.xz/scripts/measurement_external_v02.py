"""Versioned missing-token repair; original frozen scorer and cache preserved."""
import argparse
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
import measurement_external as original

core=original.core
ROOT=core.ROOT
OLD=original.OUT
OUT=ROOT/'analysis/measurement-external-v02'
AMEND=ROOT/'config/measurement-external-amendment-v02.json'
old_check=original.seal_check
old_load=original.load_native
old_features=original.features


def wrapper_hashes():
    return {str(p.relative_to(ROOT)):core.sha(p) for p in (Path(__file__).resolve(),AMEND)}


def check_seal():
    destination=original.OUT
    original.OUT=OLD
    try:
        prior=old_check()
    finally:
        original.OUT=destination
    seal=core.read(OUT/'repair-seal.json')
    assert seal['wrapper_hashes']==wrapper_hashes()
    assert seal['original_seal_sha256']==core.sha(OLD/'seal.json')
    assert seal['original_embedding_manifest_sha256']==core.sha(OLD/'embedding-manifest.json')
    return prior


def freeze():
    original.OUT=OLD
    old_check()
    path=OUT/'repair-seal.json'
    if path.exists():
        check_seal()
    else:
        assert not (OUT/'results.json').exists()
        core.save(path,{'created_utc':datetime.now(timezone.utc).isoformat(),
            'wrapper_hashes':wrapper_hashes(),'original_seal_sha256':core.sha(OLD/'seal.json'),
            'original_embedding_manifest_sha256':core.sha(OLD/'embedding-manifest.json'),
            'amendment':core.read(AMEND),
            'scope':'Repair frozen after lexical-token exception, before aggregate external correlations'})
    print('Versioned missing-token repair frozen; original implementation and native cache retained')


def load_native():
    destination=original.OUT
    original.OUT=OLD
    try:
        return old_load()
    finally:
        original.OUT=destination


def features(sentences):
    if sentences and any(not core.words(s['text']) for s in sentences):
        texts=[s['text'] for s in sentences]
        tokens=[w for t in texts for w in core.words(t)]
        if not tokens:
            raise ValueError('No lexical tokens in entire summary')
        basic={'word_count':len(tokens),'sentence_count':len(texts),
               'duplicate_fraction':1-len({core.normalized(t) for t in texts})/len(texts),
               'type_token_ratio':len(set(tokens))/len(tokens)}
        return {**basic,**{m:None for m in original.METRICS if m not in basic}},'empty_lexical_sentence'
    return old_features(sentences)


def activate():
    original.OUT=OUT
    original.seal_check=check_seal
    original.load_native=load_native
    original.features=features


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('action',choices=('freeze','score','verify'))
    action=p.parse_args().action
    if action=='freeze': freeze()
    else:
        activate()
        getattr(original,action)()
