"""Validate the team prototype and package only its scoped, local artifacts."""
import argparse
from datetime import datetime, timezone
import json
import re
import subprocess
import sys
import tempfile
import zipfile

from common import ROOT, digest, write_json
from summarize_local_pilot import analyze


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", required=True)
    args = parser.parse_args()
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,70}", args.run_id):
        parser.error("Invalid run ID")
    run = ROOT / "pilot/runs" / args.run_id
    out = ROOT / "share" / args.run_id
    metrics, records = analyze(run)
    if metrics["totals"]["completed_turns"] != 24 or metrics["totals"]["non_completed_turns"]:
        raise ValueError("This completed-prototype package requires all 24 responses")
    saved_metrics = json.loads((out / "metrics.json").read_text())
    if saved_metrics["totals"] != metrics["totals"] or saved_metrics["groups"] != metrics["groups"]:
        raise ValueError("Published metrics do not match raw records")
    reviews = json.loads((out / "qualitative-review.json").read_text())
    by_id = {f'{r["condition_id"]}-T{r["turn"]}': r for r in records}
    for review in reviews["observations"]:
        if review["evidence_quote"] not in by_id[review["record"]]["response_text"]:
            raise ValueError("Review contains a quote absent from the real response")
    manual = reviews["sentence_count_review"]["counts_by_condition_in_turn_order"]
    for row in records:
        if manual[row["condition_id"]][row["turn"] - 1] != row["sentence_count_heuristic"]:
            raise ValueError("Sentence-count review and computed count differ")
    report = (out / "team-report.ko.md").read_text()
    for ref in re.findall(r"\]\(([^)]+)\)", report):
        if "://" not in ref and not (out / ref).is_file():
            raise ValueError(f"Broken report link: {ref}")
    validation = {
        "verified_at_utc": datetime.now(timezone.utc).isoformat(), "run_id": args.run_id,
        "raw_history_and_hash_verified_turns": len(records),
        "review_quotes_verified": len(reviews["observations"]),
        "sentence_counts_cross_checked": len(records),
        "report_local_links_verified": True, "clinical_validation": False,
        "warning": "Assistant review is not independent human/expert annotation.",
    }
    write_json(out / "prototype-verification.json", validation)
    pairs = []
    for name in ["team-report.ko.md", "README.ko.md", "transcripts.en.md", "metrics.json",
                 "metrics.regex-v1.json", "turn-metrics.csv", "qualitative-review.json", "prototype-verification.json"]:
        pairs.append((out / name, name))
    for name in ["common.py", "audit_sources.py", "prepare_pilot.py", "local_preflight.py",
                 "run_local_pilot.py", "summarize_local_pilot.py"]:
        pairs.append((ROOT / "scripts" / name, "scripts/" + name))
    for name in ["config/compute-policy.json", "evidence/source-lock.json", "evidence/local-runtime.json",
                 "tests/test_local_pilot.py"]:
        pairs.append((ROOT / name, name))
    for name in ["psi_profiles", "psi_styles", "psi_formatter", "psi_license"]:
        relative = f"evidence/snapshots/{name}.txt"
        pairs.append((ROOT / relative, relative))
    for path in sorted(run.rglob("*.json")):
        pairs.append((path, str(path.relative_to(ROOT))))
    manifest = {"created_at_utc": datetime.now(timezone.utc).isoformat(),
                "run_id": args.run_id, "scope": "Report, generated data, local code, minimum MIT-licensed PATIENT-psi sources. No full clinical-paper caches.",
                "files": [{"path": relative, "bytes": path.stat().st_size, "sha256": digest(path.read_bytes())}
                          for path, relative in pairs]}
    write_json(out / "archive-manifest.json", manifest)
    pairs.append((out / "archive-manifest.json", "archive-manifest.json"))
    archive = out / (args.run_id + ".zip")
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as package:
        for path, relative in pairs:
            package.write(path, args.run_id + "/" + relative)
    with tempfile.TemporaryDirectory(prefix="persona-prototype-check-") as task_dir:
        with zipfile.ZipFile(archive) as package:
            for name in package.namelist():
                if name.startswith("/") or ".." in name.split("/"):
                    raise ValueError("Unsafe archive member")
            package.extractall(task_dir)
        from pathlib import Path
        unpacked = Path(task_dir) / args.run_id
        for member in manifest["files"]:
            if digest((unpacked / member["path"]).read_bytes()) != member["sha256"]:
                raise ValueError("Archive integrity mismatch")
        checks = [
            [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"],
            [sys.executable, "scripts/summarize_local_pilot.py", "--run-id", args.run_id],
        ]
        results = []
        for command in checks:
            result = subprocess.run(command, cwd=unpacked, capture_output=True, text=True)
            results.append({"command": command, "exit_code": result.returncode,
                            "stdout": result.stdout, "stderr": result.stderr})
            if result.returncode:
                raise ValueError(f"Unpacked prototype validation failed: {result.stderr}")
    write_json(out / "archive-check.json", {
        "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "archive": archive.name, "sha256": digest(archive.read_bytes()),
        "bytes": archive.stat().st_size, "file_count": len(pairs),
        "extracted_hashes_verified": True, "offline_unit_tests_and_reanalysis": results,
        "network_or_inference_executed_by_packaging": False,
    })
    print(json.dumps({"archive": str(archive), "files": len(pairs), "bytes": archive.stat().st_size,
                      "verified_real_turns": len(records), "quotes_checked": len(reviews["observations"]),
                      "unpacked_offline_checks": "passed"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
