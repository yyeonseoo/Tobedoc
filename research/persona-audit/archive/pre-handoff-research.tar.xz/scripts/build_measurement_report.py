"""Three-page Korean report with numerical assertions and complete appendix."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
from docx import Document
from docx.shared import Pt
from build_two_feature_report import configure
from build_integrated_report import font, paragraph, heading, table
from build_role_audit_report import reference
import measurement_audit as core

ROOT=core.ROOT
SHARE=ROOT/'share/measurement-validation-v01'
OUTPUT=SHARE/'문장 연결성 지표 검증 보고서.docx'
LABELS={'adjacent_cos':'인접 문장 유사도','all_pairs_cos':'전체 문장쌍 유사도',
        'adjacency_excess':'인접 초과 유사도','question_association':'질문 주제 연관성',
        'lexical_adjacent':'인접 어휘 겹침','duplicate_fraction':'동일 문장 반복률',
        'type_token_ratio':'어휘 다양도','word_count':'단어 수','sentence_count':'문장 수'}
REFERENCES=[
    ('He 등 2026 정신증의 연결성과 의미 유사도','https://pubmed.ncbi.nlm.nih.gov/41656336/'),
    ('Beyer 등 2021 표적화된 연결성 평가','https://aclanthology.org/2021.naacl-main.328/'),
    ('Mohiuddin 등 2021 합성과 실제 과제 평가의 차이','https://aclanthology.org/2021.eacl-main.308/'),
    ('Fabbri 등 2021 SummEval','https://aclanthology.org/2021.tacl-1.24/'),
    ('SummEval 공식 배포와 원출처 모델 목록','https://github.com/Yale-LILY/SummEval')]


def f(value):
    return '정의 불가' if value is None else f'{value:+.3f}'


def content(data):
    a=data['authored'];ext=data['external'];native=data['native'];prior=data['prior']
    c=a['comparisons'];rho=ext['correlations']
    assert a['base_cases']==16 and ext['eligible_records']==1542
    assert c['explicit_relation']['adjacent_cos']['positive']==10
    pages=[[],[],[]]
    def h(page,text): pages[page].append(('heading',text))
    def p(page,text,small=False): pages[page].append(('small' if small else 'paragraph',text))
    def t(page,headers,rows,widths): pages[page].append(('table',(headers,rows,widths)))

    h(0,'무엇을 확인했으며 무엇을 결정했나')
    p(0,'환자 페르소나가 조현병의 언어 특징을 재현하는지 평가하기 전에, 우리가 사용하는 숫자가 정말 문장 연결성을 측정하는지 확인했다. 통제 문장과 외부 사람 평가를 함께 분석한 결과, 현재의 의미 유사도를 임상적 연결성 점수로 채택하지 않기로 했다. 질문 주제 연관성·문장 간 의미적 가까움·반복을 서로 다른 특징으로 보고한다.')
    p(0,f"외부 요약문 {ext['eligible_records']:,}개에서 인접 문장 유사도와 기존 전문가 연결성 평가의 Spearman 상관은 {f(rho['adjacent_cos']['summary_spearman'])}이었다. 점수가 높은 글을 사람이 연결성도 좋다고 평가하는 경향이 매우 약했다. 통제 자료에서는 모순이 없는 원문을 더 높게 평가한 경우가 16개 중 10개였다. 의미가 비슷하다는 것과 앞뒤 관계가 성립한다는 것은 같지 않았다.")

    h(0,'어떻게 시험했나')
    p(0,'영어 허구 사례 24개를 시간 관계·상태의 긍정과 부정·행위자·원인으로 나누었다. 수치 확인 전에 개발 8개와 평가 16개로 원문 단위 분리한 뒤, 원문·질문 교체·역순·중간 순서 교체·첫 문장 반복·동일 주제 삽입·다른 주제 삽입·표현 변경·명시적 모순의 9조건을 만들었다. 총 216개는 변형 기록이며 독립 표본 216개가 아니다.')
    p(0,'모순 대조는 마지막 문장의 관계를 바꾸되 단어 수를 유지했다. 두 삽입 조건은 각 10단어로 맞췄다. 문장 섞기나 다른 주제 삽입을 곧바로 임상적 비연결성의 정답으로 삼지 않았다. 모든 사례와 표현은 같은 어시스턴트가 작성했으므로 평가 분리는 수치 노출 방지이지 독립 평가자나 새로운 문형 계열의 검증은 아니다.',True)

    h(0,'평가 사례 16개에서 나타난 반응')
    main_metrics=('adjacent_cos','all_pairs_cos','adjacency_excess','question_association','lexical_adjacent')
    def counts(group,m):
        s=c[group][m]
        return f"{s['positive']}/16"+(f"  동률 {s['ties']}" if s['ties'] else '')
    t(0,['지표','원문이 모순문보다 높음','동일 주제 삽입이 더 높음'],
      [[LABELS[m],counts('explicit_relation',m),counts('insertion',m)] for m in main_metrics],[2.3,2.35,2.35])
    p(0,'인접 유사도는 이웃 문장끼리의 평균, 전체 문장쌍 유사도는 모든 쌍의 평균이다. 인접 초과 유사도는 두 값의 차이다. 질문 주제 연관성은 각 문장과 질문의 평균 유사도이며, 어휘 겹침은 단어 집합의 Jaccard 값이다.',True)
    p(0,'숫자는 해당 방향의 사례 수이지 임상 정확도가 아니다. 질문 주제 연관성은 질문만 바꾸었을 때 16/16에서 원래 질문에 더 높았다. 답변 내부 지표는 16/16에서 그대로였다. 질문 적합성과 내부 관계를 분리해야 한다는 조작 점검이다. 나머지 지표·개발 결과·계열별 결과도 별도 데이터에 모두 보존했다.',True)

    h(1,'외부 사람이 평가한 자료에서도 확인했다')
    p(1,'공식 SummEval에서 뉴스 원문 100개에 대한 16개 시스템의 요약문 1,600개를 실제로 확보했다. 각 요약문에 이미 있는 요약 연구 전문가 3명의 연결성 평가 평균을 사용했다. 평가는 1–5점이며 정신과 전문의의 증상 등급이 아니다. 원문 기사 재구성이나 추가 사람 채점은 하지 않았다.[4,5]')
    p(1,f"문장 분리부터 점검할 필요가 있었다. 소문자와 공백 분리 마침표가 있는 배포문을 기본 문장 분리기로 처리하면 1,430개가 한 문장으로 잡혔다. 초기 분석의 적격 자료는 {native['eligible_records']}개와 7개 시스템뿐이었다. 해당 결과를 보존하고, 명시한 문장 경계 규칙을 고정해 재계산했다. 이 수정은 초기 상관을 본 뒤 시행한 전처리 후속 분석이며 사전등록 확증으로 표현하지 않는다.")
    p(1,'수정 후 한 문장 50개와 문장부호만 있는 조각을 포함한 8개를 제외해 1,542개를 분석했다. 원문은 변경하지 않았고 문자·UTF16 위치와 해시를 확인했다. 사전에 정한 약어 예외를 썼지만 문장 경계에 독립 사람 정답이 있는 것은 아니다. 임의의 분리기를 계속 시험해 상관이 높은 결과를 선택하지 않았다.',True)
    t(1,['지표','전체 상관','95퍼센트 구간','기사 내 평균 상관'],
      [[LABELS[m],f(rho[m]['summary_spearman']),
        f"{f(rho[m]['article_cluster_ci95'][0])} ~ {f(rho[m]['article_cluster_ci95'][1])}",
        f(rho[m]['within_article_mean_spearman'])]
       for m in ('adjacent_cos','all_pairs_cos','adjacency_excess','lexical_adjacent','type_token_ratio','word_count','sentence_count')],
      [1.9,1.05,2.25,1.8])
    p(1,'전체 상관은 동일한 1,542개 요약문의 Spearman 순위상관이다. 구간은 같은 기사의 시스템 요약들을 함께 뽑는 기사 단위 부트스트랩 2,000회로 계산했다. 기사 내 평균은 같은 기사에 대한 시스템들 사이의 상관을 기사별 계산해 평균한 값이다. 고정된 16개 시스템에 조건부인 분석이며, 환자 모집단이나 새로운 시스템 전반의 구간은 아니다.',True)
    p(1,'세 의미 지표의 전체 상관은 약 0.02–0.03이었다. 어휘 다양도·단어 수·문장 수도 사람 평가와 연관되었지만 이를 새로운 연결성 척도로 채택하지 않았다. 관찰된 상관만으로 길이가 원인이라고 할 수도 없다. 동일 문장 반복률은 대부분 0이어서 기사 내 상관이 가능한 기사가 4개뿐이며, 전체 세부 결과에 따로 제시했다.')

    h(2,'예문으로 보면 왜 문제가 되는가')
    rows=data['authored_rows']
    example={r['variant']:r for r in rows if r['case_id']=='T3'}
    p(2,'평가 사례 T3에서는 오후 7시에 요리를 끝내고 같은 날 오후 8시에 식사를 시작했다고 먼저 명시했다. 마지막 문장 하나만 다음과 같이 바꿨다. 아래는 결과 확인 후 선택한 설명용 예문이다.')
    t(2,['마지막 문장','인접 문장 유사도'],[
        ['Cooking finished before eating began.',f"{example['original']['metrics']['adjacent_cos']:.3f}"],
        ['Cooking finished after eating began.',f"{example['contradiction']['metrics']['adjacent_cos']:.3f}"]],[5.1,1.9])
    p(2,'두 번째 문장은 앞서 명시한 시간과 충돌하지만 유사도는 오히려 높아졌다. 전체에서도 시간 관계 대조는 2/4, 상태 긍정·부정 대조는 1/4에서만 원문이 더 높았다. 행위자 대조는 4/4였다. 같은 유사도라도 관계 유형에 따라 반응이 달라 하나의 연결성 능력으로 읽기 어렵다.')

    h(2,'기존 페르소나 분석은 어떻게 해석해야 하나')
    s={r['style']:r for r in prior['summaries']}
    p(2,f"기존 PATIENT-Ψ 지시를 Qwen에 이식한 48개 첫 응답에서 verbose와 tangent의 인접 유사도는 각각 {s['verbose']['adjacent_cos']:.3f}, {s['tangent']['adjacent_cos']:.3f}였다. 두 조건 모두 요청 사실 표식은 48/48이었다. 이번 결과를 적용하면 이 차이는 문장 간 의미적 가까움의 차이로 남겨야 하며, tangent가 더 심한 사고장애를 구현한다는 증거로 바꿀 수 없다. 기존 자료는 출처 연결용 재사용이며 새 외부 표본에 더하지 않았다.")
    p(2,'역순에도 값이 같고 첫 문장 복제에 값이 오르는 것은 대칭 평균의 알려진 수학적 성질이다. 새로운 임상 발견으로 세지 않았다. 표현 변경의 절대 변화가 모순 변경보다 큰 경우도 인접 유사도에서 11/16이었지만, 수정한 단어의 수와 위치가 동일하지 않아 표현에 더 민감하다는 일반 결론의 근거로 삼지 않았다.',True)

    h(2,'현재 결론과 다음 검증')
    p(2,'현재 파이프라인에서는 질문 주제 연관성, 문장 간 의미 유사도, 동일 문장 반복률을 각각의 기술 지표로 사용한다. 이들을 합쳐 조현병 연결성 점수나 페르소나의 임상 순위를 만들지 않는다. 새 종합 지표를 억지로 최적화하지 않고, 측정 대상과 실패 조건을 확인한 것이 이번 완료 결과다.')
    p(2,'다음 지표 후보는 방향·문맥을 반영하는 확률 기반 점수나 관계 판별 방식이다. 이번과 같은 통제 대조와 외부 사람 평가를 함께 통과하는지 먼저 시험해야 한다. 이후에만 페르소나에 적용한다. 교수님께는 어떤 언어 관계가 사고장애의 임상 개념과 연결되는지 자문받는다. 이번 뉴스 요약 결과가 실제 조현병 발화로 전이되는지는 별도 검증 대상이다.[1–3]')
    p(2,'계산은 로컬 Python과 macOS 영어 임베딩 512차원 revision 1로 수행했다. 새 생성형 모델 호출·LLM 채점·유료 API·모델 다운로드·설치·원격 작업은 모두 0회다. 공개 평가 파일 약 5.8MB만 내려받았다. 데이터·정의·전처리 수정·개별 측정값·해시·재현 실행 기록을 함께 보존했다.',True)
    return pages


def build(replace=False):
    paths={'authored':ROOT/'analysis/measurement-audit-v01/evaluation-results.json',
           'authored_rows':ROOT/'analysis/measurement-audit-v01/evaluation-measurements.json',
           'development':ROOT/'analysis/measurement-audit-v01/development-results.json',
           'external':ROOT/'analysis/measurement-external-v03/results.json',
           'native':ROOT/'analysis/measurement-external-v02/results.json',
           'prior':ROOT/'analysis/measurement-audit-v01/prior-linkage.json'}
    data={k:core.read(p) for k,p in paths.items()}
    for folder in ('measurement-audit-v01','measurement-external-v02','measurement-external-v03'):
        assert core.read(ROOT/'analysis'/folder/'verification.json')['status']=='passed'
    if OUTPUT.exists() and not replace: raise FileExistsError('Use --replace only for layout or editorial repair')
    pages=content(data)
    doc=Document();configure(doc)
    doc.core_properties.title='문장 연결성 지표의 측정 타당성 점검'
    doc.core_properties.subject='통제 문장과 외부 사람 평가를 이용한 지표 검증'
    doc.core_properties.author='연구팀';doc.core_properties.comments=''
    title=doc.add_paragraph('문장 연결성 지표의 측정 타당성 점검',style='Title')
    title.paragraph_format.line_spacing=Pt(25);title.paragraph_format.space_after=Pt(6)
    for run in title.runs:font(run,18,True)
    paragraph(doc,'2026년 11월 1일  통제 사례와 외부 평가를 결합한 연구 결과',small=True)
    markdown=['# 문장 연결성 지표의 측정 타당성 점검','', '2026년 11월 1일','']
    for i,page in enumerate(pages):
        if i: doc.add_page_break()
        for kind,value in page:
            if kind=='heading':
                heading(doc,value);markdown += ['## '+value,'']
            elif kind in ('paragraph','small'):
                paragraph(doc,value,small=kind=='small');markdown += [value,'']
            else:
                headers,rows,widths=value
                table(doc,headers,rows,widths,numeric=tuple(range(1,len(headers))))
                markdown += ['| '+' | '.join(headers)+' |','| '+' | '.join('---' for _ in headers)+' |']
                markdown += ['| '+' | '.join(map(str,row))+' |' for row in rows]+['']
    for i,(label,url) in enumerate(REFERENCES,1):
        reference(doc,f'[{i}] {label}',url)
        markdown += [f'[{i}] [{label}]({url})','']
    SHARE.mkdir(parents=True,exist_ok=True)
    doc.save(OUTPUT)
    (SHARE/'보고서.md').write_text('\n'.join(markdown))
    # Full prespecified outcome matrix; no omitted poor or tied outcomes.
    appendix=['# 전체 지표 결과와 분석 기록','',
              '주보고서는 평가 사례 16개와 외부 V03 공통 집합을 사용한다. 아래에는 개발 결과, 모든 지표, 초기 전처리 결과도 보존한다.','']
    for key in ('development','authored'):
        r=data[key]
        appendix += [f"## 통제 자료 {r['split']} 원문 {r['base_cases']}개",'']
        for comparison,metrics in r['comparisons'].items():
            appendix += ['### '+comparison,'','| 지표 | 평균 차이 | 양수 | 음수 | 동률 | 평균 차이 95% 구간 |','| --- | --- | --- | --- | --- | --- |']
            for metric,s in metrics.items():
                appendix += [f"| {LABELS[metric]} | {s['mean']:+.6f} | {s['positive']} | {s['negative']} | {s['ties']} | {s['mean_ci95'][0]:+.6f} ~ {s['mean_ci95'][1]:+.6f} |"]
            appendix += ['','계열별 결과는 해당 results.json의 by_family에 모두 포함한다.','']
    for key in ('native','external'):
        r=data[key]
        appendix += [f"## 외부 자료 {key} 적격 {r['eligible_records']}개",'',
                     '기사 군집 부트스트랩이며 고정된 시스템 집합에 조건부이다. 0 분산 상관은 0으로 채우지 않는다.','',
                     '| 지표 | 전체 rho | 군집 95% 구간 | 기사 내 평균 rho | 유효 기사 수 | 시스템 평균 rho | 유효 bootstrap |',
                     '| --- | --- | --- | --- | --- | --- | --- |']
        for metric,s in r['correlations'].items():
            ci=s['article_cluster_ci95']
            appendix += [f"| {LABELS[metric]} | {f(s['summary_spearman'])} | {f(ci[0])} ~ {f(ci[1])} | {f(s['within_article_mean_spearman'])} | {s['within_article_valid']}/{s['within_article_total']} | {f(s['system_mean_spearman'])} | {s['bootstrap_valid']}/2000 |"]
        appendix += ['', '제외 사유 '+json.dumps(r['exclusions'],ensure_ascii=False),
                     f"평가 평균 전체 {r['expert_coherence_mean_all']:.4f}, 적격 {r['expert_coherence_mean_eligible']:.4f}, 제외 {r['expert_coherence_mean_excluded']:.4f}",
                     '단일 문장을 포함한 전체 1600개 길이 어휘 지표 민감도 '+json.dumps(r['all_record_lexical_length_sensitivity'],ensure_ascii=False),'']
    (SHARE/'전체결과.md').write_text('\n'.join(appendix))
    core.save(SHARE/'report-inputs.json',{'created_utc':datetime.now(timezone.utc).isoformat(),
        'inputs':{str(p.relative_to(ROOT)):core.sha(p) for p in paths.values()},
        'builder_sha256':core.sha(Path(__file__).resolve()),
        'docx_sha256':core.sha(OUTPUT),'markdown_sha256':core.sha(SHARE/'보고서.md'),
        'appendix_sha256':core.sha(SHARE/'전체결과.md')})
    print(OUTPUT)


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--replace',action='store_true')
    build(p.parse_args().replace)
