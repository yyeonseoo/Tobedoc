"""Offline integrity and numerical reproduction of the frozen 64-call ablation."""
import json
from pathlib import Path
import subprocess
import sys

from docx import Document

from common import ROOT, digest, write_json
from first_reply_probe_runner import verify_response
from run_local_pilot import fingerprint
from return_control_ablation import (OUT, FOLDER, SPEC, ARMS, MODES, conditions, metrics, contrast)
from build_return_control_report import OUTPUT, OUT as SHARE


def read(path):
    return json.loads(path.read_text())


def main():
    result, spec = read(OUT / "results.json"), read(SPEC)
    plan, prepared = read(FOLDER / "plan.json"), read(FOLDER / "prepared-at.json")
    cases = conditions()
    assert len(cases) == result["completed_requests"] == 64
    assert digest(SPEC.read_bytes()) == plan["spec_sha256"]
    assert fingerprint(cases) == plan["conditions_sha256"]
    assert fingerprint(plan) == prepared["plan_sha256"]
    assert digest((ROOT / "scripts/fact_disclosure_probe.py").read_bytes()) == plan["matcher_file_sha256"]
    assert digest((ROOT / "scripts/return_control_ablation.py").read_bytes()) == plan["analysis_script_sha256_at_preparation"]
    hashes = 0
    for item in result["provenance"]:
        assert digest((ROOT / item["path"]).read_bytes()) == item["sha256"]
        hashes += 1
    indexed = {r["condition_id"]:r for r in result["responses"]}
    actual = []
    for case in cases:
        raw = read(FOLDER / "responses" / (case["condition_id"]+".json"))
        request = read(FOLDER / "requests" / (case["condition_id"]+".json"))
        verify_response(raw, request, case, plan["model_digest"])
        assert prepared["prepared_at_utc"] < raw["started_at_utc"]
        row = indexed[case["condition_id"]]
        assert row["response_text"] == raw["response_text"]
        for key,value in metrics(raw["response_text"],case,spec).items():
            assert row[key] == value, (case["condition_id"],key)
        actual.append(raw)
    for mode in MODES:
        group = [r for r in result["responses"] if r["task_mode"] == mode]
        assert len(group) == 32
        b = result["by_mode"][mode]
        # JSON round-trips tuple block identifiers as arrays; compare canonical JSON.
        assert fingerprint(contrast(group,"primary_return")) == fingerprint(b["contrasts"]["primary_return"])
        for arm in ARMS:
            part = [r for r in group if r["arm"] == arm]
            summary = next(s for s in b["summaries"] if s["arm"] == arm)
            assert len(part) == summary["replies"] == 16
            assert sum(r["primary_return"] for r in part) == summary["primary_return_count"]
            assert sum(r["other_present"] for r in part) == summary["other_present_count"]
    manifest = read(SHARE / "report-inputs.json")
    assert manifest["result_sha256"] == digest((OUT / "results.json").read_bytes())
    assert manifest["output_sha256"] == digest(OUTPUT.read_bytes())
    assert manifest["spec_sha256"] == digest(SPEC.read_bytes())
    assert manifest["audit_sha256"] == digest((OUT / "reference-audit.json").read_bytes())
    assert manifest["figure_sha256"] == digest((SHARE / "return-control-results.png").read_bytes())
    doc = Document(OUTPUT)
    text = "\n".join(p.text for p in doc.paragraphs)
    for clause in (spec["source_clause"],spec["replacement_clause"]):
        assert clause in text
    assert "총 64개" in text and "접두문은 연구자가" in text
    pages = list((SHARE / "render-qa-v2").glob("page-*.png"))
    assert len(pages) in (2,3) and all(p.stat().st_size > 10000 for p in pages)
    tests = subprocess.run([sys.executable,"-m","unittest","discover","-s","tests"],cwd=ROOT,capture_output=True,text=True)
    if tests.returncode:
        raise ValueError(tests.stdout+tests.stderr)
    record = {"completed_requests":64,"free_replies":32,"challenge_continuations":32,
              "all_requests_and_texts_verified":True,"source_hash_checks":hashes,
              "all_metrics_reproduced":True,"plan_preceded_every_generation":True,
              "prepared_script_unchanged":True,"task_modes_not_pooled":True,
              "local_generation_prompt_tokens":sum(r["raw_response"].get("prompt_eval_count",0) for r in actual),
              "local_generation_output_tokens":sum(r["raw_response"].get("eval_count",0) for r in actual),
              "generation_seconds":round(sum(r["wall_seconds"] for r in actual),1),
              "rendered_pages":len(pages),"unit_test_output":tests.stderr.strip(),
              "report_sha256":digest(OUTPUT.read_bytes()),"paid_api_calls":0,"llm_judge_calls":0,
              "clinical_ratings":0,"model_downloads":0}
    write_json(SHARE / "verification.json",record)
    print(json.dumps(record,ensure_ascii=False))


if __name__ == "__main__":
    main()
