"""Integrate four bounded feature axes and the precommitted optional-mode test."""
from statistics import mean
from common import ROOT,digest,write_json
from pleasing_study import read,SPEC

OUT=ROOT/'analysis/integrated-checkpoint-v05'


def main():
    spec=read(SPEC)
    discovery_path=ROOT/'analysis'/spec['discovery']['run_id']/'results.json'
    d=read(discovery_path)
    activation_path=ROOT/'pilot/runs'/spec['followup']['run_id']/'activation.json'
    activation=read(activation_path)
    f=read(ROOT/'analysis'/spec['followup']['run_id']/'results.json') if activation['execute'] else None
    paths={'verbosity':ROOT/'analysis/shared-verbosity-v02/results.json',
           'disclosure':ROOT/'analysis/disclosure-comparison-v02/results.json',
           'disclosure_audit':ROOT/'analysis/disclosure-comparison-v02/reference-audit.json',
           'topic':ROOT/'analysis/topic-local-separation-v01/results.json',
           'discovery':discovery_path,'activation':activation_path,'spec':SPEC}
    if f:
        paths['followup']=ROOT/'analysis'/spec['followup']['run_id']/'results.json'
    paths['discovery_numeric_audit']=ROOT/'analysis'/spec['discovery']['run_id']/'numeric-expression-audit.json'
    if f:
        paths['followup_numeric_audit']=ROOT/'analysis'/spec['followup']['run_id']/'numeric-expression-audit.json'
    sources={k:read(p) for k,p in paths.items()}
    adoption={}
    if f:
        sums={r['arm']:r for r in f['summaries']}
        for source in ('psi','sim'):
            original,locked=sums[source+'_original'],sums[source+'_factlock']
            c=f['contrasts'][source+'_factlock_minus_'+source+'_original']
            both=all(v>0 for v in c['correct_slots']['by_case'].values())
            fewer=locked['any_nonmatching']<original['any_nonmatching']
            cue_enough=locked['minimization_cue']>=.5*original['minimization_cue']
            adoption[source]={'correct_slot_gain':c['correct_slots']['mean'],
                              'correct_gain_in_both_cases':both,'nonmatching_count_decreased':fewer,
                              'literal_cue_count_at_least_half':cue_enough,
                              'original_literal_cues':original['minimization_cue'],
                              'locked_literal_cues':locked['minimization_cue'],
                              'prewritten_primary_rule_passed':both and fewer and cue_enough,
                              'surface_cue_retention_condition_met':original['minimization_cue']>0 and cue_enough,
                              'adopt_as_reliable_default':False,
                              'decision':'exploratory_candidate_only' if both and fewer and cue_enough else 'not_selected',
                              'reason':'Known primary numeric-parser errors require supplemental inspection; even the audited locked outputs do not consistently retain all three values.',
                              'scope':'Literal cue criterion only; no independent realism, clinical quality or native-system improvement claim'}
    v={r['arm']:r for r in sources['verbosity']['summaries']}
    disclosure={r['arm']:r for r in sources['disclosure']['summaries']}
    topic={r['style']:r for r in sources['topic']['summaries']}
    summaries={r['arm']:r for r in d['summaries']}
    axes=[
      {'axis':'verbal_productivity','name_ko':'발화량','unique_replies':80,
       'source_ids':['psi_verbose','sim_verbose'],'facts':{'simple_verbose_words':v['simple_verbose']['word_count'],
           'psi_verbose_words':v['psi_verbose']['word_count'],'sim_verbose_words':v['sim_verbose']['word_count'],
           'simple_requested_refs':v['simple_verbose']['requested_refs_total'],
           'psi_requested_refs':v['psi_verbose']['requested_refs_total'],'sim_requested_refs':v['sim_verbose']['requested_refs_total'],'denominator':64},
       'meaning_ko':'길이가 크게 증가해도 요청 정보 언급은 늘지 않았다. 발화량과 정보량을 분리한다.'},
      {'axis':'disclosure_and_skepticism','name_ko':'정보 공개와 의심 표현','unique_replies':40,
       'source_ids':['psi_reserved','sim_distrust'],'facts':{'brief_refs':disclosure['brief']['personal_references'],
           'psi_refs':disclosure['psi_reserved']['personal_references'],'sim_refs':disclosure['sim_distrust']['personal_references'],'denominator':24},
       'meaning_ko':'개인 정보의 정확한 표식 감소·근사화·의심 표현은 같은 행동이 아니었다. 원문 보조 감사는 독립 사람 평가와 구분한다.'},
      {'axis':'topic_maintenance','name_ko':'질문 대응과 주제 유지','unique_replies':48,
       'source_ids':['PSI plain','PSI verbose','PSI tangent'],'facts':{'requested_refs_each_style':48,'denominator_each':48,
           'verbose_adjacent':topic['verbose']['adjacent_cos'],'tangent_adjacent':topic['tangent']['adjacent_cos'],
           'other_insertion_increases_adjacent':sources['topic']['insertion_summary']['adjacent_cos']['positive'],'insertion_pairs':48},
       'meaning_ko':'요청 정보 전달·주제 관련도·국소 문장 유사도를 분리했다. 재분석한 48개를 새 생성으로 세지 않는다.'},
      {'axis':'downplaying','name_ko':'우려 축소와 숫자 보고','unique_replies':40+(32 if f else 0),
       'source_ids':['psi_pleasing','sim_pleasing'],'facts':{arm:{k:summaries[arm][k] for k in ('correct_slots','any_nonmatching','minimization_cue','mean_words')}
              for arm in spec['discovery']['arms']},
       'meaning_ko':'표현 완화 문구와 주어진 값과 다른 수치 보고를 분리했다. PatientSim의 수치 축소는 원문 underreporting 요구와 함께 해석한다.'}
    ]
    phases=[d]+([f] if f else [])
    result={'checkpoint_id':'integrated-checkpoint-v05','date':'2026-10-31',
            'completion_scope':'Four-axis instruction audit plus any activated prewritten factlock test complete. Not the completion of clinical validation or native-framework replication.',
            'axes':axes,'distinct_replies_across_four_main_tasks':sum(a['unique_replies'] for a in axes),
            'new_replies_this_batch':sum(r['completed_replies'] for r in phases),
            'activation':activation,'followup_adoption':adoption,
            'numeric_audits':{stage:sources[stage+'_numeric_audit']['summaries'] for stage in ('discovery','followup') if stage+'_numeric_audit' in sources},
            'cost_this_batch':{k:sum(r['cost'][k] for r in phases) for k in d['cost']},
            'remaining_human_steps_ko':['교수님과 관찰 feature와 임상 개념의 대응 범위 확인',
                 '논문 주장을 고정한 뒤 다른 기반 모델 또는 독립 평가가 필요한지 결정',
                 '외적 타당도 없이 조현병 환자 발화 재현이나 진단 성능을 주장하지 않기'],
            'source_files':{str(p.relative_to(ROOT)):digest(p.read_bytes()) for p in paths.values()}}
    write_json(OUT/'results.json',result)
    print({'axes':len(axes),'distinct_main_task_replies':result['distinct_replies_across_four_main_tasks'],
           'new_replies':result['new_replies_this_batch'],'adoption':adoption,'cost':result['cost_this_batch']})


if __name__=='__main__':
    main()
