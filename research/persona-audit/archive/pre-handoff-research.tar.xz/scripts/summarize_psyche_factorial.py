"""Local reporting plus explicitly POST-HOC exact-text sensitivity diagnostic.

Does not modify the frozen generation protocol, score clinical behavior, or call models.
"""
from collections import defaultdict
import json
import statistics

from common import ROOT, digest, write_json
import psyche_factorial as experiment


def sensitivity(rows):
    output = []
    for factor, levels, matches in [('quantity', ['Normal', 'Increased'], ('arm', 'thought', 'seed')),
                                    ('thought', ['Normal', 'Derailment'], ('arm', 'quantity', 'seed')),
                                    ('arm', ['hub_unchanged', 'quantity_clause_only'], ('quantity', 'thought', 'seed'))]:
        groups = defaultdict(dict)
        for row in rows:
            if row['status'] == 'completed':
                groups[tuple(row[k] for k in matches)][row[factor]] = row
        for values in groups.values():
            if not all(level in values for level in levels):
                continue
            a, b = (values[level] for level in levels)
            output.append({'factor': factor, 'a': a['id'], 'b': b['id'],
                           'matched_on': {k: a[k] for k in matches},
                           'text_a_sha256': digest(a['text'].encode()), 'text_b_sha256': digest(b['text'].encode()),
                           'exact_text_equal': a['text'] == b['text'],
                           'word_difference_b_minus_a': b['words'] - a['words']})
    return output


def main():
    verification = experiment.read(experiment.OUT / 'verification.json')
    assert verification['passed']
    summary = experiment.read(experiment.OUT / 'summary.json')
    rows = experiment.read(experiment.OUT / 'measurements.json')
    complete = [r for r in rows if r['status'] == 'completed']
    pairs = sensitivity(rows)
    thoughts = [r for r in pairs if r['factor'] == 'thought']
    original = [r for r in thoughts if r['matched_on']['arm'] == 'hub_unchanged']
    amended = [r for r in thoughts if r['matched_on']['arm'] == 'quantity_clause_only']
    equal_count = lambda values: sum(r['exact_text_equal'] for r in values)
    diagnostic = {'analysis_timing': 'Exploratory post-hoc implementation diagnostic, defined after inspecting completed outputs; NOT a preregistered endpoint',
                  'meaning': 'Exact identical text demonstrates no observable output distinction in that matched pair; text inequality does NOT establish correct thought-disorder portrayal',
                  'thought_pairs': len(thoughts), 'thought_pairs_exact_equal': equal_count(thoughts),
                  'original_thought_pairs_exact_equal': [equal_count(original), len(original)],
                  'amended_thought_pairs_exact_equal': [equal_count(amended), len(amended)], 'pairs': pairs,
                  'measurements_sha256': digest((experiment.OUT / 'measurements.json').read_bytes())}
    write_json(experiment.OUT / 'exploratory-exact-text-diagnostic.json', diagnostic)
    means = {quantity: statistics.mean(r['words'] for r in complete if r['quantity'] == quantity) for quantity in ['Normal', 'Increased']}
    quantity = next(r for r in summary['paired_word_count_descriptors'] if r['factor'] == 'quantity')
    positives = sum(d > 0 for d in quantity['differences'])
    negatives = sum(d < 0 for d in quantity['differences'])
    lines = ['# PSYCHE 특징 분리 파일럿 결과', '', '2026년 11월 1일 · 팀 논의용', '',
             '## 출발한 의문과 이번 결론', '',
             '우리가 궁금한 것은 “페르소나에 임상 특징의 이름을 넣으면, 실제 생성 발화에서도 그 특징이 구별되게 나타나는가?”이다. '
             '이번에는 PSYCHE 계열의 공개 프롬프트에서 발화량과 사고과정 설정을 독립적으로 바꾸고, 그 결과가 실제로 달라지는지 확인했다. '
             '공개 재구현에는 Increased 발화량을 설명하면서 주제 이탈까지 함께 지시하는 문장이 있어, 이 구절을 삭제한 비교 조건도 만들었다.', '',
             f'로컬에서 영어 응답 {summary["completed"]}개를 모두 생성했다. 발화량 Increased의 평균은 {means["Increased"]:.3f}단어, '
             f'Normal은 {means["Normal"]:.3f}단어로, 짝지은 평균 차이는 {quantity["mean_difference"]:+.3f}단어에 그쳤다. '
             f'8쌍 중 {positives}쌍은 길어졌고 {negatives}쌍은 짧아졌다. '
             '즉 이 입력·질문·백본에서는 “발화량 증가”라는 설정이 일관된 발화량 증가로 이어지지 않았다. '
             '전체 평균은 반대 방향의 조건별 효과를 섞으므로 아래 조건별 수치도 함께 보아야 한다.', '',
             f'추가 탐색적 점검에서는 사고과정만 Normal↔Derailment로 바꾼 {len(thoughts)}쌍 중 {equal_count(thoughts)}쌍에서 '
             '답변 전체가 문자 단위까지 같았다. 이 동일 출력은 임상 채점 없이 확인할 수 있는 설정 구별 실패 사례다. '
             '반대로 나머지 답변이 달랐다는 사실만으로 사고장애를 제대로 구현했다고 판단하지는 않았다.', '',
             '## 어떻게 했는가', '',
             'PatientHub 공개 구현의 영어 PSYCHE 프롬프트를 고정한 뒤, 원문과 한 구절 삭제본을 비교했다. '
             '후자는 연구자 작성 변형이며 원저 프롬프트 복원이나 검증된 개선안이 아니다. '
             'PSYCHE 원저가 사용한 GPT-4o 대신 이미 설치된 Qwen3-14B Q4_K_M을 사용했으므로 PSYCHE native replication이 아니라 로컬 prompt port다.', '',
             '- 프롬프트 2 × 발화량 Normal/Increased 2 × 사고과정 Normal/Derailment 2 × 시드 2 = 16응답.',
             '- 연구자 작성 가상 인물 1명. 과거 조현병 진단 기록과 지각 경험 등 배경은 전 조건에서 고정했다. 실제 환자나 전문가 검증 사례가 아니다.',
             '- 질문은 매번 “Tell me about your usual morning, from waking up until you get to work.”로 동일하게 했다. 각 응답은 새 대화에서 한 번만 생성했다.',
             '- 첫 생성 전에 입력·실제 요청·코드·출처 해시를 고정했다. 조건 순서는 사전에 섞고, 실패 자동 재시도·좋은 응답 선택·LLM 평가자는 사용하지 않았다.',
             '- 공개 소스 15개 해시 검증, 관련 단위 테스트 16개 통과, 응답/요청/측정값 무결성 별도 검증 완료. 잘림·빈 답·전송 오류는 0건이었다.', '',
             '## 결과를 숫자로 보면', '',
             '각 항목은 시드 2개 결과의 단어 수다. 단어는 영어 정규식으로 세었으며, 문장 수는 구두점 기반 근사치다. 임상 점수는 계산하지 않았다.', '']
    names = {'hub_unchanged': '공개 원문', 'quantity_clause_only': '한 구절 삭제'}
    for cell in summary['cells']:
        lines.append(f'- {names[cell["arm"]]} / 발화량 {cell["quantity"]} / 사고과정 {cell["thought"]}: '
                     f'{cell["words_each"]}단어 → 평균 {cell["mean_words"]:g}단어.')
    lines.extend(['',
        '원문에서 발화량을 Increased로 바꾼 평균 차이는 +6.75단어였으나, 삭제본에서는 −6단어였다. '
        '따라서 한 구절을 지웠다는 이유만으로 발화량 제어가 개선되었다고 말할 수 없다. '
        '사전 지정한 전체 차이 +0.375단어는 효과가 모든 조건에서 없었다는 뜻이 아니라 방향이 일관되지 않았다는 뜻이다.', '',
        f'사고과정만 변경했을 때 원문은 {equal_count(original)}/{len(original)}쌍, 삭제본은 {equal_count(amended)}/{len(amended)}쌍이 완전히 같은 답이었다. '
        '이 지표는 결과를 본 뒤 추가한 탐색적 무결성 점검으로, 사전 지정 결과와 구분했다. '
        '서로 다른 텍스트를 내는 것만으로 임상적 개선을 주장하지 않으며, 두 시드를 독립 환자 표본처럼 검정하지 않는다.', '',
        '## 원문 한 쌍: 사고과정 설정을 바꿨는데 답이 같았던 경우', '',
        '원문 프롬프트 / 발화량 Increased / seed 20261101에서, Thought process가 Normal인 조건과 Derailment인 조건의 답이 아래와 같이 완전히 같았다. '
        '사고장애 여부를 우리가 판정해서 얻은 결과가 아니라, 실제 입력 필드 차이와 응답 문자열을 대조한 결과다.', ''])
    equal_pair = next(r for r in thoughts if r['exact_text_equal'])
    answer = next(r['text'] for r in rows if r['id'] == equal_pair['a'])
    lines.extend(['> ' + answer, '',
        '## 이 결과로 결정할 것', '',
        '기본 실행 세팅과 첫 통제 응답 자료는 확보됐다. 그러나 지금 상태로 발화량·사고과정이 “구현됐다”고 전제해 대량 생성하거나 모델 순위를 매기는 것은 적절하지 않다. '
        '확인한 것은 이 로컬 포트에서 임상 특징의 입력 이름과 출력 변화 사이의 대응이 약하거나 불안정한 사례가 있다는 점이다. '
        '원저 PSYCHE의 GPT-4o 성능이나 실제 환자 특징에 관한 결론은 아니다.', '',
        '바로 다음 실험은 더 많은 페르소나를 생성하는 것이 아니라, **백본의 기본 지시 수행 문제와 MFC를 발화로 변환하는 문제를 나누는 작은 양성 대조군 실험**이어야 한다. '
        '예를 들어 임상 프롬프트 없이 동일 질문에 명시적 길이 범위를 지시했을 때는 길이가 분리되는지 먼저 확인한다. '
        '이 대조군은 임상 현실성 평가가 아니라 출력 제어가 가능한지 확인하는 공학적 기준이다. '
        '이것이 작동하면 MFC의 특징 이름만 있는 조건과 구체적 구현 지시가 있는 조건을 비교할 근거가 생기고, '
        '그때도 변화가 없는 경우에는 큰 실험 대신 백본/프롬프트 적합성을 재판단한다. 이번 결과를 보고 현재 v01을 수정·재실행하지는 않았다.', '',
        '사고과정의 임상적 정확성은 별도 과제다. 교수님 자문에서는 블라인드 원문 중 대표 표본을 보고 Normal/Derailment가 관찰 가능하게 구분되는지, '
        '어떤 관찰 준거를 채택할지 확인해야 한다. 팀원이 임의의 S/L/G 정답 점수를 만드는 방식은 사용하지 않는다. '
        'Roleplay-doh는 정식 접근한 개별 전문가 원칙이 확보되기 전까지 전체 모델 비교에 포함하지 않는다.', '',
        '## 재현·자료', '',
        '실행 코드와 명령은 `README.ko.md`, 조건 없는 영어 원문은 `블라인드발화.md`에 있다. '
        '전체 입력·실제 요청·원응답·측정값은 `analysis/psyche-factorial-v01/`에 보존했다. '
        '판단과 설계에는 assistant를, 생성에는 로컬 Ollama를, 집계와 해시/검증에는 로컬 Python을 썼다. 유료 모델 API 호출과 추가 다운로드는 0건이다.', '',
        '[PSYCHE 원저](https://arxiv.org/html/2501.01594v1)의 SP-Prompt-3와 Table 11은 특징을 구현하기 위한 구체적 지시/예시의 필요성을 설명한다. '
        'Table 11의 flight of ideas는 양극성장애 예시이며 조현병의 사고장애 정답으로 전용하지 않았다. '
        '[잠근 PatientHub 프롬프트](https://github.com/Sahandfer/PatientHub/blob/54d5c8761a9055a1e86d153715607ef9fa26358a/data/prompts/client/psyche.yaml)는 원저와 별도 구현이다.', ''])
    path = experiment.SHARE / '파일럿결과.md'
    path.write_text('\n'.join(lines), encoding='utf-8')
    write_json(experiment.OUT / 'report-manifest.json', {
        'report_sha256': digest(path.read_bytes()),
        'inputs': {str(p.relative_to(ROOT)): digest(p.read_bytes()) for p in [
            experiment.OUT / 'summary.json', experiment.OUT / 'measurements.json',
            experiment.OUT / 'verification.json', experiment.OUT / 'exploratory-exact-text-diagnostic.json']},
        'report_script_sha256': digest((ROOT / 'scripts/summarize_psyche_factorial.py').read_bytes())})
    print(json.dumps({'normal_mean_words': means['Normal'], 'increased_mean_words': means['Increased'],
                      'quantity_positive_pairs': positives, 'quantity_negative_pairs': negatives,
                      'thought_pairs_exact_equal': [equal_count(thoughts), len(thoughts)]}, ensure_ascii=False))


if __name__ == '__main__':
    main()
