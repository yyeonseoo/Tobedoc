"""Prepare a source-grounded thought-process protocol; default makes ZERO LLM calls.

Explicit --execute --split development runs 16 calls; holdout needs a second
explicit release flag. All 48 rendered requests are frozen before either phase.
"""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import random

from common import ROOT, digest, write_json
import psyche_controls as controls
import psyche_factorial as base
from audit_psyche_roleplay_sources import source_text, yaml_english_block, verify_sources, LOCK
from measurement_external_v03 import segment

SPEC = ROOT / 'config/psyche-thought-v01.json'
OUT = ROOT / 'analysis/psyche-thought-v01'


def read(path):
    return json.loads(path.read_text())


def make_case(item, previous):
    case = deepcopy(previous['case'])
    if item['kind'] == 'authored_case':
        identity = case['MFC-Profile']['Identifying data']
        identity.update({'Age': item['age'], 'Sex': item['sex'], 'Occupation': item['occupation']})
        case['MFC-Profile']['Developmental/social history']['Work history'] = item['work_history']
        case['MFC-History'] = item['history']
        case['MFC-Behavior']['General appearance/attitude/behavior'] = item['appearance']
    return case


def build(spec):
    previous = read(ROOT / spec['previous_case_spec'])
    constraint_spec = read(ROOT / spec['previous_control_spec'])
    template = yaml_english_block(source_text('data/prompts/client/psyche.yaml'), 'system_prompt')
    rows = []
    for item in spec['cases']:
        for arm in spec['arms']:
            for thought in spec['thought_process']:
                for question_id, question in zip(item['question_ids'], item['questions'], strict=True):
                    for seed in spec['seeds']:
                        case = make_case(item, previous)
                        case['MFC-Behavior']['Verbal productivity'] = spec['fixed_productivity']
                        case['MFC-Behavior']['Thought process'] = thought
                        case[spec['length_extension']] = constraint_spec['instruction'].format(low=spec['word_target'][0], high=spec['word_target'][1])
                        if arm == 'source_operationalized':
                            case[spec['thought_extension']] = spec['instructions'][thought]
                        elif arm != 'hub_category':
                            raise ValueError('Unknown arm')
                        prompt = template.replace('{{data.mfc}}', json.dumps(case, ensure_ascii=False, indent=2))
                        if '{{' in prompt or '}}' in prompt:
                            raise ValueError('Unresolved template')
                        payload = {'model': previous['model'], 'stream': False, 'think': False, 'keep_alive': '5m',
                                   'messages': [{'role': 'system', 'content': prompt}, {'role': 'user', 'content': question}],
                                   'options': {**previous['options'], 'seed': seed}}
                        if sum(len(m['content'].encode()) for m in payload['messages']) + previous['options']['num_predict'] + 2048 >= previous['options']['num_ctx']:
                            raise ValueError('Context guard exceeded')
                        ident = f'{item["id"]}-{arm}-{thought.lower()}-{question_id}-{seed}'
                        rows.append({'id': ident, 'split': item['split'], 'case_id': item['id'], 'arm': arm,
                                     'thought': thought, 'question_id': question_id, 'seed': seed, 'case': case,
                                     'review_subset': question_id == item['question_ids'][0] and seed == spec['seeds'][0],
                                     'payload': payload})
    random.Random(20261105).shuffle(rows)
    if len(rows) != 48:
        raise ValueError('This version is bounded to 48 requests')
    return rows


def prepare():
    spec = read(SPEC)
    verify_sources(read(LOCK))
    rows = build(spec)
    dependencies = [SPEC, ROOT / spec['previous_case_spec'], ROOT / spec['previous_control_spec'],
                    ROOT / spec['construct_notes'], LOCK, Path(__file__), Path(controls.__file__), Path(base.__file__),
                    ROOT / 'scripts/measurement_external_v03.py', ROOT / 'analysis/measurement-external-v03/results.json']
    manifest = {'protocol': spec['id'], 'input_hashes': {str(p.relative_to(ROOT)): digest(p.read_bytes()) for p in dependencies},
                'requests_sha256': base.fingerprint(rows), 'requests': len(rows),
                'development': sum(r['split'] == 'development' for r in rows),
                'holdout': sum(r['split'] == 'holdout' for r in rows),
                'proposed_review_subset': sum(r['review_subset'] for r in rows),
                'generation_automatically_started': False, 'clinical_scores': 0}
    base.save_once(OUT / 'plan.json', manifest)
    base.save_once(OUT / 'requests.json', rows)
    return spec, rows, manifest


def describe(text, target):
    count = len(base.WORDS.findall(text))
    try:
        sentence_count, error = len(segment(text)), None
    except (AssertionError, ValueError) as exc:
        sentence_count, error = None, type(exc).__name__ + ': ' + str(exc)
    return {'words': count, 'within_target': target[0] <= count <= target[1],
            'sentence_count': sentence_count, 'segmentation_error': error,
            'literal_labels': base.describe(text, {})['literal_labels']}


def analyze(spec, rows):
    measurements = []
    for row in rows:
        path = OUT / 'responses' / (row['id'] + '.json')
        if not path.exists():
            continue
        response = read(path)
        if response['request_sha256'] != base.fingerprint(row['payload']):
            raise ValueError('Request mismatch')
        text = response.get('raw', {}).get('message', {}).get('content', '')
        measurements.append({k: row[k] for k in ('id', 'split', 'case_id', 'arm', 'thought', 'question_id', 'seed')} | {
            'status': response['status'], 'text': text, **describe(text, spec['word_target'])})
    pairs = []
    for a in measurements:
        if a['thought'] != 'Normal' or a['status'] != 'completed':
            continue
        b = next((r for r in measurements if r['thought'] == 'Derailment' and r['status'] == 'completed'
                  and all(r[k] == a[k] for k in ('split', 'case_id', 'arm', 'question_id', 'seed'))), None)
        if b:
            relative = abs(a['words']-b['words']) / max(a['words'], b['words'], 1)
            pairs.append({'normal_id': a['id'], 'derailment_id': b['id'], 'arm': a['arm'], 'split': a['split'],
                          'exact_text_equal': a['text'] == b['text'], 'word_difference': b['words']-a['words'],
                          'relative_length_mismatch': relative,
                          'in_length_sensitivity_subset': a['within_target'] and b['within_target'] and relative <= .20})
    write_json(OUT / 'measurements.json', measurements)
    write_json(OUT / 'matched-pairs.json', pairs)
    print(json.dumps({'responses': len(measurements), 'matched_pairs': len(pairs), 'clinical_scores': 0}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--split', choices=['development', 'holdout'], default='development')
    parser.add_argument('--release-holdout', action='store_true')
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--analyze', action='store_true')
    args = parser.parse_args()
    spec, rows, plan = prepare()
    print(json.dumps({k: plan[k] for k in ('requests', 'development', 'holdout', 'proposed_review_subset')}))
    if args.execute:
        if args.split == 'holdout' and not args.release_holdout:
            parser.error('Holdout is sealed; explicit --release-holdout is required')
        if args.split == 'holdout':
            for row in (r for r in rows if r['split'] == 'development'):
                path = OUT / 'responses' / (row['id'] + '.json')
                if not path.exists() or read(path)['status'] != 'completed':
                    parser.error('Complete and inspect the development phase before explicitly releasing holdout')
        selected = [r for r in rows if r['split'] == args.split]
        previous_out = controls.OUT
        controls.OUT = OUT
        try:
            controls.execute(spec, read(ROOT / spec['previous_case_spec']), selected, {'cache_sources': {}}, args.resume)
        finally:
            controls.OUT = previous_out
    if args.execute or args.analyze:
        analyze(spec, rows)


if __name__ == '__main__':
    main()
