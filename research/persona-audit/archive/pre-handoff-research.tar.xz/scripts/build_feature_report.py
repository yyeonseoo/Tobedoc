"""Build a Korean result report, dictionary and a self-contained reproducibility bundle."""
import argparse
from collections import Counter
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import statistics
import subprocess
import sys
import tempfile
import zipfile

from common import ROOT, digest, write_json
from extract_automatic_features import STYLES, load_verified, mean


def number(value, digits=3):
    return "NA" if value is None else f"{value:.{digits}f}"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", default="native-features-20261030")
    args = parser.parse_args()
    folder = ROOT / "analysis/automatic-features-v01" / args.run_id
    manifest = json.loads((folder / "extraction-manifest.json").read_text())
    if manifest["completed_turns"] != 144 or manifest["dialogues"] != 36:
        raise ValueError("Completed report requires the complete 36-dialogue corpus")
    spec = json.loads((ROOT / "config/automatic-features-v01.json").read_text())
    feature_rows = [json.loads(line) for line in (folder / "features.jsonl").read_text().splitlines()]
    with (folder / "features-flat.csv").open(encoding="utf-8", newline="") as f:
        flat_rows = list(csv.DictReader(f))
    if len(flat_rows) != 144 or len(feature_rows) != 144:
        raise ValueError("Unexpected feature-matrix row count")
    verified_cells, missing_cells = 0, 0
    for rich, flat in zip(feature_rows, flat_rows):
        if rich["condition_id"] != flat["condition_id"] or rich["turn"] != int(flat["turn"]):
            raise ValueError("Flat/rich feature row identity mismatch")
        for definition in spec["features"]:
            key = definition["id"]
            value = rich["features"][key]
            if (value is None and flat[key] != "") or (value is not None and float(flat[key]) != value):
                raise ValueError("Feature CSV differs from original numeric matrix")
            verified_cells += 1
            missing_cells += int(value is None)
    profiles = json.loads((folder / "style-profiles.json").read_text())
    contrasts = json.loads((folder / "paired-contrasts.json").read_text())
    control = json.loads((folder / "metric-controls.json").read_text())["rows"]
    classifiers = json.loads((folder / "style-discrimination.json").read_text())
    first = json.loads((folder / "first-turn-sensitivity.json").read_text())
    _, _, raw, _ = load_verified(ROOT / "pilot/runs" / args.run_id)
    get = lambda style, feature: next(p for p in profiles if p["style"] == style and p["feature"] == feature)
    delta = lambda style, feature: next(p for p in contrasts if p["style"] == style and p["feature"] == feature)
    style_line = lambda feature, digits=3: " / ".join(f'{s} {number(get(s, feature)["mean"], digits)}' for s in STYLES)
    tangent = delta("tangent", "adjacent_cos_mean")
    topic = delta("tangent", "topic_answer_cos")
    tangent_first = next(c for c in first["contrasts"] if c["style"] == "tangent" and c["feature"] == "adjacent_cos_mean")
    duplicate_delta = [c["first_sentence_duplication_delta"] for c in control if c["first_sentence_duplication_delta"] is not None]
    differences = sum(r["features"]["sentence_count"] != r["sentence_count_regex_v2"] for r in
                      [json.loads(line) for line in (folder / "features.jsonl").read_text().splitlines()])
    completed = Counter(r["status"] for r in raw)
    uniqueness = len({r["response_text"] for r in raw})
    wall = sum(r["wall_seconds"] for r in raw)
    maximum_prompt = max(r["usage"].get("prompt_eval_count") or 0 for r in raw)
    lines = [
        "# 기존 페르소나 발화의 자동 feature 정량화 결과", "",
        "2026-10-30 · PATIENT-Ψ 원형 프롬프트 이식 / Qwen3-14B · 수동 등급·LLM judge 없이 계산", "",
        "## 1. 이번에 한 일", "",
        "기존 모델이 생성하는 발화의 특징을 먼저 수치화했다. 프롬프트 개선이나 사고장애 채점은 수행하지 않았다. "
        "PATIENT-Ψ의 공개 원형 6스타일(plain/upset/verbose/reserved/tangent/pleasing)을 동일한 로컬 기반 모델에서 실행했다. "
        "공개 예제의 세 상황, 상황별 두 반복, 대화당 네 턴으로 **36대화·144응답**을 확보했다. 모두 Abe 한 예제 인물에 속하므로 36명 또는 144명의 독립 환자로 세지 않는다.", "",
        "실행은 원형 demo mapping을 유지했다. 기존에 찾았던 필드 연결 문제도 이번에는 수정하지 않았다. "
        "따라서 이번 결과는 공개 코드·예제·Qwen 이식 조합의 특성이다. 원 논문의 GPT-4 실험 재현이나 여러 프레임워크 간 비교 완료를 뜻하지 않는다. "
        "이전 24응답은 추출기 점검에만 사용했고 본 분석에 섞지 않았다.", "",
        "## 2. 무엇을 계산했는가", "",
        "Python과 macOS NaturalLanguage로 17개 feature를 추출했다. 영어 문장 임베딩은 **512차원·revision 1**을 고정했고, "
        "원문·문장 경계·자동 품사/기본형·벡터와 파일 해시를 보존했다. 생성은 Qwen3-14B Q4_K_M, temperature 0.6, "
        "thinking 비활성, 문맥 16,384, 출력 상한 512토큰이었다. seed는 상황/스타일 사이에 동일하게 맞추고 반복별로 달리했다.", "",
        "- 표면·어휘·품사 8개: 단어 수, 문장 수, 문장당 단어 수, MATTR20, 고유 bigram 비율, 1인칭 단수 표현 비율, 대명사 품사 비율, Verb 태그 없는 문장 비율.",
        "- 유사도·전환 9개: 인접 문장 코사인 평균/최솟값/표준편차, 질문–응답·상황–응답 코사인, 문장 진행에 따른 상황 유사도 기울기, 인접 문장 개방형 품사 lemma Jaccard, 문장 순서 섞기 전후 차이, 이전 환자 응답과의 코사인.", "",
        "**코사인은 임베딩 공간의 의미 유사도이지 임상적 coherence 점수가 아니다.** Verb 태그 부재도 문법 오류 또는 문장 이해 불가능의 판정이 아니다. "
        "S/L/G 등급, 전문가를 대신하는 AI 판정, 임상 종합 점수는 생성하지 않았다.", "",
        "집계는 응답 → 대화 평균 → 스타일별 6대화 평균 순서다. 비교는 같은 상황·반복의 plain과 짝지었다. "
        "아래 수치는 표본 내 기술값이며 환자 모집단에 대한 p값·신뢰구간은 제시하지 않는다.", "",
        "## 3. 실제 측정 결과", "",
        "![스타일별 정량 feature 프로파일](feature-profiles.png)", "",
        "그림의 점은 대화별 평균, 막대는 해당 점들의 평균이다. 스타일당 6점은 세 상황×두 반복이며 독립적인 환자 6명이 아니다.", "",
        f"**응답당 단어 수:** {style_line('word_count', 2)}.", "",
        f"**인접 문장 코사인 평균:** {style_line('adjacent_cos_mean')}.", "",
        f"**초기 상황–응답 코사인:** {style_line('topic_answer_cos')}.", "",
        f"**고정 20단어 창의 어휘 다양도(MATTR20):** {style_line('mattr20')}.", "",
        f"tangent−plain의 인접 문장 코사인 차이는 짝지은 6블록 평균 **{number(tangent['mean_difference_from_plain'])}**이며, "
        f"낮은 블록 {tangent['negative_blocks']}/{tangent['paired_blocks']}, 높은 블록 {tangent['positive_blocks']}/{tangent['paired_blocks']}였다. "
        f"상황–응답 코사인 차이는 **{number(topic['mean_difference_from_plain'])}**였다. "
        "두 지표의 방향이 항상 같을 필요는 없다. 문장끼리의 가까움과 질문의 초기 상황에 대한 가까움은 서로 다른 계산 대상이기 때문이다.", "",
        f"첫 턴만 다시 계산한 tangent−plain의 인접 문장 코사인 차이는 **{number(tangent_first['mean_difference_from_plain'])}**였다. "
        "이는 누적 대화 이력이 없는 조건의 민감도 분석이며 별도 독립 검증 집단은 아니다.", "",
        "### 어떤 feature에 스타일별 분리가 나타났는가", "",
        "스타일 간 제곱합/전체 제곱합(기술적 η²)이 큰 항목은 다음과 같다. 이는 이 표본에서의 분리 정도이며 인과적 중요도·임상적 중요도·유의확률이 아니다.", "",
    ]
    for item in classifiers["descriptive_feature_variance"][:6]:
        lines.append(f"- `{item['feature']}`: η²={number(item['descriptive_eta_squared'])}")
    lines += ["", "### 수치만으로 알려진 스타일을 구별할 수 있는가", "",
              "추가 탐색으로, 상황 하나를 통째로 빼는 3-fold 검증에서 nearest-centroid 분류기를 사용했다. "
              "결측 대체·표준화는 매번 학습 상황에서만 계산했고 하이퍼파라미터 탐색은 하지 않았다. "
              "정답은 임상가 등급이 아니라 프로그램에 지정한 6개 스타일이다. 다수 클래스 기준 정확도는 16.7%다.", ""]
    for name, label in [("surface_8", "표면·어휘·품사 8개"), ("similarity_9", "유사도·전환 9개"), ("all_17", "전체 17개")]:
        r = classifiers["feature_sets"][name]
        lines.append(f"- {label}: 정확도 **{100*r['accuracy']:.1f}%**, macro-F1 **{r['macro_f1']:.3f}** (평가 대화 36개).")
    lines += ["", "이 분류는 프롬프트 스타일의 구별 가능성만 본다. 같은 인물의 다른 상황에 대한 작은 개발 분석이고, "
              "새 환자 일반화나 조현병 분류 성능이 아니다. 원형 지시에는 말투와 길이 상한이 묶여 있어 그 원인을 분리한 실험도 아니다.", "",
              "인접 코사인 최솟값은 비교하는 문장 쌍 수에도 영향을 받을 수 있다. 스타일별 문장 길이와 문장 수가 다르므로, "
              "수치 차이를 길이와 무관한 독립적 사고과정의 차이라고 확정하지 않는다.", "",
              "## 4. 지표 자체를 점검한 결과", "",
              f"- 문장 순서를 완전히 뒤집은 경우에도 인접 코사인 평균은 **{manifest['reversal_invariance_checks']}/{manifest['reversal_eligible']}응답**에서 수치 오차 범위 내 동일했다. "
              "코사인이 대칭이고 인접한 쌍의 집합이 유지되기 때문이다. 따라서 이 지표는 연결의 방향이나 시간적 순서를 충분히 측정하지 못한다.",
              f"- 첫 문장을 한 번 복제하면 인접 코사인 평균이 평균 **{number(mean(duplicate_delta))}** 변했다. "
              f"증가한 응답은 {sum(v > 1e-12 for v in duplicate_delta)}/{len(duplicate_delta)}개였다. 반복으로 수치를 올릴 수 있다는 기계적 민감도이며, 복제본을 실제 생성 자료로 사용하지 않았다.",
              f"- Apple 문장 경계와 이전 정규식 경계의 문장 수가 **{differences}/144응답**에서 달랐다. 원문 및 정확한 UTF-16 경계를 저장해 계산 단위를 확인할 수 있게 했다.",
              f"- MATTR20은 20단어 이상인 **{manifest['feature_eligible_turns']['mattr20']}/144응답**, 인접 코사인은 두 문장 이상인 **{manifest['feature_eligible_turns']['adjacent_cos_mean']}/144응답**에서 계산했다. 평가 불가능한 값은 0이 아닌 null로 보존했다.", "",
              "## 5. 이 결과가 말하는 것과 다음 단계", "",
              "이번 자료에서는 **길이 관련 feature의 스타일 간 분리가 가장 컸고**, "
              "tangent는 인접 문장 의미 유사도가 낮았지만 초기 상황과의 의미 유사도까지 낮아지지는 않았다. "
              "따라서 '문장 간 가까움'과 '원래 상황에 대한 가까움'을 같은 연결성 점수로 합치지 않는 것이 타당하다. "
              "또한 사용한 단순 분류기에서는 전체 17개가 표면 8개보다 잘 구분하지 못했다. 이것을 유사도 feature가 일반적으로 무용하다는 결론으로 확대할 수는 없다.", "",
              "이번에는 '누가 읽고 이상하다고 느꼈는가'가 아니라, **동일한 계산 규칙 아래 각 스타일이 어떤 수치 프로파일을 만드는가**를 확인했다. "
              "17개 중 변화가 큰 항목과 거의 변하지 않는 항목, 서로 다른 의미를 가진 유사도 지표를 구분할 수 있는 기반이 생겼다. "
              "그러나 '문장 자체는 정상이고 연결성만 저하된다'는 임상 가설을 입증한 것은 아니다. 문장 내부의 해석 가능성에 대한 검증된 자동 측정은 아직 포함하지 않았다.", "",
              "다음에는 본 결과에서 안정적으로 달라진 feature를 중심으로, 다른 페르소나 프레임워크의 원형 출력에도 같은 추출기를 적용할 수 있다. "
              "그때 기반 LLM·질문·사례·출력 제한의 차이를 기록하고 프레임워크 목적 밖의 현상을 원형의 실패로 단정하지 않는다. "
              "또한 다른 임베딩/문장 분리 방식에 대한 민감도를 확인해야 한다. 임상 현상과의 연결 또는 개선안 평가는 그 이후 단계다.", "",
              "## 재현·실행 기록", "",
              f"- 실제 완료 {completed['completed']}/144턴, 고유 응답 문자열 {uniqueness}/144개. 생성 요청 소요 시간 합계 {wall/60:.2f}분(보고서 작성·중간 확인 시간 제외).",
              f"- 최대 입력 {maximum_prompt}토큰 / 문맥 한도 16,384. 전체 원문·설정·모델 digest·입출력 해시를 보존했다.",
              "- 수동 채점 0, LLM judge 0, 유료 API 0, 추가 모델/패키지 다운로드 요청 0. 생성은 로컬 Ollama, 수치 추출은 Python/macOS에서 수행했다.",
              "- [스타일별 17개 평균 CSV](style-means.csv), [응답별 수치 CSV](features-flat.csv), [feature 전체 정의](feature-dictionary.ko.md), [원문 경계 포함 JSONL](features.jsonl), [대화별 평균](dialogue-features.json), "
              "[스타일별 프로파일](style-profiles.json), [짝지은 차이](paired-contrasts.json), [스타일 구분 분석](style-discrimination.json), [원본 검증·결측 분모](extraction-manifest.json).", "",
              "근거: [PATIENT-Ψ 원형 스타일](https://github.com/ruiyiw/patient-psi/blob/de72a768e5366d3e94f7d8c711c563fb4a5b4d26/app/api/data/patient-types.jsx), "
              "[Iter 등, 2018](https://aclanthology.org/W18-0615/), [He 등, 2026](https://pubmed.ncbi.nlm.nih.gov/41656336/), "
              "[Apple NLEmbedding](https://developer.apple.com/documentation/naturallanguage/nlembedding). "
              "문헌의 계산 취지를 참고했지만 Apple 임베딩으로의 구현은 해당 논문의 정확한 재현이 아니다.", ""]
    (folder / "report.ko.md").write_text("\n".join(lines), encoding="utf-8")
    dictionary = ["# 자동 feature 정의", "", "0.1 · 모두 관측/계산 정의이며 임상 등급이 아님. 결측은 null.", "",
                  "임베딩: Apple English sentence embedding revision 1, 512D. 문장 centroid는 각 문장 벡터를 단위 정규화한 뒤 동일 가중 평균한다. "
                  "각 대화의 feature는 평가 가능한 턴 값의 평균이다. 표본별/스타일별 계산 가능 분모를 함께 보존한다.", ""]
    for feature in spec["features"]:
        dictionary += [f"## {feature['id']}", "", f"Definition: {feature['definition']}", "", f"Unit: {feature['unit']}", ""]
    dictionary += ["## 해석 제한", "", "MATTR20은 고정 20단어 창의 표면 어휘 다양도이며 의미의 풍부함이 아니다. "
                   "대명사 비율은 지시어 모호성 점수가 아니다. Verb 태그가 없다는 것은 문법 오류의 판정이 아니다. "
                   "인접 코사인 평균/최솟값 등은 임베딩 유사도이며 임상 coherence·derailment·진단 중증도로 환산하지 않는다. "
                   "질문–응답 유사도가 낮아도 올바른 답일 수 있고, 높아도 단어 반복일 수 있다.", ""]
    (folder / "feature-dictionary.ko.md").write_text("\n".join(dictionary), encoding="utf-8")
    for link in re.findall(r"\]\(([^)]+)\)", (folder / "report.ko.md").read_text()):
        if "://" not in link and not (folder / link).is_file():
            raise ValueError(f"Broken report artifact link: {link}")
    result = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-q"], cwd=ROOT, capture_output=True, text=True)
    write_json(folder / "test-verification.json", {"timestamp": datetime.now(timezone.utc).isoformat(), "exit_code": result.returncode,
                                                  "stdout": result.stdout, "stderr": result.stderr})
    if result.returncode:
        raise ValueError("Tests failed")
    start = ROOT / "analysis/automatic-features-v01/START-HERE.ko.md"
    start.write_text(f"# 자동 feature 정량화 결과\n\n먼저 [{args.run_id}/report.ko.md]({args.run_id}/report.ko.md)를 읽는다. "
                     "수동 S/L/G 채점은 사용하지 않았다.\n\n"
                     "재계산은 프로젝트 루트에서 다음 순서로 한다. 묶음의 캐시 벡터가 있으면 새 추론·Swift 실행·인터넷 없이 계산할 수 있다.\n\n"
                     f"```bash\npython3 scripts/extract_automatic_features.py --run-id {args.run_id}\n"
                     f"python3 scripts/analyze_feature_profiles.py --run-id {args.run_id}\n```\n\n"
                     "새 발화 생성은 재집계에 필요하지 않다. `run_feature_batch.py`는 별도 로컬 생성 도구이며 기존 실행을 덮어쓰거나 모델을 자동 다운로드하지 않는다. "
                     "그림을 새로 그리려면 macOS/Swift가 필요하지만 완성 PNG를 묶음에 포함한다. "
                     "묶음에는 현재 결과에 필요한 코드·원형 예제/라이선스·원문·벡터만 들어 있고 임상 논문 원문 캐시는 포함하지 않는다.\n", encoding="utf-8")
    pairs = []
    for path in folder.iterdir():
        if path.is_file() and path.suffix in {".json", ".jsonl", ".md", ".png", ".csv"} and path.name != "archive-verification.json":
            pairs.append((path, str(path.relative_to(ROOT))))
    pairs.append((start, str(start.relative_to(ROOT))))
    scripts = ["common.py", "audit_sources.py", "prepare_pilot.py", "local_preflight.py", "run_local_pilot.py",
               "summarize_local_pilot.py", "run_feature_batch.py", "extract_automatic_features.py", "analyze_feature_profiles.py",
               "NativeFeatures.swift", "PlotFeatures.swift", "render_feature_plot.py"]
    for name in scripts:
        pairs.append((ROOT / "scripts" / name, "scripts/"+name))
    for name in ["automatic-features-v01.json", "feature-profile-analysis-v01.json", "compute-policy.json"]:
        pairs.append((ROOT / "config" / name, "config/"+name))
    for name in ["source-lock.json", "local-runtime.json"]:
        pairs.append((ROOT / "evidence" / name, "evidence/"+name))
    for name in ["psi_profiles", "psi_formatter", "psi_styles", "psi_license"]:
        relative = f"evidence/snapshots/{name}.txt"
        pairs.append((ROOT / relative, relative))
    for name in ["test_automatic_features.py", "test_feature_profiles.py"]:
        pairs.append((ROOT / "tests" / name, "tests/"+name))
    for path in sorted((ROOT / "pilot/runs" / args.run_id).rglob("*.json")):
        pairs.append((path, str(path.relative_to(ROOT))))
    archive_path = folder / "automatic-feature-results-20261030.zip"
    archive_manifest = {"files": [{"path": rel, "sha256": digest(path.read_bytes())} for path, rel in pairs]}
    with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for path, relative in pairs:
            archive.write(path, "persona-feature-results/"+relative)
        archive.writestr("persona-feature-results/archive-manifest.json", json.dumps(archive_manifest, indent=2))
    with tempfile.TemporaryDirectory(prefix="persona-feature-repro-") as task_dir:
        with zipfile.ZipFile(archive_path) as archive:
            archive.extractall(task_dir)
        unpacked = Path(task_dir) / "persona-feature-results"
        for member in archive_manifest["files"]:
            if digest((unpacked / member["path"]).read_bytes()) != member["sha256"]:
                raise ValueError("Archive hash mismatch")
        checks = []
        for command in [[sys.executable, "scripts/extract_automatic_features.py", "--run-id", args.run_id],
                        [sys.executable, "scripts/analyze_feature_profiles.py", "--run-id", args.run_id],
                        [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-q"]]:
            check = subprocess.run(command, cwd=unpacked, capture_output=True, text=True)
            checks.append({"command": command, "exit_code": check.returncode, "stdout": check.stdout, "stderr": check.stderr})
            if check.returncode:
                raise ValueError(f"Offline bundle check failed: {check.stderr}")
        regenerated = json.loads((unpacked / folder.relative_to(ROOT) / "style-profiles.json").read_text())
        if regenerated != profiles:
            raise ValueError("Reanalysis changed numeric profiles")
    write_json(folder / "archive-verification.json", {"archive": archive_path.name, "sha256": digest(archive_path.read_bytes()),
               "bytes": archive_path.stat().st_size, "checks": checks, "recomputed_profiles_equal": True,
               "verified_matrix_cells": verified_cells, "missing_matrix_cells": missing_cells,
               "manual_ratings_used": 0, "new_llm_calls_during_reanalysis": 0})
    print(json.dumps({"report": str(folder / "report.ko.md"), "archive_bytes": archive_path.stat().st_size,
                      "completed_replies": 144, "numeric_features": 17, "offline_reproduction": "passed"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
