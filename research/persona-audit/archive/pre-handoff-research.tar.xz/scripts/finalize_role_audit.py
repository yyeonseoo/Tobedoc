"""Finalize a complete, assistant-reviewed lexical candidate audit; no model judge.

The initial conservative rule remains immutable. Its counts are not promoted to
validated semantic metrics. Reviewed spans, not silent parser changes, are saved.
"""
from collections import defaultdict
from statistics import mean

from common import ROOT, digest, write_json
from role_enrichment import OUT, SPEC, read
from run_local_pilot import now


def main():
    candidates = read(OUT / 'candidate-audit.json')
    metrics = read(OUT / 'response-metrics.json')
    additions = {
        'SV-V1-QA-R8-psi_verbose-S7': ('instructor', 'Helena, who was a very encouraging and knowledgeable instructor'),
        'SV-V1-QA-R9-psi_verbose-S2': ('instructor', 'Helena, who was a very encouraging and patient instructor'),
        'SV-V1-QA-R9-simple_verbose-S2': ('participant', 'Helena, who was a fellow participant'),
        'SV-V4-QB-R8-sim_verbose-S2': ('participant', 'Adrian, a fellow participant'),
        'SV-V4-QB-R9-sim_verbose-S3': ('participant', 'Adrian, a fellow participant'),
        'SV-V4-QB-R8-psi_verbose-S1': ('participant', "Adrian, who's one of the other participants")
    }
    non_role = 'SV-V1-QB-R8-sim_verbose-S1'
    reviewed_given = {
        f'SV-{case}-Q{target}-R{seed}-{arm}'
        for case,target in [('V3','B'),('V4','A')] for seed in (8,9)
        for arm in ('neutral','simple_verbose','psi_verbose','sim_verbose','sim_concise')}
    assert len(candidates) == 27
    assert {u['id'] for u in candidates if not u['person']['roles']} == set(additions) | {non_role}
    assert {u['condition_id'] for u in candidates if u['person']['roles']} == reviewed_given
    rows = []
    for unit in candidates:
        row = {'sentence_id': unit['id'], 'condition_id': unit['condition_id'], 'sentence': unit['text'],
               'sentence_sha256': digest(unit['text'].encode()), 'person': unit['person'],
               'initial_rule_positive': bool(unit['matches']),
               'reviewer': 'assistant_source_span_audit_not_independent_human_annotation'}
        if unit['id'] in additions:
            role, span = additions[unit['id']]
            assert span in unit['text'] and not unit['person']['roles']
            row.update(label='profile_unspecified_explicit_role', canonical_role=role,
                       evidence_span=span, note='A concrete role label is added to a known person; not declared false or clinically implausible.')
        elif unit['id'] == non_role:
            assert 'field guides' in unit['text']
            row.update(label='not_a_person_role_assertion', evidence_span='collection of field guides',
                       canonical_role=None, note='Guides are books, not an attributed role of Julian.')
        else:
            assert unit['condition_id'] in reviewed_given and unit['person']['roles']
            row.update(label='profile_specified_role_reference', canonical_role=unit['person']['roles'][0],
                       evidence_span=unit['text'].strip(), note='The named instructor/speaker role is explicitly supplied in the input.')
        rows.append(row)
    additions_by_reply = {r['condition_id'] for r in rows if r['label']=='profile_unspecified_explicit_role'}
    given_by_reply = {r['condition_id'] for r in rows if r['label']=='profile_specified_role_reference'}
    reply_rows = [{**r, 'audited_role_addition': r['condition_id'] in additions_by_reply,
                   'audited_specified_role_reference': r['condition_id'] in given_by_reply} for r in metrics]
    summaries = []
    for arm in ('neutral','simple_verbose','psi_verbose','sim_verbose','sim_concise'):
        group = [r for r in reply_rows if r['style_id']==arm]
        eligible = [r for r in group if r['eligible_unspecified_role']]
        summaries.append({'arm':arm, 'eligible_replies':len(eligible),
                          'role_addition_replies':sum(r['audited_role_addition'] for r in eligible),
                          'specified_role_denominator':len(group)-len(eligible),
                          'specified_role_replies':sum(r['audited_specified_role_reference'] for r in group),
                          'case_counts': {case:sum(r['audited_role_addition'] for r in eligible if r['profile_id']==case)
                                          for case in ('V1','V2','V3','V4')}})
    blocks = defaultdict(dict)
    for row in reply_rows:
        if row['eligible_unspecified_role']:
            blocks[(row['profile_id'],row['target_event'],row['repeat_index'])][row['style_id']] = int(row['audited_role_addition'])
    contrasts = {}
    for arm, base in [('psi_verbose','simple_verbose'),('sim_verbose','simple_verbose')]:
        diffs = [{'block':list(k),'difference':v[arm]-v[base]} for k,v in sorted(blocks.items())]
        contrasts[arm+'_minus_'+base] = {'mean_difference':mean(d['difference'] for d in diffs),'blocks':diffs}
    result = {'analysis':'role-enrichment-v01', 'audit_completed_at_utc':now(),
              'candidate_sentences_reviewed':len(rows), 'total_replies_reused':80, 'total_sentences_segmented':724,
              'source_specified_role_sentences':sum(r['label']=='profile_specified_role_reference' for r in rows),
              'unspecified_role_sentences':len(additions), 'non_person_role_candidates':1,
              'summaries':summaries, 'contrasts':contrasts,
              'initial_rule_missed_audited_additions':sum(r['label']=='profile_unspecified_explicit_role' and not r['initial_rule_positive'] for r in rows),
              'initial_rule_missed_given_role_references':sum(r['label']=='profile_specified_role_reference' and not r['initial_rule_positive'] for r in rows),
              'metric_definition':'Named-person explicit event-role labels, audited inside the entire frozen name-plus-role lexical candidate set. Not all new information, not a hallucination rate, and not an independent expert assessment.',
              'sampling_warning':'The lexicon and rules were developed after examining some parent outputs. Counts are exploratory; they do not establish differences between frameworks or a population prevalence.',
              'no_patient_diagnoses':True, 'new_generation_calls':0, 'llm_judge_calls':0, 'human_ratings_fabricated':False,
              'assistant_source_span_review':True, 'independent_human_annotations':0,
              'source_hashes':{p.name:digest(p.read_bytes()) for p in [SPEC,OUT/'candidate-audit.json',OUT/'sentence-units.json']}}
    write_json(OUT/'reviewed-candidates.json',rows)
    write_json(OUT/'audited-response-metrics.json',reply_rows)
    write_json(OUT/'audited-results.json',result)
    print({'candidate_sentences':len(rows),'role_additions':len(additions), 'summaries':summaries})


if __name__=='__main__':
    main()
