"""Deterministic source checks; results are not behavioral or clinical outcomes."""
from __future__ import annotations

import csv
import json
import re

from common import ROOT, read_source, source_records, write_json


def parse_styles(source: str) -> dict:
    primary = source.split("export const patientTypeDescriptions", 1)[0]
    pairs = re.findall(r'type:\s*"([^"\\]+)"\s*,\s*content:\s*("(?:\\.|[^"\\])*")', primary)
    if len(pairs) != 6:
        raise ValueError(f"Upstream style schema changed: expected 6 styles, got {len(pairs)}")
    return {key: json.loads(value) for key, value in pairs}


def extract_template(source: str) -> str:
    match = re.search(r"const prompt = `([\s\S]*?)`;", source)
    if not match:
        raise ValueError("PATIENT-psi prompt template not found")
    return match.group(1)


def locator(source_id: str, needle: str, *, case_sensitive: bool = True) -> dict:
    text = read_source(source_id)
    offset = text.find(needle) if case_sensitive else text.lower().find(needle.lower())
    if offset < 0:
        raise ValueError(f"Expected evidence not found: {source_id}: {needle}")
    return {"source_id": source_id, "text_line": text[:offset].count("\n") + 1,
            "search_string": needle, "url": source_records()[source_id]["citation_url"]}


def main():
    profiles = json.loads(read_source("psi_profiles"))
    template = extract_template(read_source("psi_formatter"))
    styles = parse_styles(read_source("psi_styles"))
    required = sorted(set(re.findall(r"\$\{data\.([a-zA-Z_][a-zA-Z0-9_]*)\}", template)))
    field_checks = [{"profile_id": x["id"], "missing_fields": sorted(set(required) - set(x))} for x in profiles]
    findings = [
        {"id": "PSI-01", "category": "implementation", "status": "static_confirmed",
         "finding": "Provided demo contains three situations for the same named person, not three independent personas.",
         "evidence": [locator("psi_profiles", '"name": "Abe"')],
         "measured": {"records": len(profiles), "unique_names": sorted(set(x["name"] for x in profiles))}},
        {"id": "PSI-02", "category": "implementation", "status": "static_confirmed",
         "finding": "Formatter references fields absent from every provided demo profile; uploader does not rename them.",
         "evidence": [locator("psi_formatter", "data.core_belief"), locator("psi_formatter", "data.auto_thoughts"),
                      locator("psi_upload", "JSON.stringify(profile)")],
         "measured": {"required_fields": required, "profiles": field_checks},
         "limit": "Prompt-level effect can be reproduced offline; effect on generated patient behavior has not been tested."},
        {"id": "PSI-03", "category": "instruction_target_circularity", "status": "static_confirmed",
         "finding": "Tangent style explicitly prevents within-turn topic return. Low return is therefore a directly instructed outcome.",
         "evidence": [locator("psi_styles", "must not return back to topic during a turn")],
         "limit": "This does not establish clinical validity or indicate that the implementation fails its original purpose."},
        {"id": "PSI-04", "category": "instruction_tension", "status": "static_confirmed",
         "finding": "Verbose style permits up to eight sentences while the enclosing prompt limits every response to five.",
         "evidence": [locator("psi_styles", "must not exceed 8 sentences"),
                      locator("psi_formatter", "maximum of 5 sentences")],
         "limit": "Precedence in actual LLM responses is untested."},
        {"id": "PSI-05", "category": "instruction_tension", "status": "static_confirmed",
         "finding": "A shared instruction discourages disconnected responses while tangent directs unrelated-topic shifts.",
         "evidence": [locator("psi_formatter", "avoid providing abrupt or disconnected responses"),
                      locator("psi_styles", "veer off into unrelated topics")],
         "limit": "A potentially competing instruction, not proof of inability to simulate thought disorder."},
        {"id": "PSI-06", "category": "time_dynamics", "status": "static_confirmed",
         "finding": "Tangent behavior is instructed to occur on some turns and potentially improve with trust.",
         "evidence": [locator("psi_styles", "going off on tangents in some turns"),
                      locator("psi_styles", "feel better as the session goes")],
         "limit": "Conversation-related improvement must not be interpreted as an emergent therapeutic effect."},
        {"id": "PSI-07", "category": "backbone", "status": "static_confirmed",
         "finding": "Public runtime specifies gpt-4 rather than a separately released patient-model checkpoint.",
         "evidence": [locator("psi_runtime", "model: 'gpt-4'")]},
        {"id": "PSIM-01", "category": "construct_distinction", "status": "static_confirmed",
         "finding": "Dazedness includes ED-related confusion, pain fixation, memory disturbance and reassurance-dependent improvement.",
         "evidence": [locator("patientsim_dazed", "emergency situations"),
                      locator("patientsim_dazed", "reassurance from the doctor")],
         "limit": "Dazedness is not assumed to be equivalent to schizophrenia-related disorganization."},
        {"id": "PSIM-02", "category": "instruction_priority", "status": "static_confirmed",
         "finding": "PatientSim explicitly prioritizes high dazedness over personality, and imposes sentence and word limits.",
         "evidence": [locator("patientsim_patient_prompt", "Prioritize dazedness over personality"),
                      locator("patientsim_patient_prompt", "each no longer than 20 words")]},
        {"id": "PSYCHE-01", "category": "evaluation_target", "status": "paper_confirmed",
         "finding": "PSYCHE SCORE evaluates the psychiatric assessment conversational agent; it is not an off-the-shelf patient-fidelity score.",
         "evidence": [locator("psyche_paper_v1", "performance indicator for the PACA")],
         "limit": "No author-origin implementation has been established in this workspace."}
    ]
    with (ROOT / "catalog/feature-map.csv").open(encoding="utf-8", newline="") as f:
        feature_rows = list(csv.DictReader(f))
    feature_evidence = [{"feature_id": row["feature_id"], "system": row["system"],
                         "mapping_status": row["mapping_status"],
                         "evidence": locator(row["source_id"], row["locator"], case_sensitive=False)}
                        for row in feature_rows]
    write_json(ROOT / "evidence/feature-evidence.json", {
        "feature_count": len(feature_evidence), "clinical_mapping_validated": False,
        "locator_warning": "Lines refer to locked extracted text, not printed PDF pages. A locator verifies source traceability, not clinical equivalence.",
        "features": feature_evidence})
    write_json(ROOT / "evidence/static-findings.json", {
        "study_date": "2026-10-28", "upstream_code_executed": False,
        "inference_calls": 0, "clinical_validation": False,
        "style_names": list(styles), "findings": findings})
    print(f"Verified {len(findings)} source findings; no patient speech generated.")
    print(f"Checked source locators for {len(feature_evidence)} feature entries; clinical mappings remain provisional.")


if __name__ == "__main__":
    main()
