"""Prepare three actual unmodified-port replies for user-led rubric calibration.

No inference, downloads, scoring, response editing or changes to prior reports.
Source identities are separated from the review sheet, not guaranteed blinded.
"""
import json
import random

from common import ROOT, write_json
from summarize_local_pilot import analyze

RUN = "team-prototype-20261029"
FIELDS = ["sentence_interpretation_issue", "between_sentence_link_issue", "question_drift"]


def choose_examples(records):
    chosen = [r for r in records if r["arm"] == "native_demo_mapping" and r["turn"] == 1]
    if len(chosen) != 3 or {r["style_id"] for r in chosen} != {"plain", "reserved", "tangent"}:
        raise ValueError("Expected one first reply per original-port style")
    random.Random(20261030).shuffle(chosen)
    return chosen


def build_packet(records):
    selected = choose_examples(records)
    lines = ["# 세 가지 측정 정의를 맞추기 위한 실제 발화 예", "", "2026-10-30 · 새로운 생성 없음 · 점수 미입력", "",
             "목적은 모델 순위를 매기는 것이 아니라, 우리가 말하는 '연결성'의 경계를 맞추는 것이다. 아래는 기존 24응답 중 공개 원형 프롬프트 이식 조건에서 뽑은 세 개의 첫 응답이다. 같은 인물·상황이고 스타일별 한 예이므로 대표 표본이 아니다.", "",
             "제시문에서 스타일/조건 이름만 가렸다. 앞서 본 사례가 포함되므로 엄격한 눈가림 평가가 아니다. 원문을 수정하지 않았다.", "",
             "각 사례에 S/L/G를 0·1·2 또는 NA로 표시한다. 모두 자연스러우면 모두 0도 가능하다.", "",
             "- S: 단일 문장 자체를 해석하기 어려운 부분이 있는가?",
             "- L: 문장 사이 관계를 따라가기 어려운 전환이 있는가?",
             "- G: 질문이 요구하는 내용에서 벗어나는가?", "",
             "0 = 문제를 관찰하지 못함 / 1 = 애매함 / 2 = 명확한 사례 있음 / NA = 평가 불가. 1·2·NA에는 구간이나 이유를 짧게 적는다. 임상 점수가 아니라 교정용 코드다.", ""]
    answers, provenance = [], []
    for label, row in zip("ABC", selected):
        lines += [f"## {label}", "", f'Question: {row["interviewer_text"]}', "",
                  row["response_text"], "", f"응답: {label} — S=?, L=?, G=? / 근거 또는 애매한 점:", ""]
        answers.append({"example_id": label, **{field: None for field in FIELDS},
                        "evidence_or_reason": None, "annotator": None, "annotator_role": None})
        provenance.append({"example_id": label, "condition_id": row["condition_id"], "turn": row["turn"],
                           "request_sha256": row["request_sha256"], "style_id": row["style_id"], "arm": row["arm"]})
    return "\n".join(lines), answers, provenance


def main():
    _, records = analyze(ROOT / "pilot/runs" / RUN)
    packet, answers, provenance = build_packet(records)
    out = ROOT / "reviews/feature-calibration-v01"
    if out.exists():
        raise ValueError("Review folder exists; do not overwrite potential user annotations")
    out.mkdir(parents=True)
    (out / "questions.ko.md").write_text(packet, encoding="utf-8")
    write_json(out / "answers.json", {"schema_version": "0.1", "status": "awaiting_user",
               "ratings_are_clinically_validated": False, "answers": answers})
    write_json(out / "provenance.json", {"run_id": RUN, "sampling": "first turn, original demo mapping; one per style; calibration only",
               "strictly_blinded": False, "examples": provenance})
    print("Prepared 3 actual examples / 9 unanswered fields. LLM calls: 0. New generations: 0.")
    print(f"Review sheet: {out / 'questions.ko.md'}")


if __name__ == "__main__":
    main()
