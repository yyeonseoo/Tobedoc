"""Offline final checks for the two-feature report; never calls a model."""
import json
from pathlib import Path

from docx import Document

from common import ROOT, digest, write_json
from build_two_feature_report import OUT, OUTPUT


def main():
    manifest = json.loads((OUT / "report-inputs.json").read_text())
    verified = 0
    for record in manifest["inputs"]:
        path = ROOT / record["path"]
        assert digest(path.read_bytes()) == record["sha256"]
        verified += 1
        result = json.loads(path.read_text())
        for evidence in result.get("provenance", []):
            assert digest((ROOT / evidence["path"]).read_bytes()) == evidence["sha256"]
            verified += 1
    folder = ROOT / "pilot/runs/topic-selection-probe-v01"
    prepared = json.loads((folder / "prepared-at.json").read_text())
    plan = json.loads((folder / "plan.json").read_text())
    responses = [json.loads(p.read_text()) for p in (folder / "responses").glob("*.json")]
    assert len(responses) == 48 and len({r["condition_id"] for r in responses}) == 48
    assert all(r["status"] == "completed" for r in responses)
    assert prepared["prepared_at_utc"] < min(r["started_at_utc"] for r in responses)
    assert digest((ROOT / "scripts/fact_disclosure_probe.py").read_bytes()) == plan["matcher_file_sha256"]
    doc = Document(OUTPUT)
    text = "\n".join(p.text for p in doc.paragraphs) + "\n" + "\n".join(c.text for t in doc.tables for r in t.rows for c in r.cells)
    for token in ["48/48", "5/48", "22/24", "9/24", "+0.104", "Miso"]:
        assert token in text, f"Expected verified report item missing: {token}"
    pages = sorted((OUT / "qa-v1").glob("page-*.png"))
    assert len(pages) == 3 and all(p.stat().st_size > 10000 for p in pages)
    result = {"report_sha256": digest(OUTPUT.read_bytes()), "verified_input_hash_checks": verified,
              "new_topic_responses": len(responses), "all_completed": True, "plan_preceded_generation": True,
              "frozen_matcher_unchanged": True, "rendered_pages": 3, "report_values_checked": True,
              "topic_request_seconds": round(sum(r["wall_seconds"] for r in responses), 1),
              "topic_local_generated_tokens": sum(r["raw_response"].get("eval_count", 0) for r in responses),
              "paid_api_calls": 0, "clinical_ratings": 0, "new_model_downloads": 0}
    write_json(OUT / "verification.json", result)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
