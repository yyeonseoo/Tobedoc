"""Prepare 36 source-grounded prompt conditions, without calling an LLM.

Native means a prompt-level port of the pinned public formatter, not an exact
replication of the paper/webapp. The repaired arm only maps missing demo fields.
"""
from __future__ import annotations

import csv
import json
import random
import re

from audit_sources import extract_template, parse_styles
from common import ROOT, digest, read_source, source_records, write_json


class _Missing:
    pass


MISSING = _Missing()


def js_string(value):
    if value is MISSING:
        return "undefined"
    if value is None:
        return "null"
    if isinstance(value, list):
        return ",".join("" if x is None else js_string(x) for x in value)
    if isinstance(value, bool):
        return str(value).lower()
    if isinstance(value, dict):
        return "[object Object]"
    return str(value)


def repair_profile(profile: dict) -> tuple[dict, list[dict]]:
    data = dict(profile)
    changes = []
    if "core_belief" not in data:
        fields = ["helpless_belief", "unlovable_belief", "worthless_belief"]
        data["core_belief"] = [belief for key in fields for belief in profile.get(key, [])]
        changes.append({"target": "core_belief", "source_fields": fields, "operation": "concatenate existing arrays"})
    if "auto_thoughts" not in data and "auto_thought" in profile:
        data["auto_thoughts"] = profile["auto_thought"]
        changes.append({"target": "auto_thoughts", "source_fields": ["auto_thought"], "operation": "alias existing value"})
    if "intermediate_belief_depression" not in data:
        original = profile.get("intermediate_belief", "")
        marker = "[during depression]"
        if marker not in original:
            raise ValueError("No explicit depression subsection; do not invent one")
        before, after = original.split(marker, 1)
        data["intermediate_belief"] = before.strip()
        data["intermediate_belief_depression"] = after.strip()
        changes.append({"target": "intermediate_belief_depression", "source_fields": ["intermediate_belief"],
                        "operation": "split at explicit [during depression] marker; retain both parts"})
    return data, changes


def render_prompt(template: str, profile: dict, style: str) -> tuple[str, list[str]]:
    # The pinned template uses literal newlines plus escaped newline/quote sequences.
    # Decode these known syntax escapes only. Never eval JavaScript or upstream code.
    template = template.replace("\\n", "\n").replace('\\"', '"').replace("\\`", "`")
    missing = set()

    def replace(match):
        key = match.group(1)
        if key not in profile:
            missing.add(key)
        return js_string(profile.get(key, MISSING))

    prompt = re.sub(r"\$\{data\.([a-zA-Z_][a-zA-Z0-9_]*)\}", replace, template)
    prompt = prompt.replace("${patientTypeContent}", style)
    if "${" in prompt:
        raise ValueError("Unsupported upstream template expression; review source")
    return prompt, sorted(missing)


def questions(profile: dict) -> list[dict]:
    situation = profile["situation"].strip()
    return [
        {"turn": 1, "probe": "initial_narrative", "text": f"You mentioned this situation: {situation} Could you tell me what happened?"},
        {"turn": 2, "probe": "elaboration", "text": "What was going through your mind at that moment?"},
        {"turn": 3, "probe": "standardized_redirection", "text": "Returning to the situation I first asked about, what did you do next?"},
        {"turn": 4, "probe": "coping_and_continuity", "text": "How did you deal with that situation afterward?"}
    ]


def build_conditions():
    profiles = json.loads(read_source("psi_profiles"))
    styles = parse_styles(read_source("psi_styles"))
    template = extract_template(read_source("psi_formatter"))
    records = []
    for profile in profiles:
        for arm in ["native_demo_mapping", "repaired_demo_mapping"]:
            used, changes = (profile, []) if arm == "native_demo_mapping" else repair_profile(profile)
            for style_id, style_prompt in styles.items():
                prompt, missing = render_prompt(template, used, style_prompt)
                interview = questions(profile)
                payload = {"system_prompt": prompt, "interview": interview}
                fingerprint = digest(json.dumps(payload, ensure_ascii=False, sort_keys=True).encode())
                records.append({
                    "condition_id": f"A-{profile['id']}-{arm}-{style_id}",
                    "stage": "A_implementation_audit", "split": "development_only",
                    "case_family_id": "Abe", "profile_id": profile["id"], "style_id": style_id,
                    "arm": arm, "language": "en", "implementation": "prompt_level_port",
                    "is_paper_replication": False, "is_schizophrenia_case": False,
                    "profile": used, "mapping_changes": changes, "missing_fields": missing,
                    "system_prompt": prompt, "interview": interview,
                    "prompt_sha256": fingerprint,
                    "source_commit": source_records()["psi_formatter"]["commit"],
                    "backend_model_id": None, "inference_status": "not_run",
                    "response_text": None, "clinical_rating": None,
                    "repeat_index": 0,
                    "note": "Shared Abe background; situations and outputs are not independent patient samples."
                })
    return records


def main():
    records = build_conditions()
    rng = random.Random(20261028)
    rng.shuffle(records)
    out = ROOT / "pilot"
    out.mkdir(parents=True, exist_ok=True)
    with (out / "manifest.jsonl").open("w", encoding="utf-8") as f:
        for record in records:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    write_json(out / "design-summary.json", {
        "stage": "A_implementation_audit", "condition_count": len(records),
        "unique_personas": 1, "situations": 3, "styles": 6, "mapping_arms": 2,
        "turns_per_dialogue": 4, "planned_calls_per_backbone_per_repeat": len(records) * 4,
        "backbone_selected": False, "paid_inference_executed": False,
        "pilot_purpose": "test field mapping and native instruction behavior; not schizophrenia fidelity",
        "arm_difference": "Only map three missing profile fields; preserve style and output instructions in both arms.",
        "heldout_data": "none at this implementation-audit stage",
        "ordering_seed": 20261028,
        "planned_history_policy": "New session per condition; append each actual patient reply before the next fixed interviewer turn.",
        "transport_retries": "Record transport failures; never select the best of several completed responses."
    })
    write_json(out / "response-schema.json", {
        "schema_version": "0.1", "description": "Fields to record after real inference; no response records exist yet.",
        "required": ["condition_id", "prompt_sha256", "model_id_requested", "model_id_returned",
                     "provider", "generation_settings", "run_id", "turn", "request_id",
                     "started_at_utc", "status", "response_text", "finish_reason", "usage", "error"],
        "status_values": ["completed", "refused", "truncated", "transport_error", "provider_error"],
        "rules": ["Never store API keys or authorization headers.",
                  "Preserve raw returned text, including role leakage or malformed outputs.",
                  "A mock or fixture must be flagged and excluded from research results.",
                  "A seed, when supported, is not a guarantee of deterministic API output."]
    })
    with (out / "annotation-template.csv").open("w", encoding="utf-8", newline="") as f:
        csv.writer(f).writerow([
            "blind_dialogue_id", "turn", "annotator_id", "annotator_role", "evidence_quote_or_span",
            "question_relevance", "between_sentence_connectedness", "topic_return",
            "verbal_productivity", "clinical_term_leakage", "persona_fact_contradiction",
            "role_leakage", "assessability", "uncertainty", "notes"
        ])
    print(f"Prepared {len(records)} conditions / {len(records) * 4} planned turns per backbone and repeat.")
    print("Actual LLM calls: 0. Do not interpret prepared prompts as generated patient data.")


if __name__ == "__main__":
    main()
