"""Reproducible summary, per-sentence export and a directly labeled static figure."""
import json
from pathlib import Path
from statistics import mean

from PIL import Image, ImageDraw, ImageFont

from common import ROOT, digest, write_json
from topic_selection_probe import paired

OUT = ROOT / "analysis/context-topic-labeler-v01"
SHARE = ROOT / "share/topic-trajectory-v01"
STYLES = ("plain", "verbose", "tangent")
NAMES = {"plain": "기본", "verbose": "장황", "tangent": "주제 이탈"}


def read(path):
    return json.loads(path.read_text())


def figure(result):
    if result["annotated_existing_replies"] != 48:
        return None
    image = Image.new("RGB", (1100, 920), "white")
    draw = ImageDraw.Draw(image)
    path = "/System/Library/Fonts/Supplemental/Arial Unicode.ttf"
    fonts = {size: ImageFont.truetype(path, size) for size in (19, 21, 24, 28, 34)}
    ink, muted, grid = "#202B36", "#536171", "#DCE2E8"
    literal = read(ROOT / "analysis/topic-trajectory-v01/results.json")
    draw.text((44, 28), "기존 48개 답변에서 확인한 사건 전환과 복귀", fill=ink, font=fonts[34])
    draw.text((44, 78), "기본·장황·주제 이탈 지시 각 16답변  |  총 411문장", fill=muted, font=fonts[21])
    def bars(x, metric, title):
        draw.text((x, 136), title, fill=ink, font=fonts[24])
        left, top, width = x+94, 194, 310
        for tick in (0, 4, 8, 12, 16):
            xp = left+width*tick/16
            draw.line((xp, top-8, xp, top+170), fill=grid, width=1)
            draw.text((xp-9, top+182), str(tick), fill=muted, font=fonts[19])
        for i, style in enumerate(STYLES):
            s = next(s for s in literal["summaries"] if s["style"] == style)
            y = top+i*62
            draw.text((x, y+2), NAMES[style], fill=ink, font=fonts[21])
            val = s[metric]
            if val:
                draw.rectangle((left, y, left+width*val/16, y+30), fill="#315F91")
            draw.text((left+width*val/16+9, y+1), f"{val}/16", fill=ink, font=fonts[21])
        draw.text((left+110, top+216), "답변 수", fill=muted, font=fonts[19])
    bars(44, "literal_other_present", "다른 제공 사건을 언급한 답변")
    bars(590, "literal_other_then_requested", "다른 사건 뒤 원래 사건 재언급")
    draw.text((44, 488), "같은 도예 질문의 실제 문장 경로", fill=ink, font=fonts[28])
    draw.text((44, 530), "N1 / V2 / 질문 B / seed 반복 5  ·  한 칸은 원문 한 문장", fill=muted, font=fonts[21])
    colors = {"R": "#315F91", "O": "#AE5C22", "N": "#9D3644", "M": "#686D75", "U": "#E0E4E8"}
    for i, style in enumerate(STYLES):
        row = next(r for r in literal["responses"] if (r["profile_id"],r["variant_id"],r["target_event"],r["repeat_index"],r["style_id"]) == ("N1","V2","B",5,style))
        y = 585+i*57
        draw.text((44,y+2), NAMES[style], fill=ink, font=fonts[21])
        for j, sentence in enumerate(row["sentences"]):
            x, label = 170+j*39, sentence["literal_label"]
            draw.rectangle((x,y,x+33,y+34), fill=colors[label])
            draw.text((x+8,y+2),label,fill=ink if label=="U" else "white",font=fonts[21])
    labels = [("R", "원래 사건 표식"),("O", "다른 사건 표식"),("U", "표식 없음")]
    x = 44
    for label, desc in labels:
        draw.rectangle((x,775,x+25,800),fill=colors[label])
        draw.text((x+5,776),label,fill=ink if label=="U" else "white",font=fonts[19])
        draw.text((x+34,776),desc,fill=ink,font=fonts[19])
        x += {"R":280,"O":280,"U":240}[label]
    draw.text((44,834), "표식 = 사건 단어 또는 사전 정의한 장소·금액·이름 · 표식 없음은 주제 이탈 판정이 아님",fill=muted,font=fonts[19])
    draw.text((44,868), "출처: topic-trajectory-v01 · 같은 로컬 Qwen3-14B에 적용한 PATIENT-Ψ 지시 모듈",fill=muted,font=fonts[19])
    SHARE.mkdir(parents=True, exist_ok=True)
    output = SHARE / "topic-trajectory-results.png"
    image.save(output)
    return output


def main():
    path = OUT / "results.json"
    result = read(path)
    gate = result["control_gate"]
    reference_audit = read(OUT / "reference-audit.json")
    lines = ["# 페르소나 문장별 주제 흐름 분석", "", "## 실행 범위", "",
             f"기존 48답변을 411문장으로 분절했다. 문맥 보조 분류 완료는 {result['annotated_existing_replies']}답변 "
             f"{result['annotated_sentences']}문장이다. 새 환자 발화·유료 API·모델 다운로드는 없다. "
             "로컬 Qwen3-14B는 임상가가 아닌 과제 기반 주제 분류 제안자로 사용했고, 원 생성기와 동일한 모델이다.", "",
             "## 결과 해석의 결정", "",
             f"작성 대조 기준은 통과했지만 실제 원문 점검에서 {reference_audit['flagged_sentences']}문장 "
             f"{reference_audit['flagged_replies']}답변이 참조 일관성 경고에 걸렸다. 자동 분류의 N 비율·복귀율은 "
             "진단용 원시 출력으로 남기고 주 결과로 승격하지 않았다. 주 결과는 사건 표식 경로와 직접 확인 가능한 복귀 사례다.", "",
             "## 대조 문장 점검", ""]
    for phase, score in gate["scores"].items():
        lines.append(f"- {phase}: {score['items']}조건, 고유 문장 {score['unique_texts']}개, "
                     f"정확도 {score['accuracy']:.3f}, macro F1 {score['macro_f1']:.3f}, "
                     f"알려진 사건 재현율 {score['known_topic_recall']:.3f}.")
    lines += ["", "개발 및 보류 40조건은 각각 15개의 고유 문장을 네 질문 맥락에 교차한 것이다. "
              "연결 대조는 4문단 20문장이다. 보류 기준과 연결 대조 기준은 분류 요청 전에 고정했다. "
              "개발 문장에서는 두 사건이 한 문장에 함께 나오는 혼합 M 4개를 모두 놓쳤다. "
              "보류 문장에서도 M 1개를 놓쳤다. 따라서 M을 확정된 주제 이탈로 합치지 않으며 혼합 문장은 별도 검토 대상으로 보존한다.", "",
              "## 보조 분류기의 원시 결과이며 확정된 주제 이탈률이 아님", ""]
    if not gate["passed"]:
        lines += ["분류 기준 미통과로 실제 답변에 대한 확대 적용을 하지 않았다.", ""]
        (OUT / "report.ko.md").write_text("\n".join(lines))
        return
    if result["annotated_existing_replies"] != 48:
        raise ValueError("Incomplete run; no completed summary")
    for s in result["summaries"]:
        lines += [f"- {NAMES[s['style']]}: N을 포함한 답변 {s['new_topic_present']}/16, "
                  f"N 문장 비율의 답변별 평균 {100*s['mean_new_topic_sentence_fraction']:.1f}%, "
                  f"M 비율 평균 {100*s['mean_mixed_sentence_fraction']:.1f}%, "
                  f"U 비율 평균 {100*s['mean_unresolved_sentence_fraction']:.1f}%, "
                  f"R→O/N→R 경로 {s['return_after_away']}/16."]
    by_label = {style: {label: sum(s["context_label"] == label for r in result["responses"] if r["style_id"]==style for s in r["sentences"])
                        for label in ("R","O","N","M","U")} for style in STYLES}
    subgroups = {field: {value: paired([r for r in result["responses"] if r[field]==value], "tangent", "verbose", "new_topic_sentence_fraction")
                        for value in sorted({r[field] for r in result["responses"]})}
                for field in ("profile_id","variant_id","target_event")}
    contrast = result["tangent_minus_verbose"]["new_topic_sentence_fraction"]
    lines += ["", f"주제 이탈−장황의 N 비율 대응 차이는 {100*contrast['mean']:+.1f}%p이며 "
              f"16대응쌍 중 양수 {contrast['positive_blocks']}, 음수 {contrast['negative_blocks']}, 동률 {contrast['zero_blocks']}쌍이다. "
              "대응 단위는 인물·질문 대상·표현·seed이며, 두 허구 인물의 반복을 독립 환자로 세지 않았다.", "",
              "## 실제 원문과 자동 분류", ""]
    ids = ("P-N2-V2-QA-R4-tangent", "P-N1-V2-QB-R5-tangent")
    for key in ids:
        r = next(r for r in result["responses"] if r["condition_id"] == key)
        lines += [f"### {key}", "", r["question"], "", "경로 `"+r["sequence"]+"`", ""]
        lines += [f"{s['index']}. [{s['context_label']}] {s['text'].strip()}" for s in r["sentences"]]
        lines += [""]
    lines += ["## 결과가 바꾸는 선택", "",
              "정보값 검사만으로 새 이야기를 포착할 수 없다는 문제를 문장별 분석으로 보완했다. "
              "명시 표식과 문맥 분류를 구분해 저장했으므로 다른 측정기로 재검산하거나 일부 문장을 사람이 검토할 수 있다. "
              "길이·정보 언급·명시 사건 전환은 비교 가능한 수치로 확보했다. 모든 새 이야기를 포괄하는 의미 분류는 "
              "아직 고정할 수준이 아니다. 다음은 사건 밖의 새 이야기와 같은 주제의 설명 확장을 구분한 참조 과제를 보완하고, "
              "새 사건에서 확인한 뒤 공통 말투 모듈을 다른 프레임워크와 비교하는 단계다.", "",
              "## 재현", "", "`python3 scripts/run_context_topic_labeler.py --cached-only`", "",
              "`python3 scripts/summarize_topic_trajectory.py`", ""]
    (OUT / "report.ko.md").write_text("\n".join(lines))
    flat = [{"condition_id": r["condition_id"], "style": r["style_id"], **s} for r in result["responses"] for s in r["sentences"]]
    with (OUT / "sentences.jsonl").open("w") as stream:
        for item in flat:
            stream.write(json.dumps(item, ensure_ascii=False)+"\n")
    write_json(OUT / "summary-detail.json", {"per_style_label_counts": by_label, "new_topic_subgroups": subgroups,
               "source_sha256": digest(path.read_bytes()), "new_topic_comparison": contrast})
    plot = figure(result)
    print(json.dumps({"sentences_exported": len(flat), "new_topic_comparison": contrast,
                      "per_style_label_counts": by_label, "figure": str(plot)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
