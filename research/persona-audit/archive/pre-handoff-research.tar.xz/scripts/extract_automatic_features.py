"""Local deterministic/OS-neural features. No S/L/G labels, LLM judge or diagnosis.

Keeps original text, exact OS sentence spans, vectors, request hashes and missing
denominators. Semantic cosines are similarity measures, not coherence ratings.
"""
from __future__ import annotations
import argparse
from collections import Counter, defaultdict
import csv
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import random
import re
import statistics
import subprocess
import time

from common import ROOT, digest, write_json
from run_local_pilot import classify, fingerprint
from summarize_local_pilot import text_metrics, verify_turn

STYLES = ["plain", "upset", "verbose", "reserved", "tangent", "pleasing"]
SPEC = ROOT / "config/automatic-features-v01.json"


def words(text):
    return re.findall(r"[a-z0-9]+(?:['-][a-z0-9]+)*", text.lower().replace("’", "'"))


def mean(values):
    values = [v for v in values if v is not None and math.isfinite(v)]
    return statistics.mean(values) if values else None


def cosine(a, b):
    if a is None or b is None:
        return None
    if len(a) != len(b):
        raise ValueError("Embedding dimensions differ")
    denominator = math.sqrt(sum(x*x for x in a) * sum(y*y for y in b))
    if denominator == 0:
        return None
    return max(-1.0, min(1.0, sum(x*y for x, y in zip(a, b)) / denominator))


def centroid(vectors):
    if not vectors or any(v is None for v in vectors):
        return None
    dim = len(vectors[0])
    if any(len(v) != dim for v in vectors):
        raise ValueError("Embedding dimensions differ")
    unit = []
    for vector in vectors:
        norm = math.sqrt(sum(x*x for x in vector))
        if norm == 0:
            return None
        unit.append([x/norm for x in vector])
    return [sum(v[i] for v in unit)/len(unit) for i in range(dim)]


def adjacent(vectors):
    return [cosine(a, b) for a, b in zip(vectors, vectors[1:])]


def mattr(tokens, window=20):
    if len(tokens) < window:
        return None
    return mean([len(set(tokens[i:i+window]))/window for i in range(len(tokens)-window+1)])


def slope(values):
    if len(values) < 2 or any(v is None for v in values):
        return None
    xs = [i/(len(values)-1) for i in range(len(values))]
    avg = mean(values)
    return sum((x-.5)*(y-avg) for x, y in zip(xs, values))/sum((x-.5)**2 for x in xs)


def text_id(text):
    return digest(text.encode())


def load_verified(folder, allow_partial=False):
    config = json.loads((folder / "run-config.json").read_text())
    cases = json.loads((folder / "conditions.json").read_text())
    records, sources = [], []
    for case in cases:
        case["_model_digest"] = config["model_digest"]
        history = []
        for question in case["interview"]:
            stem = f'{case["condition_id"]}-T{question["turn"]}'
            path = folder / "responses" / (stem + ".json")
            if not path.exists():
                if allow_partial:
                    break
                raise ValueError(f"Missing response: {stem}")
            row = json.loads(path.read_text())
            request_path = folder / "requests" / (stem + ".json")
            verify_turn(row, json.loads(request_path.read_text()), case, history)
            if row["status"] == "completed" and classify(row["raw_response"]) != "completed":
                raise ValueError("Saved status differs from actual completion")
            row.update(situation=case["profile"]["situation"], repeat_index=case.get("repeat_index", 0))
            row["response_sha256"] = digest(row["response_text"].encode())
            records.append(row)
            sources += [{"path": str(p.relative_to(ROOT)), "sha256": digest(p.read_bytes())} for p in [path, request_path]]
            if row["status"] != "completed":
                break
            history += [{"role": "user", "content": row["interviewer_text"]},
                        {"role": "assistant", "content": row["response_text"]}]
    return config, cases, records, sources


def lexical_set(sentence):
    return {(t.get("lemma") or t["text"]).lower() for t in sentence["tokens"]
            if t.get("pos") in {"Noun", "Verb", "Adjective", "Adverb"}}


def measure(row, nlp, previous=None):
    answer = nlp[text_id(row["response_text"])]
    question = nlp[text_id(row["interviewer_text"])]
    topic = nlp[text_id(row["situation"])]
    sentences = answer["sentences"]
    vectors = [s.get("vector") for s in sentences]
    center = centroid(vectors)
    tokens = words(row["response_text"])
    pairs = adjacent(vectors)
    valid_pairs = [v for v in pairs if v is not None]
    topic_sim = [cosine(v, topic.get("vector")) for v in vectors]
    lexical = [lexical_set(s) for s in sentences]
    jaccards = [len(a & b)/len(a | b) for a, b in zip(lexical, lexical[1:]) if a | b]
    all_pos = [t.get("pos") for s in sentences for t in s["tokens"]]
    pos = [p for p in all_pos if p is not None]
    bigrams = list(zip(tokens, tokens[1:]))
    rng = random.Random(int(row["request_sha256"][:16], 16))
    shuffled = []
    if len(vectors) >= 2:
        for _ in range(100):
            order = list(vectors)
            rng.shuffle(order)
            shuffled.append(mean(adjacent(order)))
    f = {
        "word_count": len(tokens), "sentence_count": len(sentences),
        "mean_sentence_words": mean([len(words(s["text"])) for s in sentences]),
        "mattr20": mattr(tokens),
        "distinct_bigram_ratio": len(set(bigrams))/len(bigrams) if bigrams else None,
        "first_person_token_ratio": sum(t in {"i", "me", "my", "mine", "myself"} or t.startswith("i'") for t in tokens)/len(tokens) if tokens else None,
        "pronoun_pos_ratio": pos.count("Pronoun")/len(pos) if pos else None,
        "verb_absent_sentence_rate": mean([float(not any(t.get("pos") == "Verb" for t in s["tokens"])) for s in sentences
                                           if any(t.get("pos") is not None for t in s["tokens"])]),
        "adjacent_cos_mean": mean(pairs), "adjacent_cos_min": min(valid_pairs) if valid_pairs else None,
        "adjacent_cos_sd": statistics.pstdev(valid_pairs) if len(valid_pairs) >= 2 else None,
        "question_answer_cos": cosine(center, centroid([s.get("vector") for s in question["sentences"]])),
        "topic_answer_cos": cosine(center, topic.get("vector")),
        "topic_cos_slope": slope(topic_sim), "adjacent_lemma_jaccard": mean(jaccards),
        "adjacent_cos_shuffle_delta": mean(pairs) - mean(shuffled) if valid_pairs and mean(shuffled) is not None else None,
        "turn_to_previous_reply_cos": cosine(center, previous),
    }
    reversed_mean = mean(adjacent(list(reversed(vectors))))
    duplicated_mean = mean(adjacent([vectors[0]] + vectors)) if len(vectors) >= 2 else None
    control = {"condition_id": row["condition_id"], "turn": row["turn"], "actual_reply_not_replaced": True,
               "original_adjacent_cos": mean(pairs), "reversed_adjacent_cos": reversed_mean,
               "reversal_delta": reversed_mean-mean(pairs) if valid_pairs else None,
               "first_sentence_duplication_delta": duplicated_mean-mean(pairs) if duplicated_mean is not None and valid_pairs else None}
    meta = {k: row[k] for k in ["run_id", "condition_id", "profile_id", "style_id", "arm", "repeat_index", "turn", "probe",
                               "status", "response_sha256", "request_sha256"]}
    meta.update(features=f, sentence_vectors_available=sum(v is not None for v in vectors),
                pos_tag_coverage=len(pos)/len(all_pos) if all_pos else None,
                sentence_pair_count=len(pairs), sentence_count_regex_v2=text_metrics(row["response_text"])["sentence_count_heuristic"],
                sentence_spans=[{k: s[k] for k in ["text", "utf16Start", "utf16Length"]} for s in sentences])
    return meta, control, center


def summaries(rows, feature_ids):
    grouped = defaultdict(list)
    for row in rows:
        grouped[row["condition_id"]].append(row)
    dialogues = []
    for condition_id, group in grouped.items():
        head = group[0]
        dialogues.append({"condition_id": condition_id, **{k: head[k] for k in ["profile_id", "style_id", "arm", "repeat_index"]},
                          "turns": len(group), "feature_means": {f: mean([r["features"][f] for r in group]) for f in feature_ids},
                          "eligible_turns": {f: sum(r["features"][f] is not None for r in group) for f in feature_ids}})
    profiles, contrasts = [], []
    for arm in sorted({r["arm"] for r in dialogues}):
        for style in STYLES:
            group = [d for d in dialogues if d["arm"] == arm and d["style_id"] == style]
            if not group:
                continue
            for f in feature_ids:
                values = [d["feature_means"][f] for d in group if d["feature_means"][f] is not None]
                profiles.append({"arm": arm, "style": style, "feature": f, "dialogues": len(group), "eligible_dialogues": len(values),
                                 "eligible_turns": sum(d["eligible_turns"][f] for d in group), "total_turns": sum(d["turns"] for d in group),
                                 "mean": mean(values), "sd": statistics.stdev(values) if len(values) >= 2 else None,
                                 "min": min(values) if values else None, "max": max(values) if values else None})
                differences = []
                for d in group:
                    base = next((x for x in dialogues if x["arm"] == arm and x["style_id"] == "plain" and
                                 x["profile_id"] == d["profile_id"] and x["repeat_index"] == d["repeat_index"]), None)
                    if base and d["feature_means"][f] is not None and base["feature_means"][f] is not None:
                        differences.append(d["feature_means"][f] - base["feature_means"][f])
                if style != "plain":
                    contrasts.append({"arm": arm, "style": style, "feature": f, "paired_blocks": len(differences),
                                      "mean_difference_from_plain": mean(differences), "differences": differences,
                                      "positive_blocks": sum(x > 0 for x in differences), "negative_blocks": sum(x < 0 for x in differences)})
    return dialogues, profiles, contrasts


def main():
    started = time.monotonic()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--allow-partial", action="store_true")
    args = parser.parse_args()
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,70}", args.run_id):
        parser.error("Invalid run ID")
    spec = json.loads(SPEC.read_text())
    config, cases, records, sources = load_verified(ROOT / "pilot/runs" / args.run_id, args.allow_partial)
    out = ROOT / "analysis/automatic-features-v01" / args.run_id
    out.mkdir(parents=True, exist_ok=True)
    texts = {}
    for r in records:
        if r["status"] == "completed":
            for text in [r["response_text"], r["interviewer_text"], r["situation"]]:
                texts[text_id(text)] = text
    inputs = [{"id": key, "text": value} for key, value in sorted(texts.items())]
    swift = ROOT / "scripts/NativeFeatures.swift"
    cache_key = fingerprint({"inputs": inputs, "swift_sha256": digest(swift.read_bytes())})
    cache_input = out / "native-input.json"
    cache_output = out / "native-output.json"
    keyfile = out / "native-cache-key.json"
    cache_valid = False
    if cache_output.exists() and keyfile.exists():
        prior = json.loads(keyfile.read_text())
        if prior["key"] == cache_key and prior.get("output_sha256"):
            if digest(cache_output.read_bytes()) != prior["output_sha256"]:
                raise ValueError("Cached NLP output integrity mismatch; no silent replacement")
            cache_valid = True
    if not cache_valid:
        write_json(cache_input, inputs)
        binary = "/private/tmp/persona-native-features-v01"
        subprocess.run(["/usr/bin/swiftc", "-module-cache-path", "/private/tmp/persona-feature-swift-cache", str(swift), "-o", binary], check=True)
        subprocess.run([binary, str(cache_input), str(cache_output)], check=True)
        write_json(keyfile, {"key": cache_key, "output_sha256": digest(cache_output.read_bytes())})
    native = json.loads(cache_output.read_text())
    if native["embeddingRevision"] != 1 or native["embeddingDimension"] != 512:
        raise ValueError("Unexpected embedding revision/dimension; do not silently change the feature backend")
    nlp = {r["id"]: r for r in native["records"]}
    for item in inputs:
        if item["id"] not in nlp:
            raise ValueError("Missing native NLP result")
    rows, controls = [], []
    previous = {}
    for record in records:
        if record["status"] != "completed":
            continue
        row, control, center = measure(record, nlp, previous.get(record["condition_id"]))
        previous[record["condition_id"]] = center
        rows.append(row)
        controls.append(control)
    feature_ids = [f["id"] for f in spec["features"]]
    dialogues, profiles, contrasts = summaries(rows, feature_ids)
    with (out / "features.jsonl").open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    keys = ["run_id", "condition_id", "profile_id", "style_id", "repeat_index", "turn"]
    with (out / "features-flat.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=keys + feature_ids)
        writer.writeheader()
        for row in rows:
            writer.writerow({**{k: row[k] for k in keys}, **row["features"]})
    with (out / "style-means.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["style", "n_dialogues", "independent_personas"] + feature_ids)
        writer.writeheader()
        for style in STYLES:
            selected = [p for p in profiles if p["style"] == style and p["arm"] == "native_demo_mapping"]
            if selected:
                writer.writerow({"style": style, "n_dialogues": selected[0]["dialogues"], "independent_personas": 1,
                                 **{p["feature"]: p["mean"] for p in selected}})
    write_json(out / "dialogue-features.json", dialogues)
    write_json(out / "style-profiles.json", profiles)
    write_json(out / "paired-contrasts.json", contrasts)
    write_json(out / "metric-controls.json", {"label": "Algebraic/perturbation checks, not human or clinical validation", "rows": controls})
    first = [r for r in rows if r["turn"] == 1]
    _, first_profiles, first_contrasts = summaries(first, feature_ids)
    write_json(out / "first-turn-sensitivity.json", {"profiles": first_profiles, "contrasts": first_contrasts})
    manifest = {"run_id": args.run_id, "analyzed_at_utc": datetime.now(timezone.utc).isoformat(),
                "planned_turns": len(cases)*4, "recorded_turns": len(records), "completed_turns": len(rows),
                "dialogues": len(dialogues), "features": len(feature_ids), "independent_people": 1,
                "situations": len({r["profile_id"] for r in rows}), "manual_ratings_used": 0, "clinical_scores_created": 0,
                "extractor_llm_calls": 0, "model_downloads_requested": 0, "paid_api_calls": 0,
                "extraction_wall_seconds": time.monotonic()-started, "native_cache_reused": cache_valid,
                "backend": {k: native[k] for k in native if k != "records"},
                "spec_sha256": digest(SPEC.read_bytes()), "swift_sha256": digest(swift.read_bytes()),
                "native_output_sha256": digest(cache_output.read_bytes()), "verified_source_files": sources,
                "sentence_segmentation_disagreements": sum(r["features"]["sentence_count"] != r["sentence_count_regex_v2"] for r in rows),
                "feature_eligible_turns": {f: sum(r["features"][f] is not None for r in rows) for f in feature_ids},
                "pos_tag_coverage_mean": mean([r["pos_tag_coverage"] for r in rows]),
                "reversal_invariance_checks": sum(c["reversal_delta"] is not None and abs(c["reversal_delta"]) < 1e-12 for c in controls),
                "reversal_eligible": sum(c["reversal_delta"] is not None for c in controls),
                "interpretation": spec["interpretation"], "run_config": config}
    write_json(out / "extraction-manifest.json", manifest)
    print(json.dumps({k: manifest[k] for k in ["run_id", "completed_turns", "dialogues", "features", "manual_ratings_used", "extractor_llm_calls", "sentence_segmentation_disagreements"]}))
    for style in STYLES:
        selected = [p for p in profiles if p["style"] == style and p["arm"] == "native_demo_mapping" and
                    p["feature"] in {"word_count", "mattr20", "adjacent_cos_mean", "topic_answer_cos", "question_answer_cos"}]
        if selected:
            print(style, json.dumps({p["feature"]: round(p["mean"], 4) if p["mean"] is not None else None for p in selected}))


if __name__ == "__main__":
    main()
