"""Offline reproduction of every saved request, cue, reference and paired contrast."""
import argparse
import subprocess
import sys

from common import ROOT,digest,write_json
from disclosure_comparison import OUT,FOLDER,SPEC,read,conditions,measure,contrast
from disclosure_cues import check_controls
from first_reply_probe_runner import verify_response
from run_local_pilot import fingerprint


def main(report=False):
    plan,prepared=read(FOLDER/'plan.json'),read(FOLDER/'prepared-at.json')
    result,rows=read(OUT/'results.json'),read(OUT/'response-metrics.json')
    cases=conditions()
    assert len(cases)==len(rows)==result['completed_replies']==40
    assert fingerprint(plan)==prepared['plan_sha256']
    assert fingerprint(cases)==plan['conditions_sha256']
    assert digest(SPEC.read_bytes())==plan['spec_sha256']
    assert fingerprint(check_controls())==plan['controls_sha256']
    assert all(c['passed'] for c in check_controls())
    for p,sha in plan['code_at_preparation'].items():
        assert digest((ROOT/p).read_bytes())==sha,p
    for item in result['provenance']:
        assert digest((ROOT/item['path']).read_bytes())==item['sha256']
    raw_rows=[]
    for case,row in zip(cases,rows):
        stem=case['condition_id']+'.json'
        raw,request=read(FOLDER/'responses'/stem),read(FOLDER/'requests'/stem)
        verify_response(raw,request,case,plan['model_digest'])
        assert prepared['prepared_at_utc']<raw['started_at_utc']
        assert fingerprint(measure(case,raw))==fingerprint(row)
        assert raw['raw_response']['done_reason']=='stop'
        assert not raw['raw_response'].get('message',{}).get('thinking')
        raw_rows.append(raw)
    for name,value in result['contrasts'].items():
        arm,base=name.split('_minus_')
        assert fingerprint(contrast(rows,arm,base))==fingerprint(value)
    for summary in result['summaries']:
        group=[r for r in rows if r['style_id']==summary['arm']]
        assert len(group)==summary['replies']==8
        for kind in ('event','personal'):
            assert sum(r[kind+'_refs'] for r in group)==summary[kind+'_references']
        assert sum(r['nondisclosure'] for r in group)==summary['nondisclosure']
        assert sum(r['nondisclosure_with_all_personal'] for r in group)==summary['nondisclosure_with_all_personal']
    record={'completed_local_replies':40,'matched_blocks_per_arm':8,'fictional_cases':2,
            'all_requests_and_primary_metrics_reproduced':True,'cue_implementation_controls':40,
            'plan_precedes_every_generation':True,'prepared_analysis_code_unchanged':True,
            'input_output_hash_checks':len(result['provenance']),
            'max_generated_tokens':max(r['raw_response']['eval_count'] for r in raw_rows),**result['cost']}
    audit_path=OUT/'reference-audit.json'
    if audit_path.exists():
        audit=read(audit_path)
        assert {r['condition_id'] for r in audit['reviewed_responses']}=={r['condition_id'] for r in rows}
        assert set(audit['prespecified_audit_subset'])=={r['condition_id'] for r in read(OUT/'audit-candidates.json')}
        for item in audit['reviewed_responses']:
            p=FOLDER/'responses'/(item['condition_id']+'.json')
            assert digest(p.read_bytes())==item['raw_sha256']
        for item in audit['examples']:
            assert item['quote'] in read(FOLDER/'responses'/(item['condition_id']+'.json'))['response_text']
        assert len(audit['request_challenge_spans'])==16
        for item in audit['request_challenge_spans']:
            assert item['span'] in read(FOLDER/'responses'/(item['condition_id']+'.json'))['response_text']
        record.update(audited_replies=len(audit['reviewed_responses']),primary_scores_unchanged=audit['primary_scores_unchanged'])
    tests=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-q'],cwd=ROOT,capture_output=True,text=True)
    if tests.returncode:
        raise ValueError(tests.stdout+tests.stderr)
    record['unit_test_output']=tests.stderr.strip()
    share=ROOT/'share/disclosure-comparison-v02'
    if report:
        from docx import Document
        from build_disclosure_comparison_report import OUTPUT
        manifest=read(share/'report-inputs.json')
        for p,sha in manifest['inputs'].items():
            assert digest((ROOT/p).read_bytes())==sha
        assert digest(OUTPUT.read_bytes())==manifest['output_sha256']
        doc=Document(OUTPUT)
        assert len(doc.tables)>=2
        pages=list((share/'render-qa').glob('page-*.png'))
        assert len(pages) in (2,3) and all(p.stat().st_size>10000 for p in pages)
        record.update(rendered_pages=len(pages),report_sha256=digest(OUTPUT.read_bytes()))
    write_json(share/'verification.json',record)
    print(record)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report',action='store_true')
    main(parser.parse_args().report)
