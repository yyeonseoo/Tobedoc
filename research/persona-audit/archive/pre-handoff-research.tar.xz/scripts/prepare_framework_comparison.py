"""Prepare, not run, a scoped cross-source style-module comparison. Offline only."""
import json
import re
from string import Formatter

from audit_sources import parse_styles
from common import ROOT, digest, read_source, source_records, write_json

PLAN = ROOT/"config/framework-comparison-v01.json"
OUT = ROOT/"analysis/comparison-preparation-v01"


def build():
    plan = json.loads(PLAN.read_text())
    psi = parse_styles(read_source("psi_styles"))
    sim = json.loads(read_source("patientsim_personality"))
    definitions = json.loads((ROOT/plan["feature_definition_source"]).read_text())
    all_ids = [f["id"] for f in definitions["features"]]
    selected = plan["primary_descriptive_features"]+plan["exploratory_features"]
    if len(set(selected)) != 17 or set(selected) != set(all_ids):
        raise ValueError("Feature groups must cover the unchanged 17 definitions exactly once")
    modules, edits = {}, []
    for style in plan["styles"]:
        original = psi[style]
        adapted, count = re.subn(r"But you must not exceed \d+ sentences each turn\.\s*", "", original)
        if count != (1 if style == "verbose" else 0):
            raise ValueError("Unexpected upstream cap structure")
        modules[("patient_psi_style", style)] = adapted
        modules[("patientsim_style", style)] = sim[style]
        modules[("simple_baseline", style)] = "" if style == "plain" else "Give longer, more detailed answers when responding to the interviewer."
        edits.append({"program":"patient_psi_style","style":style,"source_id":"psi_styles","removed_cap_sentences":count,
                      "original_sha256":digest(original.encode()),"adapted_sha256":digest(adapted.encode())})
    rows = []
    for case in plan["cases"]:
        questions = [f"You mentioned this situation: {case['situation']} Could you tell me what happened?",
                     "What was going through your mind at that moment?",
                     "Returning to the situation I first asked about, what did you do next?",
                     "How did you deal with that situation afterward?"]
        for program in plan["programs"]:
            for style in plan["styles"]:
                prompt = (f"You are {case['family']}, a fictional adult talking with an interviewer about an everyday event. "
                          "This is not a real patient or a diagnostic assessment. Speak in English as this person.\n"
                          f"Background: {case['history']}\nSituation: {case['situation']}\n"
                          f"Thought: {case['thought']}\nEmotion: {case['emotion']}\nAction: {case['behavior']}\n"
                          "Conversation style:\n"+modules[(program, style)]+"\n"
                          "Use the supplied facts and the actual conversation history. Do not announce the style or invent a diagnosis. "
                          "Respond only with spoken words, not stage directions. "
                          f"Use at most {plan['common_sentence_limit']} sentences in each response.")
                for repeat in range(plan["repeats"]):
                    rows.append({"condition_id":f"C-{case['id']}-{program}-{style}-R{repeat}",
                        "case_id":case["id"],"case_family":case["family"],"split":case["split"],
                        "program":program,"style":style,"repeat_index":repeat,
                        "system_prompt":prompt,"prompt_sha256":digest(prompt.encode()),
                        "interview":questions,"generation_status":"not_run", "response_text":None,
                        "scope":"controlled_style_module_port_not_native_framework"})
    assert len(rows)*plan["turns"] == plan["whole_design_max_calls"]
    pilot = [r for r in rows if r["split"] == plan["pilot"]["case_split"] and r["repeat_index"] == 0]
    assert len(pilot)*plan["turns"] == plan["pilot"]["max_calls"]
    # Inspect runtime construction as text, never import or execute upstream code.
    agent = read_source("patientsim_agent")
    anchors = {
        "language_independent_axis": "self.patient_profile[\"cefr\"]",
        "recall_independent_axis": "self.patient_profile[\"memory_recall_level\"]",
        "time_dynamics_scripted": "decrease noticeably every 4-5 turns",
        "native_cap_dependency": "sentence_length_limit.json",
        "final_prompt_formatting": "self.system_prompt_text.format(**self.patient_profile)"}
    runtime_checks = [{"finding":key,"source_id":"patientsim_agent","needle":needle,
                       "line":agent[:agent.index(needle)].count("\n")+1} for key, needle in anchors.items()]
    template = read_source("patientsim_patient_prompt")
    fields = sorted({name for _, name, _, _ in Formatter().parse(template) if name})
    lock = source_records()
    cap_cached = any(r.get("path", "").endswith("/sentence_length_limit.json") and r.get("status")=="ok" for r in lock.values())
    audit = {"new_generation_calls":0,"upstream_code_executed":False,
             "comparison_scope":plan["comparison_target"],"source_edits":edits,
             "patientsim_runtime_checks":runtime_checks,"patientsim_template_fields":fields,
             "native_patientsim_execution_ready":False,
             "native_gate":["Native sentence-limit dependency is not cached" if not cap_cached else "Sentence-limit dependency cached",
                            "Full PatientAgent field assembly and output postprocessing are not ported; native run not prepared"],
             "source_provenance":[{k:lock[s][k] for k in ["id","commit","sha256","citation_url"]} for s in
                 ["psi_styles","patientsim_personality","patientsim_patient_prompt","patientsim_agent","patientsim_cefr","patientsim_recall","patientsim_dazed"]],
             "heldout_generation_executed":False,"plan_sha256":digest(PLAN.read_bytes())}
    measurement = {"definition_source":plan["feature_definition_source"],"definition_sha256":digest((ROOT/plan["feature_definition_source"]).read_bytes()),
        "features":[{**f,"analysis_role":"primary_descriptive" if f["id"] in plan["primary_descriptive_features"] else "exploratory"}
                    for f in definitions["features"]],
        "not_measured":["clinical thought disorder","sentence intelligibility","belief endorsement","factual contradiction under paraphrase","semantic repetition"],
        "analysis":plan["analysis"],"no_clinical_composite":True}
    return plan, rows, pilot, audit, measurement


def main():
    plan, rows, pilot, audit, measurement = build()
    for name, value in [("conditions.json",rows),("pilot-conditions.json",pilot),
                        ("source-audit.json",audit),("measurement-contract.json",measurement)]:
        write_json(OUT/name,value)
    report = "# 다음 단계: 공통 feature와 비교 설계"
    report += """

상태: **준비·검증 완료, 새 생성 0회. 실제 비교 결과는 아직 없음.**

## 이번에 고정한 것

- 기존 17개 feature 정의를 그대로 사용한다. 주 기술량 8개와 탐색량 9개를 구분하고 유리한 지표만 사후 선택하지 않는다. 임상 점수는 만들지 않는다.
- 첫 공통 축은 두 소스 모두 명시한 **plain/verbose**다. tangent와 dazedness를 같은 증상으로 대응시키지 않는다.
- 비교 조건은 단순 지시 대조군 / PATIENT-Ψ 스타일 지시 / PatientSim 성격 지시다. 전체 프레임워크가 아니라 **공통 프롬프트 위의 지시 모듈 비교**임을 명시한다.
- 여섯 개 허구 인물에 동일하게 완결된 사례 정보를 제공한다. 개발 세 인물과 평가 세 인물을 분리하고 평가셋은 생성하지 않는다. 실제 임상자료·원형 demo 환자자료를 사용하지 않는다.
- 기본 분석은 각 인물·프로그램·반복에서 verbose−plain 차이를 구한 뒤 그 차이를 프로그램 사이에서 비교한다. 첫 턴과 네 턴 평균을 분리한다. 일반화나 임상 품질 순위는 주장하지 않는다.

## 공정한 비교를 위해 바뀐 부분

공통 wrapper·사례·질문·이력 정책·최대 5문장 제한을 사용한다. PATIENT-Ψ 개별 문장 상한만 제거하고 원래의 일부 턴/신뢰 관련 문구는 보존한다. PatientSim에서는 personality JSON을 그대로 추출하며, 응급실 wrapper·언어능력·회상·dazedness·원형 20단어 제한을 넣지 않는다. 이 차이는 원형 실행의 재현이 아니며, 모든 변경과 해시를 기록한다. 동등한 완성 시스템 간 우열로 해석하면 안 된다.

## 실제 출처 점검에서 확인한 것

PatientAgent는 성격 JSON 하나를 그대로 보내지 않는다. 언어능력·회상·혼란 지시를 조립하고, 혼란은 4–5턴마다 감소하도록 명시한다. 따라서 이후 대화의 변화가 자발적인 임상적 변화라고 해석될 수 없다. 원형 실행에 필요한 sentence_length_limit.json은 현재 캐시에 없고 전체 조립·후처리도 이식하지 않았으므로 **원형 PatientSim 실행 준비 완료로 표시하지 않는다**. 이 제한은 지시 모듈 비교와 별개다.

## 실행 상한과 종료선

개발 세 사례·세 프로그램·두 말투·첫 반복·네 턴의 **18대화/72응답**만 첫 파일럿 후보로 준비했다. 전체 여섯 사례·두 반복까지 확장하면 72대화/288응답이며 자동 실행하지 않는다. 기존 로컬 모델과 추출기를 재사용하고 모델 다운로드·유료 API·LLM judge는 사용하지 않는다.

파일럿에서 먼저 확인할 것은 출력 잘림, 문장 제한의 바닥/천장 효과, 임베딩 계산 가능 비율과 조건별 길이 차이다. 이 문제가 비교를 지배하면 확대하지 않고 설계를 수정한다. 평가 인물은 최종 분석 규칙 고정 전 사용하지 않는다.

## 다음 실행

다음 실행 단위는 pilot-conditions.json의 72응답이다. 아직 실험 runner와 실제 응답은 생성하지 않았다. 파일럿 이후에만 최종 비교 규모를 결정한다. 지금 단계의 산출물은 구현 근거·측정 명세·고정된 비교 조건이며, 비교 성능이나 조현병 관련 임상 결론이 아니다.

재검증: `python3 scripts/prepare_framework_comparison.py`, `python3 -m unittest discover -s tests -q`.
"""
    (OUT/"report.ko.md").write_text(report+"\n",encoding="utf-8")
    print(json.dumps({"output":str(OUT),"frozen_features":17,"pilot_dialogues":len(pilot),
                      "pilot_calls":len(pilot)*4,"whole_design_calls":len(rows)*4,
                      "generation_calls":0,"native_patientsim_ready":False},ensure_ascii=False))


if __name__ == "__main__":
    main()
