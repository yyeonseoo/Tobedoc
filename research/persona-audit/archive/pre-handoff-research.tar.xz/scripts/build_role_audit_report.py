"""Concise Korean report: measured role enrichment, source scope and fixed roadmap."""
import argparse
from docx import Document
from docx.shared import Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.opc.constants import RELATIONSHIP_TYPE as RT
from docx.text.run import Run

from build_integrated_report import font, paragraph, heading, table
from build_two_feature_report import configure
from common import ROOT, digest, write_json
from role_enrichment import OUT, read

SHARE = ROOT/'share/role-enrichment-v01'
OUTPUT = SHARE/'페르소나 추가 서술 분석과 후속 비교 설계.docx'
LABELS = {'neutral':'무지시', 'simple_verbose':'단순 verbose', 'psi_verbose':'PATIENT-Ψ verbose',
          'sim_verbose':'PatientSim verbose', 'sim_concise':'PatientSim concise'}


def reference(doc, text, url):
    p = paragraph(doc,text,small=True)
    hyperlink=OxmlElement('w:hyperlink')
    hyperlink.set(qn('r:id'),p.part.relate_to(url,RT.HYPERLINK,is_external=True))
    run=OxmlElement('w:r')
    child=OxmlElement('w:t')
    child.text='  원문'
    child.set(qn('xml:space'),'preserve')
    run.append(child)
    font(Run(run,p),9.5)
    hyperlink.append(run)
    p._p.append(hyperlink)


def main(replace=False):
    if OUTPUT.exists() and not replace:
        raise ValueError('Use --replace only to repair this generated report')
    result = read(OUT/'audited-results.json')
    recheck = read(OUT/'reused-metric-checks.json')
    matrix = read(ROOT/'config/feature-comparison-roadmap-v03.json')
    literature = read(ROOT/'catalog/literature-decisions-v03.json')['sources']
    assert len(literature)==6 and len(matrix['axes'])==7
    doc = Document()
    configure(doc)
    doc.core_properties.title = '페르소나 추가 서술 분석과 후속 비교 설계'
    doc.core_properties.subject = '기존 응답 재분석과 문헌에 근거한 측정 범위 정리'
    doc.core_properties.author = '연구팀'
    doc.core_properties.comments = ''
    p=doc.add_paragraph('페르소나 추가 서술 분석과 후속 비교 설계',style='Title')
    p.paragraph_format.line_spacing=Pt(25)
    p.paragraph_format.space_after=Pt(7)
    for run in p.runs:
        font(run,18,True)
    paragraph(doc,'기존 80응답 재사용  새 생성 없이 진행한 후속 분석',bold=True)

    heading(doc,'이번에 무엇을 확인했나')
    paragraph(doc,'앞선 비교에서는 verbose 지시가 답변을 크게 늘려도 제공 정보 언급은 비슷했다. 이번에는 그 긴 답변이 입력에 없는 어떤 구체화를 포함하는지 확인했다. 허구 인물의 이름을 유지하면서 강사·참가자 같은 역할을 보충한 답변 6개를 근거 문장과 연결했다. 따라서 이름이 언급됐다는 수치와 인물 관계가 입력대로 표현됐다는 판단을 분리해야 한다.')
    paragraph(doc,'80응답을 macOS 문장 분리기로 724문장으로 나누고, 질문한 사건의 인물 이름과 정해진 역할 단어가 함께 나온 27문장을 추렸다. Python으로 원문 구간과 입력을 연결한 뒤 어시스턴트가 후보 전부를 점검했다. 20개는 입력에 명시된 역할의 재언급, 6개는 입력에 없던 역할 명시, 1개는 사람이 아니라 책을 뜻하는 field guides였다. 독립 사람 평가나 임상 채점은 아니다.')

    heading(doc,'역할이 주어지지 않은 인물의 추가 역할 명시')
    table(doc,['지시 조건','추가 역할이 나온 응답','역할이 주어진 경우 재언급'],[
        [LABELS[s['arm']],f"{s['role_addition_replies']}/{s['eligible_replies']}",
         f"{s['specified_role_replies']}/{s['specified_role_denominator']}"] for s in result['summaries']],
        [2.65,2.15,2.20],numeric=(1,2))
    paragraph(doc,'각 조건은 16응답이다. 그중 인식 대상 역할이 명시되지 않은 사건 6개 × seed 2개가 12응답, 강사·발표자가 주어진 사건 2개 × seed 2개가 4응답이다. 같은 허구 인물·사건의 반복이며 독립 환자 수가 아니다. 참가자 같은 자연스러운 보충도 포함하므로 이 빈도를 거짓 정보율로 부르지 않는다.',small=True)
    paragraph(doc,'모자이크 입력은 Helena와 함께 작업했다고만 했다. PATIENT-Ψ의 두 seed는 Helena를 instructor로, 단순 verbose의 한 seed는 fellow participant로 구체화했다. 종이접기 입력은 Adrian과 함께 앉았다고 했지만 PATIENT-Ψ 한 응답과 PatientSim 두 응답은 participant를 명시했다. 발견은 두 사건에 집중됐으므로 시스템 간 우열이나 일반적인 차이로 확대하지 않는다.')

    heading(doc,'문헌이 바꾼 판정 기준')
    paragraph(doc,'AIS와 FActScore를 참고해 문장 전체의 좋고 나쁨 대신 출처와 최소 주장을 대조하기로 했다.[1,2] PatientSim 원 논문은 프로필 일치와 프로필 밖 정보의 개연성을 별도로 평가한다.[4] 따라서 이번 엄격한 제공 사실 제한 과제에서의 추가 역할 명시는 원형 PatientSim의 결함 판정이 아니다. PATIENT-Ψ의 원래 평가 목표도 CBT 훈련이다.[3]')

    doc.add_page_break()
    heading(doc,'추가 서술을 판정하는 방법')
    paragraph(doc,'한 문장에 주어진 사실과 새 설정이 섞이면 최소 주장으로 나눈다. 예를 들어 I worked with Helena, who was an encouraging instructor에서 함께 작업했다는 부분, 격려를 받았다는 평가, 강사라는 역할을 별도로 본다. 하나의 사실이 맞는다는 이유로 문장 전체가 입력에 충실하다고 판정하지 않는다.')
    paragraph(doc,'각 주장에는 종류와 출처 관계, 발화 방식을 따로 기록한다. 종류는 구체적 사건·프로필 정보 / 주관적 평가·감정 / 대화 행위 / 판단 불가다. 출처 관계는 뒷받침됨 / 명시적 모순 / 입력에 명시되지 않음 / 판단 불가다. 발화 방식은 단정·부정·추측·인용·질문으로 구분한다. 입력에 없다는 이유만으로 거짓이나 임상적 이상이라고 하지 않는다.')
    paragraph(doc,'이 기준은 자체 개발 지침이다. 조건 이름을 가린 25문장과 입력·문맥을 팀 검토용으로 준비했으며 모든 평가 칸은 비워 두었다. 문체가 조건을 드러낼 수 있어 완전한 블라인드는 아니다. 두 사람이 독립 표기하기 전에는 일치도나 자동 분류 정확도를 보고하지 않는다.')

    heading(doc,'비교할 특징과 범위를 고정했다')
    table(doc,['특징','비교 범위','현재 상태와 다음 측정'],[
        ['발화량','두 소스 verbose','공통 대조군 80응답 비교 완료'],
        ['정보 공개와 의심','reserved와 distrust의 부분 겹침','다음 공통 비교  간결함과 거절을 분리'],
        ['질문과 주제 유지','PATIENT-Ψ tangent 내부','기존 원문 활용  의미 유사도는 기술량'],
        ['우려와 증상의 축소','두 소스 pleasing의 부분 겹침','같은 이름보다 실제 축소 지시를 비교'],
        ['제공 정보와 추가 서술','스타일이 아닌 공통 과제 조건','이번 역할 분석으로 범위를 제한해 종료'],
        ['회상과 언어능력','PatientSim 고유 축','추후 별도 평가  사고장애와 구분'],
        ['면담 중 변화','서로 다른 지시된 변화','후순위  지시된 변화를 치료 효과로 해석하지 않음']
    ],[1.65,2.25,3.10])
    paragraph(doc,'7개 축의 판단은 고정 소스의 13개 근거 구간과 연결했다. tangent와 응급실 dazedness를 같은 특징으로 맞추지 않았고, reserved와 distrust도 동일한 성격이라고 가정하지 않았다. 고유 특징을 억지로 공통 순위에 넣지 않는다.',small=True)

    heading(doc,'자동 규칙은 점검 보조로 사용한다',2)
    paragraph(doc,'보수적 역할 규칙은 작성 대조 예 24개를 통과했지만, 실제 후보에서 축약형 who\'s를 놓쳤고 역할이 이름 앞에 나오는 표현도 포괄하지 못했다. 최종 표는 자동 규칙의 결과가 아니라 27개 후보를 모두 점검한 집계다. 규칙·초기 결과·보정 근거를 각각 보존했고, 이 규칙을 전체 추가 정보의 자동 평가기로 확대하지 않았다.')

    doc.add_page_break()
    heading(doc,'다음 실행 순서와 연구의 기여')
    paragraph(doc,'정보 과잉 공개와 선택적 공개는 이미 PWP 등에서 연구되고 있다.[6] 이번 연구가 이를 처음 발견했다고 주장하지 않는다. 우리 팀의 목표는 공개 지시와 실제 발화의 대응을 확인하고, 과제·출력 길이·기반 모델의 영향을 분리한 뒤, 근거가 있는 실패 하나를 개선해 검증하는 것이다.')
    paragraph(doc,'첫째, 추가 서술 분석은 이번 보조 분석으로 마무리한다. 제공한 25문장은 기준 교정에만 쓰고 대규모 새 라벨링을 선행조건으로 삼지 않는다. 둘째, 간결함·정보 생략·명시적 거절을 구별하는 오프라인 대조 예를 만든 뒤 다음 공통 축인 정보 공개와 의심 표현을 비교한다. 설계를 고정한 후 최대 48개의 첫 응답을 로컬에서 생성하는 안을 다음 실행 단위로 둔다. 이번 단계에서 새 생성은 하지 않았다.')
    paragraph(doc,'셋째, 질문과 주제 유지의 지표를 점검한 뒤 기존 tangent 원문에 적용한다. 평균 인접 코사인 유사도는 단독 연결성 지표로 사용하지 않는다. 이전에 이미 수행한 144응답 대조 검증을 저장된 벡터로 재현한 결과, 문장 전체를 역순으로 바꿔도 144/144에서 값이 같았고 첫 문장을 복제하면 144/144에서 값이 증가했다. 복제에 따른 평균 증가는 0.1114였다. 새 실험이나 임상 판정이 아니라 기존 계측 성질의 재확인이다.')
    paragraph(doc,'관련 임상 연구도 의미 유사도와 사람이 평가한 연결성을 동일시하기 어렵다고 보고한다.[5] 따라서 순서·질문 맥락에 반응하는 측정 후보를 별도 대조 자료에서 점검한다. 교수님 자문은 이런 관찰과 임상 구성개념의 연결에 집중하고, 대량 중증도 채점을 전제하지 않는다. 마지막으로 안정적으로 반복되는 문제 하나만 수정해 사용하지 않은 사례에서 원형과 비교한다.')

    heading(doc,'실행 비용과 재현 자료')
    paragraph(doc,'이번 작업은 기존 원문·벡터를 재사용했다. 새 Ollama 생성, 별도 자동 LLM judge 호출, 유료 API, 모델 다운로드는 모두 0회다. 어시스턴트의 문헌 검토와 후보 문장 근거 대조는 포함되므로 전체 AI 토큰 사용이 0이라는 뜻은 아니다. 112개 테스트, 원문 724구간, 현재 분석의 요청·응답 160개와 기존 대조 검증의 288개 파일을 재확인했다.')
    paragraph(doc,'집계와 근거  analysis/role-enrichment-v01\n판정 지침  catalog/additional-narrative-codebook-v01.ko.md\n비교 범위  config/feature-comparison-roadmap-v03.json\n재현  python3 scripts/role_enrichment.py analyze\n후보 집계  python3 scripts/finalize_role_audit.py\n검증  python3 scripts/verify_role_audit.py --report',small=True)

    heading(doc,'참고 문헌',2)
    references = [
        '[1] Rashkin et al. AIS. Computational Linguistics, 2023.',
        '[2] Min et al. FActScore. EMNLP, 2023.',
        '[3] Wang et al. PATIENT-Ψ. EMNLP, 2024.',
        '[4] Kyung et al. PatientSim. NeurIPS, 2025. Sec. 6.1, App. D.',
        '[5] He et al. Scientific Reports, 2026. doi:10.1038/s41598-026-39025-1',
        '[6] Schlager et al. Patients With Personality. arXiv:2606.17441v1, 2026. 프리프린트.'
    ]
    for text, source in zip(references,literature):
        reference(doc,text,source['url'])
    paragraph(doc,'6편의 1차 자료를 목표 지향적으로 검토했으며 체계적 문헌고찰이나 신규성 확정은 아니다. He 등은 초록·그림 설명, PWP는 프리프린트 본문을 확인했다. 문헌별 확인 범위와 적용 결정은 literature-decisions-v03.json에 보존했다.',small=True)
    SHARE.mkdir(parents=True,exist_ok=True)
    doc.save(OUTPUT)
    inputs = [OUT/'audited-results.json',OUT/'reviewed-candidates.json',OUT/'reused-metric-checks.json',
              ROOT/'catalog/additional-narrative-codebook-v01.ko.md',ROOT/'config/feature-comparison-roadmap-v03.json',
              ROOT/'catalog/literature-decisions-v03.json',OUT/'feature-source-locators.json']
    write_json(SHARE/'report-inputs.json',{'inputs':{str(p.relative_to(ROOT)):digest(p.read_bytes()) for p in inputs},
                                       'output_sha256':digest(OUTPUT.read_bytes())})
    print(str(OUTPUT))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--replace',action='store_true')
    main(parser.parse_args().replace)
