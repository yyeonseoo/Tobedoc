"""Reuse native outputs, then compare requested/unrequested event markers locally."""
import argparse
import json
import random
import re
from collections import defaultdict
from statistics import mean

from audit_sources import parse_styles
from build_feature_audit import build as build_native_audit
from common import ROOT, digest, read_source, source_records, write_json
from fact_disclosure_probe import match_fact, normalize
from first_reply_probe_runner import run, verify_response
from reserved_length_factorial import question_paragraph_flag
from run_local_pilot import OPTIONS, fingerprint, now
from summarize_local_pilot import text_metrics

SPEC = ROOT / "config/topic-selection-probe-v01.json"
RUN = "topic-selection-probe-v01"
FOLDER = ROOT / "pilot/runs" / RUN
OUT = ROOT / "analysis" / RUN
STYLES = ["plain", "verbose", "tangent"]


def native_review():
    audit = build_native_audit()
    selected = [r for r in audit["styles"] if r["style"] in STYLES]
    result = {"source": "native-features-20261030", "existing_replies": 144,
              "styles_relevant_here": 3, "replies_in_three_selected_styles": 72,
              "new_generation": 0, "styles": selected,
              "decision": "The same Abe biography appears across three related situations. No disjoint requested/other-event fact labels exist. Do not retroactively invent an off-topic gold standard.",
              "measured_only": "Existing semantic similarity and length profiles; not a clinical tangentiality score",
              "provenance": audit["provenance"]}
    write_json(OUT / "native-review.json", result)
    return result


def conditions():
    spec = json.loads(SPEC.read_text())
    original = parse_styles(read_source("psi_styles"))
    styles = {}
    for style in STYLES:
        styles[style], count = re.subn(r"But you must not exceed \d+ sentences each turn\.\s*", "", original[style])
        if count != (0 if style == "plain" else 1):
            raise ValueError("Unexpected source style cap")
    blocks = [(c, v, t, r) for c in spec["fictional_cases"] for v in spec["question_variants"]
              for t in ("A", "B") for r in spec["repeat_indices"]]
    rng = random.Random(20261030)
    rng.shuffle(blocks)
    rows = []
    for case, variant, target, repeat in blocks:
        group = []
        question = variant["template"].format(event=case["events"][target])
        for style in STYLES:
            prompt = (f"You are {case['name']}, a fictional adult. This is a simulation, not a real patient or diagnosis.\n"
                      "The following events occurred on different days. No causal connection between them is specified.\n"
                      + "\n".join(f["description"] for f in case["facts"]) + "\nConversation style:\n" + styles[style]
                      + "\nUse only the supplied facts. Do not invent a diagnosis. Respond in natural English as this person. "
                      "Write only this person's reply, not interviewer turns or stage directions.")
            row = {"condition_id": f"P-{case['id']}-{variant['id']}-Q{target}-R{repeat}-{style}", "profile_id": case["id"],
                   "variant_id": variant["id"], "target_event": target, "repeat_index": repeat, "style_id": style, "arm": style,
                   "system_prompt": prompt, "facts": case["facts"], "interview": [{"turn": 1, "probe": "requested_event_details", "text": question}]}
            row["prompt_sha256"] = fingerprint({"system_prompt": prompt, "interview": row["interview"]})
            group.append(row)
        rng.shuffle(group)
        rows.extend(group)
    if len(rows) != spec["max_requests"] or len(rows) != 48:
        raise ValueError("Request ceiling changed")
    return rows


def prepare():
    rows = conditions()
    plan = {"run_id": RUN, "max_requests": 48,
            "scope": "Two invented adults, two events per person; two targets x two phrasings x two seeds x three source style ports",
            "source_behaviors": ["Tangent: starts answering then veers to unrelated topics", "Tangent: no within-reply return after veering", "Verbose: detailed/elaborate responses, not necessarily irrelevant"],
            "intervention": "Remove only source numeric sentence caps from verbose/tangent. No enclosing sentence cap. Same facts, question and seed within style comparisons.",
            "primary": "Paired tangent-minus-verbose fraction of the three unrequested-event facts with recognized literal mentions",
            "secondary": "Requested-event fact coverage versus plain; unrequested share of all recognized facts; word counts; other-event marker followed by requested-event marker",
            "decision_rule": {"primary_at_least": 1/3, "positive_in_each_case": True, "positive_in_each_wording": True, "positive_for_both_targets": True,
                              "meaning": "Require all for a consistent extra unrequested-fact signal beyond verbose in this task. One of three facts is a pragmatic descriptive boundary, not a clinical cutoff or powered test."},
            "direction_before_generation": "Tangent may mention more supplied unrequested-event facts than verbose. Null/opposite directions are retained; no success is assumed.",
            "measurement": "Unchanged finite-alias matcher; detects supplied fact values, not semantic topic boundaries, logical coherence, factual endorsement or clinical thought disorder. Novel tangents outside the supplied facts are not measured.",
            "aggregation": "16 case-by-target-by-wording-by-seed paired blocks. No patient-population p-values. Facts within a reply and seeds within a case are not independent people.",
            "limitations": "Marker return is a sequence proxy, not a clinical or semantic return judgment; differing answer length is not experimentally held equal; original trust dynamics and normal-turn allowance remain in source styles.",
            "stopping": "48 first replies maximum, no retries or replacement, preserve failed/truncated outputs and stop; no post-result prompt or alias tuning",
            "options": OPTIONS, "think": False, "seed_rule": "20261030 + 100*repeat_index + 1; repeat indices 4 and 5",
            "model_digest": json.loads((ROOT / "evidence/local-runtime.json").read_text())["ollama"]["candidate_metadata"]["digest"],
            "spec_sha256": digest(SPEC.read_bytes()), "conditions_sha256": fingerprint(rows),
            "matcher_file_sha256": digest((ROOT / "scripts/fact_disclosure_probe.py").read_bytes()),
            "source_url": source_records()["psi_styles"]["citation_url"]}
    for name, obj in [("plan.json", plan), ("conditions.json", rows)]:
        path = FOLDER / name
        if path.exists():
            if json.loads(path.read_text()) != obj:
                raise ValueError("Frozen topic probe changed")
        else:
            write_json(path, obj)
    if not (FOLDER / "prepared-at.json").exists():
        write_json(FOLDER / "prepared-at.json", {"prepared_at_utc": now(), "plan_sha256": fingerprint(plan)})
    return plan, rows


def event_metrics(text, facts, target):
    hits = [match_fact(text, f) for f in facts]
    requested = [f for f in hits if f["domain"] == target]
    other = [f for f in hits if f["domain"] != target]
    r, o = sum(f["recognized_mention"] for f in requested), sum(f["recognized_mention"] for f in other)
    requested_positions = [h["normalized_start"] for f in requested for h in f["matches"]]
    other_positions = [h["normalized_start"] for f in other for h in f["matches"]]
    return {"requested_count": r, "other_count": o, "requested_fraction": r/3, "other_fraction": o/3,
            "other_share_of_matched_facts": o/(r+o) if r+o else None,
            "other_then_requested_marker": bool(other_positions and requested_positions and max(requested_positions) > min(other_positions)),
            "marker_class": "both" if r and o else "requested_only" if r else "other_only" if o else "neither",
            "fact_matches": hits}


def paired(rows, style, baseline, metric):
    blocks = defaultdict(dict)
    for row in rows:
        if row["style_id"] in (style, baseline):
            blocks[(row["profile_id"], row["target_event"], row["variant_id"], row["repeat_index"])][row["style_id"]] = row[metric]
    differences = []
    for values in blocks.values():
        if set(values) != {style, baseline}:
            raise ValueError("Incomplete paired block")
        if values[style] is not None and values[baseline] is not None:
            differences.append(values[style]-values[baseline])
    if not differences:
        return {"mean": None, "eligible_blocks": 0, "differences": []}
    return {"mean": mean(differences), "eligible_blocks": len(differences), "differences": differences,
            "positive_blocks": sum(d > 0 for d in differences), "negative_blocks": sum(d < 0 for d in differences), "zero_blocks": sum(d == 0 for d in differences)}


def analyze():
    plan, cases = prepare()
    native = native_review()
    rows, files = [], [SPEC, FOLDER / "plan.json", FOLDER / "conditions.json", FOLDER / "prepared-at.json", FOLDER / "runtime.json"]
    for case in cases:
        rp = FOLDER / "requests" / (case["condition_id"] + ".json")
        sp = FOLDER / "responses" / (case["condition_id"] + ".json")
        raw, request = json.loads(sp.read_text()), json.loads(rp.read_text())
        verify_response(raw, request, case, plan["model_digest"])
        tm = text_metrics(raw["response_text"])
        rows.append({**{k: case[k] for k in ["condition_id", "profile_id", "target_event", "variant_id", "repeat_index", "style_id"]},
                     **event_metrics(raw["response_text"], case["facts"], case["target_event"]), "word_count": tm["word_count"],
                     "text_metrics": tm, "response_text": raw["response_text"], "question": case["interview"][0]["text"],
                     "question_paragraph_flag": question_paragraph_flag(raw["response_text"])})
        files += [rp, sp]
    primary = paired(rows, "tangent", "verbose", "other_fraction")
    if len(rows) != 48 or primary["eligible_blocks"] != 16:
        raise ValueError("Incomplete topic probe")
    subgroups = {field: {key: paired([r for r in rows if r[field] == key], "tangent", "verbose", "other_fraction")
                        for key in sorted({r[field] for r in rows})} for field in ["profile_id", "variant_id", "target_event"]}
    passed = primary["mean"] >= plan["decision_rule"]["primary_at_least"] and all(v["mean"] > 0 for g in subgroups.values() for v in g.values())
    summaries = []
    for style in STYLES:
        group = [r for r in rows if r["style_id"] == style]
        summaries.append({"style": style, "replies": len(group), "fact_denominator_per_event": len(group)*3,
                          "requested_mentions": sum(r["requested_count"] for r in group), "other_mentions": sum(r["other_count"] for r in group),
                          "mean_words": mean(r["word_count"] for r in group),
                          "marker_class_counts": {c: sum(r["marker_class"] == c for r in group) for c in ["requested_only", "other_only", "both", "neither"]},
                          "replies_with_other_markers": sum(r["other_count"] > 0 for r in group),
                          "other_then_requested_marker": sum(r["other_then_requested_marker"] for r in group)})
    # Non-exhaustive literal observations added AFTER seeing the outputs.
    # These do not change aliases, primary scores or decision boundaries.
    literal_notes = []
    cases_by_id = {c["condition_id"]: c for c in cases}
    for row in rows:
        text = normalize(row["response_text"])
        case = cases_by_id[row["condition_id"]]
        if "miso" in text and "miso" not in normalize(json.dumps(case["facts"])):
            literal_notes.append({"condition_id": row["condition_id"], "observation": "The reply contains the unsupplied name Miso",
                                  "other_markers_detected": row["other_count"], "scope": "Targeted lexical illustration, not a hallucination or clinical topic score"})
        cue = "get back to the pottery class"
        if row["profile_id"] == "N1" and row["target_event"] == "B" and cue in text:
            position = text.index(cue)
            earlier_other = any(h["normalized_start"] < position for f in row["fact_matches"]
                                if f["domain"] != row["target_event"] for h in f["matches"])
            literal_notes.append({"condition_id": row["condition_id"], "observation": "Literal get-back-to-pottery-class phrase",
                                  "other_event_marker_precedes_cue": earlier_other,
                                  "fact_marker_return_flag": row["other_then_requested_marker"],
                                  "scope": "Targeted return-expression illustration, not a semantic return rating or violation rate"})
    result = {"plan": plan, "actual_replies": len(rows), "primary": primary, "decision_rule_met": passed,
              "requested_tangent_minus_plain": paired(rows, "tangent", "plain", "requested_fraction"),
              "word_count_tangent_minus_verbose": paired(rows, "tangent", "verbose", "word_count"),
              "other_share_tangent_minus_verbose": paired(rows, "tangent", "verbose", "other_share_of_matched_facts"),
              "subgroups": subgroups, "summaries": summaries, "responses": rows,
              "posthoc_literal_observations": literal_notes,
              "provenance": [{"path": str(p.relative_to(ROOT)), "sha256": digest(p.read_bytes())} for p in files]}
    write_json(OUT / "results.json", result)
    lines = ["# 질문한 사건과 다른 사건 정보의 언급 비교", "",
             "## 출발 질문", "", "tangent 설정은 질문한 사건에서 다른 사건으로 이동하게 하는가, 아니면 장황한 설명과 구분하기 어려운가?", "",
             "## 기존 자료에서 확인한 것", "",
             "기존 144개 원문과 수치의 연결을 재검증하고 plain·verbose·tangent의 72개 응답을 대조했다. "
             "같은 인물의 기억과 세 상황이 겹쳐 ‘질문하지 않은 사건 정보’의 분리된 정답표를 소급해 만들지 않았다. 인접 문장 의미 유사도 감소를 임상적 주제 이탈로 판정하지 않는다.", ""]
    for s in native["styles"]:
        m = s["mean"]
        lines.append(f"- {s['style']}: 평균 {m['word_count']:.2f}단어, 인접 유사도 {m['adjacent_cos_mean']:.3f}, 질문 유사도 {m['question_answer_cos']:.3f}.")
    lines += ["", "## 새 통제 실험", "",
              "허구 인물 2명에게 서로 다른 날의 사건 두 개를 주고, 사건별 고유 장소·금액·동행인 이름을 설정했다. 한 사건의 세 정보만 질문했다. "
              "두 질문 대상·두 질문 표현·두 seed·세 말투를 완전 교차해 총 48개 첫 답변을 생성했다. 원본 verbose/tangent의 숫자 문장 제한만 제거하고 "
              "그 외 지시를 유지했다. 임상 평가·LLM judge는 사용하지 않았다.", ""]
    for s in summaries:
        lines.append(f"- {s['style']}: 질문한 사건 {s['requested_mentions']}/{s['fact_denominator_per_event']}, 다른 사건 {s['other_mentions']}/{s['fact_denominator_per_event']} 항목 식별; "
                     f"평균 {s['mean_words']:.1f}단어; 다른 사건 표식이 나온 응답 {s['replies_with_other_markers']}/{s['replies']}.")
    lines += ["", f"다른 사건 정보 언급 비율의 tangent−verbose 대응 차이: {primary['mean']:+.3f}. "
              f"증가 {primary['positive_blocks']}/16, 감소 {primary['negative_blocks']}/16, 동일 {primary['zero_blocks']}/16블록.", "",
              "생성 전 결정선은 평균 +1/3 이상이면서 두 인물·두 표현·두 질문 대상 각각에서 같은 방향의 차이가 나타나는 것이었다. "
              f"결정선 충족: {'예' if passed else '아니오'}. 이는 기술적 운영 기준이며 임상적 사고장애의 기준이 아니다.", "",
              "## 해석", "",
              ("이 과제에서는 tangent가 verbose보다 주어졌지만 질문하지 않은 다른 사건의 정보를 더 많이 언급하는 패턴이 결정선을 충족했다. " if passed else
               "이 과제에서는 tangent를 verbose와 구분하는 일관된 다른 사건 정보 증가가 사전 결정선을 충족하지 못했다. "),
              "이 값은 주어진 사건 정보의 문자적 표식이다. 다른 사건 언급 자체를 임상적 탈선으로 보지 않으며, 제공하지 않은 새로운 이야기로의 전환도 포착하지 못한다. "
              "두 사건을 연결하는 자연스러운 설명일 가능성, 표현을 바꿔 표식을 놓칠 가능성, 조건별 길이 차이를 함께 고려해야 한다. "
              "다른 사건 표식 뒤에 질문한 사건의 표식이 다시 나오는 비율도 저장했지만, 임상적 주제 복귀의 정답이나 원본 지시 위반율로 부르지 않는다.", "",
              "## 원문으로 확인한 측정의 한계", "",
              "출력 확인 후 추가한 비전수 예시 점검이다. N2의 원예 답변은 다른 사건 표식이 0개였지만, 프로필에 없는 고양이 이름 Miso와 고양이 이야기를 포함했다. "
              "따라서 다른 사건의 고유값이 없다는 것은 질문 밖의 내용이 없다는 뜻이 아니다. 또 N1의 도예 답변에는 기차 사건의 정보 뒤에 "
              "‘let's get back to the pottery class’라는 표현이 나왔다. 도예 사건의 고유 장소·금액·이름을 다시 말하지 않아 표식 순서 기반 복귀 값은 이를 놓쳤다. "
              "원본 tangent의 턴 내 복귀 금지 문구와 대조할 수 있는 구체적 사례지만 임상적 복귀 판정이나 위반율로 확장하지 않는다. "
              "이 예시들을 보고 주 분석의 표현 목록·결정선·생성 답변을 수정하지 않았다.", "",
              "## 고정 사례 원문", "", "N1 / 질문 대상 A / V1 / repeat 4의 세 조건을 모두 제시한다.", ""]
    for r in sorted(rows, key=lambda x: x["style_id"]):
        if (r["profile_id"], r["target_event"], r["variant_id"], r["repeat_index"]) == ("N1", "A", "V1", 4):
            lines += [f"### {r['style_id']}", "", r["question"], "", r["response_text"], ""]
    lines += ["## 재현", "", "`python3 scripts/topic_selection_probe.py --analyze-only`는 저장된 원문을 검증하고 같은 수치를 재계산한다. "
              "새 추론·추가 다운로드 없이 실행한다.", ""]
    (OUT / "report.ko.md").write_text("\n".join(lines))
    print(json.dumps({"actual_replies": len(rows), "summaries": summaries, "primary": primary["mean"], "decision_rule_met": passed}, ensure_ascii=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--run", action="store_true")
    mode.add_argument("--analyze-only", action="store_true")
    mode.add_argument("--review-native-only", action="store_true")
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if args.review_native_only:
        native_review()
        print("Reused 144 existing replies; new generation 0")
    elif args.analyze_only:
        analyze()
    elif args.run:
        plan, cases = prepare()
        run(plan, cases, FOLDER, args.resume)
        analyze()
    else:
        plan, _ = prepare()
        print(json.dumps(plan, ensure_ascii=False))
