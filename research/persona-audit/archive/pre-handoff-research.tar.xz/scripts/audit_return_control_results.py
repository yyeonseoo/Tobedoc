"""Secondary raw-text/QC audit; preserve the frozen primary outcomes unchanged."""
import json

from common import ROOT, digest, write_json
from return_control_ablation import OUT, block_key


def main():
    path = OUT / "results.json"
    result = json.loads(path.read_text())
    challenge = [r for r in result["responses"] if r["task_mode"] == "continuation_challenge"]
    non_echo = []
    for arm in ("original","clarified"):
        part = [r for r in challenge if r["arm"] == arm and not r["complete_prefix_echo"]]
        non_echo.append({"arm":arm,"replies":len(part),"returns":sum(r["primary_return"] for r in part),
                         "condition_ids":[r["condition_id"] for r in part]})
    keys = sorted({block_key(r) for r in challenge})
    clean_pairs = [[r for r in challenge if block_key(r) == key] for key in keys]
    clean_pairs = [p for p in clean_pairs if all(not r["complete_prefix_echo"] for r in p)]
    free_returns = [r for r in result["responses"] if r["task_mode"] == "free_reply" and r["primary_return"]]
    notes = [{"condition_id":r["condition_id"],"response_text":r["response_text"],"anchor_sequence":r["anchor_sequence"]}
             for r in free_returns]
    audit = {"secondary_posthoc_audit":True,"primary_results_changed":False,"model_calls":0,
             "challenge_non_echo":non_echo,"common_non_echo_pairs":len(clean_pairs),
             "common_non_echo_return_counts":{a:sum(r["primary_return"] for p in clean_pairs for r in p if r["arm"]==a) for a in ("original","clarified")},
             "free_return_outputs":notes,
             "targeted_reference_observation":{
                 "condition_id":"RC-free_reply-C1-QA-W2-R6-original",
                 "observation":"The only free R-O-R output describes 46 dollars, attributes that price to the bread-baking class, then reiterates 46 for astronomy. Supplied costs were astronomy 46 and baking 31. This is a price-confusion/correction reference, not necessarily a sustained excursion into another story.",
                 "scope":"Direct comparison with fictional input facts; not an expert symptom rating or a complete factual accuracy evaluation."},
             "decision":"Do not adopt the clarification as a demonstrated return-control improvement. Free other-event references declined; fixed-prefix primary returns did not decline, including in non-echo outputs.",
             "source_sha256":digest(path.read_bytes()),"script_sha256":digest((ROOT/"scripts/audit_return_control_results.py").read_bytes())}
    write_json(OUT / "reference-audit.json",audit)
    print(json.dumps({"non_echo":non_echo,"common_clean_pairs":len(clean_pairs),"common_clean_returns":audit["common_non_echo_return_counts"]},ensure_ascii=False))


if __name__ == "__main__":
    main()
