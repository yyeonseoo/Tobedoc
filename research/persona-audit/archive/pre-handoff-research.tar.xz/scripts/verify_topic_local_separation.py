"""Offline audit of source hashes, perturbations, all values, and final report."""
import argparse
import itertools
import math
import subprocess
import sys
from common import ROOT,digest,write_json
from topic_local_separation import OUT,SPEC,read,calculate
from run_local_pilot import fingerprint


def independent_cos(a,b):
    return sum(x*y for x,y in zip(a,b))/math.sqrt(sum(x*x for x in a)*sum(y*y for y in b))


def main(report=False):
    result,details=read(OUT/'results.json'),read(OUT/'response-details.json')
    plan=read(OUT/'measurement-plan.json')
    assert plan['spec']==read(SPEC)
    assert plan['spec_sha256']==digest(SPEC.read_bytes())
    assert plan['script_sha256']==digest((ROOT/'scripts/topic_local_separation.py').read_bytes())
    recalculated,recreated=calculate()
    assert fingerprint(result)==fingerprint(recalculated)
    assert fingerprint(details)==fingerprint(recreated)
    for path,sha in result['provenance'].items():
        assert digest((ROOT/path).read_bytes())==sha
    native=read(ROOT/'analysis/topic-trajectory-v01/native-output.json')
    records={r['id']:r for r in native['records']}
    formula_checks=0
    for r in details['responses']:
        v=[s['vector'] for s in records[digest(r['response_text'].encode())]['sentences']]
        if len(v)<2:
            assert all(r[k] is None for k in ('adjacent_cos','all_pairs_cos','adjacency_excess'))
            continue
        adjacent=sum(independent_cos(a,b) for a,b in zip(v,v[1:]))/(len(v)-1)
        background=sum(independent_cos(a,b) for a,b in itertools.combinations(v,2))/(len(v)*(len(v)-1)/2)
        assert abs(adjacent-r['adjacent_cos'])<1e-12
        assert abs(background-r['all_pairs_cos'])<1e-12
        assert abs(adjacent-background-r['adjacency_excess'])<1e-12
        formula_checks+=1
    assert len(details['responses'])==48 and sum(r['sentence_count'] for r in details['responses'])==411
    assert len(details['insertion_controls'])==48
    assert all(r['requested']['sentence_count']==r['other']['sentence_count'] and
               r['requested']['word_count']==r['other']['word_count'] for r in details['insertion_controls'])
    assert all(r['adjacent_cos_change']==0 for r in details['question_swap_controls'] if r['adjacent_cos_change'] is not None)
    tests=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-q'],cwd=ROOT,capture_output=True,text=True)
    if tests.returncode:
        raise ValueError(tests.stdout+tests.stderr)
    record={'existing_replies':48,'existing_sentences':411,'raw_request_response_files_reverified':96,
            'provenance_files':len(result['provenance']),'all_values_reproduced':True,
            'independent_local_metric_formula_checks':formula_checks,'single_sentence_local_metric_not_applicable':48-formula_checks,
            'word_and_sentence_matched_insertion_pairs':48,
            'new_generation':0,'new_embedding':0,'paid_api':0,'tests':tests.stderr.strip()}
    share=ROOT/'share/topic-local-separation-v01'
    if report:
        from docx import Document
        from build_topic_local_report import OUTPUT
        manifest=read(share/'report-inputs.json')
        assert digest(OUTPUT.read_bytes())==manifest['output_sha256']
        for p,sha in manifest['inputs'].items():
            assert digest((ROOT/p).read_bytes())==sha
        rows={r['condition_id']:r for r in details['responses']}
        for item in manifest['illustration_quotes']:
            assert item['quote'] in rows[item['condition_id']]['response_text']
        doc=Document(OUTPUT)
        assert len(doc.tables)==3
        pages=list((share/'render-qa').glob('page-*.png'))
        assert len(pages) in (2,3)
        assert all(p.stat().st_size>10000 for p in pages)
        record.update(report_sha256=manifest['output_sha256'],rendered_pages=len(pages))
    write_json(share/'verification.json',record)
    print(record)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report',action='store_true')
    main(parser.parse_args().report)
