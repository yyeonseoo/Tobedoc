"""Bounded, resumable local prototype: PATIENT-psi prompt port on Qwen.

Only loopback Ollama; never pulls a model, uses a cloud key or retries a
completed answer. Each request is saved before sending. Real responses only.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import random
import re
import time
import urllib.request
import uuid

from common import ROOT, digest, write_json
from local_preflight import BASE, MODEL, local_metadata
from prepare_pilot import build_conditions

OPTIONS = {"temperature": 0.6, "top_p": 0.95, "top_k": 20,
           "repeat_penalty": 1.0, "num_ctx": 16384, "num_predict": 512}
STYLES = ["plain", "reserved", "tangent"]
ARMS = ["native_demo_mapping", "repaired_demo_mapping"]


def now():
    return datetime.now(timezone.utc).isoformat()


def fingerprint(value):
    return digest(json.dumps(value, sort_keys=True, ensure_ascii=False).encode())


def select_conditions(profile_id="1-1"):
    rows = [x for x in build_conditions() if x["profile_id"] == profile_id and x["style_id"] in STYLES]
    if len(rows) != 6:
        raise ValueError("Expected one situation x three styles x two arms")
    rows.sort(key=lambda r: (STYLES.index(r["style_id"]), ARMS.index(r["arm"])))
    first, rest = rows[0], rows[1:]
    random.Random(20261029).shuffle(rest)
    return [first] + rest


def build_payload(condition, history, turn):
    expected = 2 * (turn - 1)
    if len(history) != expected:
        raise ValueError("History is incomplete; never fabricate previous replies")
    options = {**OPTIONS, "seed": 20261029 + STYLES.index(condition["style_id"]) * 100 + turn}
    messages = [{"role": "system", "content": condition["system_prompt"]}] + list(history)
    messages.append({"role": "user", "content": condition["interview"][turn - 1]["text"]})
    # Conservative byte-count guard; exact prompt token count is returned by Ollama.
    if sum(len(x["content"].encode()) for x in messages) + 512 + 256 >= OPTIONS["num_ctx"]:
        raise ValueError("Conservative context guard exceeded; review rather than truncate history")
    return {"model": MODEL, "messages": messages, "think": False, "stream": False,
            "keep_alive": "5m", "options": options}


def chat(payload, timeout=240):
    if payload.get("model") != MODEL:
        raise ValueError("Only the explicitly selected installed local model is allowed")
    request = urllib.request.Request(BASE + "/api/chat", data=json.dumps(payload).encode(),
                                     headers={"Content-Type": "application/json"}, method="POST")
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(request, timeout=timeout) as response:
        raw = response.read(2_000_001)
    if len(raw) > 2_000_000:
        raise ValueError("Unexpectedly large response; review required")
    return json.loads(raw)


def classify(raw):
    if raw.get("error"):
        return "provider_error"
    if not raw.get("done"):
        return "incomplete"
    if raw.get("done_reason") == "length":
        return "truncated"
    if not raw.get("message", {}).get("content", "").strip():
        return "empty_response"
    if raw.get("model") != MODEL:
        return "model_mismatch"
    return "completed"


def refresh_progress(folder, conditions):
    records = []
    for path in sorted((folder / "responses").glob("*.json")):
        row = json.loads(path.read_text())
        if row.get("is_fixture"):
            raise ValueError("Fixture must not enter a real run")
        records.append(row)
    status_counts = {s: sum(r["status"] == s for r in records) for s in sorted({r["status"] for r in records})}
    completed = sum(x.get("status") == "completed" for x in records)
    result = {"updated_at_utc": now(), "planned_dialogues": len(conditions),
              "planned_calls": len(conditions) * 4, "recorded_requests": len(records),
              "completed_responses": completed, "status_counts": status_counts,
              "complete": completed == len(conditions) * 4,
              "clinical_validation": False, "independent_people": 1,
              "paid_model_api_calls": 0, "fixture_responses": 0}
    write_json(folder / "progress.json", result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--max-dialogues", type=int, default=6,
                        help="Use 1 for the technical gate; resume unchanged config for the other five")
    args = parser.parse_args()
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,70}", args.run_id):
        parser.error("Run ID must be a short lowercase filename-safe identifier")
    if not 1 <= args.max_dialogues <= 6:
        parser.error("This bounded prototype permits 1..6 dialogues")
    policy = json.loads((ROOT / "config/compute-policy.json").read_text())
    if policy["paid_model_api_allowed"] or policy["automatic_model_download_allowed"]:
        raise ValueError("Unexpected policy change; review before running")
    installed = local_metadata("/api/tags").get("models", [])
    model = next((x for x in installed if x.get("name") == MODEL), None)
    if not model:
        raise ValueError("Required local model not installed; automatic pull is forbidden")
    expected = json.loads((ROOT / "evidence/local-runtime.json").read_text())["ollama"]["candidate_metadata"]["digest"]
    if model["digest"] != expected:
        raise ValueError("Installed model digest changed; do not silently replace the backbone")
    conditions = select_conditions()
    config = {"schema_version": "0.1", "run_id": args.run_id, "model": MODEL,
              "model_digest": model["digest"], "options": OPTIONS, "think": False,
              "profile_id": "1-1", "styles": STYLES, "arms": ARMS,
              "condition_ids": [x["condition_id"] for x in conditions],
              "prompt_hashes": [x["prompt_sha256"] for x in conditions],
              "seed_rule": "20261029 + style_index*100 + turn; matched across mapping arms",
              "scope": "development feasibility prototype; one person and situation; not schizophrenia",
              "retry_policy": "no automatic retries or best-of selection",
              "user_authorization": "2026-10-29: proceed with local prototype for team discussion"}
    folder = ROOT / "pilot/runs" / args.run_id
    if folder.exists():
        if not args.resume:
            raise ValueError("Run exists. Use --resume; no overwrite permitted")
        previous = json.loads((folder / "run-config.json").read_text())
        if fingerprint(previous) != fingerprint(config):
            raise ValueError("Resume config differs from locked run")
    else:
        if args.resume:
            raise ValueError("Cannot resume a nonexistent run")
        folder.mkdir(parents=True)
        (folder / "requests").mkdir()
        (folder / "responses").mkdir()
        write_json(folder / "run-config.json", config)
        write_json(folder / "conditions.json", conditions)
        write_json(folder / "runtime.json", {"checked_at_utc": now(), "model": model,
                   "version": local_metadata("/api/version"),
                   "show": local_metadata("/api/show", {"model": MODEL})})
    lock = folder / ".running"
    try:
        with lock.open("x") as f:
            f.write(now())
    except FileExistsError as error:
        raise ValueError("Run already active or interrupted. Inspect before removing its lock") from error
    try:
        for index, condition in enumerate(conditions[:args.max_dialogues], 1):
            history = []
            for question in condition["interview"]:
                turn = question["turn"]
                stem = f'{condition["condition_id"]}-T{turn}'
                request_path = folder / "requests" / (stem + ".json")
                response_path = folder / "responses" / (stem + ".json")
                payload = build_payload(condition, history, turn)
                request_hash = fingerprint(payload)
                if response_path.exists():
                    record = json.loads(response_path.read_text())
                    if record["request_sha256"] != request_hash or record["status"] != "completed":
                        raise ValueError("Cannot silently retry or resume an inconsistent/failed turn")
                else:
                    if request_path.exists():
                        raise ValueError("Unfinished saved request: inspect, do not silently duplicate inference")
                    request_id = str(uuid.uuid4())
                    started = now()
                    write_json(request_path, {"request_id": request_id, "started_at_utc": started,
                               "request_sha256": request_hash, "payload": payload})
                    clock = time.monotonic()
                    error_info = None
                    raw = {}
                    try:
                        raw = chat(payload)
                        status = classify(raw)
                    except Exception as error:
                        status = "transport_error"
                        error_info = {"type": type(error).__name__, "message": str(error)}
                    record = {
                        "run_id": args.run_id, "condition_id": condition["condition_id"],
                        "profile_id": condition["profile_id"], "style_id": condition["style_id"],
                        "arm": condition["arm"], "turn": turn, "probe": question["probe"],
                        "interviewer_text": question["text"], "prompt_sha256": condition["prompt_sha256"],
                        "request_sha256": request_hash, "request_id": request_id,
                        "started_at_utc": started, "ended_at_utc": now(),
                        "wall_seconds": time.monotonic() - clock, "provider": "local_ollama",
                        "model_id_requested": MODEL, "model_id_returned": raw.get("model"),
                        "model_digest": model["digest"], "generation_settings": {"think": False, **payload["options"]},
                        "status": status, "response_text": raw.get("message", {}).get("content", ""),
                        "finish_reason": raw.get("done_reason"),
                        "usage": {k: raw.get(k) for k in ["prompt_eval_count", "eval_count", "eval_duration", "load_duration", "total_duration"]},
                        "raw_response": raw, "error": error_info, "is_fixture": False,
                        "clinical_rating": None, "is_paper_replication": False,
                        "is_schizophrenia_case": False,
                    }
                    write_json(response_path, record)
                    print(f'{index}/6 {condition["style_id"]} {condition["arm"]} T{turn}: {status} {record["wall_seconds"]:.1f}s', flush=True)
                    refresh_progress(folder, conditions)
                if record["status"] != "completed":
                    raise ValueError("Non-completed response preserved; stop for review before continuing")
                history += [{"role": "user", "content": question["text"]},
                            {"role": "assistant", "content": record["response_text"]}]
        progress = refresh_progress(folder, conditions)
        print(json.dumps(progress), flush=True)
    finally:
        lock.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
