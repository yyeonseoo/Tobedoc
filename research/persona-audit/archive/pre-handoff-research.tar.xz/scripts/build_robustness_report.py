"""Build the existing research artifact's follow-up report and verified bundle."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import zipfile

from common import ROOT, digest, write_json


def number(value, digits=3):
    return "NA" if value is None else f"{value:+.{digits}f}"


def build_report(folder, result, audit):
    tangent = result["contrasts"]["tangent"]
    d = lambda feature: number(tangent[feature]["block_weighted_difference"])
    matches = lambda rule, tolerance: next(r["results"]["adjacent_cos_mean"] for r in result["length_matching"]
                                            if r["rule"] == rule and r["relative_word_tolerance"] == tolerance)
    words = matches("words_only", .2)
    joint = matches("words_and_sentences", .2)
    caps = {r["style"]: r for r in audit["instructions"]}
    regression = result["descriptive_length_adjustment"]["adjacent_cos_mean"]
    lines = ["# PATIENT-Ψ 발화 feature: 강건성·프롬프트 대응 분석", "",
        "2026-10-30 · 1차 자동 정량화의 후속 분석 · 새 발화 생성 0 · 수동/LLM 채점 0", "",
        "## 결론부터", "",
        "**tangent의 낮은 인접 문장 의미 유사도는 이번 자료에서 비교적 일관되지만, 이를 ‘질문에서 벗어나 돌아오지 않는 행동’ 또는 임상적 사고장애의 구현 성공으로 해석할 수 없다.** "
        "길이·상황·계산 방식을 나눠 확인한 결과, 일부 수치 차이는 유지되었고 동시에 기존 측정이 놓치는 부분도 구체적으로 드러났다.", "",
        "대상은 PATIENT-Ψ 원형 demo mapping을 Qwen3-14B에서 실행한 기존 36대화·144응답이다. Abe 한 인물, 세 상황, 두 반복, 네 질문이다. "
        "원 논문 GPT-4 재현이나 실제 조현병 환자 검증, 여러 프레임워크 비교가 아니다. 1차 결과를 이미 본 뒤 정한 **사후적 기술 분석**이며 사전등록·확증검정으로 제시하지 않는다.", "",
        "![민감도 분석](robustness-profiles.png)", "",
        "그림의 점은 tangent−plain 차이이며 신뢰구간을 뜻하지 않는다. 같은 상황·반복·질문의 응답을 대응시킨 뒤 상황×반복 블록을 동일 가중했다. "
        "선별된 부분집합은 원래 전체 자료와 추정 대상이 달라진다.", "",
        "## 1. 낮은 인접 유사도는 어디까지 유지되는가", "",
        f"전체 차이는 **{d('adjacent_cos_mean')}**이며 여섯 블록 모두 음수였다. 상황별로 나누면 다음과 같다.", ""]
    for row in result["stratified_tangent_minus_plain"]:
        if row["stratum"] == "situation" and row["feature"] == "adjacent_cos_mean":
            lines.append(f"- 상황 {row['value']}: {number(row['block_weighted_difference'])} (상황 내 두 반복 평균).")
    lines += ["", f"단어 수 차이가 두 응답 평균의 20% 이내인 원래 대응쌍만 남기면, **{words['eligible_response_pairs']}/24쌍·{words['eligible_blocks']}/6블록**에서 차이는 "
        f"**{number(words['block_weighted_difference'])}**였다. 단어 수가 비슷한 비교에서도 방향은 유지되었다.", "",
        f"그러나 단어 수 조건과 문장 수 동일 조건을 모두 요구하면 **{joint['eligible_response_pairs']}/24쌍·{joint['eligible_blocks']}/6블록**만 남았고 차이는 "
        f"{number(joint['block_weighted_difference'])}였다. 이 적은 선별 자료로 길이와 독립적인 효과를 확정할 수 없다. "
        "허용폭 10%·20%·30% 및 문장 수만 일치하는 조건을 모두 CSV에 보존했으며 유리한 조건만 고르지 않았다.", "",
        f"보조적으로 24개 대응쌍의 feature 차이를 log(단어 수 비)와 문장 수 차이에 회귀시킨 절편은 {number(regression['coefficients'][0])}였다. "
        "이는 두 길이 차이가 0일 때의 선형모형 예측일 뿐이며, 적은 완전 일치 자료에 대한 모형 의존적 보조 분석이다. "
        "길이는 스타일의 결과일 수도 있어 보정값을 ‘순수한 인과효과’라고 부르지 않는다. 표준오차·p값·환자 모집단 추론은 제시하지 않았다.", "",
        f"정규식 v2 분절과 말줄임표/종결부호 정규화를 적용해 같은 임베딩으로 다시 계산해도 차이는 **{d('regex_adjacent_cos_mean')}**였다. "
        "이는 분절과 정규화에 대한 민감도 검사이지, 별도 임베딩 모델로 재현한 결과는 아니다.", "",
        f"인접 유사도 최솟값 차이는 {d('adjacent_cos_min')}였고, 비교하는 edge 수의 영향을 줄이기 위해 ‘정확히 두 edge를 뽑았을 때 기대 최솟값’을 계산하면 "
        f"{d('fixed_two_edge_minimum')}였다. 두 값 모두 여섯 블록에서 음수였지만 후자는 원래 feature와 다른 보조 통계다.", "",
        f"반면 첫 문장쌍만 비교한 차이는 {d('first_pair_cos')}, 마지막 문장쌍만 비교한 차이는 **{d('last_pair_cos')}**였다. "
        "응답 전체 평균의 차이가 모든 위치에서 균일하게 나타나는 것은 아니다.", "",
        "## 2. ‘질문에서 벗어남’을 실제로 관찰했는가", "",
        "tangent 원문은 단순히 문장 사이 유사도를 낮추라고 하지 않는다. 질문에 답하다 다른 주제로 이동하고, 턴 안에서는 원래 주제로 돌아오지 않는 행동을 요구한다. "
        "따라서 문장 간 유사도와 질문에 대한 관련성의 방향 변화를 별도로 확인했다.", "",
        f"- 질문–응답 전체 유사도 차이: {d('question_answer_cos')}.",
        f"- 초기 상황–응답 전체 유사도 차이: {d('topic_answer_cos')}.",
        f"- 응답 내 문장 진행에 따른 질문 유사도 기울기 차이: {number(tangent['question_sentence_cos_slope']['block_weighted_difference'], 6)} "
        "(cosine/정규화 문장 위치 0–1).",
        f"- 마지막 문장−첫 문장의 질문 유사도 변화 차이: {d('question_last_minus_first_cos')} "
        f"(음수 {tangent['question_last_minus_first_cos']['negative_blocks']}/6블록).", "",
        "**문장 간 의미 유사도가 낮다는 결과에 비해, 질문 관련성이 응답 진행에 따라 더 감소한다는 패턴은 측정 방법 사이에서 일관되지 않았다.** "
        "이것은 tangent가 임상적으로 구현되지 않았다는 판정도 아니고 동등성 검정도 아니다. 현재 임베딩 지표와 표본으로 ‘이탈 후 복귀 금지’를 확인하지 못했다는 결론이다. "
        "연속적인 시작–끝 유사도 변화는 ‘이탈/복귀’ 사건의 정답 라벨을 대신하지 않는다.", "",
        "## 3. 대화가 진행되면 어떻게 달라지는가", ""]
    for row in result["stratified_tangent_minus_plain"]:
        if row["stratum"] == "turn" and row["feature"] == "adjacent_cos_mean":
            lines.append(f"- T{row['value']} tangent−plain 인접 유사도: {number(row['block_weighted_difference'])} "
                         f"(음수 {row['negative_blocks']}/6블록).")
    redirect = next(r for r in result["redirection_descriptive"] if r["style"] == "tangent")
    lines += ["", "첫 턴보다 후속 턴에서 평균 차이가 컸다. 그러나 질문 종류와 턴 위치가 고정되어 있어 질문 효과와 누적 이력 효과를 분리할 수 없다. "
        "각 응답은 실제 이전 대화를 포함하므로 후속 턴을 독립적인 반복으로 세지 않는다.", "",
        f"T3 재지시 질문 뒤 tangent의 초기 상황–응답 유사도는 T2 대비 {number(redirect['descriptive_T3_minus_T2']['topic_answer_cos'])} 변했다. "
        "재지시 유무를 무작위 배정한 대조군이 없으므로 이를 재지시의 인과효과, 신뢰 형성 또는 임상적 호전으로 해석하지 않는다.", "",
        "## 4. 원형 지시와 측정의 대응: 모델의 한계와 우리의 측정 공백을 구별", "",
        f"원문 다섯 스타일의 번호 붙은 행동 요구 **{audit['numbered_behavioral_claims']}개**를 모두 추출했다. "
        f"그중 **{audit['partially_proxied']}개는 일부 수치 대리값**을 연결할 수 있었고, **{audit['not_directly_measured']}개는 현재 직접 측정하지 못했다**. "
        "이 집계는 원문 행동 조항에 한정하며 공통 지시·문장 수 제한·시간 변화 지시는 별도로 감사했다. "
        "대응 분류는 연구자가 작성한 측정 도구 감사이지 환자나 임상 증상의 채점이 아니다. 미측정 조항은 구현 실패가 아니다.", "",
        "- verbose: 발화량 증가는 관찰되었다. 그러나 자세한 정보의 제공과 치료자 주도권 방해까지 검증한 것은 아니다.",
        "- reserved: 짧은 응답은 관찰되었다. 그러나 모호함·회피·불신·자기개방 거부를 정량화한 것은 아니다.",
        "- tangent: 유사도 관련 대리값이 있으나 임상적 이탈/복귀 여부는 판정하지 않았다.",
        "- upset/pleasing: 분노·저항·승인 추구·증상 축소·동의의 의미를 직접 포착하는 지표가 없어, 현재 결과로 이 두 스타일의 구현 성공/실패를 판단할 수 없다.", "",
        "원형 프롬프트 자체에서도 다음 조건을 확인했다.", "",
        "- verbose에는 개별 8문장 상한과 공통 5문장 상한이 동시에 들어간다. 두 제한을 모두 엄격히 적용하면 5문장이다. "
        "upset/reserved도 개별 3문장과 공통 5문장 상한을 함께 가진다. 길이 지시와 행동 지시를 분리한 실험은 아니다.",
        "- 다섯 비기본 스타일 모두 일부 턴에서는 해당 스타일, 다른 턴에서는 정상적으로 답하라는 허용 지시와 신뢰에 따른 세션 변화를 포함한다. "
        "모든 턴에서 같은 정도의 스타일이 나타나야 한다는 기대는 원형 지시와 다르다.",
        f"- 공통 5문장 제한을 자동 분절로 넘은 tangent 응답은 OS 방식 {caps['tangent']['OS_global_above_cap']}/24, "
        f"정규식 방식 {caps['tangent']['regex_global_above_cap']}/24였다. 이 값은 분절 규칙에 따른 제약 초과 플래그이며 임상적 이상 발화 판정이 아니다.",
        "- 모든 36개 실제 프롬프트에 core beliefs, automatic thoughts, depression-specific intermediate beliefs 세 필드가 undefined로 전달되었다. "
        "앞서 발견한 공개 demo–formatter 필드 연결 문제를 이번 원형 분석에서도 그대로 보존했다. 신념 관련 정보가 완전하게 전달된 실행으로 해석할 수 없다.", "",
        "## 5. 연구적으로 얻은 결론과 다음 실험의 경계", "",
        "현재 얻은 가장 강한 결론은 **‘원형 tangent 지시가 이 로컬 실행에서 낮은 인접 의미 유사도와 연관되지만, 그 값은 원문이 요구하는 행동 전체를 대표하지 않는다’**이다. "
        "발화량을 잘 구분한 결과와 임상적 행동을 충실하게 재현한 결과를 분리해야 한다.", "",
        "기존 모델의 한계를 논하려면 세 층을 구별해야 한다: ① 입력에 정보가 제대로 전달되었는가, ② 출력에서 지시된 행동이 관찰되는가, "
        "③ 그 행동/측정이 임상 현상에 타당하게 대응하는가. 이번에는 ①의 입력 누락을 확인했고 ②의 일부 수치 차이를 확인했으나, ③은 검증하지 않았다.", "",
        "다음 생성 실험은 새 개발 자료에서 입력 누락 수정·길이 지시 변경·행동 지시 변경을 한꺼번에 섞지 않고, 먼저 한 요소씩 분리하는 것이 합리적이다. "
        "다른 프레임워크 비교도 각자의 명시적 목표와 측정 가능한 범위를 확인한 뒤 동일 feature 추출기를 적용해야 한다. 임상적 종합 점수나 전체 우열 순위는 만들지 않는다.", "",
        "## 재현성과 파일", "",
        "모든 원문·실제 요청 이력을 다시 검증하고 기존 17개 feature 값을 원본 캐시 벡터에서 재계산해 동일함을 확인했다. "
        "새로 계산한 것은 사후 민감도 통계와 질문 유사도의 문장별 궤적이다. 로컬 OS 임베딩만 사용했고 새 생성·유료 API·모델 다운로드·S/L/G·LLM judge는 모두 0이다. "
        "다른 임베딩 모델에 대한 강건성 및 임상 타당도는 여전히 미검증이다.", "",
        "- [전체 수치 JSON](robustness-results.json), [조건별 차이 CSV](stratified-contrasts.csv), [길이 일치 조건 CSV](length-matching.csv).",
        "- [전체 feature 민감도 CSV](sensitivity-contrasts.csv), [원문 행동 조항 대응 CSV](prompt-claims.csv), [프롬프트 제한 감사 CSV](prompt-constraints.csv).",
        "- [문장별 원문·질문/상황 유사도 궤적](sentence-trajectories.json), [검증된 입력 해시](provenance.json).",
        "- [원형 행동 지시 전체 대응 해설](prompt-feature-audit.ko.md), [코드·원문·두 단계 결과 통합 묶음](robustness-results-20261030.zip).", "",
        "재계산: `python3 scripts/analyze_feature_robustness.py --cached-only`. 결과의 별도 임베딩 캐시를 사용하므로 Swift·네트워크·LLM 없이 계산한다. "
        "최초 대체 분절 임베딩 캐시 생성에만 macOS의 기존 영어 임베딩을 사용했다.", "",
        "출처는 기존에 해시 고정한 PATIENT-Ψ 코드이다: "
        f"[스타일 지시](https://github.com/ruiyiw/patient-psi/blob/{audit['source_commit']}/app/api/data/patient-types.jsx), "
        f"[프롬프트 formatter](https://github.com/ruiyiw/patient-psi/blob/{audit['source_commit']}/app/api/getDataFromKV.ts). "
        "현재 저장소 최신 버전이라는 주장은 하지 않는다.", ""]
    (folder/"report.ko.md").write_text("\n".join(lines), encoding="utf-8")
    detailed = ["# 원문 행동 조항 → 관찰 feature 대응 감사", "",
                "환자/증상 채점이 아닌 측정 도구 범위 감사. 부분 대리값은 조항 충족의 증명이 아니다.", ""]
    for claim in audit["claims"]:
        detailed += [f"## {claim['claim_id']} · {claim['operational_target']}", "",
                     f"Source: psi_styles, line {claim['line']} (고정 commit 및 SHA는 JSON 참조).", "",
                     claim["source_clause"], "",
                     "부분 수치 대리값: " + (", ".join(claim["numeric_proxies"]) or "없음"), "",
                     claim["limitation_ko"], ""]
    (folder/"prompt-feature-audit.ko.md").write_text("\n".join(detailed), encoding="utf-8")


def render(folder, result):
    tangent = result["contrasts"]["tangent"]
    def point(label, c):
        return {"label": label, "difference": c["block_weighted_difference"],
                "pairs": c["eligible_response_pairs"], "blocks": c["eligible_blocks"]}
    left = [point("Full corpus", tangent["adjacent_cos_mean"])]
    for kind in ["situation", "turn", "repeat"]:
        for row in result["stratified_tangent_minus_plain"]:
            if row["stratum"] == kind and row["feature"] == "adjacent_cos_mean":
                left.append(point(f"{kind.capitalize()} {row['value']}", row))
    right = [point("Original segmentation", tangent["adjacent_cos_mean"]),
             point("Regex + normalization", tangent["regex_adjacent_cos_mean"])]
    for rule, label in [("words_only", "Words within 20%"), ("sentences_only", "Equal sentence count"),
                        ("words_and_sentences", "Words + sentences matched")]:
        c = next(r["results"]["adjacent_cos_mean"] for r in result["length_matching"]
                 if r["rule"] == rule and r["relative_word_tolerance"] == .2)
        right.append(point(label, c))
    right += [point("First sentence pair only", tangent["first_pair_cos"]), point("Last sentence pair only", tangent["last_pair_cos"])]
    plot = {"panels": [{"title": "A. Situation, turn, and repeat strata", "points": left},
                       {"title": "B. Length, segmentation, and position", "points": right}],
            "caption": "Source: native-features-20261030, generated 2026-10-30. Dots are descriptive paired contrasts, not confidence intervals. Selected subsets change the target comparison."}
    write_json(folder/"plot-input.json", plot)
    with tempfile.TemporaryDirectory(prefix="persona-robustness-plot-") as tmp:
        binary = str(Path(tmp)/"plot")
        subprocess.run(["/usr/bin/swiftc", "-module-cache-path", str(Path(tmp)/"modules"),
                        str(ROOT/"scripts/PlotRobustness.swift"), "-o", binary], check=True, capture_output=True)
        subprocess.run([binary, str(folder/"plot-input.json"), str(folder/"robustness-profiles.png")], check=True, capture_output=True)


def package(folder, run_id):
    baseline = ROOT/"analysis/automatic-features-v01"/run_id/"automatic-feature-results-20261030.zip"
    with zipfile.ZipFile(baseline) as source:
        contents = {n: source.read(n) for n in source.namelist() if not n.endswith("/archive-manifest.json")}
    prefix = "persona-feature-results/"
    include = [p for p in folder.iterdir() if p.is_file() and p.suffix in {".json", ".jsonl", ".csv", ".md", ".png"}
               and p.name != "archive-verification.json"]
    include += [ROOT/"scripts"/n for n in ["analyze_feature_robustness.py", "build_robustness_report.py", "PlotRobustness.swift"]]
    include += [ROOT/"config/feature-robustness-v01.json", ROOT/"tests/test_feature_robustness.py",
                ROOT/"README.md", ROOT/"docs/decision-log.md"]
    for path in include:
        contents[prefix+str(path.relative_to(ROOT))] = path.read_bytes()
    contents[prefix+"ROBUSTNESS-START-HERE.ko.md"] = (
        f"# 강건성·프롬프트 대응 분석\n\n먼저 `analysis/feature-robustness-v01/{run_id}/report.ko.md`를 읽는다.\n\n"
        "이 묶음은 기존 원문·요청·벡터·17개 feature와 후속 민감도 분석을 모두 포함한다.\n\n"
        "폴더 루트에서 `python3 scripts/analyze_feature_robustness.py --cached-only`로 오프라인 재계산한다. "
        "표준 Python 3.10+만 필요하며 모델·Swift·인터넷은 필요 없다. 그림 재생성에는 macOS/Swift가 필요하지만 PNG를 동봉했다. "
        "원래 파일의 run 날짜·검증 기록은 그 단계의 기록이며 최신 단계 검증은 후속 폴더에 있다.\n").encode()
    manifest = {name: digest(data) for name, data in sorted(contents.items())}
    contents[prefix+"archive-manifest.json"] = json.dumps(manifest, indent=2).encode()
    target = folder/"robustness-results-20261030.zip"
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in sorted(contents.items()):
            archive.writestr(name, data)
    with tempfile.TemporaryDirectory(prefix="persona-robustness-offline-") as tmp:
        with zipfile.ZipFile(target) as archive:
            for name, expected in manifest.items():
                if digest(archive.read(name)) != expected:
                    raise ValueError("Bundle hash mismatch")
            archive.extractall(tmp)
        cwd = Path(tmp)/"persona-feature-results"
        rerun = subprocess.run([sys.executable, "scripts/analyze_feature_robustness.py", "--cached-only"],
                               cwd=cwd, capture_output=True, text=True)
        if rerun.returncode:
            raise ValueError("Offline reproduction failed: "+rerun.stderr)
        for name in ["robustness-results.json", "prompt-feature-audit.json", "sentence-trajectories.json",
                     "augmented-features.jsonl", "stratified-contrasts.csv", "length-matching.csv", "sensitivity-contrasts.csv"]:
            if (cwd/folder.relative_to(ROOT)/name).read_bytes() != (folder/name).read_bytes():
                raise ValueError("Offline numeric mismatch: "+name)
    write_json(folder/"archive-verification.json", {"sha256": digest(target.read_bytes()), "bytes": target.stat().st_size,
        "files_hashed": len(manifest), "offline_cached_reanalysis": "passed", "exact_result_files_reproduced": 7,
        "new_generation_calls": 0, "timestamp_utc": datetime.now(timezone.utc).isoformat()})
    return target


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", default="native-features-20261030")
    args = parser.parse_args()
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,70}", args.run_id):
        parser.error("Invalid run ID")
    folder = ROOT/"analysis/feature-robustness-v01"/args.run_id
    result = json.loads((folder/"robustness-results.json").read_text())
    audit = json.loads((folder/"prompt-feature-audit.json").read_text())
    render(folder, result)
    build_report(folder, result, audit)
    verification = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-q"],
                                  cwd=ROOT, capture_output=True, text=True)
    write_json(folder/"test-verification.json", {"returncode": verification.returncode,
        "stdout": verification.stdout, "stderr": verification.stderr})
    if verification.returncode:
        raise ValueError("Tests failed: "+verification.stderr)
    # ZIP is created after report links are checked, so allow that one future file.
    for link in re.findall(r"\]\(([^)]+)\)", (folder/"report.ko.md").read_text()):
        if "://" not in link and link != "robustness-results-20261030.zip" and not (folder/link).is_file():
            raise ValueError("Broken report link: "+link)
    bundle = package(folder, args.run_id)
    print(json.dumps({"report": str(folder/"report.ko.md"), "archive_bytes": bundle.stat().st_size,
                      "tests": verification.stderr.strip(), "offline_reproduction": "passed"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
