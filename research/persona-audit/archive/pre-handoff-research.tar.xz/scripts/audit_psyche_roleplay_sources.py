"""Offline source inventory and bounded code-path tests, with no model calls.

Public PatientHub files are a third-party implementation. The tests isolate
schema definitions and client classes from their dependency stack. Templates
and chat models in control-flow tests are nonclinical recording stubs.
"""
import ast
from collections import Counter
from hashlib import sha1, sha256
import json
import logging
import importlib.util
from pathlib import Path
import re
from types import SimpleNamespace
from typing import List

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'evidence/snapshots/psyche-roleplay-v01/patienthub'
OUT = ROOT / 'analysis/psyche-roleplay-source-audit-v01'
SHARE = ROOT / 'share/psyche-roleplay-source-audit-v01'
LOCK = ROOT / 'config/psyche-roleplay-source-lock-v01.json'
PHASE = ROOT / 'config/psyche-roleplay-phase-v01.json'

FIELD_NOTES = {
    'general_appearance_attitude_behavior': ('외양 태도 행동', 'mixed', '외양과 비언어 행동을 텍스트만으로 검증하지 않는다.'),
    'mood': ('기분', 'semantic_construct', '감정 단어 빈도는 기분 구현의 임상 정답이 아니다.'),
    'affect': ('정동', 'mixed', '자기 설명과 관찰되는 표현을 구분하며 음성 정보가 필요할 수 있다.'),
    'spontaneity': ('자발성', 'interaction_construct', '응답 길이나 지시 준수로 대체하지 않는다.'),
    'verbal_productivity': ('발화량', 'automatic_descriptor', '턴별 단어 수를 측정할 수 있지만 음성 속도나 음성 증상 점수는 아니다.'),
    'tone_of_voice': ('음성의 높낮이와 어조', 'audio_required', '텍스트의 낮은 목소리라는 묘사는 실제 음성 측정이 아니다.'),
    'social_judgement': ('사회적 판단', 'semantic_construct', '상황별 판단 준거가 별도로 필요하다.'),
    'insight': ('병식', 'semantic_construct', '일반적 성찰이나 도움 수용과 동일시하지 않는다.'),
    'reliability': ('진술의 신뢰성', 'semantic_construct', '입력 사실과의 일치만으로 임상적 진술 신뢰성을 증명하지 않는다.'),
    'perception': ('지각', 'semantic_construct', '환청을 보고하는 내용과 지각 경험 자체를 구분한다.'),
    'thought_process': ('사고 과정', 'semantic_construct', '단순 문장 유사도나 감정적 갈등으로 사고장애를 판정하지 않는다.'),
    'thought_content': ('사고 내용', 'semantic_construct', '내용 표지와 발화 구조를 다른 축으로 둔다.'),
}


def read_json(path):
    return json.loads(path.read_text())


def gh_blob(data):
    return sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def verify_sources(lock):
    verified = []
    for f in lock['files']:
        raw = (BASE / f['path']).read_bytes()
        if gh_blob(raw) == f['github_blob_sha']:
            normalization = 'none'
        elif raw.endswith(b'\n') and gh_blob(raw[:-1]) == f['github_blob_sha']:
            normalization = 'one patch-transport terminating LF removed for Git blob verification'
        else:
            raise AssertionError('Source hash mismatch: ' + f['path'])
        verified.append({**f, 'snapshot_sha256': sha256(raw).hexdigest(),
                         'snapshot_bytes': len(raw), 'normalization': normalization})
    assert not (BASE / 'data/resources/roleplayDoh_principles.json').exists()
    return verified


def source_text(path):
    return (BASE / path).read_text()


def class_node(path, name):
    return next(n for n in ast.parse(source_text(path)).body
                if isinstance(n, ast.ClassDef) and n.name == name)


def anchor(path, node):
    return {'path': path, 'start_line': node.lineno, 'end_line': node.end_lineno}


def behavior_fields():
    path = 'patienthub/schemas/psyche.py'
    rows = []
    for node in class_node(path, 'MFCBehavior').body:
        if not isinstance(node, ast.AnnAssign):
            continue
        alias = next(k.value.value for k in node.value.keywords if k.arg == 'alias')
        label, modality, note = FIELD_NOTES[node.target.id]
        rows.append({'field': node.target.id, 'source_alias': alias, 'label_ko': label,
                     'annotation': ast.unparse(node.annotation), 'measurement_class': modality,
                     'interpretation_rule': note, 'evidence': anchor(path, node)})
    assert len(rows) == 12 and {r['field'] for r in rows} == set(FIELD_NOTES)
    return rows


def validate_profile_fixtures():
    # These are original schema class definitions, not the full PatientHub runtime.
    # Only installed Pydantic is used. No generators, providers or LLMs are imported.
    namespace = {'__name__': 'offline_patienthub_schema_audit'}
    base_tree = ast.parse(source_text('patienthub/schemas/base.py'))
    exec(compile(base_tree, 'locked_schema_base', 'exec'), namespace)
    tree = ast.parse(source_text('patienthub/schemas/psyche.py'))
    tree.body = [n for n in tree.body if not (
        isinstance(n, ast.ImportFrom) and n.module == 'patienthub.schemas.base')]
    exec(compile(tree, 'locked_psyche_schema', 'exec'), namespace)
    model = namespace['PsycheCharacter']
    records = read_json(BASE / 'data/characters/psyche.json')
    results = []
    for i, record in enumerate(records):
        try:
            model.model_validate(record)
            errors = []
        except Exception as exc:
            if not hasattr(exc, 'errors'):
                raise
            errors = [{'location': list(e['loc']), 'error_type': e['type']}
                      for e in exc.errors()]
        results.append({'record_index': i, 'valid': not errors, 'errors': errors,
                        'thought_process': record['MFC-Behavior']['Thought process'],
                        'verbal_productivity': record['MFC-Behavior']['Verbal productivity']})
    return {'method': 'Schema-only validation using original definitions and installed Pydantic; not full package execution',
            'profiles': len(records), 'valid_profiles': sum(r['valid'] for r in results),
            'records': results}


class RecordingTemplate:
    def __init__(self):
        self.bindings = []

    def render(self, **kwargs):
        self.bindings.append(kwargs)
        return 'NONCLINICAL_TEMPLATE_SENTINEL'


class FixtureChat:
    def __init__(self):
        self.calls = []
        self.results = iter([
            SimpleNamespace(content='DRAFT_SENTINEL'),
            SimpleNamespace(questions=['CHECK_SENTINEL'], extra_questions=[]),
            SimpleNamespace(answers=['No'], justification=[],
                            response='REVISION_SENTINEL', reasoning='TEST_ONLY')])

    def generate(self, messages, **kwargs):
        self.calls.append({'messages': messages,
                           'structured_response_requested': bool(kwargs)})
        return next(self.results)


def bounded_roleplay_test():
    # Synthetic rules are deliberately not downloaded expert principles.
    pools = {'case_A': ['RULE_A_SENTINEL'], 'case_B': ['RULE_B_SENTINEL']}
    choices = []

    def choose(items):
        choices.append(list(items))
        return items[0]

    namespace = {'__name__': 'offline_roleplay_controlflow', 'BaseClient': object,
                 'DictConfig': object, 'List': List, 'QuestionSet': object,
                 'AssessmentResult': object, 'load_json': lambda _: pools,
                 'random': SimpleNamespace(choice=choose),
                 'logger': logging.getLogger('offline_source_audit')}
    node = class_node('patienthub/clients/roleplayDoh.py', 'RoleplayDohClient')
    exec(compile(ast.Module(body=[node], type_ignores=[]), 'locked_roleplay_class', 'exec'), namespace)
    client = namespace['RoleplayDohClient'].__new__(namespace['RoleplayDohClient'])
    client.configs = SimpleNamespace(principles='NO_FILE_FIXTURE')
    client.profile = 'CASE_A_NONCLINICAL_SENTINEL'
    client.principles = client.load_principles()
    client.messages = [{'role': 'Therapist', 'content': 'PRIOR_QUESTION_SENTINEL'},
                       {'role': 'client', 'content': 'PRIOR_ANSWER_SENTINEL'}]
    client.prompts = {k: RecordingTemplate() for k in ('response', 'question', 'assessment')}
    client.chat_model = FixtureChat()
    result = client.generate_response('CURRENT_QUESTION_SENTINEL')
    draft = client.prompts['response'].bindings[0]
    revision = client.prompts['assessment'].bindings[0]
    assert client.principles == ['RULE_A_SENTINEL', 'RULE_B_SENTINEL']
    assert choices == [client.principles]
    assert 'PRIOR_ANSWER_SENTINEL' in draft['conv_history']
    assert revision['conv_history'] == []
    assert 'criteria' not in draft and 'principles' not in draft
    assert result == 'REVISION_SENTINEL'
    assert len(client.chat_model.calls) == 3
    return {'fixture_only': True, 'actual_llm_calls': 0, 'recording_stub_calls': 3,
            'loaded_synthetic_rule_count': len(client.principles),
            'selection_pool_contains_rules_from_both_fixture_cases': True,
            'draft_has_prior_history': True, 'assessment_history': [],
            'draft_template_bindings': sorted(draft),
            'selected_principles_per_turn': 1,
            'interpretation': 'These are observed code-path properties of the locked PatientHub reimplementation, not clinical or original-Roleplay-doh performance results.'}


def yaml_english_block(text, key):
    # A bounded extractor for these checked literal YAML blocks, not a YAML parser.
    english = re.split(r'^zh:\s*$', text, flags=re.M)[0]
    match = re.search(r'^  ' + re.escape(key) + r':[^\S\n]*\|[^\S\n]*\n', english, re.M)
    if not match:
        raise ValueError(key)
    lines = []
    for line in english[match.end():].splitlines():
        if not line.strip():
            lines.append('')
        elif line.startswith('    '):
            lines.append(line[4:])
        else:
            break
    return '\n'.join(lines)


def prompt_inventory():
    psyche = yaml_english_block(source_text('data/prompts/client/psyche.yaml'), 'system_prompt')
    role = source_text('data/prompts/client/roleplayDoh.yaml')
    response = yaml_english_block(role, 'response')
    assessment = yaml_english_block(role, 'assessment')
    placeholders = lambda s: sorted(set(re.findall(r'{{\s*([\w.]+)\s*}}', s)))
    assert placeholders(psyche) == ['data.mfc']
    assert placeholders(response) == ['conv_history', 'profile']
    assert placeholders(assessment) == ['client_response', 'conv_history', 'criteria', 'profile', 'therapist_message']
    records = read_json(BASE / 'data/characters/psyche.json')
    rendered = psyche.replace('{{data.mfc}}', json.dumps(records[0], ensure_ascii=False, indent=2))
    assert '{{data.mfc}}' not in rendered
    for field in ('MFC-Profile', 'MFC-History', 'MFC-Behavior'):
        assert field in rendered
    return {'method': 'Literal-block inspection and single-placeholder substitution; not native Jinja or full package execution',
            'psyche_variables': placeholders(psyche), 'roleplay_draft_variables': placeholders(response),
            'roleplay_assessment_variables': placeholders(assessment),
            'psyche_prompt_english_words': len(psyche.split()),
            'thought_process_has_named_flight_of_ideas_example': 'flight of ideas' in psyche.lower(),
            'thought_process_has_named_circumstantiality_example': 'circumstantiality' in psyche.lower(),
            'rendered_existing_profile_has_all_three_mfc_blocks': True,
            'note': 'Absent named examples in this English wrapper prompt do not prove that every native PSYCHE prompt lacks them.'}


def implementation_findings():
    path = 'patienthub/clients/roleplayDoh.py'
    node = class_node(path, 'RoleplayDohClient')
    methods = {n.name: n for n in node.body if isinstance(n, ast.FunctionDef)}
    empty_history = next(n for n in ast.walk(methods['generate_assessment'])
                         if isinstance(n, ast.keyword) and n.arg == 'conv_history'
                         and isinstance(n.value, ast.List) and not n.value.elts)
    random_selection = next(n for n in ast.walk(methods['generate_response'])
                            if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute)
                            and isinstance(n.func.value, ast.Name)
                            and n.func.value.id == 'random' and n.func.attr == 'choice')
    return [
        {'id': 'HUB-RD-POOL', 'observation': 'load_principles flattens all loaded rule groups; the method does not retain per-case grouping',
         'evidence': anchor(path, methods['load_principles']),
         'scope': 'Locked PatientHub implementation, verified with a two-case nonclinical fixture'},
        {'id': 'HUB-RD-ONE', 'observation': 'One principle is selected from the pooled list for each response',
         'evidence': anchor(path, random_selection),
         'scope': 'Selection mechanism, not a clinical effect or empirical frequency'},
        {'id': 'HUB-RD-HISTORY', 'observation': 'Assessment rendering receives an empty list as conversation history',
         'evidence': anchor(path, empty_history),
         'scope': 'Bounded control-flow test; previous turns are present at draft stage but absent at refinement stage'},
        {'id': 'HUB-PSY-NAMED-EXAMPLES', 'observation': 'English wrapper prompt does not contain named flight-of-ideas or circumstantiality examples described as additional interventions in the original paper',
         'evidence': {'path': 'data/prompts/client/psyche.yaml', 'language': 'en'},
         'scope': 'Prompt-level reconstruction mismatch to check before reproduction; not an original PSYCHE model failure'}]


def write_report(checks, inventory, lock):
    fields, themes = inventory['psyche_mfc_behavior_fields'], inventory['roleplay_public_paper_themes']
    lines = ['# PSYCHE와 Roleplay doh의 특징 추출과 구현 점검', '',
             '2026년 11월 1일', '',
             '## 이번 단계의 결론', '',
             'PSYCHE를 주력 검토 대상으로 전환했다. 원저의 특징과 공개 재구현의 실제 동작을 분리하여, '
             'PSYCHE의 정신상태 관련 설정 12개와 Roleplay-doh 논문에 공개된 원칙 주제 7개를 추출했다. '
             '두 목록은 정의와 단위가 달라 19개 동등한 임상 특징으로 합치거나 점수화하지 않았다.', '',
             '공개 재구현은 그대로 원형 비교에 쓰기 어렵다. Roleplay-doh의 원칙 선택 및 수정 단계 문맥 전달이 '
             '확인됐고, PSYCHE 영어 프롬프트에는 원저가 추가했다고 설명한 사고과정 예시의 이름이 없었다. '
             '따라서 지금 생성하면 원형 모델의 특징보다 재구현 차이를 측정할 가능성이 있다. 이것은 이번 코드 감사의 판단이지 임상 성능 결과가 아니다.', '',
             '## 실제로 확보하고 확인한 것', '',
             f"PatientHub commit `{lock['commit_sha']}`의 공개 파일 {checks['public_files_verified']}개를 보존하고 Git blob 해시를 검증했다. "
             '패치 저장 과정에서 추가된 마지막 줄바꿈 한 바이트를 구분해 검증했으며 스냅샷 해시도 남겼다. '
             '원저자의 PSYCHE 코드 저장소는 확인하지 못했으므로 PatientHub를 원저 코드라고 부르지 않는다.', '',
             'PSYCHE의 제공 프로필 2개는 스키마 검사에 모두 통과했다. 그러나 둘 다 사고 과정은 Normal, 발화량은 Decreased로 설정되어 있다. '
             '이 두 예제로 조현병 사고장애의 모사 성능을 측정할 수는 없다.', '',
             'Roleplay-doh 전체 전문가 원칙 자료는 HF 로그인과 정보 공유 동의가 필요하다. '
             '파일을 받지 않았고 다른 저장소의 원칙 사본으로 우회하지 않았다. 이번 원칙 분석의 범위는 공개 원저 Table 2의 7개 주제다.', '',
             '## PSYCHE에서 추출한 설정', '']
    for f in fields:
        lines.append('- ' + f['label_ko'] + '  ' + f['interpretation_rule'])
    lines.extend(['', '위 분류는 측정 가능성에 대한 작업 메모다. 임상 등급이나 검증된 자동 척도가 아니다. '
                  '발화량의 단어 수를 계산하는 것과 음성 증상을 평가하는 것을 구분했다.', '',
                  '## Roleplay doh의 공개 주제와 저자 보고 빈도', ''])
    for r in themes:
        lines.append(f"- {r['theme_ko']}  {r['count']}/25 페르소나 ({r['author_reported_percent']:.0f}%)")
    lines.extend(['', '빈도는 원저가 25개 생성 페르소나의 전문가 원칙을 분석한 결과다. '
                  '이번에 생성 발화에서 측정한 값이나 실제 환자의 증상 유병률이 아니다. 주제는 서로 중복되므로 비율을 합하지 않는다.', '',
                  '## 같은 이름으로 맞추면 안 되는 특징', '',
                  'PSYCHE의 사고 과정은 정신상태검사의 임상 항목이다. Roleplay-doh의 덜 정돈된 표현 주제는 '
                  '감정의 상충과 불완전한 자기 이해를 포함한다. 이를 같은 사고장애 변수로 자동 정렬하지 않는다. '
                  '또한 PSYCHE의 병식과 Roleplay-doh의 성찰 역시 정의가 같지 않다.', '',
                  '비교 가능한 후보는 발화량, 표현의 정제 정도, 정보 공개와 협조 양상이다. 이 역시 동일한 임상 개념으로 '
                  '합치기 전에 각 원칙의 조건과 요구하는 행동을 기록해야 한다. 정보 공개를 줄이면서 경험을 자세히 말하라는 '
                  '서로 다른 요구가 존재하므로 모든 페르소나에 하나의 이상적인 발화량을 적용할 수 없다.', '',
                  '## 실제 코드 경로에서 확인한 결과', '',
                  '임상 내용이 없는 규칙 A와 B, 고정 응답 표식으로 원래 클래스의 선택 경로를 검사했다. '
                  '실제 LLM은 호출하지 않았다. 확인된 것은 다음과 같다.', '',
                  '- 사례별 규칙 묶음이 하나의 목록으로 합쳐지고 매 응답에서 원칙 하나가 선택된다.',
                  '- 최초 응답에는 이전 대화가 전달되지만 수정 단계의 대화 이력은 빈 목록이다.',
                  '- 최초 응답 프롬프트에 전달되는 변수는 프로필과 대화 이력이며 전문가 원칙은 별도로 전달되지 않는다.',
                  '- PSYCHE 영어 재구현에는 원저가 설명한 flight of ideas 및 circumstantiality의 이름을 가진 예시가 없다.', '',
                  '이 결과는 고정한 PatientHub 버전에 한정한다. 원형 Roleplay-doh나 PSYCHE의 임상적 실패로 보고하지 않는다. '
                  '전체 패키지를 실행한 것도 아니다. 문맥이 없는 수정이 실제 발화를 얼마나 바꾸는지는 아직 시험하지 않았다.', '',
                  '## 다음 단계와 필요한 자료', '',
                  '조현병 목표를 유지하며 다음 설계는 원저 프롬프트와 재구현의 차이를 확정하는 데서 시작한다. '
                  '원형에서 제공한 사고과정 예시와 조건부 지시를 추적하고, 원형 재현과 별도 개선안을 분리한다. '
                  '생성 파일럿을 시작할 때는 발화량을 맞추는 것과 사고과정을 구현하는 것을 다른 목표로 둔다. '
                  '새 연결성 점수를 임의로 만들거나 일반 감정 갈등을 사고장애 정답으로 쓰지 않는다.', '',
                  'Roleplay-doh 원칙 전수 분석에는 사용자가 정식 접근 조건을 확인한 뒤 받은 파일이 필요하다. '
                  '파일이 없으면 논문 공개 주제 수준의 비교까지만 진행할 수 있다. 이번에 확인한 런타임에는 '
                  'Jinja2, PyYAML, OmegaConf가 없어 전체 PatientHub 실행을 시도하거나 설치하지 않았다.', '',
                  '이번 단계는 특징 추출과 구현 점검까지 완료했다. 회귀 테스트 8개가 통과했으며 '
                  '새 LLM 호출, 임상 채점, 유료 API, 모델 다운로드, 설치, 원격 작업은 모두 0회다.', '',
                  '## 원출처', '',
                  '- [PSYCHE 원저](https://arxiv.org/html/2501.01594v1)',
                  '- [Roleplay doh 원저](https://aclanthology.org/2024.emnlp-main.591.pdf)',
                  '- [Roleplay doh 원칙 접근 조건](https://huggingface.co/datasets/SALT-NLP/roleplay-doh_principles)',
                  f"- [고정한 공개 재구현](https://github.com/Sahandfer/PatientHub/tree/{lock['commit_sha']})", ''])
    (SHARE / '특징추출과구현점검.md').write_text('\n'.join(lines))
    (SHARE / 'README.ko.md').write_text(
        '# PSYCHE 주력 전환 뒤 첫 분석\n\n'
        '특징추출과구현점검.md에 이번 결과와 다음 결정을 정리했다. '
        '실제 생성 발화의 성능 실험은 하지 않았다.\n\n'
        '재현은 프로젝트 폴더에서 아래 명령으로 가능하다. 기존 번들 Python과 Pydantic만 사용하며 네트워크 연결이 필요 없다.\n\n'
        '```bash\n'
        "cd '/Users/ohs/Documents/ChatGPT/투비닥터 연구/persona-audit'\n"
        '/Users/ohs/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 scripts/audit_psyche_roleplay_sources.py\n'
        '/Users/ohs/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3 -m unittest discover -s tests -p test_psyche_roleplay_sources.py -v\n'
        '```\n\n'
        '구조화된 결과는 analysis/psyche-roleplay-source-audit-v01의 feature-inventory.json, '
        'offline-checks.json, implementation-findings.json, source-verification.json에 있다. '
        '원칙의 전체 개별 파일은 확보하지 않았다. 초기 리터럴 블록 추출기의 공백 줄 처리 문제를 수정했으며 '
        '수정 전 진단 기록을 offline-checks.initial-parser.json에 보존하고 회귀 테스트를 추가했다.\n')


def main():
    lock, phase = read_json(LOCK), read_json(PHASE)
    OUT.mkdir(parents=True, exist_ok=True)
    SHARE.mkdir(parents=True, exist_ok=True)
    verified = verify_sources(lock)
    fields = behavior_fields()
    themes = [{**r, 'denominator': 25, 'author_reported_percent': 100 * r['count'] / 25,
               'source': 'Roleplay-doh archival paper Table 2 and Section 5.2',
               'new_output_measurement': False} for r in phase['published_theme_counts']]
    assert len(themes) == 7
    checks = {'public_files_verified': len(verified),
              'schema_validation': validate_profile_fixtures(),
              'roleplay_controlflow_fixture': bounded_roleplay_test(),
              'prompt_inventory': prompt_inventory(),
              'installed_package_availability': {name: bool(importlib.util.find_spec(name))
                  for name in ('pydantic', 'jinja2', 'yaml', 'omegaconf')}}
    inventory = {'psyche_mfc_behavior_fields': fields,
                 'roleplay_public_paper_themes': themes,
                 'proposed_crosswalk': read_json(ROOT / 'config/psyche-roleplay-crosswalk-v01.json'),
                 'units_are_not_equivalent': True,
                 'field_measurement_classes': dict(Counter(r['measurement_class'] for r in fields)),
                 'classification_scope': 'Assistant-authored measurement feasibility notes, not clinical ratings or a validated taxonomy'}
    for name, data in [('source-verification.json', verified), ('feature-inventory.json', inventory),
                       ('offline-checks.json', checks), ('implementation-findings.json', implementation_findings())]:
        (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    status = {'date': phase['date'], 'phase': phase['phase'],
              'source_inventory_completed': True, 'native_generation_ready': False,
              'original_psyche_code_verified': False,
              'roleplay_full_individual_principles_accessed': False,
              'next_decision': 'Schema fixtures pass, but do not benchmark native systems using this wrapper without addressing implementation provenance, dependency readiness and refinement-context differences.',
              'cost': {'real_llm_calls': 0, 'paid_apis': 0, 'installs': 0, 'model_downloads': 0, 'remote_jobs': 0}}
    (OUT / 'status.json').write_text(json.dumps(status, ensure_ascii=False, indent=2) + '\n')
    write_report(checks, inventory, lock)
    (OUT / 'audit-manifest.json').write_text(json.dumps({
        'script_sha256': sha256(Path(__file__).read_bytes()).hexdigest(),
        'lock_sha256': sha256(LOCK.read_bytes()).hexdigest(),
        'phase_sha256': sha256(PHASE.read_bytes()).hexdigest(),
        'crosswalk_sha256': sha256((ROOT / 'config/psyche-roleplay-crosswalk-v01.json').read_bytes()).hexdigest(),
        'report_sha256': sha256((SHARE / '특징추출과구현점검.md').read_bytes()).hexdigest(),
        'output_sha256': {p.name: sha256(p.read_bytes()).hexdigest()
                          for p in OUT.glob('*.json') if p.name != 'audit-manifest.json'}}, indent=2) + '\n')
    print(json.dumps({'status': 'passed', 'public_files_verified': len(verified),
                      'psyche_fields': len(fields), 'published_roleplay_themes': len(themes),
                      'profile_schema_valid': checks['schema_validation']['valid_profiles'],
                      'profile_schema_total': checks['schema_validation']['profiles'],
                      'new_llm_calls': 0}, ensure_ascii=False))


if __name__ == '__main__':
    main()
