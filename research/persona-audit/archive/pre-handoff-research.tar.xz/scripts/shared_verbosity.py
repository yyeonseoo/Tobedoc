"""Prospective common-baseline source-module comparison; offline analysis/local generation."""
import argparse
from collections import defaultdict
import json
import random
import re
from statistics import mean

from audit_sources import parse_styles
from common import ROOT, digest, read_source, source_records, write_json
from fact_disclosure_probe import match_fact
from first_reply_probe_runner import run, verify_response
from run_local_pilot import OPTIONS, fingerprint, now
from summarize_local_pilot import text_metrics

RUN = "shared-verbosity-v02"
SPEC = ROOT / "config" / (RUN + ".json")
FOLDER = ROOT / "pilot/runs" / RUN
OUT = ROOT / "analysis" / RUN


def read(path):
    return json.loads(path.read_text())


def freeze(path, value):
    if path.exists():
        if read(path) != value:
            raise ValueError(f"Frozen input changed: {path}")
    else:
        write_json(path, value)


def modules():
    psi = parse_styles(read_source("psi_styles"))
    sim = json.loads(read_source("patientsim_personality"))
    verbose, n = re.subn(r"But you must not exceed 8 sentences each turn\.\s*", "", psi["verbose"])
    if n != 1 or psi["plain"] != "":
        raise ValueError("Unexpected PSI source schema")
    return {"neutral": "", "simple_verbose": "Give longer, more detailed answers when responding to the interviewer.",
            "psi_verbose": verbose, "sim_verbose": sim["verbose"], "sim_concise": sim["plain"]}


def conditions():
    spec, mods = read(SPEC), modules()
    rows, rng = [], random.Random(20261102)
    blocks = [(case, target, repeat) for case in spec["fictional_cases"] for target in ("A", "B")
              for repeat in spec["repeat_indices"]]
    rng.shuffle(blocks)
    for case, target, repeat in blocks:
        # Balance list position across people; fixed within every matched block.
        facts = case["facts"] if case["id"] in ("V1", "V3") else case["facts"][4:] + case["facts"][:4]
        group = []
        for arm in spec["arms"]:
            prompt = (f"You are {case['name']}, a fictional adult. This is a simulation, not a real patient or diagnosis.\n"
                      "The following events occurred on different days. No causal connection between them is specified.\n"
                      + "\n".join(f["description"] for f in facts) + "\nConversation style:\n" + mods[arm]
                      + "\nUse only the supplied facts. Do not invent facts or a diagnosis. Respond in natural English as this person. "
                      "Write only this person's reply, not interviewer turns or stage directions.")
            row = {"condition_id": f"SV-{case['id']}-Q{target}-R{repeat}-{arm}", "profile_id": case["id"],
                   "target_event": target, "repeat_index": repeat, "style_id": arm, "arm": arm,
                   "facts": facts, "system_prompt": prompt,
                   "interview": [{"turn": 1, "probe": "single_event", "text": spec["question"].format(event=case["events"][target])}]}
            row["prompt_sha256"] = fingerprint({"system_prompt": prompt, "interview": row["interview"]})
            group.append(row)
        rng.shuffle(group)
        rows.extend(group)
    if len(rows) != spec["maximum_requests"] or len(rows) != 80:
        raise ValueError("Fixed request bound changed")
    return rows


def prepare():
    spec, rows = read(SPEC), conditions()
    locked = source_records()
    code = ["scripts/shared_verbosity.py", "scripts/fact_disclosure_probe.py", "scripts/first_reply_probe_runner.py",
            "scripts/run_feature_batch.py", "scripts/run_local_pilot.py", "scripts/summarize_local_pilot.py"]
    plan = {"run_id": RUN, "max_requests": 80, "model_digest": spec["model_digest"], "options": OPTIONS,
            "think": False, "design": "4 new fictional cases x 2 requested events x 2 seeds x 5 arms; 80 first replies",
            "seed_rule": "20261030+100*repeat_index+1; indices 8/9, matched across arms",
            "analysis_contract": spec["analysis_contract"], "spec_sha256": digest(SPEC.read_bytes()),
            "conditions_sha256": fingerprint(rows), "code_at_preparation": {p: digest((ROOT / p).read_bytes()) for p in code},
            "source_provenance": [{k: locked[s][k] for k in ("id", "commit", "sha256", "text_sha256", "citation_url")}
                                  for s in ("psi_styles", "patientsim_personality")],
            "adaptation": "PSI verbose numeric 8-sentence cap removed, all remaining style text unchanged. PatientSim personality verbose/plain verbatim. All native wrappers, CEFR/recall/dazedness excluded. Plain is renamed sim_concise. Single shared empty baseline.",
            "stopping": "80 maximum; stop on failure/truncation; preserve every output, no replacements or alias expansion",
            "paid_api_calls_allowed": False, "new_downloads_allowed": False, "llm_judge_calls_allowed": False}
    freeze(FOLDER / "plan.json", plan)
    freeze(FOLDER / "conditions.json", rows)
    if not (FOLDER / "prepared-at.json").exists():
        write_json(FOLDER / "prepared-at.json", {"prepared_at_utc": now(), "plan_sha256": fingerprint(plan)})
    return plan, rows


def measure(case, raw):
    matches = [match_fact(raw["response_text"], f) for f in case["facts"]]
    requested = sum(m["recognized_mention"] for m in matches if m["domain"] == case["target_event"])
    other = sum(m["recognized_mention"] for m in matches if m["domain"] != case["target_event"])
    metrics = text_metrics(raw["response_text"])
    return {**{k: case[k] for k in ("condition_id", "profile_id", "target_event", "repeat_index", "style_id")},
            "word_count": metrics["word_count"], "sentences": metrics["sentence_count_heuristic"],
            "requested_refs": requested, "other_refs": other, "other_positive": int(other > 0),
            "requested_full": int(requested == 4),
            "words_per_requested_ref": metrics["word_count"] / requested if requested else None,
            "output_tokens": raw["raw_response"]["eval_count"], "fact_matches": matches,
            "response_text": raw["response_text"]}


def contrast(rows, arm, baseline):
    blocks = defaultdict(dict)
    for row in rows:
        blocks[(row["profile_id"], row["target_event"], row["repeat_index"])][row["style_id"]] = row
    result = {}
    for metric in ("word_count", "sentences", "requested_refs", "other_refs", "other_positive"):
        differences = [{"block": list(key), "difference": val[arm][metric] - val[baseline][metric]}
                       for key, val in sorted(blocks.items())]
        by_case = {case: mean(d["difference"] for d in differences if d["block"][0] == case)
                   for case in sorted({r["profile_id"] for r in rows})}
        result[metric] = {"mean_difference": mean(d["difference"] for d in differences), "case_means": by_case,
                          "positive_blocks": sum(d["difference"] > 0 for d in differences),
                          "negative_blocks": sum(d["difference"] < 0 for d in differences), "block_differences": differences}
    return result


def analyze():
    plan, cases = prepare()
    rows, raw_rows, provenance = [], [], [SPEC, FOLDER / "plan.json", FOLDER / "conditions.json", FOLDER / "runtime.json"]
    for case in cases:
        rp = FOLDER / "requests" / (case["condition_id"] + ".json")
        sp = FOLDER / "responses" / (case["condition_id"] + ".json")
        request, raw = read(rp), read(sp)
        verify_response(raw, request, case, plan["model_digest"])
        if raw["raw_response"].get("done_reason") != "stop":
            raise ValueError("Non-stop completion must not enter final comparison")
        rows.append(measure(case, raw))
        raw_rows.append(raw)
        provenance += [rp, sp]
    summaries = []
    for arm in read(SPEC)["arms"]:
        subset = [r for r in rows if r["style_id"] == arm]
        summaries.append({"arm": arm, "n": len(subset), **{k: mean(r[k] for r in subset) for k in
                         ("word_count", "sentences", "requested_refs", "other_refs")},
                          "requested_refs_total": sum(r["requested_refs"] for r in subset), "requested_denominator": 64,
                          "full_coverage_replies": sum(r["requested_full"] for r in subset),
                          "other_positive_replies": sum(r["other_positive"] for r in subset),
                          "output_tokens_max": max(r["output_tokens"] for r in subset),
                          "words_per_requested_ref_pooled": sum(r["word_count"] for r in subset) / sum(r["requested_refs"] for r in subset)})
    pairs = [(a, "neutral") for a in read(SPEC)["arms"] if a != "neutral"] + [
        ("psi_verbose", "simple_verbose"), ("sim_verbose", "simple_verbose"),
        ("sim_verbose", "psi_verbose"), ("sim_verbose", "sim_concise")]
    result = {"run_id": RUN, "plan": plan, "actual_responses": len(rows), "summaries": summaries,
              "contrasts": {a + "_minus_" + b: contrast(rows, a, b) for a, b in pairs},
              "cost": {"wall_seconds": sum(r["wall_seconds"] for r in raw_rows),
                       "input_tokens": sum(r["raw_response"]["prompt_eval_count"] for r in raw_rows),
                       "output_tokens": sum(r["raw_response"]["eval_count"] for r in raw_rows),
                       "paid_api_calls": 0, "llm_judge_calls": 0, "new_downloads": 0},
              "provenance": [{"path": str(p.relative_to(ROOT)), "sha256": digest(p.read_bytes())} for p in provenance]}
    write_json(OUT / "results.json", result)
    write_json(OUT / "response-metrics.json", rows)
    transcripts = ["# Complete source-module comparison transcripts", "", "All 80 raw first replies; no selections or edits.", ""]
    for case, row in zip(cases, rows):
        transcripts += ["## " + row["condition_id"], "", "Interviewer: " + case["interview"][0]["text"], "", row["response_text"], ""]
    (OUT / "transcripts.md").write_text("\n".join(transcripts))
    print(json.dumps({"summaries": summaries, "cost": result["cost"]}, ensure_ascii=False))
    return result, rows


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("prepare", "run", "analyze"))
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if args.action == "analyze":
        analyze()
    else:
        plan, rows = prepare()
        if args.action == "run":
            run(plan, rows, FOLDER, resume=args.resume)
        else:
            print(json.dumps({"prepared": len(rows), "plan": str(FOLDER / "plan.json")}))
