// Paired descriptive profiles. Each segment is one situation/repeat, not a patient.
import AppKit
import Foundation
struct Pair: Decodable { let native: Double; let alias: Double }
struct Panel: Decodable { let title: String; let unit: String; let pairs: [Pair]; let low: Double; let high: Double }
struct Input: Decodable { let panels: [Panel]; let caption: String }
let input = try JSONDecoder().decode(Input.self, from: Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1])))
let width = 1220, height = 870
let bitmap = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: width, pixelsHigh: height, bitsPerSample: 8,
    samplesPerPixel: 4, hasAlpha: true, isPlanar: false, colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0)!
NSGraphicsContext.saveGraphicsState(); NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep: bitmap)
let cg = NSGraphicsContext.current!.cgContext
cg.setFillColor(NSColor.white.cgColor); cg.fill(CGRect(x: 0, y: 0, width: width, height: height))
func text(_ s: String, _ x: Double, _ y: Double, _ size: Double = 13, _ color: NSColor = .black) {
    (s as NSString).draw(at: CGPoint(x: x, y: y), withAttributes: [.font: NSFont.systemFont(ofSize: size), .foregroundColor: color])
}
text("One-field input ablation: automatic-thought alias only", 35, 826, 23)
text("Qwen3-14B | 24 fresh dialogues / 96 replies | Paired lines: 3 situations x 2 repeats, one example persona", 35, 797, 14, .darkGray)
for (i, panel) in input.panels.prefix(4).enumerated() {
    let left = Double(i%2)*600+90, bottom = i < 2 ? 463.0 : 110.0
    let top = bottom+215, right = left+465
    func y(_ v: Double) -> Double { bottom+(v-panel.low)/(panel.high-panel.low)*215 }
    text(panel.title, left-30, top+48, 17)
    text(panel.unit, left-30, top+26, 12, .darkGray)
    for tick in 0...4 {
        let v = panel.low+(panel.high-panel.low)*Double(tick)/4
        cg.setStrokeColor(NSColor(white: 0.87, alpha: 1).cgColor); cg.setLineWidth(0.7)
        cg.move(to: CGPoint(x: left, y: y(v))); cg.addLine(to: CGPoint(x: right, y: y(v))); cg.strokePath()
        text(String(format: "%.2f", v), left-42, y(v)-6, 12, .darkGray)
    }
    for (j, pair) in panel.pairs.enumerated() {
        let jitter = (Double(j)-Double(panel.pairs.count-1)/2)*6
        let a = left+90+jitter, b = left+360+jitter
        cg.setStrokeColor(NSColor(white: 0.62, alpha: 1).cgColor); cg.setLineWidth(1)
        cg.move(to: CGPoint(x: a, y: y(pair.native))); cg.addLine(to: CGPoint(x: b, y: y(pair.alias))); cg.strokePath()
        cg.setFillColor(NSColor.white.cgColor); cg.fillEllipse(in: CGRect(x: a-4, y: y(pair.native)-4, width: 8, height: 8))
        cg.setStrokeColor(NSColor.black.cgColor); cg.strokeEllipse(in: CGRect(x: a-4, y: y(pair.native)-4, width: 8, height: 8))
        cg.setFillColor(NSColor(calibratedRed: 0.16, green: 0.35, blue: 0.46, alpha: 1).cgColor)
        cg.fillEllipse(in: CGRect(x: b-4, y: y(pair.alias)-4, width: 8, height: 8))
    }
    text("Native mapping", left+40, bottom-25, 13)
    text("Thought alias only", left+300, bottom-25, 13)
    text("Input-mapping condition", left+160, bottom-47, 12, .darkGray)
}
text(input.caption, 35, 30, 11, .darkGray)
NSGraphicsContext.restoreGraphicsState()
try bitmap.representation(using: .png, properties: [:])!.write(to: URL(fileURLWithPath: CommandLine.arguments[2]))
print("Saved paired ablation plot.")
