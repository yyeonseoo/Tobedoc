"""Posthoc source-span audit of all 40 replies; never edit frozen primary scores."""
from common import digest,write_json
from disclosure_comparison import OUT,FOLDER,read
from run_local_pilot import now


def main():
    rows=read(OUT/'response-metrics.json')
    indexed={r['condition_id']:r for r in rows}
    # Each span below was read in the complete raw reply, not inferred from a score.
    challenges={
        'DC-DC1-event_first-R11-skeptic_only':'Why do you care so much about my personal matters?',
        'DC-DC2-event_first-R10-skeptic_only':'Why do you care so much about all this?',
        'DC-DC1-event_first-R10-skeptic_only':"Why are you asking all this? What's your interest?",
        'DC-DC2-personal_first-R10-skeptic_only':'Why do you care so much about all this?',
        'DC-DC1-personal_first-R10-skeptic_only':'Why do you ask?',
        'DC-DC1-personal_first-R11-skeptic_only':'Why do you care so much?',
        'DC-DC2-event_first-R10-psi_reserved':'Why are you asking me these questions?',
        'DC-DC1-event_first-R10-psi_reserved':'Why are you asking me all these questions?',
        'DC-DC2-event_first-R11-sim_distrust':'Why do you need all this information?',
        'DC-DC1-event_first-R11-sim_distrust':'Why are you asking all these questions?',
        'DC-DC2-event_first-R10-sim_distrust':"I don't see why you need to know all that.",
        'DC-DC1-event_first-R10-sim_distrust':'Why do you care?',
        'DC-DC2-personal_first-R11-sim_distrust':"I don't see why you're asking about it.",
        'DC-DC2-personal_first-R10-sim_distrust':"I don't see why you need all that information.",
        'DC-DC1-personal_first-R10-sim_distrust':'But why do you need all this information?',
        'DC-DC1-personal_first-R11-sim_distrust':"I don't see why you need all that information."
    }
    observations=[
        {'condition_id':'DC-DC1-personal_first-R10-psi_reserved',
         'quote':"I don't really want to talk about my bills",
         'type':'unmatched_nondisclosure_formula',
         'meaning':'The pre-frozen pattern omitted the modifier really. Its zero count cannot be read as absence of all nondisclosure language.'},
        {'condition_id':'DC-DC2-event_first-R10-psi_reserved',
         'quote':"I don't think that's any of your business.",
         'type':'unmatched_privacy_boundary',
         'meaning':'Boundary language was outside the frozen none-of-your-business pattern.'},
        {'condition_id':'DC-DC1-event_first-R10-psi_reserved',
         'quote':"I don't think that's any of your business.",
         'type':'unmatched_privacy_boundary',
         'meaning':'The reply omits both fact domains while challenging the request, not selective personal-only nondisclosure.'},
        {'condition_id':'DC-DC2-personal_first-R10-psi_reserved',
         'quote':"I'm not sure about the exact amount, but it's something like 150 dollars. And it's been a while, maybe around 10 days?",
         'type':'approximation_not_exact_reference',
         'meaning':'Profile amount 152 and 11 days are replaced by approximate 150 and 10; keep exact-reference counts unchanged, do not call both intentional withholding.'},
        {'condition_id':'DC-DC1-personal_first-R10-psi_reserved',
         'quote':"I think it's around eighty-something dollars.",
         'type':'approximation_not_exact_reference',
         'meaning':'83 is not explicitly given; broad range is not added as a posthoc alias.'},
        {'condition_id':'DC-DC1-personal_first-R11-psi_reserved',
         'quote':"it's been a little over a week since it was due.",
         'type':'temporal_approximation_not_exact_reference',
         'meaning':'A little over a week is compatible with nine days but does not identify nine exactly; preserve the primary nonmatch.'},
        {'condition_id':'DC-DC2-personal_first-R11-sim_distrust',
         'quote':"I don't owe money for some service you're talking about",
         'type':'profile_debt_denial',
         'meaning':'The response denies owing money despite the supplied overdue bill. This is not the same behavior as declining to answer.'},
        {'condition_id':'DC-DC1-personal_first-R11-sim_distrust',
         'quote':"I don't know why you're asking about that.",
         'type':'uncertainty_cue_target_is_question_purpose',
         'meaning':'The phrase I do not know concerns the question purpose; it is not evidence of poor recall of bill facts.'}
    ]
    challenge_rows=[]
    for cid,span in challenges.items():
        row=indexed[cid]
        assert span in row['response_text']
        challenge_rows.append({'condition_id':cid,'span':span,'style_id':row['style_id'],
                               'primary_skepticism_pattern_positive':bool(row['skepticism']),
                               'all_personal_references':row['personal_refs']==3,
                               'all_six_references':row['personal_refs']==row['event_refs']==3,
                               'label':'literal_challenge_to_information_request_posthoc_not_clinical_distrust'})
    for item in observations:
        assert item['quote'] in indexed[item['condition_id']]['response_text']
    summaries=[]
    for arm in ('neutral','brief','skeptic_only','psi_reserved','sim_distrust'):
        part=[r for r in challenge_rows if r['style_id']==arm]
        group=[r for r in rows if r['style_id']==arm]
        summaries.append({'arm':arm,'replies':8,'audited_request_challenge_replies':len(part),
                          'challenge_with_all_personal':sum(r['all_personal_references'] for r in part),
                          'challenge_with_all_six':sum(r['all_six_references'] for r in part),
                          'personal_by_seed':{str(seed):sum(r['personal_refs'] for r in group if r['repeat_index']==seed) for seed in (10,11)}})
    examples=[
        {'condition_id':'DC-DC2-event_first-R11-sim_distrust',
         'label':'의심을 표현하면서 정보를 답한 경우',
         'quote':"My overdue bill is for electricity, I owe 152 dollars, and it's 11 days overdue. Why do you need all this information?",
         'interpretation':'입력에 주어진 청구서 종류·금액·연체 일수를 말한 뒤 정보 요구 목적을 따졌다. 의심을 드러내는 말투와 정보 표식의 생략은 같은 현상이 아니었다.'},
        {'condition_id':'DC-DC2-personal_first-R10-psi_reserved',
         'label':'정확한 값 대신 불확실한 근사값을 말한 경우',
         'quote':"I'm not sure about the exact amount, but it's something like 150 dollars. And it's been a while, maybe around 10 days?",
         'interpretation':'주어진 값은 152달러와 11일이다. 정확한 표식은 인식되지 않지만 답변은 대략적인 값을 말하고 있다. 이런 비인식을 모두 의도적 거절로 해석하면 안 된다.'}
    ]
    for example in examples:
        assert example['quote'] in indexed[example['condition_id']]['response_text']
    reviewed=[{'condition_id':r['condition_id'],
               'raw_sha256':digest((FOLDER/'responses'/(r['condition_id']+'.json')).read_bytes())} for r in rows]
    result={'reviewed_at_utc':now(),'reviewer':'assistant_full_raw_text_and_source_span_audit_not_independent_human_rating',
            'reviewed_responses':reviewed,'prespecified_audit_subset':[r['condition_id'] for r in read(OUT/'audit-candidates.json')],
            'audit_extension':'All 40 replies were read after rule-coverage gaps were noticed, including replies outside the prespecified subset. Supplemental challenge spans are posthoc, not a validated new classifier.',
            'primary_scores_unchanged':True,'frozen_patterns_or_aliases_changed':False,
            'primary_nondisclosure_cue_known_incomplete':True,'primary_skepticism_cue_known_incomplete':True,
            'request_challenge_spans':challenge_rows,'supplemental_summaries':summaries,
            'examples':observations+examples,'report_examples':examples,'independent_human_ratings':0,
            'report_paragraph':'40응답 모두를 입력과 대조했다. 처음 정한 점검 대상 15개 외에도 표현 누락 여부를 확인하기 위해 나머지 응답을 추가로 읽었다. 비공개 규칙은 I don\'t really want to talk about을 놓쳤고, 의심 규칙은 Why do you care 같은 표현을 포괄하지 못했다. 모든 조건에서 비공개 문구 인식이 0/8이라는 원래 수치는 유지하되, 거절 표현 자체가 없다는 결론에는 사용하지 않았다. 아래 목적 도전 문구의 전수 대조는 어시스턴트가 근거 구간을 확인한 사후 보조 분석이며 독립 사람 평가가 아니다.'}
    write_json(OUT/'reference-audit.json',result)
    print({'reviewed':len(reviewed),'request_challenge_spans':len(challenge_rows),'supplemental_summaries':summaries})


if __name__=='__main__':
    main()
