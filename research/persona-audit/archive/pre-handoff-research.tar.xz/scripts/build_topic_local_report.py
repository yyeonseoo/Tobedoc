"""Concise Korean report from cached measurements; no new model calls."""
import argparse
from docx import Document
from docx.shared import Pt

from common import ROOT,digest,write_json
from topic_local_separation import OUT,read
from build_integrated_report import font,paragraph,heading,table
from build_two_feature_report import configure
from build_role_audit_report import reference

SHARE=ROOT/'share/topic-local-separation-v01'
OUTPUT=SHARE/'페르소나 질문 대응과 문장 유사도 분리 분석.docx'


def build(replace=False):
    if OUTPUT.exists() and not replace:
        raise FileExistsError('Preserve the existing report unless repairing layout')
    result=read(OUT/'results.json')
    details=read(OUT/'response-details.json')
    summaries={r['style']:r for r in result['summaries']}
    contrast=result['tangent_minus_verbose']
    doc=Document()
    configure(doc)
    doc.core_properties.title='페르소나 질문 대응과 문장 유사도 분리 분석'
    doc.core_properties.author='연구팀'
    doc.core_properties.subject='기존 48응답 재사용과 계측 대조'
    doc.core_properties.comments=''
    title=doc.add_paragraph('페르소나 질문 대응과 문장 유사도 분리 분석',style='Title')
    title.paragraph_format.line_spacing=Pt(25)
    title.paragraph_format.space_after=Pt(7)
    for run in title.runs:
        font(run,18,True)
    paragraph(doc,'기존 영어 응답 48개  411문장  새 생성과 새 임베딩 0회',bold=True)

    heading(doc,'질문에 답하는 것과 문장끼리 닮은 것은 달랐다')
    paragraph(doc,'우리는 주제 이탈이라는 이름의 페르소나가 실제로 무엇을 바꾸는지 확인하고자 했다. 질문에 답하지 않는 것인지, 필요한 답은 하면서 다른 이야기를 덧붙이는 것인지, 문장 간 유사도가 낮아지는 것인지를 나눠 보았다. 이것들을 하나로 묶으면 같은 답변에 서로 다른 해석을 붙이게 된다.')
    paragraph(doc,'plain·verbose·tangent 모두 요청한 장소·금액·동행인을 48/48개 언급했다. 반면 tangent의 인접 문장 유사도는 verbose보다 낮았다. 따라서 이 과제에서 tangent의 변화는 요청 정보 누락으로 설명되지 않았다. 다만 다른 주제 문장을 넣었는데도 인접 유사도가 올라간 경우가 있어, 이를 곧바로 사고의 연결성 점수로 해석할 수는 없다.')

    heading(doc,'동일한 답변에서 세 가지를 따로 계산했다')
    paragraph(doc,'앞서 생성한 두 허구 인물·인물별 두 사건·질문 표현 두 종·seed 두 개·세 말투의 첫 답변 48개를 재사용했다. 원래 요청과 응답 96개 파일을 다시 대조했고, 저장된 macOS 영어 임베딩 revision 1의 512차원 벡터를 사용했다. PATIENT-Ψ 말투 지시를 같은 Qwen3-14B에 이식한 자료이며 원형 앱 전체의 재현은 아니다. 기존 verbose·tangent 지시에서는 숫자 문장 상한만 제거했다.')
    paragraph(doc,'질문 대응은 기존 별칭 규칙에 맞는 정보 3개의 언급 여부로 계산했다. 주제 관련도는 각 문장과 요청 사건의 고정 설명문 3개 사이의 최대 코사인 유사도를 구한 뒤 문장 평균을 냈다. 실제 질문 문장의 유사도나 정답 점수는 아니다. 국소 유사도는 이웃한 문장 사이의 평균 코사인이다. 조건별로 계산 가능한 답변을 동일 가중했다.')
    table(doc,['말투','요청 정보','평균 단어','평균 문장','주제 관련도','인접 유사도'],[
        [style,f"{summaries[style]['requested_refs_total']}/48",f"{summaries[style]['word_count']:.1f}",
         f"{summaries[style]['sentence_count']:.1f}",f"{summaries[style]['topic_association']:.3f}",f"{summaries[style]['adjacent_cos']:.3f}"]
        for style in ('plain','verbose','tangent')],[1.0,1.0,1.0,1.0,1.5,1.5],numeric=(1,2,3,4,5))
    paragraph(doc,'정보 분모는 말투별 16응답 × 3항목이다. 문장과 반복 출력을 독립 환자로 세지 않았다. 유사도는 무단위이며 임상 절단값은 없다. 문장은 각각 34·192·185개다. plain의 인접 유사도는 1문장 답변 하나를 제외한 15응답, 나머지 두 말투는 각각 16응답의 평균이다.',small=True)

    heading(doc,'같은 문장 집합의 무작위 순서 기준도 뺐다')
    paragraph(doc,'인접 유사도가 낮은 이유가 문장 내용 자체인지 배열인지 구분하기 위해, 답변 안의 모든 서로 다른 문장 위치 쌍의 평균 유사도를 계산했다. 이는 문장 순서를 균등 무작위로 섞었을 때 기대되는 인접 평균과 같다. 원래 인접 평균에서 이 값을 뺀 차이를 보조값으로 남겼다. 단어·문장 추가 없이 계산되지만, 논리적 타당성이나 대명사의 연결을 검증하는 지표는 아니다.')

    doc.add_page_break()
    heading(doc,'두 유사도의 차이를 실제로 점검했다')
    table(doc,['말투','모든 문장 쌍 평균','인접 평균에서 뺀 값'],[
        [s,f"{summaries[s]['all_pairs_cos']:.3f}",f"{summaries[s]['adjacency_excess']:+.3f}"]
        for s in ('plain','verbose','tangent')],[1.4,2.8,2.8],numeric=(1,2))
    paragraph(doc,f"tangent−verbose의 인접 유사도 차이는 {contrast['adjacent_cos']['mean']:+.3f}로 {contrast['adjacent_cos']['negative_blocks']}/16대응쌍에서 낮았다. 모든 문장 쌍 평균을 뺀 차이도 {contrast['adjacency_excess']['mean']:+.3f}, {contrast['adjacency_excess']['negative_blocks']}/16쌍에서 낮았다. 인물·질문 대상·표현·seed별 하위집단 평균에서도 같은 방향이었으나, 검증된 임상 효과 크기는 아니다.")
    prefix=result['prefix_summary']
    paragraph(doc,f"대응쌍의 앞부분을 같은 문장 수로 맞춰도 보조값 차이는 {prefix['mean_tangent_minus_verbose']['adjacency_excess']:+.3f}였다. 단어 수까지 10% 이내인 쌍은 {prefix['word_difference_at_most_10_percent']}/16개뿐이어서 길이와 독립적인 효과는 확정하지 않는다. plain의 12응답은 2문장이라 보조값이 구조적으로 0이고, 1응답은 1문장이라 계산 불가다. 이를 정상 연결성 기준으로 쓰지 않는다.")

    heading(doc,'질문 대상과 삽입 문장을 바꾼 대조')
    swaps=result['question_swaps']
    paragraph(doc,f"답변을 그대로 두고 질문 대상만 다른 제공 사건으로 바꾸면 정보 언급은 {swaps['requested_refs_original_total']}/144개에서 {swaps['requested_refs_swapped_total']}/144개로 바뀌었다. 요청 사건 관련도는 {swaps['positive_direction']}/48응답에서 낮아졌지만, 인접 유사도는 계산 가능한 47개 모두 불변이었다. 새 질문에 답변을 생성한 실험이 아니라 측정 대상의 차이를 확인한 대조다.")
    insertion=result['insertion_summary']
    paragraph(doc,'각 원문 중간에 요청 사건 설명을 넣은 버전과 다른 제공 사건 설명을 넣은 버전을 비교했다. 기존 작성 예문을 재사용했으며 48쌍 모두 삽입 뒤 문장 수와 정규식 단어 수가 같았다. 다른 사건도 프로필 안에 있으므로 사실 오류나 임상적 비일관성으로 판정하지 않았다.')
    table(doc,['다른 사건 문장 삽입 대 요청 사건 삽입','관측 결과'],[
        ['요청 사건 관련도가 낮아짐',f"{insertion['topic_association']['negative']}/48"],
        ['인접 문장 유사도가 낮아짐',f"{insertion['adjacent_cos']['negative']}/48"],
        ['인접 문장 유사도가 오히려 높아짐',f"{insertion['adjacent_cos']['positive']}/48"]
    ],[5.3,1.7],numeric=(1,))
    paragraph(doc,'보조값도 반대 방향 22개·차이 0이 1개여서 주제 판단의 대체물로 쓰지 않는다. 기존 작성 예문의 직설·바꿔 말하기 16조건은 모두 해당 사건의 관련도가 높았지만 독립 검증 자료는 아니다.',small=True)

    heading(doc,'사건 이름이 없어도 질문에 답할 수 있었다')
    example=next(r for r in details['responses'] if r['condition_id']=='P-N1-V1-QB-R5-plain')
    paragraph(doc,example['response_text'],small=True)
    paragraph(doc,f"도예 수업의 장소·금액·동행인을 모두 맞게 언급한 답변이다. 도예라는 말은 반복하지 않았고, 요청 사건 관련도에서 다른 사건 관련도를 뺀 값은 {example['topic_margin']:+.3f}였다. 이런 짧은 사실 응답이 4개 있어, 0 이하라는 이유로 주제 이탈로 분류하지 않았다.")

    doc.add_page_break()
    heading(doc,'원문으로 본 tangent의 실제 행동')
    paragraph(doc,'아래 두 답변은 이전부터 확인했던 설명용 사례다. 이번에 무작위 표집한 대표 사례나 전문가 증상 판정이 아니다. 문장 원문과 위치는 모두 기존 응답에 연결되어 있다.')
    a=next(r for r in details['responses'] if r['condition_id']=='P-N2-V2-QA-R4-tangent')
    b=next(r for r in details['responses'] if r['condition_id']=='P-N1-V2-QB-R5-tangent')
    heading(doc,'정원 수업의 정보와 고양이 이야기가 함께 있었다',2)
    quote_a="Oh, the workshop was so much fun, but I remember thinking about my cat, Miso, who hates anything to do with dirt."
    assert quote_a in a['response_text']
    paragraph(doc,quote_a,small=True)
    paragraph(doc,'이 답변은 Westmere·28달러·Leah를 모두 언급하면서 고양이 Miso와 화분 이야기를 덧붙였다. 다른 제공 사건인 자전거 수리의 정보는 나오지 않았다. 따라서 다른 사건 정보가 0개라는 결과가 새로운 이야기의 부재를 뜻하지는 않는다.')
    heading(doc,'다른 사건을 말한 뒤 도예로 돌아오기도 했다',2)
    quote_b="I mean, I missed a train in Dunhaven once, and that was pretty stressful."
    quote_return="Oh, but let's get back to the pottery class."
    assert quote_b in b['response_text'] and quote_return in b['response_text']
    paragraph(doc,quote_b+' '+quote_return,small=True)
    paragraph(doc,'두 인용은 원문 9번째와 11번째 문장으로, 연속 인용은 아니다. 도예 질문에 답한 뒤 기차 사건을 언급하고 도예로 돌아가자는 표현이 있었다. 원래 tangent의 턴 내 복귀 금지 요구와 대조할 수 있는 구간이다. 이 명시 사례 1개를 전체 탈선 빈도나 임상적 사고장애 등급으로 확대하지 않았다.')

    heading(doc,'이번 단계에서 확정한 연구상의 선택')
    paragraph(doc,'tangent는 이번 과제에서 필요한 정보를 모두 말하면서도 verbose와 다른 문장 유사도 프로파일을 만들었다. 그러나 유사도는 요청 사건의 관련성·논리적 연결·새 이야기 여부를 한꺼번에 측정하지 못했다. 앞으로는 정보 언급과 명시적 사건 전환을 직접 관찰값으로 두고, 주제 관련도와 인접 유사도는 별도의 연속형 기술값으로 유지한다. 임계값을 조정해 주제 이탈률이나 조현병 재현 점수를 만들지 않는다.')
    paragraph(doc,'이 판단은 최근 연구가 의미 유사도와 사람의 coherence 평가를 구분한 점과도 맞는다. He 등의 초록은 세 일반 인구 자료에서 의미 유사도가 사람 평가와 상관하지 않았고, 다른 지표의 관련성도 약했다고 보고한다.[1] 이는 이번 새 보조값의 타당도를 입증하지 않으며, 확률 기반 지표로 바꾸기만 하면 해결된다는 뜻도 아니다.')

    heading(doc,'다음에는 다른 특징의 공통 비교로 넘어간다',2)
    paragraph(doc,'발화량·정보 공개·질문과 주제 유지의 첫 분석 묶음을 여기서 닫는다. 다음 후보는 두 시스템의 pleasing 지시가 공유하는 우려 축소다. 주어진 사실을 그대로 말하면서 표현만 약해지는지, 강도·빈도 같은 사실값까지 바꾸는지를 분리하는 작은 공통 과제를 설계한다. 소스 확인과 작성 대조를 거친 뒤에만 로컬 생성을 실행하며, 이번 단계에서는 아직 생성하지 않았다. 교수님께는 이 관찰값들이 임상 개념의 어느 부분에 대응하는지 자문받는다.')
    paragraph(doc,'자료와 코드  analysis/topic-local-separation-v01  scripts/topic_local_separation.py\n재계산  python3 scripts/topic_local_separation.py\n검증  python3 scripts/verify_topic_local_separation.py --report\n새 발화·새 임베딩·LLM judge·유료 API·다운로드 0회',small=True)
    reference(doc,'[1] He 등  Scientific Reports 2026 16 7799  초록 확인','https://pubmed.ncbi.nlm.nih.gov/41656336/')
    reference(doc,'[2] Wang 등  PATIENT psi  EMNLP 2024  원형은 CBT 훈련 목적','https://aclanthology.org/2024.emnlp-main.711/')
    SHARE.mkdir(parents=True,exist_ok=True)
    doc.save(OUTPUT)
    inputs=[OUT/'results.json',OUT/'response-details.json',OUT/'measurement-plan.json',ROOT/'config/research-checkpoint-v04.json']
    write_json(SHARE/'report-inputs.json',{'inputs':{str(p.relative_to(ROOT)):digest(p.read_bytes()) for p in inputs},
                                         'output_sha256':digest(OUTPUT.read_bytes()),
                                         'illustration_quotes':[{'condition_id':a['condition_id'],'quote':quote_a},
                                                                {'condition_id':b['condition_id'],'quote':quote_b},
                                                                {'condition_id':b['condition_id'],'quote':quote_return}]})
    print(OUTPUT)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--replace',action='store_true')
    build(parser.parse_args().replace)
