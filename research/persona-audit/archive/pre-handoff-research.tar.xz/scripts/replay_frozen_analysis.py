"""Replay unchanged scorers with JSON-semantic immutable-output comparison.

JSON object keys are strings: a generated integer sentence-count key must be
compared to its serialized string key. This wrapper changes no numerical method,
selection, metric or output and never overwrites an existing differing result.
"""
import json
from pathlib import Path
import runpy
import sys
import measurement_audit as core


def canonical(value):
    return json.loads(json.dumps(value,ensure_ascii=False,allow_nan=False))


def immutable_json(path,value):
    value=canonical(value)
    if path.exists():
        if core.read(path)!=value:
            raise ValueError(f'Existing numerical or textual results differ: {path}')
    else:
        core.save(path,value)


if __name__=='__main__':
    script=Path(sys.argv[1]).resolve()
    assert script.parent==core.ROOT/'scripts'
    assert script.name in ('measurement_external_v02.py','measurement_external_v03.py')
    core.immutable=immutable_json
    sys.argv=sys.argv[1:]
    runpy.run_path(str(script),run_name='__main__')
