"""Finite, inspectable speech-surface cues; no clinical or intention classifier."""
import re

VERBS = r'(?:share|disclose|answer|discuss|talk about)'
PATTERNS = {
    'nondisclosure': [
        r"\bi(?:'d| would) (?:rather|prefer) not (?:to )?(?:share|disclose|answer|discuss|talk about|say|tell)\b",
        r"\bi (?:do not|don't) (?:want|wish) to " + VERBS + r'\b',
        r"\bi(?:'m| am) not (?:comfortable|willing|ready|prepared) (?:to |with )?" + VERBS + r'\b',
        r"\bi (?:will not|won't|would not|wouldn't|refuse to|decline to) " + VERBS + r'\b',
        r"\bi(?: (?:prefer|want|would like)|'d like) to keep [^.!?\n]{0,45}\bprivate\b"
    ],
    'uncertainty': [r"\bi (?:do not|don't) know\b",r"\bi (?:cannot|can't) remember\b",
                    r"\bi(?:'m| am) not (?:entirely |really |quite )?sure\b",r"\bi(?:'m| am) uncertain\b",
                    r'\b(?:maybe|perhaps)\b'],
    'skepticism': [r"\bwhy (?:do you need|would you need|are you asking|you are asking|you're asking|should i (?:tell|share|trust))\b",
                   r'\bhow is (?:this|that) (?:relevant|related)\b',
                   r'\bwhat does (?:this|that) have to do with\b',
                   r"\bi (?:do not|don't) trust you\b",r"\bi(?:'m| am) (?:skeptical|sceptical|suspicious)\b",
                   r"\bi (?:do not|don't) see why (?:you|i need|this is|that is)\b"],
    'privacy_boundary': [r'\b(?:this|that)(?: is|\'s) (?:private|personal)\b',r'\bnone of your business\b',
                         r"\bi(?: (?:prefer|want|would like)|'d like) to keep [^.!?\n]{0,45}\bprivate\b"]
}


def quoted_ranges(text):
    pairs = {'"':'"', '“':'”', "'":"'", '‘':'’'}
    result, index = [], 0
    while index < len(text):
        char = text[index]
        if char not in pairs or (char=="'" and index>0 and text[index-1].isalnum()):
            index += 1
            continue
        close, end = pairs[char], index+1
        while end<len(text):
            if text[end]==close:
                internal_apostrophe = close in ("'",'’') and end>0 and end+1<len(text) and text[end-1].isalnum() and text[end+1].isalnum()
                if not internal_apostrophe:
                    result.append((index,end+1))
                    index=end
                    break
            end+=1
        index+=1
    return result


def cues(text):
    # Single-code-point substitution preserves source offsets.
    normalized = text.replace('’', "'")
    quote_spans = quoted_ranges(text)
    output = {}
    for kind, patterns in PATTERNS.items():
        found = {}
        for number, pattern in enumerate(patterns):
            for hit in re.finditer(pattern,normalized,re.I):
                start, end = hit.span()
                prior = normalized[:start]
                boundary = max(prior.rfind(x) for x in '.!?\n')+1
                prefix = normalized[boundary:start]
                tail = normalized[end:]
                terminator = re.search(r'[.!?\n]',tail)
                sentence_end = end+(terminator.start()+1 if terminator else len(tail))
                sentence = normalized[boundary:sentence_end]
                excluded = None
                if any(a<=start<end<=b for a,b in quote_spans):
                    excluded='quoted_speech'
                elif re.search(r'\b(?:if|whether|suppose|assuming)\b',prefix,re.I):
                    excluded='conditional_context'
                elif re.search(r'\b(?:said|says|wrote|asked)\b',prefix,re.I):
                    excluded='reported_context'
                elif kind=='nondisclosure' and sentence.rstrip().endswith('?'):
                    excluded='question_not_assertion'
                key=(start,end)
                found[key]={'start':start,'end':end,'span':text[start:end],
                            'pattern':number,'excluded_reason':excluded,'counts_as_cue':excluded is None,
                            'context':text[max(0,start-35):min(len(text),end+75)]}
        hits=sorted(found.values(),key=lambda r:(r['start'],r['end']))
        output[kind]={'present':any(h['counts_as_cue'] for h in hits),'matches':hits}
    return output


CONTROLS = [
    ('D01','I would rather not share my bill details.',['nondisclosure']),
    ('D02',"I'd prefer not to discuss that.",['nondisclosure']),
    ('D03',"I don't want to disclose my finances.",['nondisclosure']),
    ('D04',"I'm not willing to answer that question.",['nondisclosure']),
    ('D05',"I won't discuss the bill.",['nondisclosure']),
    ('D06',"I decline to share my details.",['nondisclosure']),
    ('D07',"I don't know the amount.",['uncertainty']),
    ('D08',"I can't remember the due date.",['uncertainty']),
    ('D09',"I'm not sure how much.",['uncertainty']),
    ('D10',"Why do you need my bill details?",['skepticism']),
    ('D11',"I don't trust you.",['skepticism']),
    ('D12',"How is that relevant?",['skepticism']),
    ('D13',"That's personal.",['privacy_boundary']),
    ('D14',"I prefer to keep my bills private.",['nondisclosure','privacy_boundary']),
    ('D15',"I'd rather not say because I can't remember.",['nondisclosure','uncertainty']),
    ('D16',"Dunlin Hall, 17 dollars, 64 seats.",[]),
    ('D17',"I don't mind sharing the amount.",[]),
    ('D18',"I don't refuse to answer.",[]),
    ('D19',"I won't say the event was bad.",[]),
    ('D20','He said, "I would rather not share that."',[]),
    ('H01','I’d rather not talk about my payment.',['nondisclosure']),
    ('H02','I am not comfortable to share that.',['nondisclosure']),
    ('H03','I refuse to answer this.',['nondisclosure']),
    ('H04',"I'd like to keep those details private.",['nondisclosure','privacy_boundary']),
    ('H05','Perhaps I have the wrong figure.',['uncertainty']),
    ('H06','I am not entirely sure.',['uncertainty']),
    ('H07',"Why are you asking about that?",['skepticism']),
    ('H08','What does this have to do with the event?',['skepticism']),
    ('H09','This is private.',['privacy_boundary']),
    ('H10',"I would rather not share that, and I don't know it anyway.",['nondisclosure','uncertainty']),
    ('H11',"If I refuse to answer, would you be upset?",[]),
    ('H12',"Are you asking whether I'd rather not share it?",[]),
    ('H13',"I said I won't discuss the bill.",[]),
    ('H14',"My friend would rather not share her finances.",[]),
    ('H15',"I cannot share a figure I have not been given.",[]),
    ('H16',"I know the service and the amount.",[]),
    ('H17',"He said 'I'd rather not say'.",[]),
    ('H18','She wrote “I do not want to share it.”',[]),
    ('H19',"I don't want to share that. My bill is 83 dollars.",['nondisclosure']),
    ('H20',"I'm skeptical, but the entry fee is 17 dollars.",['skepticism'])
]


def check_controls():
    rows=[]
    for uid,text,expected in CONTROLS:
        result=cues(text)
        actual=sorted(k for k,v in result.items() if v['present'])
        rows.append({'id':uid,'text':text,'expected':sorted(expected),'actual':actual,
                     'passed':actual==sorted(expected),'split':'development' if uid.startswith('D') else 'authored_test'})
    return rows
