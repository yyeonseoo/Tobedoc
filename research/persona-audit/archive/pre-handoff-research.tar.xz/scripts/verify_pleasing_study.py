"""Offline verification of both frozen stages and the outcome-dependent branch."""
import argparse
import subprocess
import sys
from common import ROOT,digest,write_json
from run_local_pilot import fingerprint
from first_reply_probe_runner import verify_response
from pleasing_measures import measure,controls
from pleasing_study import read,SPEC,prepare,contrast,METRICS
from pleasing_reported_values_audit import score as audit_score,controls as audit_controls


def verify_stage(stage):
    plan,cases,folder=prepare(stage)
    result=read(ROOT/'analysis'/plan['run_id']/'results.json')
    rows=read(ROOT/'analysis'/plan['run_id']/'response-metrics.json')
    prepared=read(folder/'prepared-at.json')
    assert prepared['plan_sha256']==fingerprint(plan)
    assert len(rows)==len(cases)==result['completed_replies']
    for p,sha in plan['code_at_preparation'].items():
        assert digest((ROOT/p).read_bytes())==sha,p
    for p,sha in result['provenance'].items():
        assert digest((ROOT/p).read_bytes())==sha,p
    for case,row in zip(cases,rows):
        raw=read(folder/'responses'/(case['condition_id']+'.json'))
        request=read(folder/'requests'/(case['condition_id']+'.json'))
        verify_response(raw,request,case,plan['model_digest'])
        assert prepared['prepared_at_utc']<raw['started_at_utc']
        assert raw['raw_response']['done_reason']=='stop'
        assert not raw['raw_response'].get('message',{}).get('thinking')
        measured=measure(raw['response_text'],case['expected'])
        assert all(measured[k]==row[k] for k in measured)
        assert row['response_text']==raw['response_text']
        for c in row['claims']:
            assert row['response_text'][c['raw_start']:c['raw_end']]==c['raw_clause']
        for c in row['cue_spans']:
            assert row['response_text'][c['start']:c['end']]==c['span']
    for name,saved in result['contrasts'].items():
        arm,base=name.split('_minus_')
        assert contrast(rows,arm,base)==saved
    for summary in result['summaries']:
        group=[r for r in rows if r['style_id']==summary['arm']]
        assert len(group)==summary['replies']==8
        for metric in METRICS:
            actual=sum(r[metric] for r in group)/(8 if metric=='word_count' else 1)
            assert actual==summary['mean_words' if metric=='word_count' else metric]
    out=ROOT/'analysis'/plan['run_id']
    audit=read(out/'numeric-expression-audit.json')
    details=read(out/'numeric-expression-details.json')
    review=read(out/'assistant-source-review.json')
    assert audit['audit_code_sha256']==digest((ROOT/'scripts/pleasing_reported_values_audit.py').read_bytes())
    assert audit['input_sha256']==digest((out/'response-metrics.json').read_bytes())
    assert audit['implementation_controls']==audit_controls()
    assert all(c['passed'] for c in audit_controls())
    assert review['primary_metrics_sha256']==digest((out/'response-metrics.json').read_bytes())
    assert review['supplemental_details_sha256']==digest((out/'numeric-expression-details.json').read_bytes())
    assert review['supplemental_results_sha256']==digest((out/'numeric-expression-audit.json').read_bytes())
    assert review['responses_read']==len(rows)
    assert set(review['source_response_hashes'])=={r['condition_id'] for r in rows}
    for row,enriched in zip(rows,details):
        scores=audit_score(row['response_text'],row['expected'])
        assert all(row[k]==enriched[k] for k in row)
        assert all(scores[k]==enriched[k] for k in scores)
        for c in scores['audited_claims']:
            assert row['response_text'][c['raw_start']:c['raw_end']]==c['raw_clause']
        assert review['source_response_hashes'][row['condition_id']]==digest((folder/'responses'/(row['condition_id']+'.json')).read_bytes())
    for summary in audit['summaries']:
        group=[r for r in details if r['style_id']==summary['arm']]
        for metric in ('audited_single_slots','audited_compatible_slots','audited_different_replies','audited_lower_replies','audited_missing_slots'):
            assert sum(r[metric] for r in group)==summary[metric]
    by_id={r['condition_id']:r for r in rows}
    for e in review['examples']:
        assert e['quote'] in by_id[e['condition_id']]['response_text']
    return {'replies':len(rows),'source_hashes':len(result['provenance']),
            'plan_and_code_unchanged':True,'all_metrics_and_spans_reproduced':True,
            'posthoc_audit_reproduced_separately':True,'assistant_review_not_independent_clinical_validation':True}


def main(report=False):
    spec=read(SPEC)
    checks={'discovery':verify_stage('discovery')}
    activation=read(ROOT/'pilot/runs'/spec['followup']['run_id']/'activation.json')
    discovery=read(ROOT/'analysis'/spec['discovery']['run_id']/'results.json')
    indexed={r['arm']:r for r in discovery['summaries']}
    expected={}
    for arm in ('psi_pleasing','sim_pleasing'):
        cases=indexed[arm]['by_case']
        a=all(c['any_nonmatching']>0 for c in cases.values())
        b=all(cases[c]['correct_slots']<indexed['neutral']['by_case'][c]['correct_slots'] for c in cases)
        expected[arm]={'nonmatching_in_both_cases':a,'fewer_correct_slots_than_neutral_in_both_cases':b,'eligible':a or b}
    assert activation['reasons']==expected
    assert activation['execute']==any(r['eligible'] for r in expected.values())
    assert activation['discovery_results_sha256']==digest((ROOT/'analysis'/spec['discovery']['run_id']/'results.json').read_bytes())
    discovery_prepared=read(ROOT/'pilot/runs'/spec['discovery']['run_id']/'prepared-at.json')
    followup_folder=ROOT/'pilot/runs'/spec['followup']['run_id']
    followup_prepared=read(followup_folder/'prepared-at.json')
    first=min(read(p)['started_at_utc'] for p in (ROOT/'pilot/runs'/spec['discovery']['run_id']/'responses').glob('*.json'))
    assert followup_prepared['prepared_at_utc']<first
    if activation['execute']:
        checks['followup']=verify_stage('followup')
        assert all(activation['decision_at_utc']<read(p)['started_at_utc'] for p in (followup_folder/'responses').glob('*.json'))
    else:
        assert not list((followup_folder/'responses').glob('*.json'))
    checks.update({'total_new_replies':sum(r['replies'] for r in checks.values()),
                   'both_stage_designs_precede_first_generation':True,'conditional_branch_verified':True,
                   'authored_controls':len(controls()),'paid_api_calls':0,'llm_judge_calls':0,'downloads':0})
    tests=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-q'],cwd=ROOT,capture_output=True,text=True)
    if tests.returncode:
        raise ValueError(tests.stdout+tests.stderr)
    checks['unit_test_output']=tests.stderr.strip()
    integrated=read(ROOT/'analysis/integrated-checkpoint-v05/results.json')
    for p,sha in integrated['source_files'].items():
        assert digest((ROOT/p).read_bytes())==sha
    assert integrated['new_replies_this_batch']==72
    assert integrated['distinct_replies_across_four_main_tasks']==240
    assert all(not d['adopt_as_reliable_default'] for d in integrated['followup_adoption'].values())
    checks['four_axis_record_count_not_independent_patients']=240
    if report:
        from docx import Document
        share=ROOT/'share/overnight-completion-v01'
        manifest=read(share/'report-inputs.json')
        for p,sha in manifest['inputs'].items():
            assert digest((ROOT/p).read_bytes())==sha
        output=ROOT/manifest['output']
        assert digest(output.read_bytes())==manifest['output_sha256']
        doc=Document(output)
        assert len(doc.tables)>=2
        pages=list((share/'render-qa').glob('page-*.png'))
        assert len(pages) in (2,3) and all(p.stat().st_size>10000 for p in pages)
        checks.update({'report_sha256':manifest['output_sha256'],'rendered_pages':len(pages)})
    write_json(ROOT/'share/overnight-completion-v01/verification.json',checks)
    print(checks)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report',action='store_true')
    main(parser.parse_args().report)
