"""Shared bounded local runner. Saves every request before calling pinned Ollama."""
import json
import time
import uuid

from common import ROOT, write_json
from local_preflight import MODEL, local_metadata
from run_feature_batch import payload
from run_local_pilot import chat, classify, fingerprint, now
from summarize_local_pilot import verify_turn


def verify_response(row, request, case, model_digest):
    verify_turn(row, request, {**case, "_model_digest": model_digest}, [])
    if request["payload"] != payload(case, [], 1) or row["status"] != "completed":
        raise ValueError("Changed request or failed response; no silent retry")


def run(plan, cases, folder, resume=False):
    if len(cases) != plan["max_requests"] or any(len(c["interview"]) != 1 for c in cases):
        raise ValueError("Frozen first-reply request limit changed")
    policy = json.loads((ROOT / "config/compute-policy.json").read_text())
    if policy["paid_model_api_allowed"] or policy["automatic_model_download_allowed"]:
        raise ValueError("Compute policy changed")
    model = next((m for m in local_metadata("/api/tags")["models"] if m["name"] == MODEL), None)
    if not model or model["digest"] != plan["model_digest"]:
        raise ValueError("Pinned local model missing/changed; no download/substitution")
    if (folder / "responses").exists() and not resume:
        raise ValueError("Existing responses require explicit --resume")
    if not (folder / "runtime.json").exists():
        write_json(folder / "runtime.json", {"checked_at_utc": now(), "model": model,
            "version": local_metadata("/api/version"), "show": local_metadata("/api/show", {"model": MODEL})})
    for name in ("requests", "responses"):
        (folder / name).mkdir(exist_ok=True)
    lock = folder / ".running"
    with lock.open("x") as handle:
        handle.write(now())
    try:
        for index, case in enumerate(cases, 1):
            request = payload(case, [], 1)
            request_hash = fingerprint(request)
            rp = folder / "requests" / (case["condition_id"] + ".json")
            sp = folder / "responses" / (case["condition_id"] + ".json")
            if sp.exists():
                row = json.loads(sp.read_text())
                verify_response(row, json.loads(rp.read_text()), case, model["digest"])
            else:
                if rp.exists():
                    raise ValueError("Unfinished saved request requires inspection")
                started = now()
                write_json(rp, {"started_at_utc": started, "request_sha256": request_hash, "payload": request})
                begin = time.monotonic()
                raw, error = {}, None
                try:
                    raw = chat(request)
                    status = classify(raw)
                except Exception as exc:
                    status, error = "transport_error", {"type": type(exc).__name__, "message": str(exc)}
                row = {"run_id": plan["run_id"], **{k: case[k] for k in ("condition_id", "profile_id", "style_id", "arm", "repeat_index")},
                    "turn": 1, "probe": case["interview"][0]["probe"], "interviewer_text": case["interview"][0]["text"],
                    "prompt_sha256": case["prompt_sha256"], "request_sha256": request_hash, "request_id": str(uuid.uuid4()),
                    "started_at_utc": started, "ended_at_utc": now(), "wall_seconds": time.monotonic()-begin,
                    "model_digest": model["digest"], "status": status, "response_text": raw.get("message", {}).get("content", ""),
                    "raw_response": raw, "error": error, "is_fixture": False, "clinical_rating": None,
                    "is_schizophrenia_case": False}
                write_json(sp, row)
            write_json(folder / "progress.json", {"planned_requests": len(cases), "processed_cells": index,
                "complete": index == len(cases) and row["status"] == "completed", "updated_at_utc": now()})
            print(f"{index}/{len(cases)} {case['condition_id']}: {row['status']}", flush=True)
            if row["status"] != "completed":
                raise ValueError("Failed/truncated response preserved; stop without regeneration")
    finally:
        lock.unlink(missing_ok=True)
