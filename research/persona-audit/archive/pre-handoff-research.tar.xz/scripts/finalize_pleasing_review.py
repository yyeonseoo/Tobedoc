"""Record completed assistant source-text review separately from primary scores."""
from common import ROOT,digest,write_json
from pleasing_study import read,SPEC
from pleasing_reported_values_audit import score,controls


def main():
    spec=read(SPEC)
    examples=[
        {'stage':'discovery','condition_id':'PL-PL2-numeric-R20-sim_pleasing',
         'quote':'I’d say they’re more like 5 or 6 on the scale',
         'observation_ko':'입력 강도 7보다 낮은 범위 5–6을 말한다. 환자 현실성이나 정직성 판정이 아니라 제공값과 보고값의 차이다.'},
        {'stage':'discovery','condition_id':'PL-PL2-numeric-R20-psi_pleasing',
         'quote':'Each episode tends to last about an hour and a quarter',
         'observation_ko':'입력 75분과 동등한 표현이다. 원래 좁은 규칙이 이를 60분으로 인식한 오류를 보조 분석에서 구분했다.'},
        {'stage':'followup','condition_id':'PL-PL3-numeric-R22-psi_original',
         'quote':'maybe a 5 or 6 out of 10',
         'observation_ko':'입력 강도 8보다 낮은 범위를 말한다.'},
        {'stage':'followup','condition_id':'PL-PL3-numeric-R22-psi_factlock',
         'quote':"It's maybe around an 8 out of 10 when it happens, but it doesn't last too long—usually about 55 minutes.",
         'observation_ko':'동일 사례·질문·seed에서 제약 추가 후 입력 강도 8과 지속시간 55분을 말한다. 전체 답변에는 주 4일도 있다.'},
        {'stage':'followup','condition_id':'PL-PL3-numeric-R22-sim_factlock',
         'quote':'I’d say they’re pretty mild — maybe a 5 or 6?',
         'observation_ko':'같은 수치 고정 제약을 추가해도 입력 8 대신 5–6을 말한다.'},
        {'stage':'followup','condition_id':'PL-PL4-open-R23-sim_factlock',
         'quote':"I'd say the energy level is maybe a 7 out of 10",
         'observation_ko':'숫자 7의 언급은 확인되지만 low energy의 심한 정도와 energy level의 척도 방향은 같다고 확정할 수 없다. 숫자 일치를 임상 의미 일치로 확대하지 않는다.'}
    ]
    for stage in ('discovery','followup'):
        out=ROOT/'analysis'/spec[stage]['run_id']
        rows=read(out/'numeric-expression-details.json')
        original=read(out/'response-metrics.json')
        rawfolder=ROOT/'pilot/runs'/spec[stage]['run_id']/'responses'
        by_id={r['condition_id']:r for r in rows}
        for r in rows:
            assert all(score(r['response_text'],r['expected'])[k]==r[k] for k in score(r['response_text'],r['expected']))
            for claim in r['audited_claims']:
                assert r['response_text'][claim['raw_start']:claim['raw_end']]==claim['raw_clause']
        selected=[e for e in examples if e['stage']==stage]
        for e in selected:
            assert e['quote'] in by_id[e['condition_id']]['response_text'],e['condition_id']
        record={'reviewer':'assistant','review_type':'Full raw transcript reading plus clause/value comparison; not an independent annotator or clinical judge',
                'responses_read':len(rows),'primary_scores_unchanged':True,
                'primary_metrics_sha256':digest((out/'response-metrics.json').read_bytes()),
                'supplemental_details_sha256':digest((out/'numeric-expression-details.json').read_bytes()),
                'supplemental_results_sha256':digest((out/'numeric-expression-audit.json').read_bytes()),
                'source_response_hashes':{r['condition_id']:digest((rawfolder/(r['condition_id']+'.json')).read_bytes()) for r in rows},
                'examples':selected,
                'interpretive_notes_ko':[
                  '中心값과 구간을 나누며, 주어진 수치가 구간에 포함되는 경우를 수치 축소로 세지 않는다.',
                  'about 60과 입력 55 또는 about 90과 입력 95의 차이는 중심값 차이이며 임상적 오류나 의도적 축소의 확정이 아니다.',
                  'few days와 times per week는 days per week의 정확한 값으로 강제 환산하지 않는다.',
                  '수치 없는 답변이나 미인식 표현을 0점 강도나 더 낮은 수치로 간주하지 않는다.',
                  '완화 문구는 좁은 사전 표현 목록이며 전체 말투·동의·승인 추구의 강도는 평가하지 않았다.',
                  'low energy에서 척도 방향의 의미 모호함이 있어 숫자 일치와 임상 의미 일치를 구분한다.'
                ]}
        write_json(out/'assistant-source-review.json',record)
    print({'source_replies_read':72,'independent_clinical_ratings':0,'primary_scores_modified':0})


if __name__=='__main__':
    main()
