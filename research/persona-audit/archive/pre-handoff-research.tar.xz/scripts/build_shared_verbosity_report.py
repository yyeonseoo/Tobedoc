"""Three-page Korean report from the frozen common-baseline local comparison."""
import argparse
import json
from statistics import mean

from docx import Document
from docx.shared import Inches, Pt
from PIL import Image, ImageDraw, ImageFont

from build_integrated_report import font, paragraph, heading, table
from build_two_feature_report import configure
from common import ROOT, digest, write_json
from shared_verbosity import OUT, FOLDER, SPEC, read

SHARE = ROOT / 'share/shared-verbosity-v02'
OUTPUT = SHARE / '환자 페르소나 공통 대조군 비교 보고서.docx'
LABELS = {'neutral': '공통 무지시 대조군', 'simple_verbose': '단순 verbose', 'psi_verbose': 'PATIENT-Ψ verbose',
          'sim_verbose': 'PatientSim verbose', 'sim_concise': 'PatientSim concise'}


def figure(result):
    canvas = Image.new('RGB', (1700, 720), 'white')
    draw = ImageDraw.Draw(canvas)
    path = '/System/Library/Fonts/Supplemental/Arial Unicode.ttf'
    title, body, small = [ImageFont.truetype(path, n) for n in (34, 27, 23)]
    draw.text((35, 18), '같은 제공 정보를 두고 달라지는 발화량', font=title, fill='black')
    draw.text((35, 68), '평균과 허구 사례별 평균 4개  각 조건 16응답', font=body, fill='#444444')
    left, right, top, row_h = 375, 1475, 174, 91
    draw.text((1520, 120), '평균', font=small, fill='black')
    ceiling = max(s['word_count'] for s in result['summaries']) * 1.25
    records = read(OUT / 'response-metrics.json')
    case_means = {arm: [mean(r['word_count'] for r in records if r['style_id'] == arm and r['profile_id'] == case)
                        for case in ('V1', 'V2', 'V3', 'V4')] for arm in LABELS}
    ceiling = max(ceiling, max(v for values in case_means.values() for v in values) * 1.10)
    step = 25 if ceiling < 230 else 50
    axis_top, axis_bottom = top - 25, top + row_h * 4 + 35
    for value in range(0, int(ceiling) + 1, step):
        x = left + value / ceiling * (right-left)
        draw.line((x, axis_top, x, axis_bottom), fill='#DFE4EA', width=2)
        draw.text((x-10, axis_bottom+14), str(value), font=small, fill='#444444')
    colors = ['#ACB7C3', '#538BB5', '#327B71', '#665799', '#AE7962']
    for i, s in enumerate(result['summaries']):
        y = top + i * row_h
        draw.text((35, y-17), LABELS[s['arm']], font=body, fill='black')
        x = left + s['word_count']/ceiling*(right-left)
        draw.rectangle((left, y-19, x, y+20), fill=colors[i])
        for j, val in enumerate(case_means[s['arm']]):
            dot = left + val/ceiling*(right-left)
            yy = y - 10 + 7*j
            draw.ellipse((dot-5, yy-5, dot+5, yy+5), fill='black')
        draw.text((1520, y-20), f"{s['word_count']:.1f}", font=body, fill='black')
    draw.text((1280, 654), '단위 단어 수', font=small, fill='black')
    draw.text((35, 654), '막대 전체 평균   검은 점 각 사례 평균   임상 등급이나 품질 순위가 아님', font=small, fill='#444444')
    path = SHARE / 'verbosity-results.png'
    canvas.save(path)
    return path


def title(doc, text):
    p = doc.add_paragraph(text, style='Title')
    p.paragraph_format.line_spacing = Pt(26)
    p.paragraph_format.space_after = Pt(7)
    for r in p.runs:
        font(r, 18, True)


def build(replace=False):
    if OUTPUT.exists() and not replace:
        raise ValueError('Use --replace only for this generated report')
    result, rows = read(OUT / 'results.json'), read(OUT / 'response-metrics.json')
    audit = read(OUT / 'reference-audit.json')
    assert result['actual_responses'] == 80
    SHARE.mkdir(parents=True, exist_ok=True)
    s = {r['arm']: r for r in result['summaries']}
    c = result['contrasts']
    wc = lambda arm, base='neutral': c[arm+'_minus_'+base]['word_count']['mean_difference']
    refs = lambda arm, base='neutral': c[arm+'_minus_'+base]['requested_refs']['mean_difference']
    directions = {arm: sum(v > 0 for v in c[arm+'_minus_neutral']['word_count']['case_means'].values())
                  for arm in ('simple_verbose', 'psi_verbose', 'sim_verbose')}
    fig = figure(result)
    doc = Document()
    configure(doc)
    doc.core_properties.title = '환자 페르소나의 공통 대조군 비교'
    doc.core_properties.subject = '기존 지시 모듈의 발화량과 제공 정보 언급 비교'
    doc.core_properties.author = '연구팀'
    doc.core_properties.comments = ''
    title(doc, '환자 페르소나의 공통 대조군 비교')
    paragraph(doc, '영어 첫 응답 80개의 로컬 통제 실험', bold=True)
    paragraph(doc, '연구팀 공유 보고  |  shared verbosity v02', small=True)

    heading(doc, '어떤 의구심에서 출발했나')
    paragraph(doc, '기존 환자 페르소나에 붙은 장황함이나 주제 이탈이라는 이름이 실제 발화에서 무엇을 바꾸는지 먼저 확인하고자 했다. 이번에는 두 소스가 공통으로 명시한 verbose 지시를 비교했다. 핵심 질문은 정교한 페르소나 지시가 단순히 길게 답하라는 지시보다 더 많은 제공 정보를 반영하는가이다.')
    paragraph(doc, f"공통 무지시 대조군의 평균은 {s['neutral']['word_count']:.1f}단어였다. 단순 verbose는 {s['simple_verbose']['word_count']:.1f}, PATIENT-Ψ는 {s['psi_verbose']['word_count']:.1f}, PatientSim은 {s['sim_verbose']['word_count']:.1f}단어였다. 요청한 사건의 정보 언급량은 아래 표와 같이 별도로 계산했다. 길이를 더 충실한 정보 전달이나 조현병 재현으로 곧바로 해석하지 않았다.")

    heading(doc, '무엇을 어떻게 했나')
    paragraph(doc, '새 허구 인물 4명에게 서로 다른 날의 사건 2개와 사건당 고유 정보 4개를 부여했다. 한 번에 한 사건만 질문하고 2개 seed로 반복했다. 같은 인물·질문·seed에서 무지시, 단순 verbose, PATIENT-Ψ verbose, PatientSim verbose, PatientSim concise의 5조건을 비교했다. 총 16개 대응 묶음과 80개 첫 응답이며, 실제 환자 80명의 자료가 아니다.')
    paragraph(doc, '이전 파일럿의 5문장 제한을 없애고 PATIENT-Ψ의 8문장 상한만 제거했다. 나머지 해당 스타일 문구와 PatientSim personality 원문은 유지했다. PatientSim plain은 간결함을 명시하므로 concise라는 별도 조건으로 명명했다. 모든 조건은 같은 Qwen3-14B Q4_K_M, 온도 0.6, 최대 512 생성 토큰을 사용했다. 원형 앱 전체나 원래 GPT 모델의 재현은 아니다.[1,2]')

    heading(doc, '새 응답에서 얻은 수치')
    table(doc, ['지시 조건', '평균 단어', '질문한 정보', '다른 사건 포함'], [
        [LABELS[a], f"{s[a]['word_count']:.1f}", f"{s[a]['requested_refs_total']}/64", f"{s[a]['other_positive_replies']}/16응답"]
        for a in LABELS], [2.55, 1.05, 1.10, 1.8], numeric=(1,2,3))
    paragraph(doc, '질문한 정보는 조건마다 16응답 × 4개 표식이다. 고정 표현 목록이 답변에 나타났는지 Python으로 세었다. 부정문·잘못 연결한 언급도 인식될 수 있어 정확성 점수는 아니다. 다른 사건 포함도 알려진 표식만 포착하며 모든 의미적 주제 이탈을 뜻하지 않는다.', small=True)

    doc.add_page_break()
    heading(doc, '같은 대조군에서 비교한 효과')
    p = doc.add_paragraph()
    run = p.add_run()
    run.add_picture(str(fig), width=Inches(7))
    inline = run._r.xpath('.//wp:docPr')[0]
    inline.set('descr', '다섯 지시 조건의 평균 단어 수와 네 허구 사례별 평균을 표시한 막대그래프')
    paragraph(doc, '그림 1  같은 사실·질문·seed에서 지시만 바꾼 결과. 점은 사례별 평균이며 오차막대나 독립 환자 분포가 아니다.', small=True)
    table(doc, ['대응 비교', '단어 수 차이', '정보 개수 차이'], [
        [LABELS[a]+' − 무지시', f'{wc(a):+.1f}', f'{refs(a):+.2f}'] for a in ('simple_verbose','psi_verbose','sim_verbose','sim_concise')
    ] + [['PatientSim − 단순 verbose', f"{wc('sim_verbose','simple_verbose'):+.1f}", f"{refs('sim_verbose','simple_verbose'):+.2f}"],
         ['PATIENT-Ψ − 단순 verbose', f"{wc('psi_verbose','simple_verbose'):+.1f}", f"{refs('psi_verbose','simple_verbose'):+.2f}"]],
          [3.65, 1.35, 1.50], numeric=(1,2))
    paragraph(doc, '각 차이는 같은 인물·질문 대상·seed끼리 뺀 뒤 16묶음에 동일 가중치를 준 값이다. 정보 개수는 응답당 요청한 정보 표식 0–4개 중 차이다. 네 사례의 평균과 모든 대응 차이는 원자료에 함께 보존했다.', small=True)
    heading(doc, 'plain을 공통 기준으로 쓰면 달라지는 해석', 2)
    total, up, down = wc('sim_verbose','sim_concise'), wc('sim_verbose'), -wc('sim_concise')
    paragraph(doc, f"PatientSim 내부의 verbose−concise 차이는 {total:+.1f}단어였다. 이는 공통 무지시보다 verbose가 {up:+.1f}단어 달라진 부분과, concise가 무지시보다 {down:+.1f}단어 짧아진 부분의 합이다. 이 두 부분을 구분하지 않으면 plain이라는 이름이 같은 대조군이라고 오해할 수 있다. 단순 verbose·PATIENT-Ψ·PatientSim의 길이 증가 방향은 각각 {directions['simple_verbose']}/4, {directions['psi_verbose']}/4, {directions['sim_verbose']}/4 사례에서 일치했다.")
    paragraph(doc, 'PATIENT-Ψ는 어떤 턴에는 장황하고 다른 턴에는 간결하며 신뢰가 생기면 듣도록 명시한다. PatientSim은 과도한 정보와 의사의 대화 진행을 어렵게 하는 성격을 함께 지시한다. 따라서 관찰한 차이는 이 지시 묶음의 효과이며, 장황함이라는 단일 문장의 순수 효과로 분해하지 않았다.')

    doc.add_page_break()
    heading(doc, '결과가 연구 방향에 주는 의미')
    interpretation = (OUT / 'interpretation.ko.md').read_text().strip()
    # The reviewed interpretation is plain paragraphs; keep it out of code so all
    # empirical claims can be checked against the completed data before rendering.
    for part in interpretation.split('\n\n'):
        paragraph(doc, part)

    heading(doc, '원문 점검과 측정의 범위')
    paragraph(doc, audit['report_paragraph'])
    max_tokens = max(r['output_tokens'] for r in rows)
    coverage = sum(r['requested_full'] for r in rows)
    paragraph(doc, f"80응답 모두 정상 종료했고 가장 긴 출력은 {max_tokens}/512토큰이었다. 숫자 문장 상한은 없었다. 요청 정보 4개가 모두 인식된 답변은 {coverage}/80개로 정보 상한에 가까웠다. 이 과제는 작은 정보 차이나 추가 설명의 가치를 충분히 판별하지 못하므로, 제공 정보와 발화량을 분리해 기술하는 데 사용한다.")

    heading(doc, '다음에 검증할 것')
    paragraph(doc, '다음에는 새 생성 없이 이번 원문을 재사용해 추가 서술을 제공 사실의 재표현·주관적 평가·주어지지 않은 구체적 사실로 나누는 기준부터 만든다. 입력에 인물 역할이 없는 경우처럼 명확한 항목부터 팀이 교차 점검할 수 있으며, 임상 중증도 채점은 필요하지 않다. 기준을 고정한 뒤 추가 사실을 억제하는 수정안을 새 사례에서 검증한다.')
    paragraph(doc, '그다음 공통 특징 비교를 정보 공개·거절 반응으로 넓힌다. reserved와 distrust의 겹치는 지시를 확인하고 간결함·단순 거절 대조군과 분리한다. 교수님께는 관찰 항목과 조현병 관련 구성개념의 연결을 자문한다. 최종 산출물은 지시된 특징과 관찰된 행동의 대응표, 재현 가능한 비교 수치, 구체적인 개선 검증이다.')

    heading(doc, '출처와 재현 자료', 2)
    for i, source in enumerate(result['plan']['source_provenance'], 1):
        paragraph(doc, f"[{i}] {source['id']}  고정 commit {source['commit'][:12]}\n{source['citation_url']}", small=True)
    paragraph(doc, '계획과 요청·원문  pilot/runs/shared-verbosity-v02\n측정값과 전체 대화  analysis/shared-verbosity-v02\n재분석  python3 scripts/shared_verbosity.py analyze\n무결성 검증  python3 scripts/verify_shared_verbosity.py --report', small=True)
    cost = result['cost']
    paragraph(doc, f"로컬 생성 {cost['wall_seconds']/60:.1f}분  입력 {cost['input_tokens']:,}토큰  출력 {cost['output_tokens']:,}토큰. 유료 API·LLM judge·새 모델 다운로드 0회. 이는 로컬 생성량이며 이 대화의 구독 토큰 사용량은 아니다.", small=True)
    doc.save(OUTPUT)
    inputs = [OUT / 'results.json', OUT / 'response-metrics.json', OUT / 'reference-audit.json',
              OUT / 'interpretation.ko.md', SPEC, fig]
    write_json(SHARE / 'report-inputs.json', {'inputs': {str(p.relative_to(ROOT)): digest(p.read_bytes()) for p in inputs},
                                           'output_sha256': digest(OUTPUT.read_bytes())})
    print(json.dumps({'report': str(OUTPUT), 'sha256': digest(OUTPUT.read_bytes())}, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--replace', action='store_true')
    build(parser.parse_args().replace)
