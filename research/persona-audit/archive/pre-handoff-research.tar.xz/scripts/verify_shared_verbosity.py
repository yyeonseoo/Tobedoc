"""Offline integrity, full paired metric reproduction, and optional DOCX checks."""
import argparse
import json
import subprocess
import sys

from common import ROOT, digest, write_json
from first_reply_probe_runner import verify_response
from run_local_pilot import fingerprint
from shared_verbosity import OUT, FOLDER, SPEC, read, conditions, measure, contrast


def main(report=False):
    result, plan = read(OUT / 'results.json'), read(FOLDER / 'plan.json')
    prepared, cases = read(FOLDER / 'prepared-at.json'), conditions()
    rows = read(OUT / 'response-metrics.json')
    assert len(cases) == len(rows) == result['actual_responses'] == 80
    assert digest(SPEC.read_bytes()) == plan['spec_sha256']
    assert fingerprint(cases) == plan['conditions_sha256']
    assert fingerprint(plan) == prepared['plan_sha256']
    assert plan == result['plan']
    for path, sha in plan['code_at_preparation'].items():
        assert digest((ROOT / path).read_bytes()) == sha, path
    for item in result['provenance']:
        assert digest((ROOT / item['path']).read_bytes()) == item['sha256'], item['path']
    for case, row in zip(cases, rows):
        stem = case['condition_id'] + '.json'
        raw, request = read(FOLDER / 'responses' / stem), read(FOLDER / 'requests' / stem)
        verify_response(raw, request, case, plan['model_digest'])
        assert prepared['prepared_at_utc'] < raw['started_at_utc']
        assert fingerprint(measure(case, raw)) == fingerprint(row)
        assert raw['raw_response']['done_reason'] == 'stop'
        assert not raw['raw_response'].get('message', {}).get('thinking')
        assert raw['raw_response']['eval_count'] < 512
    for name, value in result['contrasts'].items():
        arm, baseline = name.split('_minus_')
        assert fingerprint(contrast(rows, arm, baseline)) == fingerprint(value)
    for summary in result['summaries']:
        group = [r for r in rows if r['style_id'] == summary['arm']]
        assert len(group) == summary['n'] == 16
        assert sum(r['requested_refs'] for r in group) == summary['requested_refs_total']
        assert sum(r['other_positive'] for r in group) == summary['other_positive_replies']
        assert sum(r['word_count'] for r in group) / 16 == summary['word_count']
    c = result['contrasts']
    total = c['sim_verbose_minus_sim_concise']['word_count']['mean_difference']
    up = c['sim_verbose_minus_neutral']['word_count']['mean_difference']
    down = c['sim_concise_minus_neutral']['word_count']['mean_difference']
    assert abs(total - (up - down)) < 1e-10
    audit = read(OUT / 'reference-audit.json')
    expected_review = {r['condition_id'] for r in rows if r['requested_refs'] < 4 or
                       (r['profile_id'] == 'V1' and r['target_event'] == 'A')}
    assert {r['condition_id'] for r in audit['reviewed_responses']} == expected_review
    assert audit['reviewed_response_count'] == len(expected_review) == 21
    assert len(audit['all_reference_negatives']) == 11
    assert not audit['primary_counts_changed'] and not audit['unsupported_fact_rate_estimated']
    for item in audit['reviewed_responses']:
        path = FOLDER / 'responses' / (item['condition_id'] + '.json')
        assert digest(path.read_bytes()) == item['raw_sha256']
    for item in audit['examples']:
        raw = read(FOLDER / 'responses' / (item['condition_id'] + '.json'))
        assert item['quote'] in raw['response_text']
    tests = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-q'],
                           cwd=ROOT, capture_output=True, text=True)
    if tests.returncode:
        raise ValueError(tests.stdout + tests.stderr)
    record = {'verified_responses': 80, 'paired_blocks': 16, 'fictional_cases': 4,
              'plan_precedes_every_generation': True, 'prepared_analysis_code_unchanged': True,
              'all_metrics_reproduced': True, 'input_output_file_hash_checks': len(result['provenance']),
              'unit_test_output': tests.stderr.strip(), 'max_output_tokens': max(r['output_tokens'] for r in rows),
              **result['cost']}
    if report:
        from docx import Document
        from build_shared_verbosity_report import SHARE, OUTPUT
        manifest = read(SHARE / 'report-inputs.json')
        for path, sha in manifest['inputs'].items():
            assert digest((ROOT / path).read_bytes()) == sha
        assert manifest['output_sha256'] == digest(OUTPUT.read_bytes())
        doc = Document(OUTPUT)
        text = '\n'.join(p.text for p in doc.paragraphs)
        assert '80' in text and '512' in text and '공통' in text
        assert len(doc.tables) >= 2
        pages = list((SHARE / 'render-qa-v2').glob('page-*.png'))
        assert len(pages) == 3 and all(p.stat().st_size > 10000 for p in pages)
        record.update(rendered_pages=len(pages), report_sha256=digest(OUTPUT.read_bytes()),
                      render_directory='share/shared-verbosity-v02/render-qa-v2',
                      visual_review='All three final page PNGs inspected at original resolution; Korean glyphs, tables and figure clean.')
    write_json(ROOT / 'share/shared-verbosity-v02/verification.json', record)
    print(json.dumps(record, ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--report', action='store_true')
    main(parser.parse_args().report)
