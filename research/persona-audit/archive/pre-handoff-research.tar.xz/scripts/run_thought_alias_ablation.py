"""Bounded local single-field ablation; fresh paired controls, no clinical judge."""
import argparse
import json
import random
import time
import uuid

from audit_sources import extract_template, parse_styles
from common import ROOT, digest, read_source, write_json
from local_preflight import MODEL, local_metadata
from prepare_pilot import build_conditions, render_prompt
from run_feature_batch import payload
from run_local_pilot import OPTIONS, chat, classify, fingerprint, now, refresh_progress
from summarize_local_pilot import verify_turn

PLAN = ROOT/"config/thought-alias-ablation-v01.json"


def conditions():
    plan = json.loads(PLAN.read_text())
    template = extract_template(read_source("psi_formatter"))
    styles = parse_styles(read_source("psi_styles"))
    originals = [c for c in build_conditions() if c["arm"] == "native_demo_mapping" and c["style_id"] in plan["styles"]]
    groups = [(c, repeat) for c in originals for repeat in range(plan["repeats"])]
    rng = random.Random(20261030)
    rng.shuffle(groups)
    result = []
    for original, repeat in groups:
        pair = []
        for arm in plan["arms"]:
            row = json.loads(json.dumps(original))
            row.update(condition_id=f'M-{row["profile_id"]}-{row["style_id"]}-R{repeat}-'+("native" if arm == "native_demo_mapping" else "alias"),
                       repeat_index=repeat, arm=arm, stage="single_field_input_ablation", intervention="none")
            if arm != "native_demo_mapping":
                row["profile"]["auto_thoughts"] = row["profile"]["auto_thought"]
                row["system_prompt"], row["missing_fields"] = render_prompt(template, row["profile"], styles[row["style_id"]])
                row["mapping_changes"] = [{"target": "auto_thoughts", "source_fields": ["auto_thought"], "operation": "alias existing value; nothing else changed"}]
                row["intervention"] = "automatic_thought_alias_only"
                old = "Automatic Thoughts: undefined"
                new = "Automatic Thoughts: "+row["profile"]["auto_thought"]
                if original["system_prompt"].count(old) != 1 or row["system_prompt"] != original["system_prompt"].replace(old, new):
                    raise ValueError("Intervention changed more than one rendered field")
            row["prompt_sha256"] = fingerprint({"system_prompt": row["system_prompt"], "interview": row["interview"]})
            pair.append(row)
        rng.shuffle(pair)
        result.extend(pair)
    if len(result) != plan["planned_dialogues"]:
        raise ValueError("Unexpected ablation design size")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--max-dialogues", type=int, default=24)
    args = parser.parse_args()
    if not 1 <= args.max_dialogues <= 24:
        parser.error("Bounded experiment permits 1..24 dialogues")
    policy = json.loads((ROOT/"config/compute-policy.json").read_text())
    if policy["paid_model_api_allowed"] or policy["automatic_model_download_allowed"]:
        raise ValueError("Compute policy changed")
    model = next((m for m in local_metadata("/api/tags")["models"] if m.get("name") == MODEL), None)
    expected = json.loads((ROOT/"evidence/local-runtime.json").read_text())["ollama"]["candidate_metadata"]["digest"]
    if not model or model["digest"] != expected:
        raise ValueError("Pinned installed model absent or changed; no replacement/pull")
    plan = json.loads(PLAN.read_text())
    cases = conditions()
    config = {"run_id": plan["run_id"], "model": MODEL, "model_digest": model["digest"], "options": OPTIONS,
              "think": False, "plan_sha256": digest(PLAN.read_bytes()), "plan": plan,
              "conditions": [{k: c[k] for k in ["condition_id", "prompt_sha256"]} for c in cases],
              "user_authorization": "User requests next research stage; local single-field ablation within prior local-only policy"}
    folder = ROOT/"pilot/runs"/plan["run_id"]
    if folder.exists():
        if not args.resume or json.loads((folder/"run-config.json").read_text()) != config:
            raise ValueError("Existing run requires identical --resume config")
        if json.loads((folder/"conditions.json").read_text()) != cases:
            raise ValueError("Stored conditions differ from locked design")
    else:
        if args.resume:
            raise ValueError("Cannot resume nonexistent run")
        for name in ["requests", "responses"]:
            (folder/name).mkdir(parents=True, exist_ok=False)
        write_json(folder/"run-config.json", config)
        write_json(folder/"conditions.json", cases)
        write_json(folder/"runtime.json", {"checked_at_utc": now(), "model": model,
            "version": local_metadata("/api/version"), "show": local_metadata("/api/show", {"model": MODEL})})
    lock = folder/".running"
    with lock.open("x") as file:
        file.write(now())
    try:
        for i, case in enumerate(cases[:args.max_dialogues], 1):
            history = []
            for question in case["interview"]:
                turn = question["turn"]
                stem = f'{case["condition_id"]}-T{turn}'
                rp, sp = folder/"requests"/(stem+".json"), folder/"responses"/(stem+".json")
                request = payload(case, history, turn)
                sha = fingerprint(request)
                if sp.exists():
                    row = json.loads(sp.read_text())
                    case_check = {**case, "_model_digest": model["digest"]}
                    verify_turn(row, json.loads(rp.read_text()), case_check, history)
                    if row["request_sha256"] != sha or row["status"] != "completed":
                        raise ValueError("Failed/inconsistent response; no silent retry")
                else:
                    if rp.exists():
                        raise ValueError("Unfinished request requires inspection")
                    request_id, started = str(uuid.uuid4()), now()
                    write_json(rp, {"request_id": request_id, "started_at_utc": started, "request_sha256": sha, "payload": request})
                    begin = time.monotonic()
                    raw, error = {}, None
                    try:
                        raw = chat(request)
                        status = classify(raw)
                    except Exception as exc:
                        status, error = "transport_error", {"type": type(exc).__name__, "message": str(exc)}
                    row = {"run_id": plan["run_id"], "condition_id": case["condition_id"], "profile_id": case["profile_id"],
                        "style_id": case["style_id"], "arm": case["arm"], "repeat_index": case["repeat_index"],
                        "turn": turn, "probe": question["probe"], "interviewer_text": question["text"],
                        "prompt_sha256": case["prompt_sha256"], "request_sha256": sha, "request_id": request_id,
                        "started_at_utc": started, "ended_at_utc": now(), "wall_seconds": time.monotonic()-begin,
                        "provider": "local_ollama", "model_id_requested": MODEL, "model_id_returned": raw.get("model"),
                        "model_digest": model["digest"], "generation_settings": {"think": False, **request["options"]},
                        "status": status, "response_text": raw.get("message", {}).get("content", ""),
                        "finish_reason": raw.get("done_reason"), "raw_response": raw, "error": error,
                        "is_fixture": False, "clinical_rating": None, "is_schizophrenia_case": False,
                        "usage": {k: raw.get(k) for k in ["prompt_eval_count", "eval_count", "eval_duration", "load_duration", "total_duration"]}}
                    write_json(sp, row)
                    print(f'{i}/24 {case["condition_id"]} T{turn}: {status}, {row["wall_seconds"]:.1f}s', flush=True)
                progress = refresh_progress(folder, cases)
                if row["status"] != "completed":
                    raise ValueError("Failed output preserved; inspect before continuing")
                history += [{"role": "user", "content": question["text"]}, {"role": "assistant", "content": row["response_text"]}]
    finally:
        lock.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
