"""Final offline integrity/reproducibility gate for sentence trajectory deliverables."""
import json
from pathlib import Path
import subprocess
import sys

from docx import Document

from common import ROOT, digest, write_json
from analyze_topic_trajectory import exact_utf16
from build_topic_trajectory_report import OUT, OUTPUT, PATHS
from run_context_topic_labeler import payload, parse_labels, requests


def read(path):
    return json.loads(path.read_text())


def main():
    topic = read(ROOT / "analysis/topic-trajectory-v01/results.json")
    context = read(ROOT / "analysis/context-topic-labeler-v01/results.json")
    audit = read(ROOT / "analysis/context-topic-labeler-v01/reference-audit.json")
    assert topic["existing_replies"] == context["annotated_existing_replies"] == 48
    assert sum(r["sentence_count"] for r in topic["responses"]) == context["annotated_sentences"] == 411
    verified = 0
    for item in topic["provenance"]["source_files"]:
        assert digest((ROOT / item["path"]).read_bytes()) == item["sha256"]
        verified += 1
    for r in topic["responses"]:
        for s in r["sentences"]:
            assert exact_utf16(r["response_text"], s["utf16_start"], s["utf16_length"]) == s["text"]
    spec = read(ROOT / "config/context-topic-labeler-v01.json")
    jobs = requests(spec, read(ROOT / "config/topic-trajectory-v01.json"), topic)
    local_outputs = []
    base = ROOT / "analysis/context-topic-labeler-v01"
    for job in jobs:
        req = read(base / "requests" / (job["id"]+".json"))
        saved = read(base / "responses" / (job["id"]+".json"))
        from run_local_pilot import fingerprint
        assert req["payload"] == payload(job, spec)
        assert req["request_sha256"] == saved["request_sha256"] == fingerprint(req["payload"])
        assert saved["raw_sha256"] == fingerprint(saved["raw"])
        assert len(parse_labels(saved["raw"], job)) == len(job["input"]["sentences"])
        local_outputs.append((job, saved))
        verified += 2
    last_control = max(s["ended_at_utc"] for j,s in local_outputs if j["phase"] != "existing_reply")
    first_reply = min(s["started_at_utc"] for j,s in local_outputs if j["phase"] == "existing_reply")
    assert last_control <= first_reply
    assert audit["source_sha256"] == digest((base / "results.json").read_bytes())
    assert not audit["automatic_semantic_rate_promoted_to_primary"]
    assert audit["flagged_sentences"] == 4 and audit["flagged_replies"] == 3
    report = read(OUT / "report-inputs.json")
    for item in report["inputs"]:
        assert digest((ROOT / item["path"]).read_bytes()) == item["sha256"]
        verified += 1
    assert report["output_sha256"] == digest(OUTPUT.read_bytes())
    doc = Document(OUTPUT)
    text = "\n".join(p.text for p in doc.paragraphs) + "\n" + "\n".join(c.text for t in doc.tables for r in t.rows for c in r.cells)
    for token in ("411", "2/16", "1/16", "원시 출력", "주 결과로 채택하지", "pottery class"):
        assert token in text, token
    pages = list((OUT / "render-qa-v2").glob("page-*.png"))
    assert len(pages) == 3 and all(p.stat().st_size > 10000 for p in pages)
    tests = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "tests"], cwd=ROOT,
                           capture_output=True, text=True)
    if tests.returncode:
        raise ValueError(tests.stdout+tests.stderr)
    result = {"existing_replies": 48, "sentences": 411, "source_and_request_checks": verified,
              "all_sentence_spans_verified": True, "local_labeler_calls": len(local_outputs),
              "control_calls": 12, "reply_annotation_calls": 48,
              "local_labeler_prompt_tokens": sum(s["raw"].get("prompt_eval_count",0) for j,s in local_outputs),
              "local_labeler_output_tokens": sum(s["raw"].get("eval_count",0) for j,s in local_outputs),
              "local_labeler_seconds": round(sum(s["wall_seconds"] for j,s in local_outputs),1),
              "controls_preceded_reply_annotation": True, "semantic_rate_used_as_primary": False,
              "reference_flags": 4, "rendered_pages": len(pages), "unit_test_output": tests.stderr.strip(),
              "report_sha256": digest(OUTPUT.read_bytes()), "new_persona_replies": 0,
              "paid_api_calls": 0, "model_downloads": 0, "clinical_ratings": 0}
    write_json(OUT / "verification.json", result)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
