"""Frozen, local contrastive measurement audit; no LLM generation or judge.

Usage: prepare; embed; score --split development; score --split evaluation;
verify. The seal binds the authored corpus, protocol, scorer and Swift backend.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import itertools
import json
import math
from pathlib import Path
import random
import re
from statistics import mean, median
import subprocess
import tempfile
import time

ROOT = Path(__file__).resolve().parents[1]
SPEC = ROOT / "config/measurement-audit-v01.json"
CASES = ROOT / "config/measurement-audit-cases-v01.json"
SWIFT = ROOT / "scripts/NativeFeatures.swift"
OUT = ROOT / "analysis/measurement-audit-v01"
METRICS = ("adjacent_cos", "all_pairs_cos", "adjacency_excess",
           "question_association", "lexical_adjacent", "duplicate_fraction",
           "type_token_ratio")
VARIANTS = ("original", "question_swap", "reverse", "middle_swap", "repeat_first",
            "insert_related", "insert_other", "paraphrase", "contradiction")
EPS = 1e-12


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ident(text):
    return hashlib.sha256(text.encode()).hexdigest()


def words(text):
    return re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?|\d+(?:\.\d+)?", text.lower())


def normalized(text):
    return " ".join(words(text))


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def immutable(path, value):
    if path.exists():
        if read(path) != value:
            raise ValueError(f"Preserve existing output under a new version: {path}")
    else:
        save(path, value)


def validate_cases(cases):
    assert len(cases) == 24 and len({c['id'] for c in cases}) == 24
    assert len({tuple(c['sentences']) for c in cases}) == 24
    for family in read(SPEC)['families']:
        group = [c for c in cases if c['family'] == family]
        assert len(group) == 6
        assert Counter(c['split'] for c in group) == {'development': 2, 'evaluation': 4}
    for c in cases:
        assert len(c['sentences']) == 5
        assert all(s.endswith('.') and len(words(s)) >= 4 for s in c['sentences'])
        assert len(words(c['related'])) == 10, (c['id'], len(words(c['related'])))
        assert len(words(c['contradiction'])) == len(words(c['sentences'][-1])), c['id']
        assert c['paraphrase'] != c['sentences'][0]
        assert c['contradiction'] != c['sentences'][-1]
        assert c['question'].endswith('?') or c['question'].endswith('.')


def variants(cases):
    result = []
    for i, c in enumerate(cases):
        s = c['sentences']
        other = cases[(i + 7) % len(cases)]
        texts = {
            'original': list(s), 'question_swap': list(s), 'reverse': s[::-1],
            'middle_swap': [s[j] for j in (0, 2, 1, 3, 4)],
            'repeat_first': [s[0]] + s,
            'insert_related': s[:2] + [c['related']] + s[2:],
            'insert_other': s[:2] + [other['related']] + s[2:],
            'paraphrase': [c['paraphrase']] + s[1:],
            'contradiction': s[:-1] + [c['contradiction']]
        }
        for kind in VARIANTS:
            result.append({'id': c['id'] + '-' + kind, 'case_id': c['id'],
                           'family': c['family'], 'split': c['split'], 'variant': kind,
                           'question': other['question'] if kind == 'question_swap' else c['question'],
                           'sentences': texts[kind], 'text': ' '.join(texts[kind]),
                           'other_case_id': other['id']})
    return result


def files():
    return [SPEC, CASES, Path(__file__).resolve(), SWIFT]


def current_hashes():
    return {str(p.relative_to(ROOT)): sha(p) for p in files()}


def check_seal():
    seal = read(OUT / 'seal.json')
    assert seal['source_hashes'] == current_hashes(), 'Frozen input or implementation changed'
    for name in ('variants.json', 'embedding-input.json'):
        assert seal['prepared_hashes'][name] == sha(OUT / name), name
    return seal


def prepare():
    cases = read(CASES)
    validate_cases(cases)
    records = variants(cases)
    assert len(records) == 216
    atoms = sorted({t for r in records for t in r['sentences'] + [r['question']]})
    immutable(OUT / 'variants.json', records)
    immutable(OUT / 'embedding-input.json', [{'id': ident(t), 'text': t} for t in atoms])
    if (OUT / 'seal.json').exists():
        check_seal()
    else:
        assert not (OUT / 'embedding-output.json').exists(), 'Seal must precede embeddings'
        save(OUT / 'seal.json', {
            'created_utc': datetime.now(timezone.utc).isoformat(),
            'description': 'Local freeze before new embeddings or scores; not external preregistration',
            'source_hashes': current_hashes(),
            'prepared_hashes': {n: sha(OUT/n) for n in ('variants.json', 'embedding-input.json')},
            'counts': {'base_cases': 24, 'development_cases': 8, 'evaluation_cases': 16,
                       'variant_records': len(records), 'unique_atomic_texts': len(atoms)},
            'holdout_scope': 'No numerical outcomes seen at freeze; same author and relation patterns across splits'
        })
    print(json.dumps(read(OUT/'seal.json')['counts']))


def embed():
    check_seal()
    out = OUT / 'embedding-output.json'
    if out.exists():
        load_vectors()
        print('Verified existing immutable embedding cache; no calls repeated')
        return
    start = time.monotonic()
    with tempfile.TemporaryDirectory(prefix='measurement-audit-', dir='/private/tmp') as tmp:
        binary = Path(tmp) / 'NativeFeatures'
        subprocess.run(['/usr/bin/swiftc', '-module-cache-path', str(Path(tmp)/'modules'),
                        str(SWIFT), '-o', str(binary)], check=True, capture_output=True, text=True)
        subprocess.run([str(binary), str(OUT/'embedding-input.json'), str(out)], check=True)
    save(OUT / 'embedding-manifest.json', {
        'input_sha256': sha(OUT/'embedding-input.json'), 'output_sha256': sha(out),
        'swift_sha256': sha(SWIFT), 'wall_seconds': time.monotonic()-start,
        'description': 'OS-supplied Apple English sentence embedding revision 1; no asset request or model download',
        'new_generation_calls': 0, 'llm_judge_calls': 0, 'paid_api_calls': 0
    })
    load_vectors()


def cosine(a, b):
    if len(a) != len(b) or not a:
        raise ValueError('Vector dimension mismatch')
    norms = []
    for v in (a, b):
        if not all(math.isfinite(x) for x in v):
            raise ValueError('Non-finite vector')
        norm = math.sqrt(sum(x*x for x in v))
        if norm == 0:
            raise ValueError('Zero vector')
        norms.append(norm)
    return sum(x*y for x,y in zip(a,b)) / (norms[0]*norms[1])


def load_vectors():
    check_seal()
    manifest = read(OUT/'embedding-manifest.json')
    assert manifest['input_sha256'] == sha(OUT/'embedding-input.json')
    assert manifest['output_sha256'] == sha(OUT/'embedding-output.json')
    assert manifest['swift_sha256'] == sha(SWIFT)
    native = read(OUT/'embedding-output.json')
    assert native['embeddingRevision'] == 1 and native['embeddingDimension'] == 512
    inputs = read(OUT/'embedding-input.json')
    index = {r['id']: r for r in native['records']}
    assert len(index) == len(inputs) == len(native['records'])
    assert set(index) == {r['id'] for r in inputs}
    result = {}
    for item in inputs:
        assert item['id'] == ident(item['text'])
        record = index[item['id']]
        # All atoms are deliberately one sentence. Verify native segmentation too.
        assert len(record['sentences']) == 1, item['text']
        sentence = record['sentences'][0]
        data = item['text'].encode('utf-16-le')
        a,b = 2*sentence['utf16Start'], 2*(sentence['utf16Start']+sentence['utf16Length'])
        assert data[a:b].decode('utf-16-le') == sentence['text'] == item['text']
        v = record['vector']
        assert v is not None and len(v) == 512
        assert abs(cosine(v,v)-1) < 1e-10
        result[item['text']] = v
    return result, {k:v for k,v in native.items() if k != 'records'}


def jaccard(a, b):
    a,b = set(words(a)), set(words(b))
    if not a or not b:
        raise ValueError('Empty lexical set')
    return len(a & b)/len(a | b)


def measure(sentences, question, vectors):
    vs = [vectors[s] for s in sentences]
    if len(vs) < 2:
        raise ValueError('This audit requires at least two sentences')
    adjacent = mean(cosine(a,b) for a,b in zip(vs,vs[1:]))
    allpairs = mean(cosine(a,b) for a,b in itertools.combinations(vs,2))
    tokens = [w for s in sentences for w in words(s)]
    return {
        'adjacent_cos': adjacent, 'all_pairs_cos': allpairs,
        'adjacency_excess': adjacent-allpairs,
        'question_association': mean(cosine(v,vectors[question]) for v in vs),
        'lexical_adjacent': mean(jaccard(a,b) for a,b in zip(sentences,sentences[1:])),
        'duplicate_fraction': 1-len({normalized(s) for s in sentences})/len(sentences),
        'type_token_ratio': len(set(tokens))/len(tokens),
        'word_count': len(tokens), 'sentence_count': len(sentences)
    }


def quantile(values, p):
    values = sorted(values)
    k = p*(len(values)-1)
    low = int(k)
    return values[low] + (values[min(low+1,len(values)-1)]-values[low])*(k-low)


def summarize(entries, repetitions=2000, seed=20261101):
    values = [e['value'] for e in entries]
    groups = {f:[e['value'] for e in entries if e['family']==f] for f in sorted({e['family'] for e in entries})}
    rng = random.Random(seed)
    boot = []
    boot_fraction = []
    for _ in range(repetitions):
        sample = [rng.choice(g) for g in groups.values() for _ in g]
        boot.append(mean(sample))
        boot_fraction.append(sum(v>EPS for v in sample)/len(sample))
    return {'n_cases':len(values), 'mean':mean(values), 'median':median(values),
            'mean_absolute':mean(abs(v) for v in values),
            'positive':sum(v>EPS for v in values), 'negative':sum(v < -EPS for v in values),
            'ties':sum(abs(v)<=EPS for v in values),
            'mean_ci95':[quantile(boot,.025),quantile(boot,.975)],
            'positive_fraction_ci95':[quantile(boot_fraction,.025),quantile(boot_fraction,.975)],
            'by_family':{f:{'n':len(g),'mean':mean(g),'positive':sum(v>EPS for v in g),
                            'negative':sum(v < -EPS for v in g),'ties':sum(abs(v)<=EPS for v in g)} for f,g in groups.items()}}


def contrasts(index):
    base = index['original']
    pairs = {
        'explicit_relation':('original','contradiction'),
        'insertion':('insert_related','insert_other'),
        'question_target':('original','question_swap'),
        'paraphrase':('paraphrase','original'),
        'middle_order':('middle_swap','original'),
        'reversal':('reverse','original'),
        'repetition':('repeat_first','original')
    }
    result = {name:{m:index[a]['metrics'][m]-index[b]['metrics'][m] for m in METRICS}
              for name,(a,b) in pairs.items()}
    result['paraphrase_vs_relation'] = {
        m:abs(index['contradiction']['metrics'][m]-base['metrics'][m])-
          abs(index['paraphrase']['metrics'][m]-base['metrics'][m]) for m in METRICS}
    return result


def score(split):
    check_seal()
    if split == 'evaluation':
        assert (OUT/'development-results.json').exists(), 'Run development integrity checks first'
    vectors, backend = load_vectors()
    records = [r for r in read(OUT/'variants.json') if r['split']==split]
    rows = [{**r, 'metrics':measure(r['sentences'],r['question'],vectors)} for r in records]
    details=[]
    for case_id in sorted({r['case_id'] for r in rows}):
        group={r['variant']:r for r in rows if r['case_id']==case_id}
        assert set(group)==set(VARIANTS)
        cs = contrasts(group)
        # Exact manipulation checks, no performance-dependent acceptance criteria.
        assert group['original']['text'] == group['question_swap']['text']
        assert group['insert_related']['metrics']['word_count'] == group['insert_other']['metrics']['word_count']
        assert group['contradiction']['metrics']['word_count'] == group['original']['metrics']['word_count']
        assert all(abs(cs['question_target'][m]) <= EPS for m in METRICS if m!='question_association')
        assert all(abs(cs['reversal'][m]) <= EPS for m in ('adjacent_cos','all_pairs_cos','adjacency_excess','question_association','lexical_adjacent','duplicate_fraction','type_token_ratio'))
        predicted=(1-group['original']['metrics']['adjacent_cos'])/5
        assert abs(cs['repetition']['adjacent_cos']-predicted)<1e-10
        details.append({'case_id':case_id,'family':group['original']['family'],'contrasts':cs})
    spec=read(SPEC)
    summary={name:{m:summarize([{'family':r['family'],'value':r['contrasts'][name][m]} for r in details],
                              repetitions=spec['analysis']['bootstrap_repetitions'],
                              seed=spec['analysis']['bootstrap_seed']) for m in METRICS}
             for name in details[0]['contrasts']}
    result={'study_id':spec['study_id'],'split':split,'base_cases':len(details),'variant_records':len(rows),
            'unique_answer_texts':len({r['text'] for r in rows}), 'metrics':list(METRICS),
            'comparisons':summary,'embedding_backend':backend,
            'interpretation':'Authored contrastive sensitivity audit, not coherence classification accuracy or clinical validation',
            'source_hashes':current_hashes(),
            'embedding_output_sha256':sha(OUT/'embedding-output.json'),
            'cost':spec['budget']}
    immutable(OUT/f'{split}-measurements.json',rows)
    immutable(OUT/f'{split}-case-contrasts.json',details)
    immutable(OUT/f'{split}-results.json',result)
    print(json.dumps({'split':split,'cases':len(details),'records':len(rows),
                      'explicit_relation_adjacent':summary['explicit_relation']['adjacent_cos'],
                      'insertion_adjacent':summary['insertion']['adjacent_cos'],
                      'question_target_association':summary['question_target']['question_association']},ensure_ascii=False))


def verify():
    seal=check_seal()
    load_vectors()
    validate_cases(read(CASES))
    cases=read(CASES)
    assert not ({c['id'] for c in cases if c['split']=='development'} & {c['id'] for c in cases if c['split']=='evaluation'})
    for split in ('development','evaluation'):
        r=read(OUT/f'{split}-results.json')
        assert r['source_hashes']==current_hashes()
        assert r['embedding_output_sha256']==sha(OUT/'embedding-output.json')
        details=read(OUT/f'{split}-case-contrasts.json')
        rows=read(OUT/f'{split}-measurements.json')
        assert len(rows)==9*len(details)==r['variant_records']
        for name,ms in r['comparisons'].items():
            for m,stats in ms.items():
                vals=[e['contrasts'][name][m] for e in details]
                assert abs(stats['mean']-mean(vals))<EPS
                assert stats['positive']+stats['negative']+stats['ties']==len(details)
                assert stats['mean_ci95'][0] <= stats['mean_ci95'][1]
        originals={x['case_id'] for x in rows}
        assert originals=={c['id'] for c in cases if c['split']==split}
    from topic_local_separation import load as load_prior
    load_prior()  # Independently recheck existing source, request and cache hashes.
    prior_result=ROOT/'analysis/topic-local-separation-v01/results.json'
    prior_details=ROOT/'analysis/topic-local-separation-v01/response-details.json'
    prior=read(prior_result)
    example_ids=('P-N2-V2-QA-R4-tangent','P-N1-V2-QB-R5-tangent')
    prior_rows=read(prior_details)['responses']
    examples=[r for r in prior_rows if r['condition_id'] in example_ids]
    assert len(examples)==2
    immutable(OUT/'prior-linkage.json',{
        'scope':'Already inspected persona records, descriptive linkage only; no new independent evaluation',
        'source_hashes':{str(p.relative_to(ROOT)):sha(p) for p in (prior_result,prior_details)},
        'reused_response_records':prior['existing_replies'],
        'summaries':prior['summaries'], 'examples':examples,
        'instruction':'Do not infer that one style is clinically more disorganized from adjacent cosine differences'})
    save(OUT/'verification.json',{'status':'passed','base_cases':24,'development':8,'evaluation':16,
        'variants':216,'frozen_source_files':len(seal['source_hashes']),
        'manipulation_checks':['matched insertion lengths','matched contradiction lengths','question-only invariance',
            'reverse invariance','duplication identity','no split leakage at base-case level'],
        'raw_embedding_records_verified':seal['counts']['unique_atomic_texts'],
        'prior_48_responses_source_hashes_verified':True,
        'clinical_validation':False})
    print(json.dumps(read(OUT/'verification.json')))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=('prepare','embed','score','verify'))
    parser.add_argument('--split',choices=('development','evaluation'))
    args=parser.parse_args()
    if args.action=='score':
        assert args.split, '--split is required'
        score(args.split)
    else:
        globals()[args.action]()
