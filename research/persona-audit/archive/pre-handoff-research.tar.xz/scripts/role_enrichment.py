"""No-generation, source-linked explicit event-role audit on 80 saved first replies."""
import argparse
from collections import defaultdict
import json
from pathlib import Path
import random
import re
from statistics import mean
import subprocess
import tempfile

from common import ROOT, digest, write_json
from first_reply_probe_runner import verify_response
from run_local_pilot import fingerprint, now
from shared_verbosity import FOLDER as PARENT, conditions

SPEC = ROOT / 'config/role-enrichment-v01.json'
OUT = ROOT / 'analysis/role-enrichment-v01'


def read(path):
    return json.loads(path.read_text())


def matcher(text, person, spec):
    role_map = {alias: kind for kind, aliases in spec['role_aliases'].items() for alias in aliases}
    role = '(?:' + '|'.join(sorted(map(re.escape, role_map), key=len, reverse=True)) + ')'
    name = r'\b' + re.escape(person['name']) + r'\b'
    role_terms = list(re.finditer(r'\b' + role + r'\b', text, re.I))
    named = bool(re.search(name, text, re.I))
    candidate = bool(named and role_terms)
    blocker = re.search(r"\b(?:not|no|never|if|whether|maybe|perhaps|might|could|seems?|seemed|apparently|suppose|wonder|guess|said|asked)\b|n['’]t|[?\"“”‘’]", text, re.I)
    if not candidate or blocker:
        return {'candidate': candidate, 'abstained': bool(candidate and blocker), 'matches': []}
    pre = '(?:' + '|'.join(map(re.escape, spec['premodifiers'])) + ')'
    filler = '(?:' + pre + r'\s+){0,7}'
    patterns = [
        ('copular', name + r'\s*,?\s+(?:(?:who\s+)?(?:was|is|were)\s+)' + filler + r'(?P<role>' + role + r')\b'),
        ('name_apposition', name + r',\s*' + filler + r'(?P<role>' + role + r')\b'),
        ('role_before_name', r'\b(?:my|our|the|a|an)\s+' + filler + r'(?P<role>' + role + r')\b\s*,?\s+(?:named\s+)?' + name)
    ]
    found = {}
    for rule, pattern in patterns:
        for hit in re.finditer(pattern, text, re.I):
            kind = role_map[hit.group('role').lower()]
            key = (kind, hit.start('role'), hit.end('role'))
            found[key] = {'rule': rule, 'canonical_role': kind, 'start': hit.start(), 'end': hit.end(),
                          'role_start': hit.start('role'), 'role_end': hit.end('role'), 'span': hit.group(),
                          'profile_role_status': 'source_specified' if kind in person['roles'] else
                          ('profile_unspecified' if not person['roles'] else 'different_role_label_not_adjudicated')}
    return {'candidate': candidate, 'abstained': False, 'matches': list(found.values())}


def prepare():
    spec, cases = read(SPEC), conditions()
    parent_plan = read(PARENT / 'plan.json')
    inputs, rows = [], []
    for case in cases:
        person = spec['people'][case['profile_id']][case['target_event']]
        person_fact = next(f for f in case['facts'] if f['id'] == case['target_event']+'3')
        assert person['name'] in person_fact['description']
        # Validate the two explicit role declarations against the exact source input.
        for role in person['roles']:
            assert role in person_fact['description'].lower()
        stem = case['condition_id'] + '.json'
        raw, request = read(PARENT / 'responses' / stem), read(PARENT / 'requests' / stem)
        verify_response(raw, request, case, parent_plan['model_digest'])
        inputs.append({'id': case['condition_id'], 'text': raw['response_text']})
        rows += [PARENT / 'responses' / stem, PARENT / 'requests' / stem]
    write_json(OUT / 'sentence-input.json', inputs)
    plan = {'prepared_at_utc': now(), 'analysis': spec['analysis_id'], 'spec_sha256': digest(SPEC.read_bytes()),
            'parent_plan_sha256': digest((PARENT / 'plan.json').read_bytes()),
            'input_sha256': fingerprint(inputs), 'code_sha256': digest(Path(__file__).read_bytes()),
            'segmenter_sha256': digest((ROOT / 'scripts/SentenceUnits.swift').read_bytes()),
            'new_generation_calls': 0, 'judging_model_calls': 0, 'clinical_ratings': 0,
            'status': spec['status'], 'prior_exposure': spec['prior_exposure'],
            'raw_provenance': [{'path': str(p.relative_to(ROOT)), 'sha256': digest(p.read_bytes())} for p in rows]}
    path = OUT / 'plan.json'
    if path.exists():
        old = read(path)
        for k, v in plan.items():
            if k != 'prepared_at_utc' and old[k] != v:
                raise ValueError(f'Frozen measurement changed: {k}')
    else:
        write_json(path, plan)
    return spec, cases


def segment():
    prepare()
    output = OUT / 'sentence-output.json'
    if output.exists():
        return
    with tempfile.TemporaryDirectory(prefix='persona-roles-') as temporary:
        directory = Path(temporary)
        executable = directory / 'SentenceUnits'
        subprocess.run(['/usr/bin/swiftc', '-module-cache-path', str(directory / 'modules'),
                        str(ROOT / 'scripts/SentenceUnits.swift'), '-o', str(executable)], check=True, capture_output=True)
        subprocess.run([str(executable), str(OUT / 'sentence-input.json'), str(output)], check=True)


def analyze():
    spec, cases = prepare()
    segment()
    inputs = {r['id']: r['text'] for r in read(OUT / 'sentence-input.json')}
    native = read(OUT / 'sentence-output.json')
    by_id = {r['id']: r['sentences'] for r in native['records']}
    controls = []
    for fixture in spec['controls']:
        observed = bool(matcher(fixture['text'], {'name': 'Helena', 'roles': []}, spec)['matches'])
        controls.append({**fixture, 'observed': observed, 'passed': observed == fixture['expected']})
    if not all(r['passed'] for r in controls):
        raise ValueError('Authored implementation control failed; not a clinical validation set')
    metrics, units = [], []
    for case in cases:
        cid = case['condition_id']
        person = spec['people'][case['profile_id']][case['target_event']]
        text, sentences = inputs[cid], by_id[cid]
        all_matches = []
        for sentence in sentences:
            # The immutable UTF16 source span must reproduce the exact sentence.
            encoded = text.encode('utf-16-le')
            start, length = sentence['utf16Start'], sentence['utf16Length']
            assert encoded[start*2:(start+length)*2].decode('utf-16-le') == sentence['text']
            found = matcher(sentence['text'], person, spec)
            unit = {'id': cid + '-S' + str(sentence['index']), 'condition_id': cid,
                    **sentence, **found, 'person': person, 'profile_id': case['profile_id'],
                    'target_event': case['target_event'], 'style_id': case['style_id'],
                    'repeat_index': case['repeat_index']}
            units.append(unit)
            all_matches += [{**m, 'sentence_id': unit['id']} for m in found['matches']]
        metrics.append({**{k: case[k] for k in ('condition_id','profile_id','target_event','style_id','repeat_index')},
                        'eligible_unspecified_role': not person['roles'], 'sentence_count': len(sentences),
                        'role_assertion': bool(all_matches),
                        'unspecified_role_positive': bool(not person['roles'] and all_matches),
                        'specified_role_positive': bool(any(m['profile_role_status']=='source_specified' for m in all_matches)),
                        'explicit_assertions': all_matches})
    summaries = []
    for arm in ('neutral','simple_verbose','psi_verbose','sim_verbose','sim_concise'):
        group = [r for r in metrics if r['style_id'] == arm]
        eligible = [r for r in group if r['eligible_unspecified_role']]
        specified = [r for r in group if not r['eligible_unspecified_role']]
        summaries.append({'arm': arm, 'replies': len(group), 'eligible': len(eligible),
                          'unspecified_role_replies': sum(r['unspecified_role_positive'] for r in eligible),
                          'specified_role_denominator': len(specified),
                          'specified_role_replies': sum(r['specified_role_positive'] for r in specified),
                          'candidates': sum(u['candidate'] for u in units if u['style_id']==arm),
                          'matched_sentences': sum(bool(u['matches']) for u in units if u['style_id']==arm)})
    blocks = defaultdict(dict)
    for row in metrics:
        if row['eligible_unspecified_role']:
            blocks[(row['profile_id'],row['target_event'],row['repeat_index'])][row['style_id']] = int(row['unspecified_role_positive'])
    contrasts = {}
    for arm, baseline in [('simple_verbose','neutral'),('psi_verbose','neutral'),('sim_verbose','neutral'),
                          ('psi_verbose','simple_verbose'),('sim_verbose','simple_verbose')]:
        differences = [{'block': list(k), 'difference': v[arm]-v[baseline]} for k,v in sorted(blocks.items())]
        contrasts[arm+'_minus_'+baseline] = {'mean_difference': mean(d['difference'] for d in differences), 'blocks': differences}
    result = {'analysis': spec['analysis_id'], 'reused_replies': len(metrics), 'sentences': len(units),
              'summaries': summaries, 'contrasts': contrasts, 'controls_passed': sum(r['passed'] for r in controls),
              'candidates': sum(u['candidate'] for u in units), 'matched_sentences': sum(bool(u['matches']) for u in units),
              'uncertainty_abstentions': sum(u['abstained'] for u in units), 'new_generation_calls': 0,
              'llm_judge_calls': 0, 'scope': spec['scope'], 'segmentation': {k:v for k,v in native.items() if k!='records'}}
    for name, value in [('results.json',result),('response-metrics.json',metrics),('sentence-units.json',units),
                        ('controls.json',controls),('candidate-audit.json',[u for u in units if u['candidate']])]:
        write_json(OUT / name, value)
    # Balanced, condition-label-masked review pack. No invented human decisions.
    selected = []
    rng = random.Random(20261103)
    for arm in ('neutral','simple_verbose','psi_verbose','sim_verbose','sim_concise'):
        pool = sorted((u for u in units if u['style_id']==arm), key=lambda u:u['id'])
        selected += rng.sample(pool, 5)
    rng.shuffle(selected)
    packet, key = [], []
    for index, unit in enumerate(selected, 1):
        case = next(c for c in cases if c['condition_id']==unit['condition_id'])
        uid = 'R'+str(index).zfill(2)
        packet.append({'review_id': uid, 'profile_facts': case['facts'], 'question': case['interview'][0]['text'],
                       'preceding_context': [u['text'] for u in by_id[unit['condition_id']] if u['index'] < unit['index']],
                       'sentence': unit['text'], 'atomic_claims': None, 'speech_act': None, 'notes': None,
                       'rater_id': None, 'status': 'unrated'})
        key.append({'review_id': uid, 'sentence_id': unit['id'], 'style_id': unit['style_id']})
    write_json(OUT / 'team-review-packet.json', packet)
    write_json(OUT / 'team-review-key.json', key)
    print(json.dumps(result,ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('prepare','analyze'))
    args = parser.parse_args()
    prepare() if args.action == 'prepare' else analyze()
