"""Download the explicit public-source allowlist and record immutable provenance.

No repository clone, upstream import, secret file, API inference or patient data.
Existing snapshots are checked and reused; changed remote content is not overwritten.
"""
from __future__ import annotations

import concurrent.futures
from datetime import datetime, timezone
from html.parser import HTMLParser
import io
import json
from pathlib import Path
import shutil
import subprocess
import urllib.request
import xml.etree.ElementTree as ET

from common import ROOT, digest, write_json


class TextExtractor(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []
        self.hidden = 0

    def handle_starttag(self, tag, attrs):
        if tag in {"script", "style"}:
            self.hidden += 1
        if tag in {"p", "div", "tr", "li", "h1", "h2", "h3", "section", "br"}:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in {"script", "style"}:
            self.hidden = max(0, self.hidden - 1)
        if tag in {"p", "tr", "li", "h1", "h2", "h3"}:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self.hidden:
            self.parts.append(data)


def extract(data: bytes, kind: str) -> str:
    if kind == "pdf":
        if not data.startswith(b"%PDF"):
            raise ValueError("PDF URL did not return PDF bytes")
        executable = shutil.which("pdftotext")
        if executable:
            result = subprocess.run([executable, "-layout", "-", "-"], input=data,
                                    capture_output=True, check=True)
            return result.stdout.decode("utf-8")
        from pypdf import PdfReader
        return "\n\f\n".join(p.extract_text() or "" for p in PdfReader(io.BytesIO(data)).pages)
    if kind == "html":
        parser = TextExtractor()
        parser.feed(data.decode("utf-8"))
        return "\n".join(" ".join(x.split()) for x in "".join(parser.parts).splitlines() if x.strip())
    if kind == "xml":
        root = ET.fromstring(data)
        return "\n".join(" ".join(" ".join(x.itertext()).split())
                         for x in root.iter() if x.tag in {"article-title", "title", "p"})
    return data.decode("utf-8")


def fetch_one(item: dict, repositories: dict, old: dict) -> dict:
    record = dict(item)
    if "repository_id" in item:
        repo = repositories[item["repository_id"]]
        path = Path(item["path"])
        if any(part.startswith(".env") for part in path.parts):
            raise ValueError("Secret configuration files are outside the source allowlist")
        record.update(repository=repo["repository"], commit=repo["commit"])
        record["url"] = f'https://raw.githubusercontent.com/{repo["repository"]}/{repo["commit"]}/{item["path"]}'
        record["citation_url"] = f'https://github.com/{repo["repository"]}/blob/{repo["commit"]}/{item["path"]}'
    else:
        record["citation_url"] = item["url"]
    previous = old.get(item["id"])
    try:
        if previous and previous.get("local_raw") and previous.get("sha256"):
            for key, hash_key in [("local_raw", "sha256"), ("local_text", "text_sha256")]:
                if digest((ROOT / previous[key]).read_bytes()) != previous[hash_key]:
                    raise ValueError(f"Existing local snapshot failed integrity check: {key}")
            if previous["url"] != record["url"]:
                raise ValueError("Source URL changed; explicit version review required")
            if previous.get("status") == "ok":
                return previous
            # A prior integrity/version failure must never remove the hash lock.
            raise ValueError("Previously locked source needs explicit review; no automatic replacement")
        request = urllib.request.Request(record["url"], headers={"User-Agent": "PatientPersonaResearchAudit/0.1"})
        with urllib.request.urlopen(request, timeout=45) as response:
            data = response.read(15_000_001)
            record.update(http_status=response.status, final_url=response.url,
                          content_type=response.headers.get("Content-Type"))
        if len(data) > 15_000_000:
            raise ValueError("Source exceeds 15 MB research snapshot limit")
        text = extract(data, item["kind"])
        if not text.strip() or (item["kind"] == "text" and "<!DOCTYPE html" in text[:200]):
            raise ValueError("Empty or unexpected source content")
        raw_suffix = {"pdf": ".pdf", "html": ".html", "xml": ".xml"}.get(item["kind"], ".txt")
        raw_path = Path("evidence/snapshots") / (item["id"] + raw_suffix)
        text_path = Path("evidence/snapshots") / (item["id"] + ".txt")
        (ROOT / raw_path).parent.mkdir(parents=True, exist_ok=True)
        (ROOT / raw_path).write_bytes(data)
        if raw_path != text_path:
            (ROOT / text_path).write_text(text, encoding="utf-8")
        record.update(status="ok", bytes=len(data), sha256=digest(data),
                      local_raw=str(raw_path), local_text=str(text_path),
                      text_sha256=digest((ROOT / text_path).read_bytes()),
                      retrieved_at_utc=datetime.now(timezone.utc).isoformat())
    except Exception as error:
        if previous and previous.get("sha256"):
            attempted_url = record["url"]
            record = dict(previous)
            record["attempted_url"] = attempted_url
        record.update(status="error", error_type=type(error).__name__, error=str(error))
    return record


def main():
    config = json.loads((ROOT / "config/sources.json").read_text())
    lock_path = ROOT / "evidence/source-lock.json"
    old = {}
    if lock_path.exists():
        old = {x["id"]: x for x in json.loads(lock_path.read_text())["sources"]}
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
        futures = [pool.submit(fetch_one, item, config["repositories"], old) for item in config["sources"]]
        records = [future.result() for future in futures]
    write_json(lock_path, {"study_date": config["study_date"], "repositories": config["repositories"], "sources": records})
    for record in records:
        print(f'{record["id"]}: {record["status"]}' + (f' ({record["error"]})' if record["status"] == "error" else ""))
    failures = [x for x in records if x["status"] != "ok"]
    print(f"Snapshot summary: {len(records) - len(failures)}/{len(records)} verified")
    return 1 if failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
