"""Three-page Korean disclosure comparison report from frozen local outputs."""
import argparse
from decimal import Decimal,ROUND_HALF_UP
from docx import Document
from docx.shared import Pt

from build_integrated_report import font,paragraph,heading,table
from build_two_feature_report import configure
from build_role_audit_report import reference
from common import ROOT,digest,write_json
from disclosure_comparison import OUT,SPEC,FOLDER,read

SHARE=ROOT/'share/disclosure-comparison-v02'
OUTPUT=SHARE/'페르소나 정보 공개와 거절 표현 비교 보고서.docx'
LABELS={'neutral':'무지시','brief':'단순 간결함','skeptic_only':'단순 의심 표현',
        'psi_reserved':'PATIENT-Ψ reserved','sim_distrust':'PatientSim distrust'}


def one_decimal(value):
    return str(Decimal(str(value)).quantize(Decimal('0.1'),rounding=ROUND_HALF_UP))


def main(replace=False):
    if OUTPUT.exists() and not replace:
        raise ValueError('Use --replace only for this generated report')
    result=read(OUT/'results.json')
    audit=read(OUT/'reference-audit.json')
    assert result['completed_replies']==40
    summaries={s['arm']:s for s in result['summaries']}
    audited={s['arm']:s for s in audit['supplemental_summaries']}
    doc=Document()
    configure(doc)
    doc.core_properties.title='페르소나의 정보 공개와 거절 표현 비교'
    doc.core_properties.subject='간결함과 정보 생략 및 거절 문구를 분리한 로컬 통제 실험'
    doc.core_properties.author='연구팀'
    doc.core_properties.comments=''
    p=doc.add_paragraph('페르소나의 정보 공개와 거절 표현 비교',style='Title')
    p.paragraph_format.line_spacing=Pt(25)
    p.paragraph_format.space_after=Pt(7)
    for run in p.runs:
        font(run,18,True)
    paragraph(doc,'새 허구 사례의 영어 첫 응답 40개  동일 Qwen 기반의 지시 모듈 비교',bold=True)

    heading(doc,'무엇을 알아보려 했나')
    paragraph(doc,'경계적이거나 의심 많은 페르소나가 정말 정보를 덜 말하는지, 아니면 말투만 달라지는지 확인하고자 했다. 짧은 답변·정보 표식의 생략·명시적인 비공개 표현은 서로 다르므로 각각 측정했다. 이 구분은 기존 페르소나의 이름을 임상 특징으로 곧바로 받아들이지 않고 실제 발화 행동을 비교하기 위한 것이다.')
    paragraph(doc,(OUT/'headline.ko.md').read_text().strip())

    heading(doc,'어떻게 비교했나')
    paragraph(doc,'새 허구 인물 Elise와 Damon에게 행사 정보 3개와 개인 청구서 정보 3개를 주었다. 행사에서는 장소·입장료·좌석 수, 청구서에서는 서비스 종류·미납액·연체 일수를 모두 질문했다. 두 질문의 순서 2종과 seed 2개를 완전히 교차했고, 무지시·단순 간결함·단순 의심 표현·PATIENT-Ψ reserved·PatientSim distrust의 5조건을 비교했다. 총 8개 대응 묶음, 조건당 8응답이다.')
    paragraph(doc,'단순 간결함은 Give brief, concise answers, 단순 의심 표현은 Express distrust or skepticism toward the interviewer로 설정했다. reserved의 원문 3문장 상한만 제거하고 나머지 지시는 보존했다. distrust는 personality 원문 그대로다. 두 소스의 이 지시를 같은 임상 특성이나 동일한 묶음으로 가정하지 않았다. 공통 문장 수 제한 없이 Qwen3-14B Q4_K_M, 온도 0.6, 최대 512 생성 토큰을 고정했다.[1,2]')

    heading(doc,'정보 표식과 비공개 표현의 전체 결과')
    table(doc,['지시 조건','개인 정보','행사 정보','평균 단어'],[
        [LABELS[a],f"{summaries[a]['personal_references']}/24",f"{summaries[a]['event_references']}/24",
         one_decimal(summaries[a]['mean_words'])] for a in LABELS],
         [2.6,1.45,1.45,1.5],numeric=(1,2,3))
    paragraph(doc,'정보는 응답당 영역별 3개 표현의 인식 여부다. 고정된 별칭 목록으로 세었으며, 사실의 정확성이나 누락의 의도는 판정하지 않았다. 사전 비공개 문구 규칙은 모든 조건에서 0/8이었지만 원문 점검에서 표현 누락이 발견돼, 실제 거절 표현의 부재로 해석하지 않았다. 원래 규칙과 점수는 보존했다.',small=True)

    doc.add_page_break()
    heading(doc,'생성 전에 정한 두 비교의 결과')
    pairs=[('psi_reserved_minus_brief','reserved − 단순 간결함'),('sim_distrust_minus_skeptic_only','distrust − 단순 의심 표현')]
    table(doc,['대응 비교','개인 표식 차이','고정 문구 차이','단어 수 차이'],[
        [label,f"{result['contrasts'][name]['personal_refs']['mean_difference']:+.3f}개",
         f"{100*result['contrasts'][name]['nondisclosure']['mean_difference']:+.1f}%p",
         f"{result['contrasts'][name]['word_count']['mean_difference']:+.1f}"] for name,label in pairs],
        [2.75,1.45,1.45,1.35],numeric=(1,2,3))
    paragraph(doc,'같은 인물·질문 순서·seed에서 뺀 뒤 8개 묶음에 동일 가중치를 주었다. 개인 표식 차이는 응답당 0–3개 중 차이다. 고정 문구 차이는 좁은 사전 비공개 패턴의 인식 비율 차이이며, 불완전한 검출 범위 때문에 전체 거절 행동의 비교에 쓰지 않는다. 사전 두 비교를 모두 보고했다.',small=True)
    for name,label in pairs:
        c=result['contrasts'][name]['personal_refs']
        passed=result['consistency'][name]['negative_in_both_cases_and_orders']
        paragraph(doc,f"{label}: 개인 표식 차이는 Elise {c['by_case']['DC1']:+.2f}개, Damon {c['by_case']['DC2']:+.2f}개였다. 행사 우선에서는 {c['by_order']['event_first']:+.2f}개, 개인 질문 우선에서는 {c['by_order']['personal_first']:+.2f}개였다. 두 인물과 두 순서의 평균이 모두 음수라는 기술적 일관성 조건은 {'충족했다' if passed else '충족하지 못했다'}. 이는 임상 문턱값이나 유의성 검정이 아니다.")

    heading(doc,'질문 순서와 표현을 분리해서 보았다')
    table(doc,['지시 조건','행사 우선 개인 표식','개인 우선 개인 표식','요구 도전 문구'],[
        [LABELS[a],f"{summaries[a]['personal_by_order']['event_first']}/12",
         f"{summaries[a]['personal_by_order']['personal_first']}/12",
         f"{audited[a]['audited_request_challenge_replies']}/8"] for a in LABELS],
        [2.35,1.65,1.65,1.35],numeric=(1,2,3))
    paragraph(doc,'각 순서는 인물 2개 × seed 2개의 4응답이므로 표식 분모는 12다. 요구 도전 문구는 왜 필요한가·왜 묻는가·왜 관심을 갖는가처럼 정보 요청을 따지는 실제 구간을 어시스턴트가 사후 대조한 보조 집계다. 사전 의심 규칙은 단순 의심 조건에서 1/8만 인식했지만 원문에는 이 구간이 6/8 있었다. 따라서 원래 패턴 수치로 의심의 강도를 비교하지 않는다.',small=True)
    paragraph(doc,f"distrust의 요구 도전 문구 8응답 중 {audited['sim_distrust']['challenge_with_all_personal']}개는 개인 표식 3개를 모두, {audited['sim_distrust']['challenge_with_all_six']}개는 행사까지 포함한 6개를 모두 언급했다. 단순 의심 조건은 해당 문구 6응답 모두 6개 표식을 언급했다. 표현의 존재와 정보 전달을 분리해야 한다는 구체적 관찰이다.")

    doc.add_page_break()
    heading(doc,'원문과 자동 측정값을 대조했다')
    paragraph(doc,audit['report_paragraph'])
    for example in audit['report_examples']:
        paragraph(doc,example['label'],bold=True)
        paragraph(doc,example['quote'],small=True)
        paragraph(doc,example['interpretation'])
    heading(doc,'이번 결과의 의미와 다음 단계')
    paragraph(doc,'reserved는 간결함 대조군보다 개인 표식을 응답당 평균 1.375개 적게 언급했고, 두 사례·두 순서에서 같은 방향이었다. 행사 표식도 24개에서 17개로 감소해 개인 정보만 선택적으로 보호했다고 볼 수 없다. 짧은 표현·전체 질문에 대한 경계·불확실한 근사화가 함께 관찰됐다.')
    paragraph(doc,'distrust는 개인 표식이 평균 0.625개 적었지만 행사 우선에서는 차이가 없어 사전 일관성 조건을 충족하지 못했다. 정보를 말하면서도 요청 목적을 따졌다. 따라서 답변 길이·정확한 표식·불확실한 근사값·질문 목적을 따지는 표현을 별도 feature로 유지한다. 좁은 문구 검출을 임상적 경계심 점수로 확대하지 않는다.')
    paragraph(doc,'정보 공개 축의 첫 공통 비교는 여기서 마무리한다. 다음에는 이미 생성한 tangent 발화를 재사용해 질문과 주제 유지 측정의 적용 범위를 점검한다. 추가 대규모 생성이나 이번 결과에 맞춘 지시 수정은 하지 않는다.')
    heading(doc,'검증과 재현 자료',2)
    max_tokens=max(r['output_tokens'] for r in read(OUT/'response-metrics.json'))
    paragraph(doc,f"40응답 모두 정상 종료했고 최대 출력은 {max_tokens}/512토큰이었다. 입력·별칭·규칙·질문 순서·seed·분석 코드 해시는 생성 전에 저장했다. 구현 점검용 예문 40개는 독립 검증 표본이 아니다. 독립 사람 평가나 임상 등급은 만들지 않았다. 두 허구 인물의 사건·청구서라는 제한된 과제이며, 임상적 경계심이나 원형 앱 전체의 성능 순위로 해석하지 않는다.")
    cost=result['cost']
    paragraph(doc,f"로컬 생성 {cost['wall_seconds']/60:.1f}분  입력 {cost['input_tokens']:,}토큰  출력 {cost['output_tokens']:,}토큰. 유료 API·별도 자동 LLM judge·새 모델 다운로드 0회. 이 수치는 로컬 생성량이며, 이 대화의 구독 토큰 사용량은 아니다.",small=True)
    paragraph(doc,'계획·요청·원문  pilot/runs/disclosure-comparison-v02\n측정값·전체 대화  analysis/disclosure-comparison-v02\n재분석  python3 scripts/disclosure_comparison.py analyze\n검증  python3 scripts/verify_disclosure_comparison.py --report',small=True)
    for index,source in enumerate(result['plan']['source_provenance'],1):
        reference(doc,f"[{index}] {source['id']}  고정 commit {source['commit'][:12]}",source['citation_url'])
    SHARE.mkdir(parents=True,exist_ok=True)
    doc.save(OUTPUT)
    files=[OUT/'results.json',OUT/'reference-audit.json',OUT/'headline.ko.md',OUT/'interpretation.ko.md',SPEC]
    write_json(SHARE/'report-inputs.json',{'inputs':{str(p.relative_to(ROOT)):digest(p.read_bytes()) for p in files},
                                        'output_sha256':digest(OUTPUT.read_bytes())})
    print(str(OUTPUT))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--replace',action='store_true')
    main(parser.parse_args().replace)
