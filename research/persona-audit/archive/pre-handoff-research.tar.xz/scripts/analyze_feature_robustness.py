"""Offline descriptive sensitivity and source-to-observation audit. No LLM calls.

First execution may run the already available OS embedding on alternative sentence
chunks. Subsequent executions verify and reuse that cache. No asset requests.
"""
from __future__ import annotations
import argparse
from collections import defaultdict
import csv
from itertools import combinations
import json
import math
from pathlib import Path
import re
import statistics
import subprocess
import tempfile

from common import ROOT, digest, read_source, source_records, write_json
from extract_automatic_features import adjacent, centroid, cosine, load_verified, mean, measure, slope, text_id, STYLES


def regex_sentences(text):
    normalized = re.sub(r"\.{2,}|…+", " ", text.strip())
    return [s.strip() for s in re.split(r'''[.!?]+["”’']*(?:\s+|$)''', normalized)
            if re.search(r"[A-Za-z0-9]", s)]


def fixed_two_minimum(scores):
    """Expected min of two observed edges sampled uniformly without replacement."""
    if len(scores) < 2 or any(x is None for x in scores):
        return None
    return mean([min(a, b) for a, b in combinations(scores, 2)])


def relative_length(a, b):
    return abs(a-b)/((a+b)/2) if a+b > 0 else None


def select_length_pairs(pairs, rule, tolerance):
    if rule not in {"words_only", "sentences_only", "words_and_sentences"}:
        raise ValueError("Unknown matching rule")
    selected = []
    for a, b in pairs:
        equal = a["features"]["sentence_count"] == b["features"]["sentence_count"]
        distance = relative_length(a["features"]["word_count"], b["features"]["word_count"])
        close = distance is not None and distance <= tolerance
        if (rule == "words_only" and close) or (rule == "sentences_only" and equal) or (rule == "words_and_sentences" and close and equal):
            selected.append((a, b))
    return selected


def paired_rows(rows, style):
    index = {(r["style_id"], r["profile_id"], r["repeat_index"], r["turn"]): r for r in rows}
    pairs = []
    for row in rows:
        if row["style_id"] != style:
            continue
        base = index.get(("plain", row["profile_id"], row["repeat_index"], row["turn"]))
        if base is None:
            raise ValueError("Missing original matched reference")
        pairs.append((row, base))
    return pairs


def contrast(pairs, feature):
    blocks = defaultdict(list)
    details = []
    for row, base in pairs:
        a, b = row["features"].get(feature), base["features"].get(feature)
        if a is None or b is None:
            continue
        difference = a-b
        key = (row["profile_id"], row["repeat_index"])
        blocks[key].append(difference)
        details.append({"condition_id": row["condition_id"], "reference_id": base["condition_id"],
                        "profile_id": key[0], "repeat_index": key[1], "turn": row["turn"],
                        "difference": difference})
    block_values = [{"profile_id": p, "repeat_index": r, "eligible_pairs": len(v), "difference": mean(v)}
                    for (p, r), v in sorted(blocks.items())]
    return {"feature": feature, "eligible_response_pairs": len(details), "eligible_blocks": len(block_values),
            "block_weighted_difference": mean([v["difference"] for v in block_values]),
            "response_weighted_difference": mean([v["difference"] for v in details]),
            "negative_blocks": sum(v["difference"] < 0 for v in block_values),
            "positive_blocks": sum(v["difference"] > 0 for v in block_values),
            "blocks": block_values, "pairs": details}


def solve_least_squares(x, y):
    """Small full-rank least squares; no standard errors or hypothesis tests."""
    if not x or len(x) != len(y):
        raise ValueError("Invalid regression rows")
    p = len(x[0])
    if any(len(row) != p for row in x) or len(x) < p:
        raise ValueError("Insufficient rows")
    matrix = [[sum(row[i]*row[j] for row in x) for j in range(p)] +
              [sum(row[i]*target for row, target in zip(x, y))] for i in range(p)]
    for i in range(p):
        pivot = max(range(i, p), key=lambda k: abs(matrix[k][i]))
        if abs(matrix[pivot][i]) < 1e-10:
            raise ValueError("Rank-deficient sensitivity regression")
        matrix[i], matrix[pivot] = matrix[pivot], matrix[i]
        scale = matrix[i][i]
        matrix[i] = [v/scale for v in matrix[i]]
        for j in range(p):
            if j != i:
                scale = matrix[j][i]
                matrix[j] = [a-scale*b for a, b in zip(matrix[j], matrix[i])]
    coefficients = [row[-1] for row in matrix]
    residuals = [target-sum(a*b for a, b in zip(row, coefficients)) for row, target in zip(x, y)]
    return {"coefficients": coefficients, "n": len(x), "residual_sum_squares": sum(v*v for v in residuals)}


def alternate_vectors(records, folder, cached_only=False):
    segments = {text_id(s): s for r in records for s in regex_sentences(r["response_text"])}
    inputs = [{"id": k, "text": v} for k, v in sorted(segments.items())]
    swift = ROOT / "scripts/NativeFeatures.swift"
    key = digest(json.dumps({"inputs": inputs, "swift": digest(swift.read_bytes())}, sort_keys=True).encode())
    output, metadata = folder/"alternative-native-output.json", folder/"alternative-cache.json"
    if output.exists() and metadata.exists():
        prior = json.loads(metadata.read_text())
        if prior["key"] != key or prior["sha256"] != digest(output.read_bytes()):
            raise ValueError("Alternative cache mismatch; do not silently replace")
    else:
        if cached_only:
            raise ValueError("Alternative embedding cache required by --cached-only")
        write_json(folder/"alternative-native-input.json", inputs)
        with tempfile.TemporaryDirectory(prefix="persona-robustness-swift-") as tmp:
            binary = str(Path(tmp)/"native-features")
            subprocess.run(["/usr/bin/swiftc", "-module-cache-path", str(Path(tmp)/"modules"),
                            str(swift), "-o", binary], check=True, capture_output=True)
            subprocess.run([binary, str(folder/"alternative-native-input.json"), str(output)], check=True, capture_output=True)
        write_json(metadata, {"key": key, "sha256": digest(output.read_bytes()), "text_chunks": len(inputs),
                              "note": "Local OS embeddings only; not new patient responses or an independent embedding model"})
    result = json.loads(output.read_text())
    if result["embeddingRevision"] != 1 or result["embeddingDimension"] != 512:
        raise ValueError("Unexpected alternative embedding backend")
    return {r["id"]: r["vector"] for r in result["records"]}


def measurements(row, native, alternate):
    answer = native[text_id(row["response_text"])]
    vectors = [s.get("vector") for s in answer["sentences"]]
    q = centroid([s.get("vector") for s in native[text_id(row["interviewer_text"])]["sentences"]])
    topic = native[text_id(row["situation"])]["vector"]
    question_scores = [cosine(v, q) for v in vectors]
    topic_scores = [cosine(v, topic) for v in vectors]
    edges = adjacent(vectors)
    alt_sentences = regex_sentences(row["response_text"])
    alt = [alternate[text_id(s)] for s in alt_sentences]
    alt_edges = adjacent(alt)
    alt_valid = [v for v in alt_edges if v is not None]
    alt_center = centroid(alt)
    features = {
        "first_pair_cos": edges[0] if edges else None,
        "last_pair_cos": edges[-1] if edges else None,
        "fixed_two_edge_minimum": fixed_two_minimum(edges),
        "question_sentence_cos_slope": slope(question_scores),
        "question_last_minus_first_cos": question_scores[-1]-question_scores[0] if len(question_scores) >= 2 and all(v is not None for v in question_scores) else None,
        "topic_last_minus_first_cos": topic_scores[-1]-topic_scores[0] if len(topic_scores) >= 2 and all(v is not None for v in topic_scores) else None,
        "regex_sentence_count": len(alt),
        "regex_adjacent_cos_mean": mean(alt_edges),
        "regex_adjacent_cos_min": min(alt_valid) if alt_valid else None,
        "regex_adjacent_cos_sd": statistics.pstdev(alt_valid) if len(alt_valid) >= 2 else None,
        "regex_topic_answer_cos": cosine(alt_center, topic),
        "regex_question_answer_cos": cosine(alt_center, q),
        "regex_topic_cos_slope": slope([cosine(v, topic) for v in alt]),
    }
    trajectory = {"condition_id": row["condition_id"], "turn": row["turn"], "style_id": row["style_id"],
                  "sentences": [{"text": s["text"], "question_cos": qc, "topic_cos": tc}
                                for s, qc, tc in zip(answer["sentences"], question_scores, topic_scores)],
                  "regex_segments": alt_sentences}
    return features, trajectory


# These are source-interpretation metadata, not ratings of generated patients.
# Nonempty feature lists deliberately mean partial numeric proxies, not validation.
CLAUSE_MAP = {
    "upset": [([], "anger/resistance", "감정·저항의 의미와 상호작용을 직접 측정하지 않음"),
              ([], "dismissal", "제안 거절 여부를 직접 측정하지 않음"),
              ([], "trust/alliance", "신뢰·치료적 동맹을 직접 측정하지 않음"),
              ([], "argument/frustration", "논쟁·좌절을 직접 측정하지 않음")],
    "verbose": [(["word_count", "sentence_count"], "detailed responses", "양은 측정하지만 정보의 상세함이나 질문 적합성은 판정하지 않음"),
                (["word_count", "mean_sentence_words"], "extensive elaboration", "발화량의 부분 대리값이며 경험·감정의 풍부함은 아님"),
                ([], "difficulty allowing guidance", "치료자 주도권에 대한 상호작용 지표가 없음")],
    "reserved": [(["word_count", "sentence_count"], "brief/vague/evasive answers", "짧음만 측정; 모호함·회피를 판정하지 않음"),
                 ([], "reluctance to disclose", "자기개방 또는 의도적 비공개를 직접 측정하지 않음"),
                 ([], "need for encouragement", "추가 격려를 조작한 조건이 없어 검증 불가"),
                 ([], "distrust/skepticism", "불신·회의를 직접 측정하지 않음")],
    "tangent": [(["question_answer_cos", "question_sentence_cos_slope", "question_last_minus_first_cos"], "veer away from question", "질문 유사도의 부분 대리값; 무관한 주제인지 또는 임상적 tangentiality인지 판정하지 않음"),
                (["question_last_minus_first_cos", "question_sentence_cos_slope"], "do not return within turn", "연속적 시작–끝 변화만 측정; 주제 이탈 후 복귀 사건을 판정하지 않음"),
                (["question_answer_cos"], "irrelevant experiences", "질문 유사도는 관련성의 참값이 아니며 임베딩이 놓치는 관계가 있음"),
                (["topic_answer_cos"], "need for redirection", "T3 수치 변화는 질문·턴·이력이 함께 변하므로 재지시의 인과효과가 아님")],
    "pleasing": [([], "downplay concerns", "증상 축소 또는 자기제시 전략을 직접 측정하지 않음"),
                 ([], "avoid disagreement", "동의·반대의 의미를 직접 측정하지 않음"),
                 ([], "seek approval", "승인 추구를 직접 측정하지 않음"),
                 ([], "agree readily", "동의 표현과 실제 이해·믿음의 차이를 판정하지 않음")]
}


def audit_prompt_sources(cases, rows):
    source = read_source("psi_styles")
    formatter = read_source("psi_formatter")
    records = source_records()
    main = source.split("export const patientTypeDescriptions")[0]
    entries = dict(re.findall(r'type:\s*"(\w+)",\s*content:\s*"([^"\n]*)"', main))
    if set(entries) != set(STYLES):
        raise ValueError("Unexpected style source structure")
    claims, instructions = [], []
    for style in STYLES:
        content = entries[style]
        style_cases = [c for c in cases if c["style_id"] == style]
        if any(content not in c["system_prompt"] for c in style_cases):
            raise ValueError("Source style not present in actual run prompt")
        cap = re.search(r"must not exceed (\d+) sentences each turn", content)
        caps = [int(v) for v in re.findall(r"(?:must not exceed |maximum of )(\d+) sentences", style_cases[0]["system_prompt"])]
        instruction = {"style": style, "style_sentence_cap": int(cap[1]) if cap else None,
                       "global_sentence_cap": 5, "actual_prompt_caps": caps,
                       "unequal_caps_in_prompt": len(set(caps)) > 1,
                       "permissive_mixed_turns": "in some turns" in content,
                       "scripted_trust_or_session_change": "as the session goes" in content,
                       "style_source_line": source[:source.index(f'type: "{style}"')].count("\n")+1,
                       "source_id": "psi_styles", "source_sha256": records["psi_styles"]["sha256"]}
        if "maximum of 5 sentences" not in formatter or caps[-1] != 5:
            raise ValueError("Common 5-sentence cap changed")
        style_rows = [r for r in rows if r["style_id"] == style]
        for method, key in [("OS", "sentence_count"), ("regex", "regex_sentence_count")]:
            for label, limit in [("global", 5), ("style", instruction["style_sentence_cap"]),
                                 ("strictest_stated", min(caps))]:
                instruction[f"{method}_{label}_above_cap"] = sum(r["features"][key] > limit for r in style_rows) if limit else None
        instruction["responses"] = len(style_rows)
        instructions.append(instruction)
        pieces = re.findall(r"\d\)\s*(.*?)(?=,?\s*\d\)|\. But you|$)", content.split("But you")[0]) if content else []
        metadata = CLAUSE_MAP.get(style, [])
        if len(pieces) != len(metadata):
            raise ValueError(f"Unexpected numbered clause count: {style}: {len(pieces)}")
        for i, (piece, (features, concept, boundary)) in enumerate(zip(pieces, metadata), 1):
            claims.append({"claim_id": f"{style}-{i}", "style": style, "source_clause": piece.strip(" ,."),
                           "source_id": "psi_styles", "line": instruction["style_source_line"],
                           "operational_target": concept, "numeric_proxies": features,
                           "coverage": "partial_proxy_only" if features else "not_directly_measured",
                           "limitation_ko": boundary, "clinical_validated": False})
    return {"source_commit": cases[0]["source_commit"], "numbered_behavioral_claims": len(claims),
            "partially_proxied": sum(bool(c["numeric_proxies"]) for c in claims),
            "not_directly_measured": sum(not c["numeric_proxies"] for c in claims),
            "note": "Coverage of source clauses is a researcher-authored instrument audit, NOT patient/clinical scoring. A partial proxy does not establish fulfillment or failure.",
            "instructions": instructions, "claims": claims,
            "missing_demo_fields": sorted({f for c in cases for f in c["missing_fields"]}),
            "undefined_fields_preserved_in_all_prompts": all("Core Beliefs: undefined" in c["system_prompt"] and
                "Automatic Thoughts: undefined" in c["system_prompt"] and "Intermediate Beliefs during Depression: undefined" in c["system_prompt"] for c in cases),
            "common_prompt_constraints": ["Gradual disclosure", "Maintain profile consistency", "Avoid abrupt or disconnected responses", "Maximum 5 sentences"],
            "text_only_unmeasured": ["actual trust", "authentic emotion", "therapeutic alliance", "clinical thought-disorder severity"]}


def csv_write(path, rows):
    if not rows:
        raise ValueError("Do not export an empty result as observed data")
    with path.open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", default="native-features-20261030")
    parser.add_argument("--cached-only", action="store_true")
    args = parser.parse_args()
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,70}", args.run_id):
        parser.error("Invalid run ID")
    original = ROOT/"analysis/automatic-features-v01"/args.run_id
    folder = ROOT/"analysis/feature-robustness-v01"/args.run_id
    folder.mkdir(parents=True, exist_ok=True)
    plan_path = ROOT/"config/feature-robustness-v01.json"
    plan = json.loads(plan_path.read_text())
    if plan["run_id"] != args.run_id:
        raise ValueError("Run does not match frozen sensitivity specification")
    config, cases, records, sources = load_verified(ROOT/"pilot/runs"/args.run_id)
    features_path = original/"features.jsonl"
    base_rows = [json.loads(line) for line in features_path.read_text().splitlines()]
    if len(records) != 144 or len(base_rows) != 144 or any(r["status"] != "completed" for r in records):
        raise ValueError("Requires the complete original 144-reply corpus")
    native_path = original/"native-output.json"
    native = json.loads(native_path.read_text())
    cache = json.loads((original/"native-cache-key.json").read_text())
    if digest(native_path.read_bytes()) != cache["output_sha256"]:
        raise ValueError("Original embedding cache hash mismatch")
    nlp = {r["id"]: r for r in native["records"]}
    # Recompute all baseline cells, not merely hashes of feature-row identifiers.
    baseline_index = {(r["condition_id"], r["turn"]): r for r in base_rows}
    previous = {}
    for raw in records:
        recomputed, _, center = measure(raw, nlp, previous.get(raw["condition_id"]))
        saved = baseline_index[(raw["condition_id"], raw["turn"])]
        if recomputed["features"] != saved["features"]:
            raise ValueError("Baseline feature values do not reproduce from verified text/vectors")
        previous[raw["condition_id"]] = center
    alternate = alternate_vectors(records, folder, args.cached_only)
    raw_index = {(r["condition_id"], r["turn"]): r for r in records}
    rows, trajectories = [], []
    for row in base_rows:
        row = json.loads(json.dumps(row))
        raw = raw_index[(row["condition_id"], row["turn"])]
        if row["response_sha256"] != raw["response_sha256"] or row["request_sha256"] != raw["request_sha256"]:
            raise ValueError("Feature rows do not match verified raw data")
        extra, trajectory = measurements(raw, nlp, alternate)
        row["features"].update(extra)
        rows.append(row)
        trajectories.append(trajectory)
    pairs = paired_rows(rows, "tangent")
    metric_ids = list(rows[0]["features"])
    full = {style: {f: contrast(paired_rows(rows, style), f) for f in metric_ids} for style in STYLES if style != "plain"}
    stratified = []
    for kind, values in [("situation", sorted({r["profile_id"] for r in rows})), ("turn", [1, 2, 3, 4]), ("repeat", [0, 1])]:
        for value in values:
            field = {"situation": "profile_id", "turn": "turn", "repeat": "repeat_index"}[kind]
            for f in ["adjacent_cos_mean", "topic_answer_cos", "question_answer_cos", "word_count"]:
                stratified.append({"stratum": kind, "value": value, **contrast([(a, b) for a, b in pairs if a[field] == value], f)})
    matching = []
    for tolerance in plan["length_tolerance_grid"]:
        for rule in ["words_only", "sentences_only", "words_and_sentences"]:
            selected = select_length_pairs(pairs, rule, tolerance)
            matching.append({"rule": rule, "relative_word_tolerance": tolerance,
                             "selected_fraction": len(selected)/len(pairs),
                             "results": {f: contrast(selected, f) for f in ["adjacent_cos_mean", "adjacent_cos_min", "topic_answer_cos"]}})
    regressions = {}
    x = [[1, math.log(a["features"]["word_count"]/b["features"]["word_count"]),
          a["features"]["sentence_count"]-b["features"]["sentence_count"]] for a, b in pairs]
    for f in ["adjacent_cos_mean", "adjacent_cos_min", "topic_answer_cos"]:
        y = [a["features"][f]-b["features"][f] for a, b in pairs]
        regressions[f] = {"predictors": ["intercept", "log_word_count_ratio", "sentence_count_difference"],
                          **solve_least_squares(x, y), "unadjusted_mean_difference": mean(y)}
    turns = []
    for style in STYLES:
        for turn in [1, 2, 3, 4]:
            group = [r for r in rows if r["style_id"] == style and r["turn"] == turn]
            turns.append({"style": style, "turn": turn, "responses": len(group),
                          "means": {f: mean([r["features"][f] for r in group]) for f in metric_ids}})
    redirection = []
    for style in STYLES:
        by_turn = {r["turn"]: r for r in turns if r["style"] == style}
        redirection.append({"style": style, "descriptive_T3_minus_T2": {f: by_turn[3]["means"][f]-by_turn[2]["means"][f]
                           for f in ["topic_answer_cos", "question_answer_cos", "adjacent_cos_mean", "word_count"]},
                            "causal_redirection_effect_identifiable": False})
    segmentation = {"changed_sentence_counts": sum(r["features"]["sentence_count"] != r["features"]["regex_sentence_count"] for r in rows),
                    "note": "Alternative = regex v2 sentence segmentation plus removal of ellipses and terminal punctuation. Not a second embedding or a clean boundary-only intervention.",
                    "style_comparisons": {style: {f: contrast(paired_rows(rows, style), f) for f in
                        ["regex_adjacent_cos_mean", "regex_adjacent_cos_min", "regex_topic_answer_cos", "regex_question_answer_cos", "regex_topic_cos_slope"]}
                        for style in STYLES if style != "plain"}}
    audit = audit_prompt_sources(cases, rows)
    result = {"run_id": args.run_id, "plan": plan, "plan_sha256": digest(plan_path.read_bytes()),
              "independent_personas": 1, "responses": len(rows), "dialogues": len(cases), "paired_response_comparisons": len(pairs),
              "contrasts": full, "stratified_tangent_minus_plain": stratified,
              "length_matching": matching, "descriptive_length_adjustment": regressions,
              "style_turn_means": turns, "redirection_descriptive": redirection,
              "segmentation_sensitivity": segmentation,
              "additional_generation_calls": 0, "paid_api_calls": 0, "expert_or_llm_ratings": 0,
              "independent_embedding_backends": 1, "clinical_validation": False}
    write_json(folder/"robustness-results.json", result)
    write_json(folder/"prompt-feature-audit.json", audit)
    write_json(folder/"sentence-trajectories.json", trajectories)
    with (folder/"augmented-features.jsonl").open("w", encoding="utf-8") as file:
        for row in rows:
            file.write(json.dumps(row, ensure_ascii=False)+"\n")
    csv_write(folder/"stratified-contrasts.csv", [{"stratum": r["stratum"], "value": r["value"], "feature": r["feature"],
        "pairs": r["eligible_response_pairs"], "blocks": r["eligible_blocks"], "tangent_minus_plain": r["block_weighted_difference"]} for r in stratified])
    csv_write(folder/"sensitivity-contrasts.csv", [{"style": s, "feature": f, "pairs": c["eligible_response_pairs"],
        "blocks": c["eligible_blocks"], "difference_from_plain": c["block_weighted_difference"], "negative_blocks": c["negative_blocks"]}
        for s, values in full.items() for f, c in values.items()])
    csv_write(folder/"length-matching.csv", [{"rule": r["rule"], "word_tolerance": r["relative_word_tolerance"], "feature": f,
        "pairs": c["eligible_response_pairs"], "blocks": c["eligible_blocks"], "block_weighted_difference": c["block_weighted_difference"],
        "response_weighted_difference": c["response_weighted_difference"]} for r in matching for f, c in r["results"].items()])
    csv_write(folder/"prompt-claims.csv", [{**c, "numeric_proxies": ";".join(c["numeric_proxies"])} for c in audit["claims"]])
    csv_write(folder/"prompt-constraints.csv", audit["instructions"])
    snapshots = [source_records()[s] for s in ["psi_styles", "psi_formatter"]]
    inputs = [features_path, native_path, original/"native-cache-key.json", plan_path,
              ROOT/"pilot/runs"/args.run_id/"conditions.json", ROOT/"pilot/runs"/args.run_id/"run-config.json"]
    write_json(folder/"provenance.json", {"inputs": [{"path": str(p.relative_to(ROOT)), "sha256": digest(p.read_bytes())} for p in inputs],
        "raw_requests_and_responses": sources, "upstream_sources": snapshots,
        "analysis_code_sha256": digest(Path(__file__).read_bytes()),
        "baseline_17_feature_cells_preserved": all(all(a["features"][f] == b["features"][f] for f in a["features"]) for a, b in zip(base_rows, rows)),
        "actual_history_verified_responses": len(records)})
    head = full["tangent"]
    print(json.dumps({"output": str(folder), "original_delta": head["adjacent_cos_mean"]["block_weighted_difference"],
        "regex_delta": head["regex_adjacent_cos_mean"]["block_weighted_difference"],
        "first_pair_delta": head["first_pair_cos"]["block_weighted_difference"],
        "last_pair_delta": head["last_pair_cos"]["block_weighted_difference"],
        "length_adjusted_descriptive_intercept": regressions["adjacent_cos_mean"]["coefficients"][0],
        "clauses": audit["numbered_behavioral_claims"], "partial_proxies": audit["partially_proxied"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
