"""Korean single-field-ablation report and portable offline reproduction bundle."""
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import zipfile

from common import ROOT, digest, write_json
from analyze_thought_alias_ablation import RUN, NATIVE, ALIAS, STYLES


def n(value, digits=3, signed=True):
    return "NA" if value is None else (f"{value:+.{digits}f}" if signed else f"{value:.{digits}f}")


def report(folder, result):
    primary = result["primary_T1_by_style"]
    whole = result["whole_dialogue_all_features"]
    style_effects = result["style_contrasts_by_arm"]
    replay = result["historical_replay"]
    lines = ["# 단일 필드 전달 실험: automatic thoughts 연결의 영향", "",
        "2026-10-30 · PATIENT-Ψ prompt port / Qwen3-14B · 원형 대조군도 새로 생성 · 임상 채점 없음", "",
        "## 핵심 결과", "",
        f"한 필드의 전달 누락을 수정했지만 출력의 대상 문구 유사도가 일률적으로 증가하지 않았다. 첫 턴 수정−원형 차이는 "
        f"plain {n(primary['plain']['alias_minus_native'])} (증가 {primary['plain']['positive_pairs']}/6), "
        f"tangent {n(primary['tangent']['alias_minus_native'])} (증가 {primary['tangent']['positive_pairs']}/6)였다. "
        f"네 턴 평균에서는 각각 {n(whole['plain']['provided_thought_cos']['alias_minus_native'])}, "
        f"{n(whole['tangent']['provided_thought_cos']['alias_minus_native'])}였고 plain도 평균은 양수지만 증가한 블록은 "
        f"{whole['plain']['provided_thought_cos']['positive_pairs']}/6개였다. **입력 전달의 수정과 관찰 지표의 일괄적인 향상은 같은 일이 아니었다.**", "",
        "또한 스타일 사이의 인접 유사도 격차 변화는 어느 쪽이 움직였는지 분해해야 했다. 대상 문구 유사도·발화 구조·임상 충실도를 서로 같은 점수로 합치지 않는 것이 이번 결과의 핵심이다.", "",
        "## 1. 이번에 바꾼 것은 정확히 하나", "",
        "공개 demo에는 `auto_thought`가 있지만 formatter는 `auto_thoughts`를 읽어, 기존 실행에서 Automatic Thoughts에 `undefined`가 들어갔다. "
        "이번 수정 조건은 **기존 `auto_thought`를 `auto_thoughts`로 그대로 연결하는 것만** 바꿨다. "
        "core beliefs·depression-specific intermediate beliefs 두 누락, 스타일 지시, 문장 수 제한, 면담 질문은 바꾸지 않았다. "
        "다른 필드까지 한꺼번에 고친 이전 프로토타입과 구별된다.", "",
        "연구 질문은 ‘이 한 필드의 명시적 전달이 출력의 수치적 특성을 어떻게 바꾸는가’이다. "
        "세 필드 전체를 수리한 실험, 모델 전반의 개선, 실제 환자 사고의 재현 또는 조현병 검증이 아니다.", "",
        "## 2. 실행 설계와 분석 규칙", "",
        "plain/tangent 두 스타일 × 세 상황 × 두 반복 × 원형/단일 연결 수정 두 조건 × 네 턴 = **24개 새 대화·96개 실제 응답**이다. "
        "두 조건 모두 이번에 실행했으며 과거 응답을 대조군으로 대체하지 않았다. 같은 상황·스타일·반복의 두 조건을 묶고 실행 선후를 섞었으며, "
        "각 대화 안에서는 실제 이전 응답을 계속 전달했다. 상황별 자동사고 원문은 공개 예제에 이미 있는 값이다.", "",
        "- 상황 1-1: What if I run out of money?",
        "- 상황 1-2: I should be able to do this on my own.",
        "- 상황 1-3: I should have tried harder.", "",
        "생성 전 분석 규칙을 파일로 고정했다. 다만 이미 조사한 Abe 예제와 개발 상황을 다시 사용한 실험이며, 사전등록이나 새 인물에 대한 확증 실험은 아니다. "
        "스타일당 여섯 대응 블록은 세 상황×두 stochastic seed 반복이지 독립 환자 여섯 명이 아니다.", "",
        "**주 지표는 첫 턴(T1)의 ‘제공된 자동사고 문구–응답 centroid 코사인 유사도’**이다. 응답 문장 벡터를 단위 정규화한 뒤 동일 가중 평균하고, "
        "공개 자동사고 문구 벡터와 비교했다. Apple English embedding revision 1, 512D를 유지했다. "
        "두 조건은 같은 Qwen3-14B digest·양자화·temperature 0.6·top_p 0.95·top_k 20·출력 상한 512·문맥 16384·thinking off를 사용했고 턴별 seed도 짝지었다. "
        "같은 seed가 동일한 생성 잡음이나 재현성을 보장한다고 가정하지 않는다.", "",
        "첫 턴은 누적 환자 응답이 없는 프롬프트 비교다. 네 턴 평균은 수정된 프롬프트에 더해 각 조건의 이전 생성 응답 경로까지 포함한다. "
        "두 결과를 같은 추정 대상으로 합치지 않았다. 기존 17개 feature, 다른 상황의 자동사고 대비 상대 유사도, 자동사고 전체 토큰열의 문자적 출현을 보조 지표로 계산했다.", "",
        "![조건별 대응 변화](thought-alias-profiles.png)", "",
        "선 하나는 같은 상황·반복의 원형→수정 조건이며 독립 환자의 전후 변화가 아니다. 위 패널은 첫 턴의 대상 문구 유사도, 아래는 네 턴 평균 인접 문장 유사도다. "
        "오차막대·임상 점수·유의확률을 표시하지 않았다.", "",
        "## 3. 실제 주 지표 결과", ""]
    for style in STYLES:
        r = primary[style]
        lines += [f"### {style}", "",
            f"첫 턴 대상 문구 유사도는 원형 **{n(r['native_mean'], signed=False)} → 수정 {n(r['alias_mean'], signed=False)}**, "
            f"수정−원형 평균 차이는 **{n(r['alias_minus_native'])}**였다. 증가 {r['positive_pairs']}/6, 감소 {r['negative_pairs']}/6, "
            f"수치상 동일 {r['zero_pairs']}/6이며 대응 차이 범위는 {n(r['min_difference'])}~{n(r['max_difference'])}였다.", ""]
    lines += ["이 코사인 값은 문구의 의미 표현에 가까워진 정도일 뿐, 그 생각을 실제로 믿거나 적절한 정서·행동으로 구현했다는 판정이 아니다. "
        "명시적으로 넣은 문구에 더 가까운 문장을 생성한 것은 입력 민감도 또는 부분적인 프롬프트 충실도의 관찰이며 임상적 개선의 증거가 아니다.", "",
        "## 4. 대화 전체와 다른 feature도 같은 방향인가", ""]
    for style in STYLES:
        value = whole[style]
        literal = result["literal_target_occurrences_out_of_24"][style]
        lines += [f"### {style}: 네 턴 대화 평균", "",
            f"- 대상 문구 유사도 수정−원형: {n(value['provided_thought_cos']['alias_minus_native'])} "
            f"(증가 {value['provided_thought_cos']['positive_pairs']}/6, 감소 {value['provided_thought_cos']['negative_pairs']}/6).",
            f"- 대상 유사도−다른 두 상황 문구의 평균 유사도: 수정−원형 {n(value['thought_cos_specificity']['alias_minus_native'])}.",
            f"- 자동사고 전체 토큰열이 그대로 나타난 응답: 원형 {int(literal[NATIVE])}/24 → 수정 {int(literal[ALIAS])}/24. "
            "이는 전체 토큰열 출현이며 부분 표현·동의어·의역을 검출하지 않는다.",
            f"- 응답당 단어 수 변화: {n(value['word_count']['alias_minus_native'], 1)}단어.",
            f"- 인접 문장 유사도 변화: {n(value['adjacent_cos_mean']['alias_minus_native'])}.",
            f"- 초기 상황–응답 유사도 변화: {n(value['topic_answer_cos']['alias_minus_native'])}.", ""]
    adjacent = style_effects["adjacent_cos_mean"]
    interaction = result["mapping_by_style_interaction"]["adjacent_cos_mean"]["difference_in_style_contrasts"]
    lines += [f"**tangent−plain 인접 유사도 차이**는 원형 {n(adjacent[NATIVE]['tangent_minus_plain'])}, "
        f"수정 조건 {n(adjacent[ALIAS]['tangent_minus_plain'])}였다. 두 스타일 차이의 변화(수정−원형)는 {n(interaction)}이다. "
        "이는 한 예제의 입력 연결×스타일 상호작용을 기술한 것이며 ‘사고장애가 호전되었다’는 의미가 아니다.", "",
        f"격차가 줄어든 것을 tangent의 연결성이 좋아진 것으로 읽어서는 안 된다. tangent 자체의 인접 유사도 변화는 "
        f"{n(whole['tangent']['adjacent_cos_mean']['alias_minus_native'], 6)}로 거의 없었고, plain은 "
        f"{n(whole['plain']['adjacent_cos_mean']['alias_minus_native'])} 변했다. 즉 이번 격차 축소의 대부분은 대조 스타일인 plain의 수치 하락에서 왔다. "
        "이는 종합 점수나 두 조건의 간격만 보면 변화의 원인을 잘못 해석할 수 있음을 보여준다.", "",
        "## 5. 해석에서 구분해야 할 것", "",
        "1. **입력 전달과 임상 타당도는 별개다.** 이번에는 실제 전송된 프롬프트에서 한 필드만 바뀌었음을 대응 대화 12쌍 모두 확인했다. "
        "어떤 출력 지표가 변하든 임상가의 사고장애 판정을 대신하지 않는다.",
        "2. **자동사고 정보가 원형에 완전히 없었다는 뜻은 아니다.** 상황·행동·intermediate beliefs에도 관련 정보가 이미 있으므로 원형 LLM이 비슷한 내용을 추론할 수 있다. "
        "작은 차이나 혼합된 방향은 필드 연결이 일반적으로 불필요하다는 증거가 아니다.",
        "3. **길이와 생성 경로도 달라질 수 있다.** 주 지표는 문장 centroid를 사용하므로 문장 수·내용 분포 변화의 영향을 받는다. "
        "같은 seed는 두 프롬프트 사이의 의미 수준 반사실적 대응을 보장하지 않는다. 후속 턴의 차이는 수정된 입력과 그로부터 생성된 이전 응답의 누적 영향이다.",
        "4. **문자열 수정과 의미 정보 추가를 분리하지 않았다.** 이 실험은 undefined를 제거하면서 실제 자동사고를 넣는 한 필드 교체의 효과다. "
        "빈칸/중립 문구 대조군이 없으므로 해당 토큰 제거 자체의 효과와 내용 추가 효과를 따로 식별할 수 없다.",
        "5. **한 인물·세 개발 상황에 한정된다.** 다른 기반 LLM, 독립 페르소나, 다른 프레임워크나 실제 조현병 환자로 일반화하지 않는다. "
        "여러 보조 feature를 살펴본 결과에서 유리한 값만 골라 성공으로 선언하지 않으며 전체 수치를 제공한다.", "",
        "## 재현과 원자료", "",
        f"과거 원형 실행과 같은 입력을 다시 보낸 {replay['compared_responses']}개 응답 중 요청 해시 일치 {replay['identical_requests']}, "
        f"응답 문자열 완전 일치 {replay['identical_responses']}개였다. 이는 해당 실행의 관찰이며 향후 결정성 보장은 아니다. "
        "연구 비교의 대조군은 이번에 새로 생성한 원형 응답이다.", "",
        f"실제 생성 요청 시간 합계 {result['generation_wall_minutes_sum']:.2f}분, 최대 입력 {result['maximum_input_tokens']}토큰. "
        "유료 API·모델 다운로드·전문가 채점·LLM judge는 0이다. 원문·요청·원시 응답·모델 메타데이터·해시를 보존하고 기존 17개 feature를 캐시에서 재검산했다.", "",
        "- [전체 수치 JSON](results.json), [20개 feature 원자료 CSV](features-flat.csv), [모든 대응 효과 CSV](paired-effects.csv).",
        "- [전체 영어 대화 원문](transcripts.en.md), [입력·이력 검증 기록](provenance.json), [코드·원문·결과 묶음](thought-alias-results-20261030.zip).", "",
        "오프라인 재계산: `python3 scripts/extract_automatic_features.py --run-id thought-alias-20261030` 다음 "
        "`python3 scripts/analyze_thought_alias_ablation.py --cached-only`. 동봉 캐시를 이용하므로 새로운 LLM 추론·Swift 실행·인터넷 없이 재계산할 수 있다. "
        "그림 재생성에는 macOS/Swift가 필요하지만 완성 PNG를 포함한다.", "",
        f"원형 출처(commit {result['source_commit']}): "
        f"[프로필](https://github.com/ruiyiw/patient-psi/blob/{result['source_commit']}/python/data/profiles.json), "
        f"[formatter](https://github.com/ruiyiw/patient-psi/blob/{result['source_commit']}/app/api/getDataFromKV.ts), "
        f"[스타일 지시](https://github.com/ruiyiw/patient-psi/blob/{result['source_commit']}/app/api/data/patient-types.jsx). "
        "현재 최신판이라는 주장은 하지 않는다.", ""]
    (folder/"report.ko.md").write_text("\n".join(lines), encoding="utf-8")


def render(folder, result):
    panel_groups = [("A", "B", "T1: target-thought similarity", "provided_thought_cos", result["first_turn_all_features"]),
                    ("C", "D", "Dialogue mean: adjacent similarity", "adjacent_cos_mean", result["whole_dialogue_all_features"])]
    panels = []
    for first, second, label, feature, data in panel_groups:
        values = [v for s in STYLES for p in data[s][feature]["pairs"] for v in [p["native"], p["alias"]]]
        low, high = max(-1, min(values)-.04), min(1, max(values)+.04)
        for letter, style in zip([first, second], STYLES):
            panels.append({"title": f"{letter}. {style} / {label}", "unit": "Cosine similarity (same scale within each row)",
                           "pairs": [{k: r[k] for k in ["native", "alias"]} for r in data[style][feature]["pairs"]],
                           "low": low, "high": high})
    write_json(folder/"plot-input.json", {"panels": panels,
        "caption": "Source: thought-alias-20261030. Each line is a matched situation/repeat, not a person. Similarity is not clinical validity, diagnosis, or belief endorsement."})
    with tempfile.TemporaryDirectory(prefix="persona-thought-plot-") as tmp:
        binary = str(Path(tmp)/"plot")
        subprocess.run(["/usr/bin/swiftc", "-module-cache-path", str(Path(tmp)/"modules"), str(ROOT/"scripts/PlotThoughtAlias.swift"), "-o", binary], check=True, capture_output=True)
        subprocess.run([binary, str(folder/"plot-input.json"), str(folder/"thought-alias-profiles.png")], check=True, capture_output=True)


def package(folder):
    baseline = ROOT/"analysis/automatic-features-v01/native-features-20261030/automatic-feature-results-20261030.zip"
    with zipfile.ZipFile(baseline) as archive:
        content = {name: archive.read(name) for name in archive.namelist() if not name.endswith("/archive-manifest.json")}
    prefix = "persona-feature-results/"
    paths = []
    for directory in [folder, ROOT/"pilot/runs"/RUN, ROOT/"analysis/automatic-features-v01"/RUN]:
        paths += [p for p in directory.rglob("*") if p.is_file() and p.suffix in {".json", ".jsonl", ".csv", ".md", ".png"}
                  and p.name != "archive-verification.json"]
    paths += [ROOT/"scripts"/name for name in ["run_thought_alias_ablation.py", "analyze_thought_alias_ablation.py", "build_thought_alias_report.py", "PlotThoughtAlias.swift"]]
    paths += [ROOT/"config/thought-alias-ablation-v01.json", ROOT/"tests/test_thought_alias_ablation.py"]
    for path in paths:
        content[prefix+str(path.relative_to(ROOT))] = path.read_bytes()
    content[prefix+"THOUGHT-ALIAS-START-HERE.ko.md"] = (
        "# 단일 필드 연결 실험\n\n"
        f"먼저 `analysis/thought-alias-v01/{RUN}/report.ko.md`를 읽는다. 원형 대조군도 새로 생성한 24대화·96응답 실험이다.\n\n"
        "표준 Python 3.10+에서 다음 명령으로 캐시 기반 오프라인 재계산한다.\n\n"
        f"`python3 scripts/extract_automatic_features.py --run-id {RUN}`\n\n"
        "`python3 scripts/analyze_thought_alias_ablation.py --cached-only`\n\n"
        "과거 원형 실행은 재현성 비교용으로 포함하며 현재 실험의 대조군을 대체하지 않는다. "
        "새 발화 생성을 재계산에 사용하지 않는다. 로컬 전체 테스트 기록과 묶음 내 선택 테스트는 범위가 다르다.\n").encode()
    manifest = {name: digest(data) for name, data in sorted(content.items())}
    content[prefix+"archive-manifest.json"] = json.dumps(manifest, indent=2).encode()
    target = folder/"thought-alias-results-20261030.zip"
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, data in sorted(content.items()):
            archive.writestr(name, data)
    with tempfile.TemporaryDirectory(prefix="persona-thought-offline-") as tmp:
        with zipfile.ZipFile(target) as archive:
            for name, expected in manifest.items():
                if digest(archive.read(name)) != expected:
                    raise ValueError("Bundle hash mismatch")
            archive.extractall(tmp)
        cwd = Path(tmp)/"persona-feature-results"
        commands = [[sys.executable, "scripts/extract_automatic_features.py", "--run-id", RUN],
                    [sys.executable, "scripts/analyze_thought_alias_ablation.py", "--cached-only"],
                    [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-q"]]
        outputs = []
        for command in commands:
            run = subprocess.run(command, cwd=cwd, capture_output=True, text=True)
            if run.returncode:
                raise ValueError("Offline reproduction failed: "+run.stderr)
            outputs.append({"command": command[1:], "stdout": run.stdout[-1500:], "stderr": run.stderr[-1500:]})
        for name in ["results.json", "features-flat.csv", "paired-effects.csv", "transcripts.en.md"]:
            if (cwd/folder.relative_to(ROOT)/name).read_bytes() != (folder/name).read_bytes():
                raise ValueError("Offline result mismatch: "+name)
    write_json(folder/"archive-verification.json", {"sha256": digest(target.read_bytes()), "bytes": target.stat().st_size,
        "files_hashed": len(manifest), "offline_cached_reanalysis": "passed", "exact_result_files_reproduced": 4,
        "new_generation_calls_for_reproduction": 0, "commands": outputs})
    return target


def main():
    folder = ROOT/"analysis/thought-alias-v01"/RUN
    result = json.loads((folder/"results.json").read_text())
    if result["actual_responses"] != 96 or result["actual_dialogues"] != 24:
        raise ValueError("Incomplete experiment")
    render(folder, result)
    report(folder, result)
    tests = subprocess.run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-q"], cwd=ROOT, capture_output=True, text=True)
    write_json(folder/"test-verification.json", {"returncode": tests.returncode, "stdout": tests.stdout, "stderr": tests.stderr})
    if tests.returncode:
        raise ValueError("Local tests failed: "+tests.stderr)
    for link in re.findall(r"\]\(([^)]+)\)", (folder/"report.ko.md").read_text()):
        if "://" not in link and link != "thought-alias-results-20261030.zip" and not (folder/link).is_file():
            raise ValueError("Broken report link: "+link)
    target = package(folder)
    print(json.dumps({"report": str(folder/"report.ko.md"), "archive_bytes": target.stat().st_size,
                      "local_tests": tests.stderr.strip(), "offline_reproduction": "passed"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
