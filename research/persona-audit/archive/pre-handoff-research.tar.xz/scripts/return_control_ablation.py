"""One-clause PSI prompt ablation: 32 free replies plus 32 separate continuations."""
import argparse
from collections import defaultdict
import json
import random
import re
from statistics import mean

from audit_sources import parse_styles
from common import ROOT, digest, read_source, source_records, write_json
from fact_disclosure_probe import match_fact, normalize
from first_reply_probe_runner import run, verify_response
from run_local_pilot import OPTIONS, fingerprint, now
from summarize_local_pilot import text_metrics

SPEC = ROOT / "config/return-control-ablation-v01.json"
RUN = "return-control-ablation-v01"
FOLDER = ROOT / "pilot/runs" / RUN
OUT = ROOT / "analysis" / RUN
ARMS = ("original", "clarified")
MODES = ("free_reply", "continuation_challenge")


def read(path):
    return json.loads(path.read_text())


def freeze(path, value):
    if path.exists():
        if read(path) != value:
            raise ValueError(f"Frozen ablation input changed: {path}")
    else:
        write_json(path, value)


def styles(spec):
    original = parse_styles(read_source("psi_styles"))["tangent"]
    original, count = re.subn(r"But you must not exceed 5 sentences each turn\.\s*", "", original)
    if count != 1 or original.count(spec["source_clause"]) != 1:
        raise ValueError("Unexpected source style structure")
    return {"original": original, "clarified": original.replace(spec["source_clause"], spec["replacement_clause"])}


def conditions():
    spec = read(SPEC)
    variants = styles(spec)
    rng, rows = random.Random(20261031), []
    for mode in MODES:
        blocks = [(case, target, wording, repeat) for case in spec["fictional_cases"] for target in ("A", "B")
                  for wording in spec["question_variants"] for repeat in spec["repeat_indices"]]
        rng.shuffle(blocks)
        for case, target, wording, repeat in blocks:
            group = []
            question = wording["template"].format(event=case["events"][target])
            prefix = case["prefixes"][target] if mode == "continuation_challenge" else ""
            user_text = question if not prefix else (
                "The interviewer asked: " + question + "\n"
                "The person's reply has already begun with this researcher-supplied prefix:\n"
                "<reply_prefix>" + prefix + "</reply_prefix>\n"
                "Continue the same reply after that prefix. Output only the continuation, without repeating the prefix or explaining the task.")
            for arm in ARMS:
                prompt = (f"You are {case['name']}, a fictional adult. This is a simulation, not a real patient or diagnosis.\n"
                          "The following events occurred on different days. No causal connection between them is specified.\n"
                          + "\n".join(f["description"] for f in case["facts"]) + "\nConversation style:\n" + variants[arm]
                          + "\nUse only the supplied facts. Do not invent a diagnosis. Respond in natural English as this person. "
                          "Write only this person's reply, not interviewer turns or stage directions.")
                row = {"condition_id": f"RC-{mode}-{case['id']}-Q{target}-{wording['id']}-R{repeat}-{arm}",
                       "profile_id": case["id"], "target_event": target, "variant_id": wording["id"],
                       "repeat_index": repeat, "task_mode": mode, "style_id": arm, "arm": arm,
                       "facts": case["facts"], "topic_words": case["topic_words"], "events": case["events"],
                       "stimulus_prefix": prefix, "original_question": question, "system_prompt": prompt,
                       "interview": [{"turn": 1, "probe": mode, "text": user_text}]}
                row["prompt_sha256"] = fingerprint({"system_prompt": prompt, "interview": row["interview"]})
                group.append(row)
            rng.shuffle(group)
            rows.extend(group)
    if len(rows) != 64 or len(rows) != spec["maximum_requests"]:
        raise ValueError("Ablation request bound changed")
    return rows


def prepare():
    spec, rows = read(SPEC), conditions()
    plan = {"run_id": RUN, "max_requests": len(rows), "model_digest": spec["model_digest"],
            "design": "2 fictional cases x 2 requested events x 2 wordings x 2 seeds x 2 arms x 2 separate task modes",
            "intervention": "Replace only the no-return clause; remove the same source numeric cap in both arms as in prior probe. No other source instruction, including normal-turn allowance, changed.",
            "scope": "Original PSI instruction port versus one-clause clarification on pinned Qwen3-14B. Not original-backend replication or schizophrenia treatment.",
            "task_modes": {"free_reply": "32 entirely new first replies", "continuation_challenge": "32 new continuations after explicitly researcher-authored R-to-O prefixes; never pooled with free replies"},
            "analysis_contract": spec["analysis_contract"], "source_clause": spec["source_clause"],
            "replacement_clause": spec["replacement_clause"], "options": OPTIONS, "think": False,
            "seed_rule": "20261030+100*repeat_index+1, indices 6 and 7; matched across arms and modes",
            "spec_sha256": digest(SPEC.read_bytes()), "conditions_sha256": fingerprint(rows),
            "matcher_file_sha256": digest((ROOT / "scripts/fact_disclosure_probe.py").read_bytes()),
            "analysis_script_sha256_at_preparation": digest((ROOT / "scripts/return_control_ablation.py").read_bytes()),
            "source_url": source_records()["psi_styles"]["citation_url"]}
    freeze(FOLDER / "plan.json", plan)
    freeze(FOLDER / "conditions.json", rows)
    if not (FOLDER / "prepared-at.json").exists():
        write_json(FOLDER / "prepared-at.json", {"prepared_at_utc": now(), "plan_sha256": fingerprint(plan)})
    return plan, rows


def anchor_stream(text, case):
    normalized, hits = normalize(text), []
    for domain in ("A", "B"):
        aliases = [(w, "topic_word") for w in case["topic_words"][domain]]
        aliases += [(a, f["id"]) for f in case["facts"] if f["domain"] == domain for a in f["aliases"]]
        for alias, kind in aliases:
            pattern = r"(?<![\w.])" + re.escape(normalize(alias)) + r"(?!\w|\.\d|,\d)"
            for m in re.finditer(pattern, normalized):
                hits.append({"domain": domain, "start": m.start(), "end": m.end(), "alias": alias, "kind": kind,
                             "context": normalized[max(0,m.start()-40):m.end()+50]})
    hits.sort(key=lambda h: (h["start"], h["end"], h["domain"]))
    ambiguous = [h for h in hits if any(o["domain"] != h["domain"] and h["start"] < o["end"] and o["start"] < h["end"] for o in hits)]
    usable = [h for h in hits if h not in ambiguous]
    stream = []
    for h in usable:
        label = "R" if h["domain"] == case["target_event"] else "O"
        if not stream or stream[-1] != label:
            stream.append(label)
    return {"normalized_text": normalized, "hits": hits, "ambiguous_overlaps": ambiguous, "sequence": stream}


def metrics(text, case, spec):
    stream = anchor_stream(text, case)
    seq = stream["sequence"]
    requested = any(x == "R" for x in seq)
    other = any(x == "O" for x in seq)
    return_after_o = any(x == "O" and "R" in seq[i+1:] for i,x in enumerate(seq))
    r_o_r = any(x == "R" and any(y == "O" and "R" in seq[j+1:] for j,y in enumerate(seq) if j>i) for i,x in enumerate(seq))
    primary = return_after_o if case["task_mode"] == "free_reply" else requested
    fact_hits = [match_fact(text, f) for f in case["facts"]]
    requested_facts = sum(h["recognized_mention"] for h in fact_hits if h["domain"] == case["target_event"])
    other_facts = sum(h["recognized_mention"] for h in fact_hits if h["domain"] != case["target_event"])
    tm = text_metrics(text)
    meta = bool(re.search(spec["analysis_contract"]["meta_pattern"], text, re.I))
    echo = bool(case["stimulus_prefix"] and normalize(case["stimulus_prefix"]) in normalize(text))
    return {"anchor_sequence": " ".join(seq), "anchor_evidence": stream,
            "requested_present": requested, "other_present": other, "return_after_other": return_after_o,
            "strict_r_o_r": r_o_r, "primary_return": primary,
            "requested_fact_count": requested_facts, "other_fact_count": other_facts,
            "word_count": tm["word_count"], "sentence_count_heuristic": tm["sentence_count_heuristic"],
            "meta_response_flag": meta, "complete_prefix_echo": echo,
            "adequate_challenge_continuation": tm["word_count"] >= 8 and other and not meta and not echo,
            "fact_matches": fact_hits}


def block_key(row):
    return tuple(row[k] for k in ("profile_id", "target_event", "variant_id", "repeat_index"))


def contrast(rows, metric):
    blocks = defaultdict(dict)
    for r in rows:
        blocks[block_key(r)][r["arm"]] = r[metric]
    changes = []
    for key in sorted(blocks):
        values = blocks[key]
        if set(values) != set(ARMS):
            raise ValueError("Incomplete matched arm block")
        changes.append({"block": key, "original": values["original"], "clarified": values["clarified"],
                        "difference": values["clarified"]-values["original"]})
    return {"paired_blocks": len(changes), "mean_difference": mean(c["difference"] for c in changes),
            "reduced": sum(c["difference"] < 0 for c in changes), "increased": sum(c["difference"] > 0 for c in changes),
            "unchanged": sum(c["difference"] == 0 for c in changes), "blocks": changes}


def decision(summaries, contrasts, subgroups, mode, spec):
    a = {s["arm"]: s for s in summaries}
    d = spec["analysis_contract"]["decisions"]
    o, c = a["original"], a["clarified"]
    min_count = d["free_min_original_return_count"] if mode == "free_reply" else d["challenge_min_original_return_count"]
    if o["primary_return_count"] < min_count:
        return {"status": "insufficient_baseline_returns", "reason": "Too few original returns to assess a reduction; zero is not proof of improvement."}
    if mode == "free_reply":
        passed = (c["primary_return_count"] < o["primary_return_count"] and
                  c["other_present_count"] >= o["other_present_count"]-d["maximum_other_occurrence_loss"] and
                  c["mean_words"] >= o["mean_words"]*d["mean_word_ratio_floor"])
    else:
        passed = (o["primary_return_count"]-c["primary_return_count"] >= d["challenge_min_net_return_reduction"] and
                  c["other_present_count"] >= o["other_present_count"]-d["maximum_other_occurrence_loss"] and
                  c["adequate_continuation_count"] >= o["adequate_continuation_count"]-d["maximum_adequate_continuation_loss"] and
                  c["mean_words"] >= o["mean_words"]*d["mean_word_ratio_floor"] and
                  all(v["mean_difference"] <= 0 for g in subgroups.values() for v in g.values()))
    return {"status": "descriptive_rule_met" if passed else "descriptive_rule_not_met",
            "reason": "Frozen screening rule, with event-occurrence and length/continuation guardrails; no clinical or population efficacy claim."}


def analyze():
    plan, cases = prepare()
    spec, rows = read(SPEC), []
    files = [SPEC, FOLDER / "plan.json", FOLDER / "conditions.json", FOLDER / "prepared-at.json", FOLDER / "runtime.json"]
    for case in cases:
        req_path, raw_path = (FOLDER / name / (case["condition_id"]+".json") for name in ("requests", "responses"))
        request, raw = read(req_path), read(raw_path)
        verify_response(raw, request, case, plan["model_digest"])
        row = {**{k:case[k] for k in ("condition_id", "profile_id", "target_event", "variant_id", "repeat_index", "task_mode", "arm", "stimulus_prefix", "original_question")},
               "response_text": raw["response_text"], **metrics(raw["response_text"], case, spec)}
        rows.append(row)
        files += [req_path, raw_path]
    by_mode = {}
    for mode in MODES:
        group = [r for r in rows if r["task_mode"] == mode]
        summaries = []
        for arm in ARMS:
            part = [r for r in group if r["arm"] == arm]
            summaries.append({"arm": arm, "replies": len(part),
                "primary_return_count": sum(r["primary_return"] for r in part),
                "other_present_count": sum(r["other_present"] for r in part),
                "strict_r_o_r_count": sum(r["strict_r_o_r"] for r in part),
                "return_after_other_count": sum(r["return_after_other"] for r in part),
                "conditional_return_given_other": sum(r["return_after_other"] for r in part)/sum(r["other_present"] for r in part) if any(r["other_present"] for r in part) else None,
                "adequate_continuation_count": sum(r["adequate_challenge_continuation"] for r in part),
                "mean_words": mean(r["word_count"] for r in part),
                "requested_fact_mentions": sum(r["requested_fact_count"] for r in part),
                "other_fact_mentions": sum(r["other_fact_count"] for r in part),
                "meta_responses": sum(r["meta_response_flag"] for r in part),
                "prefix_echoes": sum(r["complete_prefix_echo"] for r in part)})
        contrasts = {metric: contrast(group, metric) for metric in ("primary_return", "other_present", "word_count", "requested_fact_count", "adequate_challenge_continuation")}
        subgroups = {field: {value: contrast([r for r in group if r[field] == value], "primary_return")
                            for value in sorted({r[field] for r in group})} for field in ("profile_id", "target_event", "variant_id")}
        by_mode[mode] = {"summaries": summaries, "contrasts": contrasts, "subgroups": subgroups,
                         "decision": decision(summaries, contrasts, {k:v for k,v in subgroups.items() if k in ("profile_id","target_event")}, mode, spec)}
    result = {"plan": plan, "completed_requests": len(rows), "by_mode": by_mode, "responses": rows,
              "provenance": [{"path": str(p.relative_to(ROOT)), "sha256": digest(p.read_bytes())} for p in files]}
    write_json(OUT / "results.json", result)
    lines = ["# 복귀 금지 지시의 단일 절 수정 실험", "", "## 설계", "",
             "PATIENT-Ψ의 주제 이탈 지시에서 복귀 금지 절 하나만 바꾸었다. 양쪽 모두 이전 실험과 같은 숫자 문장 상한 제거를 적용했다. "
             "미사용 사건 4종·두 인물·두 질문 대상·두 표현·두 seed를 교차해 자유응답 32개와 별도 이어쓰기 32개를 생성했다. "
             "이어쓰기의 R→O 접두문은 연구자가 작성한 입력이며 생성 데이터로 세지 않았다. 두 과제는 합치지 않는다.", "",
             "## 실제 바꾼 절", "", "원형: "+spec["source_clause"], "", "수정: "+spec["replacement_clause"], "",
             "## 결과", ""]
    for mode, block in by_mode.items():
        lines += ["### "+mode, ""]
        for s in block["summaries"]:
            lines.append(f"- {s['arm']}: 복귀 표식 {s['primary_return_count']}/16, 다른 사건 표식 {s['other_present_count']}/16, "
                         f"평균 {s['mean_words']:.1f}단어, 충분한 이어쓰기 {s['adequate_continuation_count']}/16.")
        lines += ["", "고정 규칙의 판정: "+block["decision"]["status"], ""]
    lines += ["## 측정과 해석", "",
              "사건 단어·고유값의 위치를 고정 규칙으로 추적했다. 자유응답에서는 다른 사건 뒤 원래 사건 표식, 이어쓰기에서는 생성된 뒷부분의 원래 사건 표식을 센다. "
              "이는 텍스트 참조 제어이며 임상적 사고장애 점수가 아니다. 전체 답변을 보존했고 출력에 맞춰 표현 목록을 바꾸거나 실패 답변을 대체하지 않았다. "
              "조건에 따라 다른 사건 언급 자체가 변할 수 있어 조건부 복귀율은 기술값일 뿐 선택된 하위집단 간 인과 효과로 해석하지 않는다. "
              "원형 복귀가 드물면 개선 여부를 판단할 여지가 적다고 보고한다.", "",
              "## 재현", "", "`python3 scripts/return_control_ablation.py --analyze-only`", ""]
    (OUT / "report.ko.md").write_text("\n".join(lines))
    print(json.dumps({mode: {"summaries": b["summaries"], "decision": b["decision"]} for mode,b in by_mode.items()},ensure_ascii=False))
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepare-only", action="store_true")
    parser.add_argument("--analyze-only", action="store_true")
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if args.analyze_only:
        analyze()
    else:
        plan, cases = prepare()
        if not args.prepare_only:
            run(plan, cases, FOLDER, resume=args.resume)
            analyze()
        else:
            print(json.dumps({"prepared_requests": len(cases), "modes": MODES}))
