"""Reproduce the bounded audit from local, hash-verified inputs and caches.

Use the existing Python runtime with NumPy. No installs, automatic downloads,
LLM generations, paid APIs or remote jobs. macOS Swift is needed only for a
missing native cache. Original intermediate and corrected analyses are retained.
"""
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
import measurement_audit as core

ROOT=core.ROOT


def main():
    if not (ROOT/'catalog/summeval-official/model_annotations.aligned.jsonl').exists():
        raise FileNotFoundError('Obtain the official public SummEval annotation file as documented in the guide; no automatic download')
    steps=[('measurement_audit.py',['prepare']),('measurement_audit.py',['embed']),
           ('measurement_audit.py',['score','--split','development']),
           ('measurement_audit.py',['score','--split','evaluation']),('measurement_audit.py',['verify']),
           ('measurement_external.py',['prepare']),('measurement_external.py',['embed']),
           ('measurement_external_v02.py',['freeze'])]
    alias=ROOT/'analysis/measurement-external-v02/embedding-output.json'
    alias.parent.mkdir(parents=True,exist_ok=True)
    if not alias.exists():
        if alias.is_symlink(): raise ValueError('Existing cache alias is broken; do not overwrite')
        alias.symlink_to('../measurement-external-v01/embedding-output.json')
    steps += [('measurement_external_v02.py',['score']),('measurement_external_v02.py',['verify']),
              ('measurement_external_v03.py',['prepare']),('measurement_external_v03.py',['embed']),
              ('measurement_external_v03.py',['score']),('measurement_external_v03.py',['verify'])]
    logs=[]
    for script,args in steps:
        command=[sys.executable,str(ROOT/'scripts'/script),*args]
        if args==['score'] and script in ('measurement_external_v02.py','measurement_external_v03.py'):
            command=[sys.executable,str(ROOT/'scripts/replay_frozen_analysis.py'),str(ROOT/'scripts'/script),*args]
        run=subprocess.run(command,cwd=ROOT,text=True,capture_output=True)
        logs.append({'script':script,'args':args,'returncode':run.returncode,
                     'stdout':run.stdout,'stderr':run.stderr})
        print(script,' '.join(args),':', 'passed' if run.returncode==0 else 'FAILED',flush=True)
        if run.returncode:
            print(run.stderr[-4000:]);raise RuntimeError('Stop on failed stage, no score imputation')
    tests=subprocess.run([sys.executable,'-m','unittest','discover','-s','tests'],cwd=ROOT,text=True,capture_output=True)
    logs.append({'script':'unittest','returncode':tests.returncode,'stdout':tests.stdout,'stderr':tests.stderr})
    if tests.returncode: raise RuntimeError(tests.stderr)
    stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    folder=ROOT/'analysis/measurement-audit-v01/reproductions'
    core.save(folder/f'{stamp}.json',{'completed_utc':stamp,'python':sys.executable,
        'runner_sha256':core.sha(Path(__file__).resolve()),
        'json_comparison_wrapper_sha256':core.sha(ROOT/'scripts/replay_frozen_analysis.py'),'stages':logs,
        'results':{str(p.relative_to(ROOT)):core.sha(p) for p in (
            ROOT/'analysis/measurement-audit-v01/evaluation-results.json',
            ROOT/'analysis/measurement-external-v02/results.json',
            ROOT/'analysis/measurement-external-v03/results.json')},
        'tests_passed':True,'generations':0,'judges':0,'paid_apis':0})
    print('All stages and tests passed; immutable results and complete logs retained')


if __name__=='__main__': main()
