// Static scientific plot; descriptive paired differences, not confidence intervals.
import AppKit
import Foundation
struct Point: Decodable { let label: String; let difference: Double; let pairs: Int; let blocks: Int }
struct Panel: Decodable { let title: String; let points: [Point] }
struct Input: Decodable { let panels: [Panel]; let caption: String }
let input = try JSONDecoder().decode(Input.self, from: Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1])))
let width = 1440, height = 850
let bitmap = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: width, pixelsHigh: height, bitsPerSample: 8,
    samplesPerPixel: 4, hasAlpha: true, isPlanar: false, colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0)!
NSGraphicsContext.saveGraphicsState()
NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep: bitmap)
let cg = NSGraphicsContext.current!.cgContext
cg.setFillColor(NSColor.white.cgColor); cg.fill(CGRect(x: 0, y: 0, width: width, height: height))
func text(_ s: String, _ x: Double, _ y: Double, _ size: Double = 13, _ color: NSColor = .black) {
    (s as NSString).draw(at: CGPoint(x: x, y: y), withAttributes: [.font: NSFont.systemFont(ofSize: size), .foregroundColor: color])
}
text("Tangent versus plain: what survives sensitivity analysis?", 35, 805, 24)
text("PATIENT-PSI prompt port on Qwen3-14B | Same 144 responses, one example persona | Post-hoc descriptive analysis", 35, 778, 14, .darkGray)
for (i, panel) in input.panels.prefix(2).enumerated() {
    let origin = Double(i)*700+35
    let plotLeft = origin+220, plotRight = origin+550
    let bottom = 125.0, top = 685.0
    let minX = -0.15, maxX = 0.03
    func x(_ value: Double) -> Double { plotLeft+(value-minX)/(maxX-minX)*(plotRight-plotLeft) }
    text(panel.title, origin, 732, 18)
    text("Response pairs / blocks", origin+518, 702, 11, .darkGray)
    for tick in [-0.15, -0.10, -0.05, 0.0] {
        cg.setStrokeColor(NSColor(white: tick == 0 ? 0.45 : 0.88, alpha: 1).cgColor)
        cg.setLineWidth(tick == 0 ? 1.2 : 0.7)
        cg.move(to: CGPoint(x: x(tick), y: bottom)); cg.addLine(to: CGPoint(x: x(tick), y: top)); cg.strokePath()
        text(String(format: "%.2f", tick), x(tick)-17, bottom-25, 12, .darkGray)
    }
    for (j, point) in panel.points.enumerated() {
        let yy = top-27-Double(j)*46
        text(point.label, origin, yy-6, 13)
        cg.setFillColor((j == 0 ? NSColor(calibratedRed: 0.15, green: 0.32, blue: 0.43, alpha: 1) : NSColor(white: 0.30, alpha: 1)).cgColor)
        cg.fillEllipse(in: CGRect(x: x(point.difference)-4.5, y: yy-4.5, width: 9, height: 9))
        text(String(format: "%+.3f", point.difference), x(point.difference)+9, yy-5, 11)
        text("\(point.pairs) / \(point.blocks)", origin+580, yy-6, 12, .darkGray)
    }
    text("Tangent - plain (cosine units; equal eligible-block weighting)", origin+120, bottom-53, 12, .darkGray)
}
text(input.caption, 35, 36, 12, .darkGray)
NSGraphicsContext.restoreGraphicsState()
try bitmap.representation(using: .png, properties: [:])!.write(to: URL(fileURLWithPath: CommandLine.arguments[2]))
print("Saved robustness plot.")
