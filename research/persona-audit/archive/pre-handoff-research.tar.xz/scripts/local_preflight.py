"""Read local hardware and installed-model metadata. No inference or downloads.

Only the loopback Ollama metadata routes are used. No API keys, cloud hosts,
server starts, remote execution, package installs or model pulls.
"""
from datetime import datetime, timezone
import importlib.util
import json
import platform
import shutil
import subprocess
import urllib.request

from common import ROOT, digest, write_json

BASE = "http://127.0.0.1:11434"
MODEL = "qwen3:14b"


def sysctl(key):
    executable = shutil.which("sysctl") or "/usr/sbin/sysctl"
    result = subprocess.run([executable, "-n", key], capture_output=True, text=True, timeout=5)
    return result.stdout.strip() if result.returncode == 0 else None


def local_metadata(route, payload=None):
    if route not in {"/api/tags", "/api/ps", "/api/show", "/api/version"}:
        raise ValueError("Only read-only Ollama metadata routes are allowed")
    data = None if payload is None else json.dumps(payload).encode()
    request = urllib.request.Request(BASE + route, data=data, headers={"Content-Type": "application/json"})
    # Bypass proxy environment settings for an explicitly loopback-only request.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(request, timeout=10) as response:
        raw = response.read(2_000_001)
    if len(raw) > 2_000_000:
        raise ValueError("Metadata response too large")
    return json.loads(raw)


def main():
    memory = sysctl("hw.memsize") if platform.system() == "Darwin" else None
    report = {
        "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "os": platform.system(), "architecture": platform.machine(),
        "hardware_model": sysctl("hw.model") if platform.system() == "Darwin" else None,
        "cpu": sysctl("machdep.cpu.brand_string") if platform.system() == "Darwin" else None,
        "memory_bytes": int(memory) if memory and memory.isdigit() else None,
        "memory_gib": int(memory) / (1024 ** 3) if memory and memory.isdigit() else None,
        "python": platform.python_version(), "ollama_cli_present": shutil.which("ollama") is not None,
        "python_modules": {name: importlib.util.find_spec(name) is not None for name in
                           ["numpy", "pandas", "scipy", "sklearn", "torch", "mlx", "mlx_lm", "sentence_transformers"]},
        "inference_calls": 0, "downloads": 0, "remote_hosts_inspected": 0,
        "experimental_backbone_selected": False,
    }
    try:
        version = local_metadata("/api/version")
        tags = local_metadata("/api/tags").get("models", [])
        active = local_metadata("/api/ps").get("models", [])
        selected = next((m for m in tags if m.get("name") == MODEL or m.get("model") == MODEL), None)
        report["ollama"] = {
            "reachable": True, "version": version.get("version"),
            "installed": [{k: m.get(k) for k in ["name", "model", "digest", "size", "details"]} for m in tags],
            "active_models": [m.get("name") or m.get("model") for m in active],
        }
        if selected:
            detail = local_metadata("/api/show", {"model": MODEL})
            report["ollama"]["candidate_metadata"] = {
                "model": MODEL, "digest": selected.get("digest"),
                "details": detail.get("details"), "model_info": detail.get("model_info"),
                "capabilities": detail.get("capabilities"), "parameters": detail.get("parameters"),
                "template_sha256": digest(detail.get("template", "").encode()),
                "license_sha256": digest(detail.get("license", "").encode()),
                "performance_tested": False,
            }
    except Exception as error:
        report["ollama"] = {"reachable": False, "error_type": type(error).__name__, "error": str(error)}
    write_json(ROOT / "evidence/local-runtime.json", report)
    print(json.dumps({"memory_gib": report["memory_gib"], "cpu": report["cpu"],
                      "ollama_reachable": report["ollama"]["reachable"],
                      "candidate_installed": "candidate_metadata" in report["ollama"],
                      "inference_calls": 0, "downloads": 0}, ensure_ascii=False))
    print("Saved evidence/local-runtime.json. Metadata only; performance and clinical suitability are untested.")


if __name__ == "__main__":
    main()
