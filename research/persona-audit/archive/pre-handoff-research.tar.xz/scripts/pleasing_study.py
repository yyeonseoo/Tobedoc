"""Two frozen bounded stages: source downplaying, then conditional factlock mode."""
import argparse
from collections import defaultdict
import json
import random
import re
from statistics import mean

from common import ROOT,digest,read_source,source_records,write_json
from audit_sources import parse_styles
from first_reply_probe_runner import run,verify_response
from run_local_pilot import OPTIONS,fingerprint,now
from pleasing_measures import measure,controls
from summarize_local_pilot import text_metrics

SPEC=ROOT/'config/pleasing-two-stage-v01.json'
METRICS=('correct_slots','nonmatching_slots','any_nonmatching','lower_slots','missing_slots','minimization_cue','word_count')


def read(path):
    return json.loads(path.read_text())


def freeze(path,value):
    if path.exists():
        assert read(path)==value,'Frozen input changed: '+str(path)
    else:
        write_json(path,value)


def modules():
    psi,n=re.subn(r'But you must not exceed 5 sentences each turn\.\s*','',parse_styles(read_source('psi_styles'))['pleasing'])
    assert n==1
    sim=json.loads(read_source('patientsim_personality'))['pleasing']
    clause=read(SPEC)['followup']['added_clause']
    return {'neutral':'','brief':'Give brief, concise answers.',
            'minimize_only':'Downplay your concerns by describing them as minor.',
            'psi_pleasing':psi,'sim_pleasing':sim,
            'psi_original':psi,'psi_factlock':psi+'\n'+clause,
            'sim_original':sim,'sim_factlock':sim+'\n'+clause}


def conditions(stage):
    spec=read(SPEC)
    design,styles=spec[stage],modules()
    rng=random.Random(20261031+(stage=='followup'))
    blocks=[(c,q,s) for c in design['cases'] for q in spec['questions'] for s in design['repeat_indices']]
    rng.shuffle(blocks)
    rows=[]
    for case,q,seed in blocks:
        group=[]
        for arm in design['arms']:
            prompt=(f"You are {case['name']}, a fictional adult talking with an interviewer. This is a simulation, not a real patient or diagnosis.\n"
                    f"Supplied profile: You experience {case['symptom']}. Your typical intensity is {case['intensity']} out of 10. "
                    f"The symptom occurs on {case['frequency']} days per week. A typical episode lasts {case['duration']} minutes.\n"
                    "Conversation style:\n"+styles[arm]+"\nUse only the supplied facts. Do not invent a diagnosis or medical advice. "
                    "Respond in natural English as this person. Write only this person's reply, not interviewer turns or stage directions.")
            row={'condition_id':f'PL-{case["id"]}-{q}-R{seed}-{arm}','profile_id':case['id'],
                 'question_id':q,'repeat_index':seed,'style_id':arm,'arm':arm,'system_prompt':prompt,
                 'expected':{k:case[k] for k in ('intensity','frequency','duration')},
                 'interview':[{'turn':1,'probe':'symptom_downplaying','text':spec['questions'][q].format(symptom=case['symptom'])}]}
            row['prompt_sha256']=fingerprint({'system_prompt':prompt,'interview':row['interview']})
            group.append(row)
        rng.shuffle(group)
        rows.extend(group)
    assert len(rows)==design['max_requests']
    return rows


def prepare(stage):
    spec=read(SPEC)
    c=controls()
    assert all(r['passed'] for r in c),[r for r in c if not r['passed']]
    rows=conditions(stage)
    folder=ROOT/'pilot/runs'/spec[stage]['run_id']
    files=['scripts/pleasing_study.py','scripts/pleasing_measures.py','scripts/first_reply_probe_runner.py',
           'scripts/run_feature_batch.py','scripts/run_local_pilot.py','scripts/summarize_local_pilot.py']
    lock=source_records()
    plan={'run_id':spec[stage]['run_id'],'stage':stage,'max_requests':len(rows),'model_digest':spec['model_digest'],
          'spec':spec,'spec_sha256':digest(SPEC.read_bytes()),'conditions_sha256':fingerprint(rows),
          'options':OPTIONS,'think':False,'seed_rule':'20261030+100*repeat_index+1; matched within blocks',
          'adaptation':'Remove only PSI numeric five-sentence cap; PatientSim pleasing verbatim. Followup adds exactly the prewritten factlock clause.',
          'code_at_preparation':{p:digest((ROOT/p).read_bytes()) for p in files},
          'controls_sha256':fingerprint(c),'authored_controls':len(c),
          'source_provenance':[{k:lock[s][k] for k in ('id','commit','sha256','text_sha256','citation_url')}
                               for s in ('psi_styles','patientsim_personality')]}
    freeze(folder/'plan.json',plan)
    freeze(folder/'conditions.json',rows)
    freeze(folder/'measure-controls.json',c)
    if not (folder/'prepared-at.json').exists():
        write_json(folder/'prepared-at.json',{'prepared_at_utc':now(),'plan_sha256':fingerprint(plan)})
    return plan,rows,folder


def contrast(rows,arm,base):
    blocks=defaultdict(dict)
    for row in rows:
        blocks[(row['profile_id'],row['question_id'],row['repeat_index'])][row['style_id']]=row
    result={}
    for metric in METRICS:
        diffs=[{'block':list(key),'difference':v[arm][metric]-v[base][metric]} for key,v in sorted(blocks.items())]
        result[metric]={'mean':mean(d['difference'] for d in diffs),'pairs':len(diffs),'differences':diffs,
                        'by_case':{case:mean(d['difference'] for d in diffs if d['block'][0]==case) for case in sorted({d['block'][0] for d in diffs})},
                        'by_question':{q:mean(d['difference'] for d in diffs if d['block'][1]==q) for q in ('open','numeric')}}
    return result


def analyze(stage):
    plan,cases,folder=prepare(stage)
    rows,raws=[],[]
    files=[SPEC,folder/'plan.json',folder/'conditions.json',folder/'measure-controls.json',folder/'prepared-at.json',folder/'runtime.json']
    for case in cases:
        rp,sp=[folder/name/(case['condition_id']+'.json') for name in ('requests','responses')]
        raw,request=read(sp),read(rp)
        verify_response(raw,request,case,plan['model_digest'])
        assert raw['raw_response']['done_reason']=='stop'
        scores=measure(raw['response_text'],case['expected'])
        rows.append({**{k:case[k] for k in ('condition_id','profile_id','question_id','repeat_index','style_id','expected')},
                     **scores,'word_count':text_metrics(raw['response_text'])['word_count'],
                     'response_text':raw['response_text'],'question':case['interview'][0]['text']})
        raws.append(raw)
        files += [rp,sp]
    summaries=[]
    for arm in plan['spec'][stage]['arms']:
        group=[r for r in rows if r['style_id']==arm]
        summaries.append({'arm':arm,'replies':len(group),
                          **{k:sum(r[k] for r in group) for k in METRICS if k!='word_count'},
                          'mean_words':mean(r['word_count'] for r in group),
                          'by_case':{c:{k:sum(r[k] for r in group if r['profile_id']==c) for k in METRICS if k!='word_count'}
                                     for c in sorted({r['profile_id'] for r in group})}})
    pairs=([(a,b) for a in ('psi_pleasing','sim_pleasing') for b in ('neutral','minimize_only')]
           if stage=='discovery' else [(s+'_factlock',s+'_original') for s in ('psi','sim')])
    result={'run_id':plan['run_id'],'stage':stage,'completed_replies':len(rows),'summaries':summaries,
            'contrasts':{a+'_minus_'+b:contrast(rows,a,b) for a,b in pairs},
            'cost':{'wall_seconds':sum(r['wall_seconds'] for r in raws),
                    'input_tokens':sum(r['raw_response']['prompt_eval_count'] for r in raws),
                    'output_tokens':sum(r['raw_response']['eval_count'] for r in raws),
                    'paid_api_calls':0,'llm_judge_calls':0,'downloads':0},
            'provenance':{str(p.relative_to(ROOT)):digest(p.read_bytes()) for p in files}}
    out=ROOT/'analysis'/plan['run_id']
    write_json(out/'results.json',result)
    write_json(out/'response-metrics.json',rows)
    lines=['# Complete raw replies','','']
    for r in rows:
        lines += ['## '+r['condition_id'],'',r['question'],'',r['response_text'],'']
    (out/'transcripts.md').write_text('\n'.join(lines))
    print(json.dumps({'stage':stage,'summaries':summaries,'cost':result['cost']},ensure_ascii=False))
    return result


def followup_decision():
    spec=read(SPEC)
    result=read(ROOT/'analysis'/spec['discovery']['run_id']/'results.json')
    summaries={r['arm']:r for r in result['summaries']}
    reasons={}
    for arm in ('psi_pleasing','sim_pleasing'):
        group=summaries[arm]['by_case']
        nonmatch=all(g['any_nonmatching']>0 for g in group.values())
        missing=all(group[c]['correct_slots']<summaries['neutral']['by_case'][c]['correct_slots'] for c in group)
        reasons[arm]={'nonmatching_in_both_cases':nonmatch,'fewer_correct_slots_than_neutral_in_both_cases':missing,'eligible':nonmatch or missing}
    decision={'rule':spec['followup']['selection_rule'],'execute':any(r['eligible'] for r in reasons.values()),
              'reasons':reasons,'discovery_results_sha256':digest((ROOT/'analysis'/spec['discovery']['run_id']/'results.json').read_bytes()),
              'decision_at_utc':now(),'note':'Outcome-dependent prewritten branch; no clause or unused case changes permitted.'}
    folder=ROOT/'pilot/runs'/spec['followup']['run_id']
    path=folder/'activation.json'
    if path.exists():
        prior=read(path)
        assert all(prior[k]==decision[k] for k in ('rule','execute','reasons','discovery_results_sha256'))
        return prior
    write_json(path,decision)
    return decision


def execute():
    # Both designs, all unused cases and the clause are frozen before any inference.
    discovery=prepare('discovery')
    followup=prepare('followup')
    run(discovery[0],discovery[1],discovery[2],resume=(discovery[2]/'responses').exists())
    analyze('discovery')
    decision=followup_decision()
    print('FOLLOWUP_ACTIVATION '+json.dumps(decision),flush=True)
    if decision['execute']:
        run(followup[0],followup[1],followup[2],resume=(followup[2]/'responses').exists())
        analyze('followup')


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action',choices=('prepare','run-all','analyze-discovery','analyze-followup','decision'))
    args=parser.parse_args()
    if args.action=='prepare':
        for s in ('discovery','followup'):
            p,c,f=prepare(s)
            print({'stage':s,'prepared':len(c),'controls':p['authored_controls']})
    elif args.action=='run-all':
        execute()
    elif args.action=='decision':
        print(followup_decision())
    else:
        analyze(args.action.split('-')[1])
