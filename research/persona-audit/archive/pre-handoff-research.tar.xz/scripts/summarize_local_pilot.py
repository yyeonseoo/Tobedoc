"""Verify actual requests/history and compute descriptive (not clinical) metrics."""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import json
from pathlib import Path
import re
import statistics

from common import ROOT, digest, write_json
from run_local_pilot import ARMS, STYLES, fingerprint


def text_metrics(text):
    words = re.findall(r"[A-Za-z0-9]+(?:['’\-][A-Za-z0-9]+)*", text)
    # V1 is retained for audit. Its naive splitting overcounts ellipses and
    # misses terminators followed by closing quotes. V2 normalises only a copy.
    old_sentences = [s for s in re.split(r'(?<=[.!?])\s+', text.strip()) if re.search(r"[A-Za-z0-9]", s)]
    normalised = re.sub(r"\.{2,}|…+", " ", text.strip())
    sentences = [s for s in re.split(r'''[.!?]+["”’']*(?:\s+|$)''', normalised) if re.search(r"[A-Za-z0-9]", s)]
    return {"word_count": len(words), "sentence_count_heuristic": len(sentences),
            "sentence_count_v1": len(old_sentences),
            "character_count": len(text), "counting_method": "english_regex_v2_ellipsis_quotes"}


def verify_turn(row, request, condition, history):
    if row.get("is_fixture"):
        raise ValueError("Mock/fixture output cannot enter empirical results")
    for field in ["condition_id", "style_id", "arm", "profile_id"]:
        if row.get(field) != condition.get(field):
            raise ValueError(f"Condition identity mismatch: {field}")
    if fingerprint({"system_prompt": condition["system_prompt"], "interview": condition["interview"]}) != condition["prompt_sha256"]:
        raise ValueError("Stored condition does not match original prompt hash")
    payload = request["payload"]
    if fingerprint(payload) != row["request_sha256"] or request["request_sha256"] != row["request_sha256"]:
        raise ValueError("Request fingerprint mismatch")
    if row["prompt_sha256"] != condition["prompt_sha256"]:
        raise ValueError("Condition fingerprint mismatch")
    expected = [{"role": "system", "content": condition["system_prompt"]}] + history
    expected += [{"role": "user", "content": condition["interview"][row["turn"] - 1]["text"]}]
    if payload["messages"] != expected:
        raise ValueError("Missing, edited or inconsistent conversation history")
    raw = row["raw_response"]
    if row["response_text"] != raw.get("message", {}).get("content", ""):
        raise ValueError("Analysis text differs from raw returned content")
    if row["model_digest"] != condition["_model_digest"]:
        raise ValueError("Model digest mismatch")


def analyze(folder):
    config = json.loads((folder / "run-config.json").read_text())
    conditions = json.loads((folder / "conditions.json").read_text())
    records = []
    provenance = [{"path": str((folder / name).relative_to(ROOT)), "sha256": digest((folder / name).read_bytes())}
                  for name in ["run-config.json", "conditions.json", "runtime.json"]]
    for condition in conditions:
        condition["_model_digest"] = config["model_digest"]
        history = []
        for question in condition["interview"]:
            stem = f'{condition["condition_id"]}-T{question["turn"]}'
            path = folder / "responses" / (stem + ".json")
            if not path.exists():
                continue
            row = json.loads(path.read_text())
            req_path = folder / "requests" / (stem + ".json")
            request = json.loads(req_path.read_text())
            verify_turn(row, request, condition, history)
            provenance += [{"path": str(path.relative_to(ROOT)), "sha256": digest(path.read_bytes())},
                           {"path": str(req_path.relative_to(ROOT)), "sha256": digest(req_path.read_bytes())}]
            text = text_metrics(row["response_text"])
            cap = 3 if row["style_id"] == "reserved" else 5
            duration = row["usage"].get("eval_duration") or 0
            row.update(text)
            row.update(sentence_cap=cap, sentence_cap_flag=text["sentence_count_heuristic"] > cap,
                       thinking_output_present=bool(row["raw_response"].get("message", {}).get("thinking")),
                       tokens_per_second=(row["usage"].get("eval_count", 0) / (duration / 1e9)) if duration else None,
                       missing_profile_field_count=len(condition["missing_fields"]))
            records.append(row)
            if row["status"] == "completed":
                history += [{"role": "user", "content": row["interviewer_text"]},
                            {"role": "assistant", "content": row["response_text"]}]
    grouped = []
    for style in STYLES:
        for arm in ARMS:
            rows = [r for r in records if r["style_id"] == style and r["arm"] == arm]
            completed = [r for r in rows if r["status"] == "completed"]
            grouped.append({"style": style, "arm": arm, "planned_turns": 4, "recorded_turns": len(rows),
                            "completed_turns": len(completed), "dialogues": 1,
                            "mean_words": statistics.mean(r["word_count"] for r in completed) if completed else None,
                            "mean_sentences_heuristic": statistics.mean(r["sentence_count_heuristic"] for r in completed) if completed else None,
                            "sentence_cap_flags": sum(r["sentence_cap_flag"] for r in completed),
                            "mean_wall_seconds": statistics.mean(r["wall_seconds"] for r in rows) if rows else None})
    totals = {"planned_dialogues": 6, "planned_turns": 24, "recorded_turns": len(records),
              "completed_turns": sum(r["status"] == "completed" for r in records),
              "non_completed_turns": sum(r["status"] != "completed" for r in records),
              "sentence_cap_flags": sum(r["sentence_cap_flag"] for r in records if r["status"] == "completed"),
              "thinking_outputs": sum(r["thinking_output_present"] for r in records),
              "wall_seconds_sum": sum(r["wall_seconds"] for r in records),
              "wall_seconds_median": statistics.median(r["wall_seconds"] for r in records) if records else None,
              "wall_seconds_min": min((r["wall_seconds"] for r in records), default=None),
              "wall_seconds_max": max((r["wall_seconds"] for r in records), default=None),
              "prompt_tokens_max": max((r["usage"].get("prompt_eval_count") or 0 for r in records), default=None),
              "generated_tokens_total": sum(r["usage"].get("eval_count") or 0 for r in records),
              "independent_people": 1, "situations": 1, "repeats_per_condition": 1,
              "paid_model_api_calls": 0, "history_verified_turns": len(records)}
    result = {"run_id": config["run_id"], "analyzed_at_utc": datetime.now(timezone.utc).isoformat(),
              "totals": totals, "groups": grouped, "run_config": config,
              "counting_note": "English regex_v2_ellipsis_quotes: contractions/hyphens retained in word counts; ellipses treated as nonterminal pauses, closing quotes recognised at sentence boundaries. V1 counts retained per turn. Heuristic, not a validated clinical measure.",
              "inference_note": "Descriptive development prototype. Same persona/situation, one dialogue per cell. No p-values, clinical severity scores or population generalisation.",
              "clinical_validation": False, "is_paper_replication": False,
              "raw_record_integrity": provenance}
    return result, records


def export_transcripts(path, result, records):
    lines = ["# Actual local prototype transcripts", "",
             "PATIENT-Ψ prompt port on Qwen3-14B; English generated text. Development example, not clinical validation.",
             f'Run: `{result["run_id"]}`. Source requests/responses and hashes are retained in the run folder.', "",
             "All recorded replies are included below. No best-of selection, spelling correction or translation.", ""]
    for style in STYLES:
        for arm in ARMS:
            lines += [f"## {style} / {arm}", ""]
            for row in [r for r in records if r["style_id"] == style and r["arm"] == arm]:
                lines += [f'### Turn {row["turn"]} · {row["status"]}', "",
                          f'Interviewer: {row["interviewer_text"]}', "",
                          f'Patient: {row["response_text"]}', "",
                          f'Record: `{row["condition_id"]}-T{row["turn"]}`. '
                          f'Words: {row["word_count"]}; sentence heuristic: {row["sentence_count_heuristic"]}; '
                          f'wall time: {row["wall_seconds"]:.2f} s.', ""]
    path.write_text("\n".join(lines), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", required=True)
    parser.add_argument("--allow-partial", action="store_true")
    args = parser.parse_args()
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,70}", args.run_id):
        parser.error("Invalid run ID")
    folder = ROOT / "pilot/runs" / args.run_id
    result, records = analyze(folder)
    if result["totals"]["completed_turns"] != 24 and not args.allow_partial:
        raise ValueError("Incomplete run; use --allow-partial only to report explicitly incomplete results")
    out = ROOT / "share" / args.run_id
    out.mkdir(parents=True, exist_ok=True)
    previous = out / "metrics.json"
    if previous.exists():
        old = json.loads(previous.read_text())
        if "regex_v1:" in old.get("counting_note", "") and not (out / "metrics.regex-v1.json").exists():
            write_json(out / "metrics.regex-v1.json", old)
    write_json(out / "metrics.json", result)
    fields = ["condition_id", "style_id", "arm", "turn", "status", "word_count", "sentence_count_heuristic", "sentence_count_v1",
              "sentence_cap", "sentence_cap_flag", "wall_seconds", "tokens_per_second", "thinking_output_present",
              "missing_profile_field_count"]
    with (out / "turn-metrics.csv").open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(records)
    export_transcripts(out / "transcripts.en.md", result, records)
    print(json.dumps({"totals": result["totals"], "groups": result["groups"]}, indent=2, ensure_ascii=False))
    print(f"Saved verified descriptive metrics and all transcripts to {out}")


if __name__ == "__main__":
    main()
