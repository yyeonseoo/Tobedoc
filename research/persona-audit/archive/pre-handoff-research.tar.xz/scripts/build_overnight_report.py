"""Three-page Korean checkpoint: four feature axes and bounded one-clause test."""
import argparse
from decimal import Decimal,ROUND_HALF_UP
from docx import Document
from docx.shared import Pt
from common import ROOT,digest,write_json
from pleasing_study import SPEC,read
from build_integrated_report import font,paragraph,heading,table
from build_two_feature_report import configure
from build_role_audit_report import reference

SHARE=ROOT/'share/overnight-completion-v01'
OUTPUT=SHARE/'페르소나 특징 비교와 수치 보존 후속 실험 보고서.docx'


def decimal(value):
    return str(Decimal(str(value)).quantize(Decimal('.1'),rounding=ROUND_HALF_UP))


def derived(rows,arm):
    g=[r for r in rows if r['style_id']==arm]
    return {'lower_intensity':sum(r['audited_slots']['intensity']['strictly_lower'] for r in g),
            'full_single':sum(r['audited_single_slots']==3 for r in g)}


def build(replace=False):
    if OUTPUT.exists() and not replace:
        raise FileExistsError('Preserve an existing report except for layout repair')
    spec=read(SPEC)
    paths={'integrated':ROOT/'analysis/integrated-checkpoint-v05/results.json','spec':SPEC}
    for stage in ('discovery','followup'):
        folder=ROOT/'analysis'/spec[stage]['run_id']
        for suffix,name in (('primary','results.json'),('audit','numeric-expression-audit.json'),
                            ('details','numeric-expression-details.json'),('review','assistant-source-review.json')):
            paths[stage+'_'+suffix]=folder/name
    data={k:read(p) for k,p in paths.items()}
    main=data['integrated']
    d={r['arm']:r for r in data['discovery_audit']['summaries']}
    f={r['arm']:r for r in data['followup_audit']['summaries']}
    dp={r['arm']:r for r in data['discovery_primary']['summaries']}
    fp={r['arm']:r for r in data['followup_primary']['summaries']}
    dd,fd=data['discovery_details'],data['followup_details']
    doc=Document()
    configure(doc)
    doc.core_properties.title='페르소나 특징 비교와 수치 보존 후속 실험'
    doc.core_properties.subject='네 특징의 지시 행동 분석과 미사용 사례의 단일 문장 제약 비교'
    doc.core_properties.author='연구팀'
    doc.core_properties.comments=''
    title=doc.add_paragraph('페르소나 특징 비교와 수치 보존 후속 실험',style='Title')
    title.paragraph_format.line_spacing=Pt(25)
    title.paragraph_format.space_after=Pt(7)
    for run in title.runs:
        font(run,18,True)
    paragraph(doc,'2026년 10월 31일  새 응답 72개와 기존 세 특징의 통합',bold=True)

    heading(doc,'페르소나의 이름 대신 실제 행동을 비교했다')
    paragraph(doc,'우리는 전문가가 설계한 환자 페르소나를 그대로 조현병 연구에 사용해도 되는가라는 의구심에서 출발했다. 환자 발화를 확보하기 어려운 상황에서 먼저 공개 지시가 어떤 언어 행동을 만드는지 확인했다. 같은 이름의 페르소나도 말투·정보 보고·사실값 변화를 묶는 방식이 달라, 각각을 분리해 정량화해야 했다.')
    paragraph(doc,'이번에는 pleasing의 우려 축소를 비교하고, 수치 보존을 요구하는 한 문장 제약을 새 사례에서 시험했다. PSI에서는 단일 수치의 일치가 늘었지만 완전 보존은 아니었고, PatientSim에서는 강도를 낮춰 말하는 답변이 남았다. 따라서 한 문장을 덧붙였다고 개선이 끝난 것으로 채택하지 않았다. 네 특징의 첫 분석과 후속 검증까지 완료한 연구 체크포인트다.')

    heading(doc,'앞서 확보한 세 특징의 결과')
    axes=main['axes']
    v,disc,topic=[a['facts'] for a in axes[:3]]
    table(doc,['특징과 기존 응답 수','측정 결과'],[
        ['발화량  80개',f"단순 verbose {decimal(v['simple_verbose_words'])}단어  PSI {decimal(v['psi_verbose_words'])}  PatientSim {decimal(v['sim_verbose_words'])}"],
        ['정보 공개  40개',f"개인 표식  단순 간결함 {disc['brief_refs']}/24  PSI reserved {disc['psi_refs']}/24"],
        ['주제 유지  48개',f"요청 정보 세 말투 모두 48/48  인접 유사도 verbose {topic['verbose_adjacent']:.3f}  tangent {topic['tangent_adjacent']:.3f}"]
    ],[1.8,5.2],numeric=())
    paragraph(doc,'발화량이 늘어도 요청 정보 언급은 늘지 않았고, 의심 표현과 정보 비공개도 달랐다. 주제 유지에서는 정보를 모두 답하면서도 유사도가 달랐다. 각 과제의 분모와 정의가 달라 합산 점수나 시스템 순위를 만들지 않았다. 주제 분석에서 재사용한 문장·원문은 새 표본으로 중복 계산하지 않았다.',small=True)

    heading(doc,'새로운 비교와 후속 실험을 먼저 고정했다')
    paragraph(doc,'발견 단계는 새 허구 인물 2개 × 질문 표현 2종 × seed 2개 × 지시 5종으로 첫 응답 40개를 생성했다. 공통 무지시·단순 간결함·단순 우려 축소와 PSI pleasing·PatientSim pleasing을 비교했다. 강도 0–10, 주당 발생 일수, 회당 지속시간을 제공했다. 질문은 같은 세 항목을 자연스럽게 묻거나 수치를 직접 요청했다.')
    paragraph(doc,'후속은 다른 인물 2개와 새 seed 2개를 사용한 32응답이다. 두 소스 각각에서 원형 지시와 한 문장 추가를 8대응쌍으로 비교했다. 두 단계의 사례·질문·제약·발동 규칙은 첫 생성 전에 고정했다. 두 소스 모두 발견 단계의 발동 조건을 충족해 후속을 실행했다. 동일 Qwen3-14B Q4_K_M, 온도 0.6, 최대 512토큰이며 PSI의 숫자 문장 상한만 제거했다. 원형 앱 전체의 재현이 아니라 추출 지시의 통제 비교다.[1,2]')

    doc.add_page_break()
    heading(doc,'말을 가볍게 하는 것과 수치를 낮추는 것은 달랐다')
    paragraph(doc,'아래 표는 원문을 대조한 사후 수치 표현 분석이다. 사전에 고정한 좁은 규칙은 거의 매일을 정확히 7일로 세거나 한 시간 15분을 놓치는 문제가 있었다. 원래 점수는 보존하고, 구간·단위 환산·문맥을 분리한 보조 결과를 별도로 보고한다. 독립 전문가 평가나 새로운 확증 검증은 아니다.')
    labels={'neutral':'무지시','brief':'단순 간결함','minimize_only':'단순 우려 축소','psi_pleasing':'PSI pleasing','sim_pleasing':'PatientSim pleasing'}
    table(doc,['조건별 8응답','단일값 일치','구간 포함','낮은 강도','완화 문구'],[
        [labels[a],f"{d[a]['audited_single_slots']}/24",f"{d[a]['audited_compatible_slots']}/24",
         f"{derived(dd,a)['lower_intensity']}/8",f"{dp[a]['minimization_cue']}/8"] for a in labels
    ],[2.1,1.3,1.2,1.2,1.2],numeric=(1,2,3,4))
    paragraph(doc,'단일값 일치는 강도·빈도·시간의 보고 중심값이 입력과 같은 항목 수다. about 7도 중심값 7로 세며 정밀도를 보증하지 않는다. 구간 포함은 7–8처럼 입력값을 포함한 범위도 허용한다. 낮은 강도는 보고 범위의 상한도 입력 강도보다 낮은 응답이다. 수치 없는 표현은 낮은 값으로 세지 않는다. 완화 문구는 좁은 사전 패턴이며 전체 말투의 강도는 아니다.',small=True)
    paragraph(doc,'PSI에서는 강도 범위가 낮아진 응답이 0/8인데도 단일 수치 일치가 감소했다. 빈도 불확실성과 시간의 근사화 등이 함께 있었다. PatientSim에서는 강도를 낮춘 범위가 4/8에 나타났다. 이는 PatientSim 원문이 underreports symptoms를 요구한다는 점과 함께 해석해야 하며, 연구 과제와 다른 보고 정책이지 그 자체로 원형 시스템 오류는 아니다.')

    heading(doc,'수치를 고정하라는 한 문장만 추가해 보았다')
    paragraph(doc,spec['followup']['added_clause'],small=True)
    table(doc,['새 사례의 조건','단일값 일치','낮은 강도','세 항목 일치','완화 문구'],[
        [label,f"{f[a]['audited_single_slots']}/24",f"{derived(fd,a)['lower_intensity']}/8",f"{derived(fd,a)['full_single']}/8",f"{fp[a]['minimization_cue']}/8"]
        for a,label in [('psi_original','PSI 원형'),('psi_factlock','PSI 제약 추가'),('sim_original','PatientSim 원형'),('sim_factlock','PatientSim 제약 추가')]
    ],[2.1,1.3,1.2,1.2,1.2],numeric=(1,2,3,4))
    paragraph(doc,'PSI는 단일값 일치가 12→18/24개, PatientSim은 7→13/24개로 늘었다. 그러나 세 항목을 모두 보존한 답변은 제약 추가 후에도 각각 3/8과 1/8뿐이었다. 시간 95분을 약 90분, 55분을 약 60분으로 말하는 근사화도 포함하므로, 모든 차이를 의도적 축소나 임상 오류로 해석하지 않는다.')
    paragraph(doc,'원래 고정 규칙의 후속 단일값 일치는 PSI 6→13/24개, PatientSim 4→11/24개였다. 사전 기술적 기준은 PSI만 통과했지만 실제 문맥·환산 오류가 있어 개선 확정의 근거로 쓰지 않았다. 보조 원문 분석도 완전 보존을 보여주지 못했다. PSI는 실험용 후보로만 남기고, 두 소스 모두 안정적인 기본 수치 보존 모드로 채택하지 않았다.',small=True)

    doc.add_page_break()
    heading(doc,'원문에서 확인한 변화와 남은 실패')
    paragraph(doc,'같은 새 인물 Ellis의 입력은 강도 8, 주 4일, 회당 55분이었다. 수치를 직접 묻는 질문과 같은 seed에서 PSI 원형은 다음처럼 말했다.')
    paragraph(doc,'I would say the nervousness is pretty mild, maybe a 5 or 6 out of 10.',small=True)
    paragraph(doc,'제약 추가 답변에는 강도 8과 55분이 나타났고, 같은 원문에 주 4일도 있었다.')
    paragraph(doc,"It's maybe around an 8 out of 10 when it happens, but it doesn't last too long—usually about 55 minutes.",small=True)
    paragraph(doc,'그러나 같은 조건의 PatientSim 제약 추가 답변은 아래처럼 5–6을 유지했다. 문장 하나의 효과가 소스 지시 묶음에 따라 달랐던 직접 비교다.')
    paragraph(doc,'Oh, you know, I’d say they’re pretty mild — maybe a 5 or 6?',small=True)

    heading(doc,'연구 결과를 어떤 주장으로 정리할 것인가')
    paragraph(doc,'이번 연구의 결과는 페르소나가 조현병을 얼마나 잘 재현하는가라는 점수가 아니다. 공개 지시가 묶어 놓은 행동을 발화량·정보 공개·주제 유지·우려 축소로 나누고, 제공 사실과 실제 발화를 연결한 정량적 프로파일이다. 같은 이름의 말투도 숫자 보고와 결합되는 방식이 달랐으며, 단순 제약을 추가해도 두 행동이 완전히 분리되지는 않았다.')
    paragraph(doc,'네 주요 과제의 응답 기록 240개를 보존했으며 이번 생성은 그중 72개다. 동일 문자열의 반복도 포함하므로 고유 텍스트 수가 아니다. 문장과 반복 seed를 독립 환자로 세거나 과제 간 점수를 합산하지 않았다. 원문 72개를 어시스턴트가 대조했지만 독립 사람·임상 평가라고 보고하지 않는다. low energy 답변의 energy level 7처럼 척도 방향이 모호한 표현도 있어 숫자 일치를 임상 의미 일치로 바꾸지 않는다.')

    heading(doc,'다음 의사결정은 추가 생성보다 평가 목표의 확정이다',2)
    paragraph(doc,'우선 이번 코드·원문·실패 결과를 팀에서 검토하고 교수님께 두 가지를 자문한다. 첫째, 이 관찰값들이 임상적으로 어떤 언어 행동에 대응하며 어떤 대응은 부적절한가. 둘째, 조현병 관련 확장에서 문장 간 조직과 질문 대응을 어떤 평가 기준으로 구분할 것인가. 자문을 240개 답변의 임상 검증으로 표현하지 않는다.')
    paragraph(doc,'수치 보존이 필수라면 다음 개선 후보는 사실 상태와 환자의 보고 정책을 분리하는 구조다. 내부의 고정값과 발화에서 의도적으로 축소한 값을 따로 기록하고, 평가는 그 차이를 추적해야 한다. 이는 이번 실패에서 도출한 후속 설계이며 아직 구현·검증한 성과로 세지 않는다. 다른 기반 모델이나 독립 평가의 필요성은 논문 주장을 고정한 뒤 결정한다.')
    cost=main['cost_this_batch']
    paragraph(doc,f"이번 로컬 생성 {cost['wall_seconds']/60:.1f}분  입력 {cost['input_tokens']:,}토큰  출력 {cost['output_tokens']:,}토큰. 유료 API·자동 LLM judge·다운로드·원격 Mac 작업 0회. 이 수치는 로컬 생성량이며 구독 대화 전체의 토큰 사용량은 아니다. 요청·조건·seed·소스 commit·모델 digest·분석 해시를 보존했고 72응답 모두 정상 종료했다.",small=True)
    paragraph(doc,'재현 안내  share/overnight-completion-v01/README.ko.md\n새 실험  analysis/pleasing-discovery-v01  analysis/pleasing-factlock-v01\n통합 결과  analysis/integrated-checkpoint-v05/results.json',small=True)
    plan=read(ROOT/'pilot/runs'/spec['discovery']['run_id']/'plan.json')
    for i,s in enumerate(plan['source_provenance'],1):
        reference(doc,f"[{i}] {s['id']}  고정 commit {s['commit'][:12]}",s['citation_url'])
    SHARE.mkdir(parents=True,exist_ok=True)
    doc.save(OUTPUT)
    write_json(SHARE/'report-inputs.json',{'inputs':{str(p.relative_to(ROOT)):digest(p.read_bytes()) for p in paths.values()},
                                         'output':str(OUTPUT.relative_to(ROOT)),'output_sha256':digest(OUTPUT.read_bytes())})
    print(OUTPUT)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--replace',action='store_true')
    build(parser.parse_args().replace)
