"""Record reviewed raw excerpts and an exhaustive literal-reference-negative audit.

No LLM judge, inference about diagnoses, primary score changes, or error-rate estimate.
"""
from common import digest, write_json
from run_local_pilot import now
from shared_verbosity import OUT, FOLDER, read, conditions


def build():
    rows = read(OUT / 'response-metrics.json')
    cases = {c['condition_id']: c for c in conditions()}
    missing = [r for r in rows if r['requested_refs'] < 4]
    canonical = [r for r in rows if r['profile_id'] == 'V1' and r['target_event'] == 'A']
    reviewed = {r['condition_id']: r for r in missing + canonical}
    # These exact excerpts were read with their full raw replies and source facts.
    examples = [
        {'condition_id': 'SV-V1-QA-R8-psi_verbose',
         'quote': 'with the sound of soft music playing in the background',
         'observation': 'No music is specified in any supplied V1 fact; this is an added concrete setting, not a proven false statement.'},
        {'condition_id': 'SV-V1-QA-R8-psi_verbose',
         'quote': 'I worked with Helena, who was a very encouraging and knowledgeable instructor.',
         'observation': 'Input states only that the person worked with Helena; instructor is an unspecified role.'},
        {'condition_id': 'SV-V1-QA-R9-simple_verbose',
         'quote': 'I remember working with Helena, who was a fellow participant,',
         'observation': 'The simple instruction also adds an unspecified role. This is not a phenomenon demonstrated to be unique to source-derived modules.'},
        {'condition_id': 'SV-V1-QA-R9-neutral',
         'quote': 'which looked really nice in the sunlight.',
         'observation': 'Even the neutral reply adds sunlight; no whole-corpus or between-arm unsupported-fact rate was adjudicated.'}
    ]
    for item in examples:
        row = reviewed[item['condition_id']]
        assert item['quote'] in row['response_text']
        item['input_facts'] = cases[item['condition_id']]['facts']
        item['raw_sha256'] = digest((FOLDER / 'responses' / (item['condition_id']+'.json')).read_bytes())
    negatives = []
    for row in missing:
        ids = [m['fact_id'] for m in row['fact_matches'] if m['domain'] == row['target_event'] and not m['recognized_mention']]
        assert len(ids) == 1 and ids[0] in ('A1', 'B1')
        negatives.append({'condition_id': row['condition_id'], 'unrecognized_fact_ids': ids,
                          'reference_review': 'Full proper venue name not expressed; no observed alternate proper-name wording requiring an alias correction.'})
    result = {'reviewed_at_utc': now(), 'reviewed_response_count': len(reviewed),
              'selection': 'All 11 requested-reference-negative replies plus both seeds of canonical case V1/target A (10 replies), union 21. Examples are qualitative posthoc observations, not a new primary endpoint.',
              'reviewer': 'Assistant source-to-output inspection; not a clinical rating or independent expert adjudication',
              'reviewed_responses': [{'condition_id': key,
                                     'raw_sha256': digest((FOLDER / 'responses' / (key+'.json')).read_bytes())}
                                    for key in sorted(reviewed)],
              'all_reference_negatives': negatives, 'examples': examples,
              'primary_counts_changed': False, 'aliases_added_after_generation': 0,
              'unsupported_fact_rate_estimated': False,
              'report_paragraph': '표식이 누락된 11응답과 모자이크 사례의 두 seed 10응답을 읽어 총 21개를 점검했다. 누락 11건은 모두 장소명이었고 다른 고유 장소 표현은 확인되지 않아 원래 수치를 유지했다. 모자이크 입력은 Helena와 함께 작업했다고만 했지만 PATIENT-Ψ 답변은 강사, 단순 verbose 답변은 동료 참가자로 역할을 보충했다. 무지시 답변에도 햇빛 같은 추가 설정이 있었다. 이는 입력에 없는 구체화의 사례이며, 사실 오류율이나 특정 조건만의 결함으로 집계하지 않았다.'}
    write_json(OUT / 'reference-audit.json', result)
    print({'reviewed': len(reviewed), 'reference_negatives': len(negatives), 'verified_excerpts': len(examples)})


if __name__ == '__main__':
    build()
