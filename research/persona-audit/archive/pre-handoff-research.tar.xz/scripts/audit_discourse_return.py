"""Posthoc lexical bug fix: separate conversational return from physical back to."""
import json
import re

from common import ROOT, digest, write_json
from analyze_topic_trajectory import anchors, freeze

OUT = ROOT / "analysis/topic-trajectory-v01"
SPEC = ROOT / "config/discourse-return-cue-v01.json"


def discourse_cue(text, requested_hits, spec):
    if not requested_hits:
        return False
    return bool(re.search(spec["pattern"], text, re.I) and
                not re.search(spec["exclusion_pattern"], text, re.I))


def build():
    spec = json.loads(SPEC.read_text())
    topic_spec = json.loads((ROOT / "config/topic-trajectory-v01.json").read_text())
    base = json.loads((OUT / "results.json").read_text())
    freeze(OUT / "discourse-cue-plan.json", spec)
    controls = [{**c, "predicted": discourse_cue(c["text"], anchors(c["text"], topic_spec, c["requested_topic"]), spec)}
                for c in spec["controls"]]
    if not all(c["expected"] == c["predicted"] for c in controls):
        raise ValueError("Discourse cue regression control failed")
    replies = []
    for row in base["responses"]:
        matches = [s["index"] for s in row["sentences"] if discourse_cue(s["text"], s["requested_anchor_hits"], spec)]
        replies.append({"condition_id": row["condition_id"], "style": row["style_id"],
                        "broad_back_to_phrase": row["explicit_requested_return_cue"],
                        "narrow_discourse_cue": bool(matches), "sentence_indices": matches,
                        "literal_other_then_requested": row["literal_other_then_requested"],
                        "matches": [s for s in row["sentences"] if s["index"] in matches]})
    summaries = [{"style": style, "replies": 16,
                  "broad_back_to_phrase": sum(r["broad_back_to_phrase"] for r in replies if r["style"] == style),
                  "narrow_discourse_cue": sum(r["narrow_discourse_cue"] for r in replies if r["style"] == style)}
                 for style in ("plain", "verbose", "tangent")]
    result = {"posthoc_refinement": True, "controls": controls, "correct_controls": len(controls),
              "unseen_control_wordings": sum(not c.get("seen_in_generated_outputs", False) for c in controls),
              "scope": "Regression checks for two selected phrase forms and physical movement confounds; not sensitivity on all discourse returns",
              "summaries": summaries, "responses": replies,
              "source_sha256": digest((OUT / "results.json").read_bytes()), "spec_sha256": digest(SPEC.read_bytes()),
              "script_sha256": digest((ROOT / "scripts/audit_discourse_return.py").read_bytes())}
    write_json(OUT / "discourse-return-results.json", result)
    print(json.dumps({"controls_correct": len(controls), "summaries": summaries}, ensure_ascii=False))
    return result


if __name__ == "__main__":
    build()
