"""Generate a bounded original-mapping corpus for automatic feature extraction.

Six original styles x three situations x two repeats x four turns. Local only.
No persona repair, manual rating, prompt improvement, API charges or model pull.
"""
import argparse
import json
import random
import re
import time
import uuid

from common import ROOT, write_json
from local_preflight import MODEL, local_metadata
from prepare_pilot import build_conditions
from run_local_pilot import OPTIONS, chat, classify, fingerprint, now


def conditions():
    rows = []
    for base in build_conditions():
        if base["arm"] != "native_demo_mapping":
            continue
        for repeat in range(2):
            row = dict(base)
            row.update(condition_id=f'F-{base["profile_id"]}-{base["style_id"]}-R{repeat}',
                       base_condition_id=base["condition_id"], repeat_index=repeat)
            rows.append(row)
    if len(rows) != 36:
        raise ValueError("Unexpected source design")
    random.Random(20261030).shuffle(rows)
    return rows


def payload(condition, history, turn):
    if len(history) != 2 * (turn - 1):
        raise ValueError("Incomplete history")
    messages = [{"role": "system", "content": condition["system_prompt"]}] + list(history)
    messages.append({"role": "user", "content": condition["interview"][turn - 1]["text"]})
    if sum(len(m["content"].encode()) for m in messages) + 768 >= OPTIONS["num_ctx"]:
        raise ValueError("Context guard exceeded; no history truncation")
    return {"model": MODEL, "messages": messages, "think": False, "stream": False, "keep_alive": "5m",
            "options": {**OPTIONS, "seed": 20261030 + 100 * condition["repeat_index"] + turn}}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-id", default="native-features-20261030")
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--max-dialogues", type=int, default=36)
    args = parser.parse_args()
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,70}", args.run_id) or not 1 <= args.max_dialogues <= 36:
        parser.error("Invalid run ID or dialogue bound")
    policy = json.loads((ROOT / "config/compute-policy.json").read_text())
    if policy["paid_model_api_allowed"] or policy["automatic_model_download_allowed"]:
        raise ValueError("Unexpected compute policy")
    tags = local_metadata("/api/tags")["models"]
    model = next((r for r in tags if r.get("name") == MODEL), None)
    expected = json.loads((ROOT / "evidence/local-runtime.json").read_text())["ollama"]["candidate_metadata"]["digest"]
    if not model or model["digest"] != expected:
        raise ValueError("Installed model absent or changed; no automatic download/substitution")
    cases = conditions()
    config = {"run_id": args.run_id, "model": MODEL, "model_digest": model["digest"], "options": OPTIONS,
              "think": False, "conditions": [{k: c[k] for k in ["condition_id", "prompt_sha256"]} for c in cases],
              "seed_rule": "20261030 + 100*repeat_index + turn; matched across all styles and situations",
              "spec_sha256": fingerprint(json.loads((ROOT / "config/automatic-features-v01.json").read_text())),
              "scope": "Original demo-mapping prompt port; 1 person, 3 situations, 2 repeats; no clinical labels",
              "user_authorization": "2026-10-30: run full quantitative feature-extraction process locally"}
    folder = ROOT / "pilot/runs" / args.run_id
    if folder.exists():
        if not args.resume or json.loads((folder / "run-config.json").read_text()) != config:
            raise ValueError("Existing run requires identical --resume config")
    else:
        if args.resume:
            raise ValueError("Run does not exist")
        folder.mkdir(parents=True)
        (folder / "requests").mkdir()
        (folder / "responses").mkdir()
        write_json(folder / "run-config.json", config)
        write_json(folder / "conditions.json", cases)
        write_json(folder / "runtime.json", {"model": model, "version": local_metadata("/api/version"),
                                            "show": local_metadata("/api/show", {"model": MODEL})})
    lock = folder / ".running"
    with lock.open("x") as f:
        f.write(now())
    try:
        for index, case in enumerate(cases[:args.max_dialogues], 1):
            history = []
            for question in case["interview"]:
                turn = question["turn"]
                stem = f'{case["condition_id"]}-T{turn}'
                rp, sp = folder / "requests" / (stem + ".json"), folder / "responses" / (stem + ".json")
                request = payload(case, history, turn)
                sha = fingerprint(request)
                if sp.exists():
                    row = json.loads(sp.read_text())
                    if row["request_sha256"] != sha or row["status"] != "completed":
                        raise ValueError("Failed/inconsistent turn; no silent retry")
                else:
                    if rp.exists():
                        raise ValueError("Saved unfinished request requires inspection")
                    request_id, started = str(uuid.uuid4()), now()
                    write_json(rp, {"request_id": request_id, "started_at_utc": started,
                                    "request_sha256": sha, "payload": request})
                    start = time.monotonic()
                    raw, error = {}, None
                    try:
                        raw = chat(request)
                        status = classify(raw)
                    except Exception as exc:
                        status, error = "transport_error", {"type": type(exc).__name__, "message": str(exc)}
                    row = {"run_id": args.run_id, "condition_id": case["condition_id"], "profile_id": case["profile_id"],
                           "style_id": case["style_id"], "arm": case["arm"], "repeat_index": case["repeat_index"],
                           "turn": turn, "probe": question["probe"], "interviewer_text": question["text"],
                           "prompt_sha256": case["prompt_sha256"], "request_sha256": sha, "request_id": request_id,
                           "started_at_utc": started, "ended_at_utc": now(), "wall_seconds": time.monotonic() - start,
                           "provider": "local_ollama", "model_id_requested": MODEL, "model_id_returned": raw.get("model"),
                           "model_digest": model["digest"], "generation_settings": {"think": False, **request["options"]},
                           "status": status, "response_text": raw.get("message", {}).get("content", ""),
                           "finish_reason": raw.get("done_reason"), "raw_response": raw, "error": error,
                           "is_fixture": False, "clinical_rating": None, "is_schizophrenia_case": False,
                           "usage": {k: raw.get(k) for k in ["prompt_eval_count", "eval_count", "eval_duration", "load_duration", "total_duration"]}}
                    write_json(sp, row)
                if row["status"] != "completed":
                    raise ValueError("Failure preserved; inspect before continuing")
                history += [{"role": "user", "content": question["text"]}, {"role": "assistant", "content": row["response_text"]}]
            records = [json.loads(p.read_text()) for p in (folder / "responses").glob("*.json")]
            completed = sum(r["status"] == "completed" for r in records)
            write_json(folder / "progress.json", {"updated_at_utc": now(), "planned_calls": 144, "recorded_calls": len(records),
                                                  "completed_calls": completed, "complete": completed == 144,
                                                  "paid_api_calls": 0, "manual_ratings": 0, "independent_people": 1})
            print(f'{index}/36 {case["condition_id"]}: {completed}/144 completed', flush=True)
    finally:
        lock.unlink(missing_ok=True)


if __name__ == "__main__":
    main()
