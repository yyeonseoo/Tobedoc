"""Computed three-page report and a static outcome plot for the frozen ablation."""
import argparse
import json
from pathlib import Path

from docx import Document
from docx.shared import Pt
from PIL import Image, ImageDraw, ImageFont

from build_integrated_report import font, heading, paragraph, table
from build_two_feature_report import configure
from common import ROOT, digest, write_json
from return_control_ablation import ARMS, MODES, OUT as ANALYSIS, SPEC, block_key

OUT = ROOT / "share/return-control-ablation-v01"
OUTPUT = OUT / "복귀 금지 지시 수정 비교 보고서.docx"
NAMES = {"original": "원형", "clarified": "수정"}
STATUSES = {"insufficient_baseline_returns": "원형의 복귀가 적어 감소 효과를 판정할 여지가 부족함",
            "descriptive_rule_met": "사전에 고정한 감소 기준과 보조 조건을 충족함",
            "descriptive_rule_not_met": "사전에 고정한 감소 기준과 보조 조건을 충족하지 못함"}


def read(path):
    return json.loads(path.read_text())


def select_pair(rows, mode):
    group = [r for r in rows if r["task_mode"] == mode]
    keys = sorted({block_key(r) for r in group})
    # Fixed, direction-neutral selector: first discordant pair, otherwise first pair.
    for key in keys:
        pair = sorted([r for r in group if block_key(r) == key], key=lambda r: ARMS.index(r["arm"]))
        if pair[0]["primary_return"] != pair[1]["primary_return"]:
            return pair
    return sorted([r for r in group if block_key(r) == keys[0]], key=lambda r: ARMS.index(r["arm"]))


def plot(result):
    image = Image.new("RGB", (1100, 840), "white")
    draw = ImageDraw.Draw(image)
    font_path = "/System/Library/Fonts/Supplemental/Arial Unicode.ttf"
    fonts = {s: ImageFont.truetype(font_path,s) for s in (19,21,24,32)}
    ink, muted, grid = "#202B36", "#536171", "#DCE2E8"
    draw.text((40,25), "복귀 금지 절 하나를 바꾼 뒤 행동이 달라졌는가",fill=ink,font=fonts[32])
    draw.text((40,73), "같은 로컬 Qwen3-14B · 과제별 원형 16개와 수정 16개 · 총 64개 생성",fill=muted,font=fonts[21])
    panels = [
        (40,130,"free_reply","other_present_count","자유응답  다른 사건 언급"),
        (590,130,"free_reply","primary_return_count","자유응답  다른 사건 뒤 원래 사건"),
        (40,460,"continuation_challenge","adequate_continuation_count","이어쓰기  다른 사건의 충분한 계속"),
        (590,460,"continuation_challenge","primary_return_count","이어쓰기  원래 사건 다시 언급")]
    for x,y,mode,metric,title in panels:
        draw.text((x,y),title,fill=ink,font=fonts[24])
        left, top, width = x+70,y+62,320
        for tick in (0,4,8,12,16):
            xp = left+width*tick/16
            draw.line((xp,top-8,xp,top+112),fill=grid,width=1)
            draw.text((xp-9,top+128),str(tick),fill=muted,font=fonts[19])
        for i,arm in enumerate(ARMS):
            s = next(s for s in result["by_mode"][mode]["summaries"] if s["arm"] == arm)
            val,yp = s[metric],top+i*65
            draw.text((x,yp+3),NAMES[arm],fill=ink,font=fonts[21])
            if val:
                draw.rectangle((left,yp,left+width*val/16,yp+32),fill="#315F91" if arm=="original" else "#AD5B26")
            draw.text((left+width*val/16+8,yp+2),f"{val}/16",fill=ink,font=fonts[21])
        draw.text((left+130,top+162),"생성 답변 수",fill=muted,font=fonts[19])
    draw.text((40,780),"원래 사건의 문자적 표식을 집계 · 이어쓰기 접두문은 입력이며 생성 데이터에 포함하지 않음",fill=muted,font=fonts[19])
    OUT.mkdir(parents=True,exist_ok=True)
    path = OUT / "return-control-results.png"
    image.save(path)
    return path


def build(replace=False):
    path = ANALYSIS / "results.json"
    result, spec = read(path), read(SPEC)
    audit = read(ANALYSIS / "reference-audit.json")
    if result["completed_requests"] != 64:
        raise ValueError("Only completed fixed-bound experiments can be reported")
    OUT.mkdir(parents=True,exist_ok=True)
    with (ANALYSIS / "response-metrics.jsonl").open("w") as stream:
        for row in result["responses"]:
            flat = {k:row[k] for k in ("condition_id","profile_id","target_event","variant_id","repeat_index",
                    "task_mode","arm","primary_return","other_present","strict_r_o_r","word_count",
                    "requested_fact_count","other_fact_count","adequate_challenge_continuation",
                    "meta_response_flag","complete_prefix_echo","anchor_sequence","stimulus_prefix",
                    "original_question","response_text")}
            stream.write(json.dumps(flat,ensure_ascii=False)+"\n")
    figure = plot(result)
    free, challenge = [result["by_mode"][m] for m in MODES]
    doc = Document()
    configure(doc)
    doc.core_properties.title = "복귀 금지 지시 수정 비교"
    doc.core_properties.subject = "자유응답과 고정 전환 이어쓰기에서의 단일 절 비교"
    doc.core_properties.author = "연구팀"
    doc.core_properties.comments = ""
    p = doc.add_paragraph("복귀 금지 지시 수정 비교",style="Title")
    p.paragraph_format.line_spacing,p.paragraph_format.space_after = Pt(25),Pt(5)
    for r in p.runs:
        font(r,19,True)
    paragraph(doc,"자유응답과 고정 전환 이어쓰기에서의 단일 절 비교",bold=True)
    fsummary = {s['arm']:s for s in free['summaries']}
    csummary = {s['arm']:s for s in challenge['summaries']}
    paragraph(doc,f"복귀 금지 절을 구체화했지만 이번 수정안은 개선으로 채택하지 않았다. 자유응답에서 다른 사건 표식은 {fsummary['original']['other_present_count']}/16에서 {fsummary['clarified']['other_present_count']}/16으로 줄었고, 이미 다른 사건으로 넘어간 이어쓰기에서 원래 사건 재언급은 {csummary['original']['primary_return_count']}/16과 {csummary['clarified']['primary_return_count']}/16으로 같았다.")
    heading(doc,"왜 이 실험을 했나")
    paragraph(doc,"앞선 분석에서 주제 이탈 지시를 받은 답변이 도예 이야기에서 기차 이야기로 옮겨갔다가 다시 도예로 돌아온 사례를 찾았다. 원형 지시는 이탈한 턴 안에서 복귀하지 말라고 명시한다. 이번에는 그 절만 더 구체적으로 표현하면 실제 발화의 복귀가 줄어드는지 시험했다. 더 짧게 말하거나 다른 사건을 아예 말하지 않는 변화를 성공으로 간주하지 않도록 별도 조건을 두었다.")
    heading(doc,"무엇을 바꿨나")
    paragraph(doc,"PATIENT-Ψ 말투 지시를 로컬 Qwen3-14B Q4_K_M에 적용했다. 양쪽 모두 앞선 실험과 동일하게 숫자 문장 상한을 제거했다. 자연스러움·정상적으로 답할 수 있는 턴·신뢰 관련 지시는 그대로 두고, 아래 복귀 금지 절만 교체했다.")
    paragraph(doc,"원형  "+spec["source_clause"],small=True)
    paragraph(doc,"수정  "+spec["replacement_clause"],small=True)
    heading(doc,"어떻게 비교했나")
    paragraph(doc,"미사용 허구 인물 2명에게 천문 관측과 빵 굽기, 카누 대여와 세금 신고 수업의 사건 정보를 주었다. 인물 2개·질문 대상 2종·표현 2종·seed 2개·원형과 수정 2조건을 교차했다. 같은 블록에서는 입력 정보·질문·seed를 맞췄다. 두 과제 각각 32개, 총 64개를 생성 전에 고정했고 결과에 맞춰 확대하지 않았다.")
    table(doc,["과제","답변 수","복귀 표식 집계 위치"],[
        ["자유응답","원형 16  수정 16","생성 답변에서 다른 사건 뒤 원래 사건을 다시 언급했는가"],
        ["고정 전환 이어쓰기","원형 16  수정 16","R에서 O로 넘어간 접두문 이후 생성 부분에 R이 나오는가"]],
        [1.4,1.5,4.1])
    paragraph(doc,"R은 질문한 사건, O는 다른 제공 사건의 고유값 또는 사건 단어다. 이어쓰기 접두문은 연구자가 만든 입력이다. 환자 발화나 모델 생성 결과로 세지 않았고, 자유응답과 이어쓰기를 합산해 하나의 효과로 보고하지 않았다.",small=True)

    doc.add_page_break()
    heading(doc,"무슨 결과가 나왔나")
    table(doc,["과제와 조건","복귀 표식","다른 사건 표식","평균 단어 수"],[
        [f"{'자유응답' if mode=='free_reply' else '이어쓰기'}  {NAMES[s['arm']]}",
         f"{s['primary_return_count']}/16",f"{s['other_present_count']}/16",f"{s['mean_words']:.1f}"]
        for mode in MODES for s in result["by_mode"][mode]["summaries"]], [2.3,1.4,1.7,1.6],numeric=(1,2,3))
    for mode,label in (("free_reply","자유응답"),("continuation_challenge","이어쓰기")):
        b = result["by_mode"][mode]
        c = b["contrasts"]["primary_return"]
        paragraph(doc,f"{label}에서 원형보다 복귀가 줄어든 대응쌍은 {c['reduced']}/16, 늘어난 쌍은 {c['increased']}/16, 같은 쌍은 {c['unchanged']}/16이었다. 사전 판정은 ‘{STATUSES[b['decision']['status']]}’였다.")
    heading(doc,"무엇을 성공으로 정했나",2)
    paragraph(doc,"자유응답은 원형에서 복귀가 최소 2개는 있어야 감소 가능성을 평가했다. 이어쓰기는 원형 복귀가 최소 4개이고 수정 후 순감소가 4개 이상이어야 했다. 이어쓰기에서는 인물과 질문 대상별 복귀가 늘지 않아야 했고, 다른 사건 언급과 충분한 계속 답변의 감소는 각각 최대 2개, 평균 단어 수는 원형의 절반 이상으로 정했다. 임상 기준이나 검정력이 확보된 유의성 검정이 아니라 작은 실험의 기술적 판정선이다.")
    a = {s["arm"]:s for s in challenge["summaries"]}
    paragraph(doc,f"이어쓰기의 ‘충분한 계속’은 8단어 이상이며 다른 사건 표식이 있고, 과제 설명 같은 메타 응답이나 전체 접두문 복사가 없는 답변이다. 원형은 {a['original']['adequate_continuation_count']}/16, 수정은 {a['clarified']['adequate_continuation_count']}/16이었다. 짧거나 비어 있는 답변으로 복귀만 줄어드는 경우를 따로 점검했다.",small=True)
    clean = {s["arm"]:s for s in audit["challenge_non_echo"]}
    paragraph(doc,f"전체 접두문을 복사한 출력은 원형 {a['original']['prefix_echoes']}개, 수정 {a['clarified']['prefix_echoes']}개였다. 이 출력들을 제외한 사후 점검에서도 원래 사건 표식은 원형 {clean['original']['returns']}/{clean['original']['replies']}, 수정 {clean['clarified']['returns']}/{clean['clarified']['replies']}였다. 양쪽 모두 접두문을 복사하지 않은 {audit['common_non_echo_pairs']}대응쌍에서도 각 조건 모두 복귀 표식이 있었다. 주 분석은 바꾸지 않았다.",small=True)
    heading(doc,"어떻게 측정했나",2)
    paragraph(doc,"정해 둔 사건 단어·장소·금액·이름을 토큰 경계와 함께 찾고 문자 위치 순서를 추적했다. 한 문장 안의 사건 전환도 포함했다. 이는 원래 사건의 문자적 재언급 지표다. 임상적 사고장애의 판정이나 모든 의미적 복귀를 포괄하는 점수가 아니다. LLM 채점 없이 Python으로 집계했다.")
    paragraph(doc,"다른 사건이 실제로 등장한 답변만 고른 조건부 복귀율도 보존했지만, 수정 지시 자체가 다른 사건의 등장 여부를 바꿀 수 있으므로 그 하위집단 차이를 인과 효과로 해석하지 않았다. 각 16개 대응쌍을 기본 단위로 보고했다.",small=True)

    doc.add_page_break()
    heading(doc,"실제 생성 결과의 대응 예시")
    pair = select_pair(result["responses"],"continuation_challenge")
    reference = pair[0]
    paragraph(doc,f"이어쓰기에서 블록 정렬상 처음으로 두 조건의 복귀 여부가 다른 쌍을 선택하고, 그런 쌍이 없으면 첫 쌍을 제시하도록 했다. 아래는 {reference['profile_id']}·질문 {reference['target_event']}·{reference['variant_id']}·반복 {reference['repeat_index']}이다. 효과에 유리한 방향만 고르지 않았다.",small=True)
    paragraph(doc,"연구자가 제공한 시작 문장  "+reference["stimulus_prefix"],small=True)
    if all(r["anchor_sequence"].startswith("R") for r in pair):
        paragraph(doc,"제공한 시작 문장은 다른 사건 O로 끝난다. 그러나 원형과 수정 모두 생성문의 첫 표식부터 원래 사건 R로 돌아왔다.",bold=True)
    for row in pair:
        heading(doc,NAMES[row["arm"]]+" 조건",2)
        paragraph(doc,row["response_text"],small=True)
        paragraph(doc,f"입력 R O | 생성 {row['anchor_sequence'] or '표식 없음'}  복귀 표식 {'있음' if row['primary_return'] else '없음'}  {row['word_count']}단어",small=True)
    heading(doc,"결론과 다음 선택",2)
    fs,cs = free["decision"]["status"],challenge["decision"]["status"]
    if fs == "descriptive_rule_met" and cs == "descriptive_rule_met":
        conclusion = "이번 입력과 같은 기반 모델에서는 복귀 금지 절의 구체화가 자유응답과 고정 전환 과제 모두에서 사전 감소 기준을 충족했다. 이제 다른 사건·질문 또는 독립 기반 모델에서 같은 효과가 유지되는지 확인할 후보 수정안이 생겼다."
    elif cs == "descriptive_rule_met":
        conclusion = "이미 다른 사건으로 넘어간 입력을 주었을 때는 수정 지시가 사전 감소 기준을 충족했다. 다만 자유응답에서의 판정은 별개이므로 자연스러운 발화 전체가 개선됐다고 합쳐 결론 내리지 않았다. 고정 전환 이후의 참조 제어와 자발적 사건 전환을 분리해 다음 비교를 설계할 수 있다."
    elif fs == "insufficient_baseline_returns" and cs == "insufficient_baseline_returns":
        conclusion = "두 과제 모두 원형의 복귀가 적어 이번 수정의 감소 효과를 판정할 여지가 부족했다. 이전의 한 사례는 수정 동기가 되었지만 새 입력에서 빈번한 복귀로 재현되지는 않았다. 수정안을 개선으로 채택하기보다, 문제 행동이 안정적으로 나타나는 조건을 확인하는 것이 다음 선택이다."
    else:
        f = {s['arm']:s for s in free['summaries']}
        conclusion = (f"복귀 금지 문구를 구체화해도 의도한 복귀 제어는 개선되지 않았다. 자유응답에서는 다른 사건 표식이 {f['original']['other_present_count']}/16에서 {f['clarified']['other_present_count']}/16으로 줄었다. "
                      f"이미 다른 사건으로 넘어간 이어쓰기에서는 원래 사건 재언급이 {a['original']['primary_return_count']}/16과 {a['clarified']['primary_return_count']}/16으로 같았다. "
                      "따라서 이 수정안을 개선으로 채택하지 않는다. 이탈할지 여부와 이미 이탈한 뒤의 복귀는 서로 다른 제어 대상이라는 결과를 얻었다.")
    paragraph(doc,conclusion)
    paragraph(doc,"자유응답의 유일한 R-O-R은 46달러를 빵 수업 가격으로 혼동했다가 천문 관측 가격으로 다시 말하는 장면이었다. 고유값 재언급과 지속적인 이야기 이탈도 구분해야 한다. 다음은 문구를 더 강하게 반복하기보다, 원래 질문의 정보 요구와 다른 사건을 계속하라는 지시를 분리해 어떤 입력 구조에서 복귀가 생기는지 확인하는 것이다. 다른 시스템과 비교할 때도 이 과제와 측정 단위를 맞춘다.",small=True)
    paragraph(doc,"출처  PATIENT-Ψ 말투 지시 고정 커밋 de72a768. 기반 모델  Qwen3-14B Q4_K_M digest bdbd181c. 입력·원문·표식 위치·실행 설정·사전 판정선은 return-control-ablation-v01에 보존. 새 모델 다운로드·유료 API·LLM 채점은 사용하지 않았다.",small=True)
    if OUTPUT.exists() and not replace:
        raise FileExistsError("Preserve generated draft; use --replace for task-local repairs")
    doc.save(OUTPUT)
    (ANALYSIS / "interpretation.ko.md").write_text(
        "# 복귀 금지 절 수정 실험의 결론\n\n"
        "## 이번 수정안은 채택하지 않는다\n\n"
        + f"자유응답에서 다른 사건 표식은 원형 {fsummary['original']['other_present_count']}/16, 수정 {fsummary['clarified']['other_present_count']}/16이었다. "
        + f"그 뒤 원래 사건 재언급은 {fsummary['original']['primary_return_count']}/16과 {fsummary['clarified']['primary_return_count']}/16이었다. "
        + "원형 복귀가 드물었고 다른 사건 언급 자체도 줄어, 복귀 제어가 개선됐다고 채택하지 않는다.\n\n"
        + f"고정 전환 이어쓰기의 원래 사건 표식은 {csummary['original']['primary_return_count']}/16과 {csummary['clarified']['primary_return_count']}/16으로 같았다. "
        + f"전체 시작 문장 복사를 제외한 사후 점검에서도 원형 {clean['original']['returns']}/{clean['original']['replies']}, 수정 {clean['clarified']['returns']}/{clean['clarified']['replies']}이었다. "
        + f"양쪽 모두 복사하지 않은 {audit['common_non_echo_pairs']}대응쌍에서도 결과는 같았다.\n\n"
        + "## 이 결과의 의미\n\n"
        + "더 구체적으로 쓴 한 절이 자발적 다른 사건 언급에는 영향을 주었지만 이미 전환된 뒤의 원래 사건 참조를 제어하지 못했다. "
        + "문구 강화만 반복하기보다 원래 질문의 정보 요구, 이어쓰기의 입력 구조, 원래 사건을 재언급하는 행동을 분리하는 다음 실험이 적절하다. "
        + "모든 결과는 같은 로컬 기반 모델에 이식한 지시 모듈의 문자적 표식 분석이며 임상적 사고장애 점수가 아니다.\n\n"
        + "## 재현\n\n`python3 scripts/return_control_ablation.py --analyze-only`\n\n"
        + "`python3 scripts/audit_return_control_results.py`\n\n"
        + "응답별 원문과 수치: `response-metrics.jsonl`. 조건·요청·원문 해시는 원 실험 폴더에 보존했다.\n")
    write_json(OUT / "report-inputs.json", {"output_sha256":digest(OUTPUT.read_bytes()),
               "result_sha256":digest(path.read_bytes()), "spec_sha256":digest(SPEC.read_bytes()),
               "audit_sha256":digest((ANALYSIS / "reference-audit.json").read_bytes()),
               "example_pair": [r["condition_id"] for r in pair], "figure_sha256":digest(figure.read_bytes())})
    print(OUTPUT)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replace",action="store_true")
    build(parser.parse_args().replace)
