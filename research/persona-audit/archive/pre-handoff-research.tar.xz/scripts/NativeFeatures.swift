// Local OS-provided NLP only. No networking, asset requests, model pulls or ratings.
import Foundation
import NaturalLanguage

struct TextInput: Decodable { let id: String; let text: String }
struct TokenOutput: Encodable { let text: String; let lemma: String?; let pos: String? }
struct SentenceOutput: Encodable { let text: String; let utf16Start: Int; let utf16Length: Int; let tokens: [TokenOutput]; let vector: [Double]? }
struct TextOutput: Encodable { let id: String; let sentences: [SentenceOutput]; let vector: [Double]? }
struct Export: Encodable {
    let os: String; let embeddingRevision: Int; let embeddingDimension: Int
    let embeddingLanguage: String; let processorCount: Int; let records: [TextOutput]
}

guard CommandLine.arguments.count == 3 else {
    fputs("Usage: NativeFeatures input.json output.json\n", stderr); exit(2)
}
guard let embedding = NLEmbedding.sentenceEmbedding(for: .english, revision: 1) else {
    fputs("English OS embedding is unavailable. No asset download was requested.\n", stderr); exit(3)
}
let input = try JSONDecoder().decode([TextInput].self, from: Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1])))
var result: [TextOutput] = []
for item in input {
    let tokenizer = NLTokenizer(unit: .sentence)
    tokenizer.string = item.text
    tokenizer.setLanguage(.english)
    var sentences: [SentenceOutput] = []
    tokenizer.enumerateTokens(in: item.text.startIndex..<item.text.endIndex) { range, _ in
        let sentence = String(item.text[range])
        if sentence.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return true }
        let tagger = NLTagger(tagSchemes: [.lexicalClass, .lemma])
        tagger.string = sentence
        tagger.setLanguage(.english, range: sentence.startIndex..<sentence.endIndex)
        var tokens: [TokenOutput] = []
        tagger.enumerateTags(in: sentence.startIndex..<sentence.endIndex, unit: .word, scheme: .lexicalClass,
                            options: [.omitWhitespace, .omitPunctuation]) { tag, tokenRange in
            let lemma = tagger.tag(at: tokenRange.lowerBound, unit: .word, scheme: .lemma).0
            tokens.append(TokenOutput(text: String(sentence[tokenRange]), lemma: lemma?.rawValue, pos: tag?.rawValue))
            return true
        }
        let nsRange = NSRange(range, in: item.text)
        sentences.append(SentenceOutput(text: sentence, utf16Start: nsRange.location, utf16Length: nsRange.length, tokens: tokens,
                                        vector: embedding.vector(for: sentence)))
        return true
    }
    result.append(TextOutput(id: item.id, sentences: sentences, vector: embedding.vector(for: item.text)))
}
let export = Export(os: ProcessInfo.processInfo.operatingSystemVersionString,
                    embeddingRevision: embedding.revision, embeddingDimension: embedding.dimension,
                    embeddingLanguage: "en", processorCount: ProcessInfo.processInfo.processorCount, records: result)
let encoder = JSONEncoder()
encoder.outputFormatting = [.sortedKeys]
try encoder.encode(export).write(to: URL(fileURLWithPath: CommandLine.arguments[2]), options: .atomic)
print("Exported \(result.count) text records; OS embedding \(embedding.dimension)D revision \(embedding.revision).")
