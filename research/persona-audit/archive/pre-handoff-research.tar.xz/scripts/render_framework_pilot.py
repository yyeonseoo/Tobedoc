"""Reuse the existing native static plotting backend, no new dependencies."""
import json
from pathlib import Path
import subprocess
import tempfile

from common import ROOT,write_json
from run_framework_pilot import RUN
from analyze_framework_pilot import OUT,PROGRAMS


def main():
    rows=json.loads((ROOT/"analysis/automatic-features-v01"/RUN/"dialogue-features.json").read_text())
    groups=[(p,s) for p in PROGRAMS for s in ["plain","verbose"]]
    panels=[]
    for feature,title,unit in [("word_count","Response length","Words / response"),
                              ("mattr20","Fixed-window lexical diversity","MATTR20 proportion"),
                              ("adjacent_cos_mean","Adjacent-sentence similarity","Cosine similarity"),
                              ("question_answer_cos","Question-reply similarity","Cosine similarity")]:
        values=[[r["feature_means"][feature] for r in rows if r["arm"]==p and r["style_id"]==s and r["feature_means"][feature] is not None] for p,s in groups]
        if all(values):
            panels.append({"title":title,"unit":unit,"values":values})
    if not panels:
        raise ValueError("No complete plot panels")
    data={"title":"Cross-source style modules on Qwen3-14B: development pilot",
          "subtitle":"Base = simple; PSI = PATIENT style; Sim = PatientSim personality. P = plain, V = verbose. Not native frameworks.",
          "styles":["Base-P","Base-V","PSI-P","PSI-V","Sim-P","Sim-V"],"panels":panels,
          "caption":"Source: framework-pilot-20261030. Bars: means; dots: invented case means (up to 3/cell). Missing omitted. Matched contrasts use common turns."}
    write_json(OUT/"plot-input.json",data)
    with tempfile.TemporaryDirectory(prefix="persona-framework-plot-") as tmp:
        binary=str(Path(tmp)/"plot")
        subprocess.run(["/usr/bin/swiftc","-module-cache-path",str(Path(tmp)/"modules"),str(ROOT/"scripts/PlotFeatures.swift"),"-o",binary],check=True,capture_output=True)
        subprocess.run([binary,str(OUT/"plot-input.json"),str(OUT/"feature-profiles.png")],check=True,capture_output=True)
    print("Saved static descriptive plot; not clinical ratings.")


if __name__=="__main__":
    main()
