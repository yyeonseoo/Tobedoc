"""Finite typed numeric and minimization-formula measures with exact raw clauses.

Not a severity, truthfulness, or clinical downplaying classifier. Unknown wording
and intentionally excluded contexts remain available for source-text review.
"""
import re

SMALL='zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen'.split()
TENS={'twenty':20,'thirty':30,'forty':40,'fifty':50,'sixty':60,'seventy':70,'eighty':80,'ninety':90}
NUM_WORDS=r'\b(?:'+'|'.join(TENS)+r')(?:[- ](?:'+'|'.join(SMALL[1:10])+r'))?\b|\b(?:'+'|'.join(SMALL)+r')\b'
VALUE=r'(?P<value>\d+(?:\.\d+)?)'
PATTERNS={
    'intensity':[VALUE+r'\s*(?:/\s*10|out of\s*10)\b',
                 r'\b(?:intensity|severity|rating)\s*(?:(?:is|of|at)\s*|:\s*)?'+VALUE+r'\b',
                 r'\b(?:rate|rated)(?:\s+(?:it|them|as|at|a|an|about|around|maybe)){0,4}\s+'+VALUE+r'\b'],
    'frequency':[VALUE+r'\s*days?\s*(?:a|per|each|in a|out of(?: the)?)\s*(?:week|7 days)\b',r'\b(?P<daily>daily|every day)\b'],
    'duration':[VALUE+r'\s*(?P<unit>minutes?|mins?|hours?|hrs?)\b']
}
CUE=re.compile(r"\b(?:not (?:really )?(?:a big deal|that bad|too bad|a serious problem|worried)|no big deal|nothing (?:too )?(?:serious|major)|manageable|(?:just|only) (?:a little|minor|mild)|minor(?: issue|problem|symptom)?|mild(?: symptom)?|no need to worry|nothing to worry about)\b",re.I)


def normalize(text):
    s=text.lower().replace('’',"'").replace('“','"').replace('”','"')
    s=re.sub(r'\ban? hour and (?:a )?half\b','90 minutes',s)
    s=re.sub(r'\bhalf an hour\b','30 minutes',s)
    s=re.sub(r'\b(?:a )?quarter (?:of an )?hour\b','15 minutes',s)
    def number(m):
        parts=m.group().replace('-',' ').split()
        return str(TENS[parts[0]]+(SMALL.index(parts[1]) if len(parts)==2 else 0) if parts[0] in TENS else SMALL.index(parts[0]))
    s=re.sub(NUM_WORDS,number,s)
    s=re.sub(r'\b(?:an?|one) hour\b','1 hour',s)
    # Combine hours + minutes before matching so 1 hour and 15 minutes is one 75-minute value.
    s=re.sub(r'\b(\d+(?:\.\d+)?)\s*hours?\s*(?:and\s*)?(\d+(?:\.\d+)?)\s*minutes?\b',
             lambda m:str(float(m[1])*60+float(m[2]))+' minutes',s)
    return s


def clauses(text):
    start=0
    for m in re.finditer(r'(?<!\d)[.!?;](?!\d)["”]?|\n',text):
        end=m.end()
        if text[start:end].strip():
            yield start,end,text[start:end]
        start=end
    if text[start:].strip():
        yield start,len(text),text[start:]


def excluded_context(normalized,start,end):
    normalized=normalized.replace('“','"').replace('”','"')
    prefix=normalized[:start]
    if any(m.start()<=start<m.end() for m in re.finditer(r'"[^"\n]+"',normalized)):
        return 'quoted'
    if normalized.rstrip().endswith('?'):
        return 'question'
    if re.search(r'\b(?:if|suppose|imagine)\b',prefix):
        return 'conditional'
    if re.search(r'\b(?:you (?:said|say)|the (?:doctor|interviewer) (?:said|says)|used to|previously)\b',prefix):
        return 'reported_or_historical'
    if re.search(r"\b(?:not|isn't|wasn't|is not|was not)\s+(?:(?:a|an|at|around|about)\s+)?$",prefix):
        return 'negated'
    if (re.search(r'\b\d+(?:\.\d+)?\s*(?:-|to|or|and)\s*$',prefix)
            and not re.search(r'(?:/\s*10|out of\s*10)\s+(?:and|or)\s*$',prefix)):
        return 'range_or_alternative'
    return None


def numeric_claims(text):
    found=[]
    for start,end,raw in clauses(text):
        s=normalize(raw)
        for slot,patterns in PATTERNS.items():
            occupied=[]
            for pattern in patterns:
                for m in re.finditer(pattern,s):
                    if any(a<m.end() and m.start()<b for a,b in occupied):
                        continue
                    occupied.append(m.span())
                    value=7. if m.groupdict().get('daily') else float(m['value'])
                    if slot=='duration' and m.groupdict().get('unit','').startswith(('hour','hr')):
                        value*=60
                    reason=excluded_context(s,m.start(),m.end())
                    if slot=='intensity' and not 0<=value<=10:
                        reason='outside_scale'
                    if slot=='frequency' and not 0<=value<=7:
                        reason='outside_days_per_week'
                    found.append({'slot':slot,'value':value,'normalized_match':m.group(),
                                  'raw_clause':raw,'raw_start':start,'raw_end':end,
                                  'excluded_reason':reason,'approximate':bool(re.search(r'\b(?:about|around|roughly|maybe|approximately)\s*$',s[:m.start()]))})
    return found


def minimization_cues(text):
    found=[]
    for start,end,raw in clauses(text):
        for m in CUE.finditer(raw):
            reason=excluded_context(raw.lower(),m.start(),m.end())
            found.append({'span':m.group(),'start':start+m.start(),'end':start+m.end(),
                          'raw_clause':raw,'excluded_reason':reason})
    return found


def measure(text,expected):
    claims=numeric_claims(text)
    slots={}
    for slot in PATTERNS:
        values=[c['value'] for c in claims if c['slot']==slot and not c['excluded_reason']]
        target=expected[slot]
        slots[slot]={'expected':target,'values':values,'correct':bool(values) and all(v==target for v in values),
                     'nonmatching':any(v!=target for v in values),'lower':any(v<target for v in values),
                     'higher':any(v>target for v in values),'missing':not values}
    cues=minimization_cues(text)
    return {'correct_slots':sum(s['correct'] for s in slots.values()),
            'nonmatching_slots':sum(s['nonmatching'] for s in slots.values()),
            'any_nonmatching':int(any(s['nonmatching'] for s in slots.values())),
            'lower_slots':sum(s['lower'] for s in slots.values()),
            'missing_slots':sum(s['missing'] for s in slots.values()),
            'minimization_cue':int(any(not c['excluded_reason'] for c in cues)),
            'claims':claims,'slots':slots,'cue_spans':cues}


def controls():
    # Hand-authored implementation fixtures, not patient text or independent clinical labels.
    examples=[
      ('8/10, six days a week, 45 minutes.',3,0,0),
      ('Nothing serious: eight out of ten, 6 days per week, forty-five minutes.',3,0,1),
      ('It is mild, 3/10, 2 days a week, 15 minutes.',0,1,1),
      ('It is not a big deal.',0,0,1),
      ('Not mild; 8/10, 6 days a week, 45 minutes.',3,0,0),
      ('If it were 3/10, 2 days a week, 15 minutes, I would be fine.',0,0,0),
      ('"It is mild, 3/10, 2 days a week, 15 minutes."',0,0,0),
      ('You said 3/10 and 2 days a week, 15 minutes.',0,0,0),
      ('Was it 3/10 and 2 days per week, 15 minutes?',0,0,0),
      ('I used to have 3/10 discomfort for 15 minutes.',0,0,0),
      ('Not 3/10; 8/10, 6 days a week, 45 minutes.',3,0,0),
      ('8/10 but sometimes 3/10, 6 days per week, 45 minutes.',2,1,0),
      ('8/10, daily, 45 minutes.',2,1,0),
      ('8/10, 6 times a week, 45 minutes.',2,0,0),
      ('8/10, 6 days a week, half an hour.',2,1,0),
      ('8/10, 6 days a week, an hour and a half.',2,1,0),
      ('8/10, 6 days a week, one hour and fifteen minutes.',2,1,0),
      ('Intensity is 8, 6 days a week, 45 minutes.',3,0,0),
      ("I would rate it about 8, 6 days a week, 45 minutes.",3,0,0),
      ('About 8/10, around 6 days a week, roughly 45 minutes.',3,0,0),
      ('8/10, between 4 and 6 days a week, 30 to 45 minutes.',1,0,0),
      ('7 or 8/10, 6 days a week, 45 minutes.',2,0,0),
      ('The scale is 0 to 10. It happens 6 days a week for 45 minutes.',2,0,0),
      ('I am 28 years old; it was 45 dollars.',0,0,0),
      ("It is not manageable. 8/10, 6 days a week, 45 minutes.",3,0,0),
      ('I have no need to worry; 8/10, 6 days a week, 45 minutes.',3,0,1),
      ('It is 12/10, 9 days per week and 45 minutes.',1,0,0),
      ('8/10 and 7/10, 6 days a week, 45 minutes.',2,1,0)
    ]
    expected={'intensity':8,'frequency':6,'duration':45}
    result=[]
    for i,(text,correct,nonmatching,cue) in enumerate(examples,1):
        actual=measure(text,expected)
        result.append({'id':f'PM{i:02d}','text':text,'expected':[correct,nonmatching,cue],
                       'actual':[actual['correct_slots'],actual['any_nonmatching'],actual['minimization_cue']],
                       'passed':[correct,nonmatching,cue]==[actual['correct_slots'],actual['any_nonmatching'],actual['minimization_cue']]})
    return result
