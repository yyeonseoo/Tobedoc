"""Fictional fact-mention probe: plain vs brief vs PSI reserved, 18 first replies."""
import argparse
import json
import random
import re
from collections import defaultdict
from statistics import mean

from audit_sources import parse_styles
from common import ROOT, digest, read_source, source_records, write_json
from first_reply_probe_runner import run, verify_response
from reserved_length_factorial import question_paragraph_flag
from run_feature_batch import payload
from run_local_pilot import OPTIONS, fingerprint, now
from summarize_local_pilot import text_metrics

SPEC = ROOT / "config/fact-disclosure-probe-v01.json"
RUN = "fact-disclosure-probe-v01"
FOLDER = ROOT / "pilot/runs" / RUN
OUT = ROOT / "analysis" / RUN


def normalize(text):
    return re.sub(r"\s+", " ", text.lower().replace("–", " ").replace("-", " ").replace("’", "'")).strip()


def match_fact(text, fact):
    normalized = normalize(text)
    hits = []
    for alias in fact["aliases"]:
        pattern = r"(?<![\w.])" + re.escape(normalize(alias)) + r"(?!\w|\.\d|,\d)"
        for hit in re.finditer(pattern, normalized):
            context = normalized[max(0, hit.start()-45):hit.end()+55]
            hits.append({"alias": alias, "normalized_start": hit.start(), "normalized_end": hit.end(),
                         "context": context,
                         "negation_nearby_flag": bool(re.search(r"\b(not|never|isn't|wasn't|don't|won't|can't)\b", context))})
    return {"fact_id": fact["id"], "domain": fact["domain"], "recognized_mention": bool(hits), "matches": hits}


def conditions():
    spec = json.loads(SPEC.read_text())
    reserved = parse_styles(read_source("psi_styles"))["reserved"]
    reserved, removed = re.subn(r"But you must not exceed 3 sentences each turn\.\s*", "", reserved)
    if removed != 1:
        raise ValueError("Source style schema changed")
    styles = {"plain": "", "brief_only": "Give brief, concise answers.", "psi_reserved_no_numeric_cap": reserved}
    rows, rng = [], random.Random(20261030)
    blocks = [(case, repeat) for case in spec["fictional_cases"] for repeat in range(spec["repeats"])]
    rng.shuffle(blocks)
    for case, repeat in blocks:
        questions = [spec["event_question"], spec["personal_question"]]
        if repeat == 1:
            questions.reverse()
        question = " ".join(questions)
        group = []
        for style in spec["style_arms"]:
            prompt = (f"You are {case['name']}, a fictional adult. This is a simulation, not a real patient or a diagnosis.\n"
                      "These supplied facts describe the community event and your household situation:\n"
                      + "\n".join(f["description"] for f in case["facts"]) + "\nConversation style:\n" + styles[style]
                      + "\nUse only the supplied facts. Do not invent facts or a diagnosis. Respond in natural English as this person. "
                      "Write only this person's reply, not interviewer turns or stage directions.")
            row = {"condition_id": f"D-{case['id']}-R{repeat}-{style}", "profile_id": case["id"], "repeat_index": repeat,
                   "style_id": style, "arm": style, "system_prompt": prompt, "facts": case["facts"],
                   "interview": [{"turn": 1, "probe": "event_and_bill_facts", "text": question}]}
            row["prompt_sha256"] = fingerprint({"system_prompt": prompt, "interview": row["interview"]})
            group.append(row)
        rng.shuffle(group)
        rows.extend(group)
    if len(rows) != spec["max_requests"] or len(rows) != 18:
        raise ValueError("Probe request ceiling changed")
    return rows


def prepare():
    rows = conditions()
    plan = {"run_id": RUN, "max_requests": 18, "scope": "Three invented nonclinical adults, two seeds, three instruction arms, one reply each",
            "research_question": "Does the reserved instruction bundle reduce personal fact mentions more than a brevity-only instruction?",
            "primary": "Within-block reserved-minus-brief_only difference in recognized personal fact fraction (3 facts per reply)",
            "specificity_contrast": "(personal-event mention fraction)_reserved minus (personal-event mention fraction)_brief_only",
            "secondary": "All six fact mentions, event mentions, word counts, plain comparisons; no clinical scores",
            "hypothesis_before_generation": "Reserved may reduce personal mentions relative to brief_only; selectivity is not assumed",
            "recognition_contract": "Frozen finite aliases and token-boundary matches; detects references, not factual correctness, semantic entailment, intentional withholding or clinical guardedness. Negated mentions may match; inspect context flags.",
            "domain_limit": "Event vs personal-bill content is an operational contrast, not a validated sensitivity scale; fact types differ",
            "analysis": "Six paired case-by-seed blocks, equal weights; no population p-values. Word counts are not forced equal.",
            "order": "Domain question order reversed at repeat 1, matched across styles; order and seed effects cannot be separated",
            "limits": "No sentence cap; same 512-token technical ceiling. Reserved retains brevity/vagueness/trust instructions and may act normally in some turns. Not native PSI replication.",
            "stopping": "18 requests maximum; preserve and stop on error/truncation; no retries, replacement, new cases or posthoc alias expansion",
            "options": OPTIONS, "think": False, "seed_rule": "20261030+100*repeat_index+1, matched across styles",
            "model_digest": json.loads((ROOT / "evidence/local-runtime.json").read_text())["ollama"]["candidate_metadata"]["digest"],
            "spec_sha256": digest(SPEC.read_bytes()), "conditions_sha256": fingerprint(rows),
            "source": source_records()["psi_styles"]["citation_url"]}
    for name, obj in [("plan.json", plan), ("conditions.json", rows)]:
        path = FOLDER / name
        if path.exists():
            if json.loads(path.read_text()) != obj:
                raise ValueError("Frozen probe changed; never overwrite")
        else:
            write_json(path, obj)
    if not (FOLDER / "prepared-at.json").exists():
        write_json(FOLDER / "prepared-at.json", {"prepared_at_utc": now(), "plan_sha256": fingerprint(plan)})
    return plan, rows


def paired(rows, arm, baseline, domain):
    blocks = defaultdict(dict)
    for row in rows:
        if row["style_id"] in (arm, baseline):
            value = row["fraction"][domain] if domain != "personal_minus_event" else row["fraction"]["personal"]-row["fraction"]["event"]
            blocks[(row["profile_id"], row["repeat_index"])][row["style_id"]] = value
    if len(blocks) != 6 or any(set(v) != {arm, baseline} for v in blocks.values()):
        raise ValueError("Missing matched block")
    changes = [v[arm]-v[baseline] for v in blocks.values()]
    return {"mean": mean(changes), "block_differences": changes, "positive": sum(v > 0 for v in changes),
            "negative": sum(v < 0 for v in changes), "zero": sum(v == 0 for v in changes)}


def analyze():
    plan, cases = prepare()
    rows, provenance = [], [SPEC, FOLDER / "plan.json", FOLDER / "conditions.json", FOLDER / "runtime.json"]
    for case in cases:
        rp = FOLDER / "requests" / (case["condition_id"] + ".json")
        sp = FOLDER / "responses" / (case["condition_id"] + ".json")
        raw, request = json.loads(sp.read_text()), json.loads(rp.read_text())
        verify_response(raw, request, case, plan["model_digest"])
        found = [match_fact(raw["response_text"], f) for f in case["facts"]]
        counts = {d: sum(f["recognized_mention"] for f in found if f["domain"] == d) for d in ("event", "personal")}
        rows.append({"condition_id": case["condition_id"], "profile_id": case["profile_id"], "repeat_index": case["repeat_index"],
                     "style_id": case["style_id"], "count": counts, "fraction": {d: n/3 for d, n in counts.items()},
                     "fact_matches": found, "text_metrics": text_metrics(raw["response_text"]), "response_text": raw["response_text"],
                     "question_paragraph_flag": question_paragraph_flag(raw["response_text"])})
        provenance += [rp, sp]
    summaries = []
    for style in json.loads(SPEC.read_text())["style_arms"]:
        subset = [r for r in rows if r["style_id"] == style]
        if len(subset) != 6:
            raise ValueError("Incomplete arm")
        summaries.append({"style": style, "replies": 6, "personal_mentions": sum(r["count"]["personal"] for r in subset),
                          "event_mentions": sum(r["count"]["event"] for r in subset), "denominator_per_domain": 18,
                          "mean_words": mean(r["text_metrics"]["word_count"] for r in subset)})
    contrasts = {"reserved_minus_brief_personal": paired(rows, "psi_reserved_no_numeric_cap", "brief_only", "personal"),
                 "reserved_minus_brief_selectivity": paired(rows, "psi_reserved_no_numeric_cap", "brief_only", "personal_minus_event"),
                 "reserved_minus_plain_personal": paired(rows, "psi_reserved_no_numeric_cap", "plain", "personal")}
    result = {"plan": plan, "actual_responses": len(rows), "summaries": summaries, "contrasts": contrasts, "responses": rows,
              "provenance": [{"path": str(p.relative_to(ROOT)), "sha256": digest(p.read_bytes())} for p in provenance]}
    write_json(OUT / "results.json", result)
    lines = ["# 짧은 답변과 정보 언급의 분리 실험", "",
             "실제 허구 사례 3개×seed 2개×말투 3개, 총 18개 첫 답변. 조현병이나 임상적 경계심의 판정이 아니다.", "",
             "## 무엇을 했나", "",
             "행사 정보 3개(장소·입장료·좌석 수)와 개인 청구서 정보 3개(종류·금액·연체 일수)를 프로필에 주고 모두 질문했다. "
             "말투 없음 / 간결하게 답하기 / PSI reserved의 숫자 문장 제한만 제거한 지시를 같은 Qwen에서 비교했다. 별도 문장 수 제한은 넣지 않았다.", "",
             "## 실제 관찰", ""]
    for s in summaries:
        lines.append(f"- {s['style']}: 개인 정보 표현 {s['personal_mentions']}/18, 행사 정보 표현 {s['event_mentions']}/18 식별; 평균 {s['mean_words']:.1f}단어.")
    lines += ["", "개인 정보 언급 비율의 reserved−간결 대조군 차이: "
              f"{contrasts['reserved_minus_brief_personal']['mean']:+.3f}. 개인−행사 차이의 조건 간 차이: "
              f"{contrasts['reserved_minus_brief_selectivity']['mean']:+.3f}. 모두 같은 사례·seed 안에서 짝지은 기술값이다.", "",
              "## 해석 경계", "",
              "사전에 고정한 표현 목록으로 정보의 문자적 언급을 찾았다. 같은 뜻의 다른 표현을 놓치거나 부정된 수치를 셀 수 있어 의미적 정답률이 아니다. "
              "원문과 일치 구간·주변 문맥을 results.json에 보존한다. 정보 누락에는 회피뿐 아니라 재표현·질문 이해·일반적인 간결함 등이 섞일 수 있다. "
              "개인 청구서와 행사 정보는 사실 유형도 다르므로 차이를 심리적 민감성 하나로 설명할 수 없다. "
              "세 허구 인물과 한 기반 모델의 결과이며, 실제 환자 행동·진단 특이성·임상적 경계심의 검증은 아니다.", "",
              "## 고정 사례 원문", "", "효과 크기를 보지 않고 C1 / 반복 0의 세 조건을 모두 제시한다.", ""]
    for r in sorted(rows, key=lambda x: x["style_id"]):
        if r["profile_id"] == "C1" and r["repeat_index"] == 0:
            lines += [f"### {r['style_id']}", "", r["response_text"], ""]
    lines += ["## 재현", "", "`python3 scripts/fact_disclosure_probe.py --analyze-only`는 저장된 출력만 재분석한다. "
              "`--run`은 18회 로컬 생성을 실행하며 기존 결과가 있으면 덮어쓰지 않는다. 재개는 동일 조건의 `--run --resume`만 허용한다.", ""]
    (OUT / "report.ko.md").write_text("\n".join(lines))
    print(json.dumps({"completed": len(rows), "summaries": summaries, "contrasts": {k: v["mean"] for k, v in contrasts.items()}}, ensure_ascii=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--run", action="store_true")
    mode.add_argument("--analyze-only", action="store_true")
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    if args.analyze_only:
        analyze()
    elif args.run:
        plan, cases = prepare()
        run(plan, cases, FOLDER, args.resume)
        analyze()
    else:
        plan, _ = prepare()
        print(json.dumps(plan, ensure_ascii=False))
