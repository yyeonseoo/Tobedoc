"""Bounded local-only contextual topic annotation, gated on authored controls."""
import argparse
from collections import defaultdict
import json
from pathlib import Path
from statistics import mean
import time

from common import ROOT, digest, write_json
from analyze_topic_trajectory import freeze, make_controls, other_topic, sequence_metrics
from local_preflight import MODEL, local_metadata
from run_local_pilot import chat, classify as response_status, fingerprint, now
from topic_selection_probe import paired

SPEC = ROOT / "config/context-topic-labeler-v01.json"
OUT = ROOT / "analysis/context-topic-labeler-v01"
BASE = ROOT / "analysis/topic-trajectory-v01/results.json"
LABELS = ("R", "O", "N", "M", "U")
SCHEMA = {"type": "object", "properties": {"labels": {"type": "array", "items": {
    "type": "object", "properties": {"id": {"type": "integer"}, "label": {"type": "string", "enum": list(LABELS)}},
    "required": ["id", "label"], "additionalProperties": False}}}, "required": ["labels"], "additionalProperties": False}


def read(path):
    return json.loads(path.read_text())


def requests(spec, topic_spec, base):
    cases = read(ROOT / "config/topic-selection-probe-v01.json")["fictional_cases"]
    def context(topic):
        info = topic_spec["topics"][topic]
        case = next(c for c in cases if c["id"] == info["case"])
        return {"requested_event": case["events"][info["event"]],
                "other_event": case["events"]["B" if info["event"] == "A" else "A"]}
    jobs = []
    controls = make_controls(topic_spec)
    for split in ("development", "holdout"):
        for topic in topic_spec["topics"]:
            group = [c for c in controls if c["split"] == split and c["topic"] == topic]
            jobs.append({"id": f"{split}-{topic}", "phase": split,
                         "input": {**context(topic), "mode": "independent", "sentences": [{"id": i+1, "text": c["text"]} for i, c in enumerate(group)]},
                         "expected": ["N" if c["expected"] == "D" else "M" if c["expected"] == "B" else c["expected"] for c in group]})
    for topic, group in spec["connected_controls"].items():
        jobs.append({"id": f"connected-{topic}", "phase": "connected_control",
                     "input": {**context(topic), "mode": "connected", "sentences": [{"id": i+1, "text": c["text"]} for i,c in enumerate(group)]},
                     "expected": [c["expected"] for c in group]})
    # Fixed response order; style names are not included in any model input.
    for row in sorted(base["responses"], key=lambda r: fingerprint(r["condition_id"])):
        jobs.append({"id": "reply-"+fingerprint(row["condition_id"])[:16], "phase": "existing_reply",
                     "condition_id": row["condition_id"],
                     "input": {**context(row["topic"]), "mode": "connected", "question": row["question"],
                               "sentences": [{"id": s["index"], "text": s["text"]} for s in row["sentences"]]}})
    if len(jobs) != spec["maximum_requests"]:
        raise ValueError("Request bound changed")
    return jobs


def payload(job, spec):
    return {"model": spec["model"], "messages": [{"role": "system", "content": spec["system_prompt"]},
            {"role": "user", "content": json.dumps(job["input"], ensure_ascii=False)}],
            "think": False, "stream": False, "keep_alive": "5m", "format": SCHEMA, "options": spec["options"]}


def parse_labels(raw, job):
    if response_status(raw) != "completed":
        raise ValueError("Failed/truncated local annotation preserved")
    labels = json.loads(raw["message"]["content"])["labels"]
    ids = [s["id"] for s in job["input"]["sentences"]]
    if [r.get("id") for r in labels] != ids or any(r.get("label") not in LABELS for r in labels):
        raise ValueError("Missing, duplicate, reordered or invalid sentence labels")
    return [r["label"] for r in labels]


def metrics(records):
    matrix = {a: {b: 0 for b in LABELS} for a in LABELS}
    for r in records:
        matrix[r["expected"]][r["predicted"]] += 1
    by_label = {}
    for c in LABELS:
        tp, actual, predicted = matrix[c][c], sum(matrix[c].values()), sum(matrix[a][c] for a in LABELS)
        p, r = tp/predicted if predicted else 0, tp/actual if actual else 0
        by_label[c] = {"actual": actual, "predicted": predicted, "precision": p, "recall": r,
                       "f1": 2*p*r/(p+r) if p+r else 0}
    known = [r for r in records if r["expected"] in ("R", "O")]
    return {"items": len(records), "unique_texts": len({r["text"] for r in records}),
            "accuracy": mean(r["expected"] == r["predicted"] for r in records),
            "macro_f1": mean(s["f1"] for s in by_label.values() if s["actual"]), "classes": by_label,
            "known_topic_recall": mean(r["expected"] == r["predicted"] for r in known),
            "errors": [r for r in records if r["expected"] != r["predicted"]], "confusion_matrix": matrix}


def control_gate(jobs, outputs, spec):
    records = [{"job": job["id"], "phase": job["phase"], "text": s["text"], "expected": expected, "predicted": predicted}
               for job in jobs if job["phase"] != "existing_reply" and job["id"] in outputs
               for s, expected, predicted in zip(job["input"]["sentences"], job["expected"], outputs[job["id"]])]
    scores = {phase: metrics([r for r in records if r["phase"] == phase]) for phase in ("development", "holdout", "connected_control")}
    g, h = spec["control_gate"], scores["holdout"]
    passed = (h["macro_f1"] >= g["holdout_macro_f1_min"] and h["known_topic_recall"] >= g["holdout_known_topic_recall_min"]
              and h["classes"]["N"]["precision"] >= g["holdout_new_topic_precision_min"]
              and scores["connected_control"]["accuracy"] >= g["connected_control_accuracy_min"])
    return {"passed": passed, "scores": scores, "records": records}


def analyze(spec, jobs, outputs, base, gate):
    by_condition = {j["condition_id"]: outputs[j["id"]] for j in jobs if j["phase"] == "existing_reply" and j["id"] in outputs}
    rows = []
    for row in base["responses"]:
        if row["condition_id"] not in by_condition:
            continue
        labels = by_condition[row["condition_id"]]
        # M is not forced into either R or N; report a separate ambiguity interval.
        mapped = ["D" if x == "N" else x for x in labels]
        metrics_sequence = sequence_metrics(mapped)
        s = [{**sentence, "context_label": label} for sentence, label in zip(row["sentences"], labels)]
        rows.append({**{k: row[k] for k in ("condition_id", "profile_id", "target_event", "variant_id", "repeat_index", "style_id", "word_count", "sentence_count", "question", "response_text")},
                     "sentences": s, "sequence": " ".join(labels), "new_topic_present": "N" in labels,
                     "other_topic_present": "O" in labels, "mixed_present": "M" in labels,
                     "new_topic_sentence_fraction": labels.count("N")/len(labels),
                     "mixed_sentence_fraction": labels.count("M")/len(labels),
                     "unresolved_sentence_fraction": labels.count("U")/len(labels),
                     "off_requested_excluding_mixed_fraction": sum(x in ("N", "O") for x in labels)/len(labels),
                     "return_after_away": metrics_sequence["requested_away_requested"],
                     "label_changes": metrics_sequence["definite_label_changes"]})
    summaries = []
    for style in ("plain", "verbose", "tangent"):
        group = [r for r in rows if r["style_id"] == style]
        if not group:
            continue
        summaries.append({"style": style, "replies": len(group),
                          **{metric: sum(r[metric] for r in group) for metric in ("new_topic_present", "other_topic_present", "mixed_present", "return_after_away")},
                          **{"mean_"+metric: mean(r[metric] for r in group) for metric in
                             ("new_topic_sentence_fraction", "mixed_sentence_fraction", "unresolved_sentence_fraction", "off_requested_excluding_mixed_fraction", "label_changes")}})
    contrasts = {m: paired(rows, "tangent", "verbose", m) for m in
                 ("new_topic_sentence_fraction", "off_requested_excluding_mixed_fraction", "return_after_away")} if len(rows) == 48 else {}
    result = {"analysis_id": spec["analysis_id"], "control_gate": gate, "annotated_existing_replies": len(rows),
              "annotated_sentences": sum(r["sentence_count"] for r in rows), "new_persona_replies": 0,
              "summaries": summaries, "tangent_minus_verbose": contrasts, "responses": rows,
              "scope": spec["role"], "spec_sha256": digest(SPEC.read_bytes()), "base_sha256": digest(BASE.read_bytes()),
              "script_sha256": digest(Path(__file__).read_bytes())}
    write_json(OUT / "results.json", result)
    return result


def main(cached_only=False):
    spec, base = read(SPEC), read(BASE)
    topics = read(ROOT / "config/topic-trajectory-v01.json")
    jobs = requests(spec, topics, base)
    freeze(OUT / "plan.json", {"spec": spec, "base_sha256": digest(BASE.read_bytes()), "jobs": jobs})
    if not (OUT / "prepared-at.json").exists():
        write_json(OUT / "prepared-at.json", {"prepared_at_utc": now(), "plan_sha256": digest((OUT / "plan.json").read_bytes())})
    if not cached_only:
        model = next((m for m in local_metadata("/api/tags")["models"] if m["name"] == MODEL), None)
        if not model or model["digest"] != spec["model_digest"]:
            raise ValueError("Pinned installed local model missing; no pull or substitution")
        if not (OUT / "runtime.json").exists():
            write_json(OUT / "runtime.json", {"model": model, "show": local_metadata("/api/show", {"model": MODEL}),
                                            "version": local_metadata("/api/version")})
    outputs, gate = {}, None
    for index, job in enumerate(jobs):
        if job["phase"] == "existing_reply" and gate is None:
            gate = control_gate(jobs, outputs, spec)
            freeze(OUT / "control-gate.json", gate)
            print(json.dumps({"gate_passed": gate["passed"], "scores": {k: {m:v[m] for m in ("accuracy", "macro_f1", "known_topic_recall")} for k,v in gate["scores"].items()} }), flush=True)
            if not gate["passed"]:
                break
        request = payload(job, spec)
        req_path, res_path = OUT / "requests" / (job["id"]+".json"), OUT / "responses" / (job["id"]+".json")
        freeze(req_path, {"payload": request, "request_sha256": fingerprint(request)})
        if res_path.exists():
            saved = read(res_path)
            if saved["request_sha256"] != fingerprint(request) or saved["raw_sha256"] != fingerprint(saved["raw"]):
                raise ValueError("Changed cached annotation")
            raw = saved["raw"]
        else:
            if cached_only:
                raise ValueError("Missing cached annotation; --cached-only will never infer")
            started = now()
            begin = time.monotonic()
            raw = chat(request)
            write_json(res_path, {"started_at_utc": started, "ended_at_utc": now(), "wall_seconds": time.monotonic()-begin,
                                  "request_sha256": fingerprint(request), "raw_sha256": fingerprint(raw), "raw": raw})
        outputs[job["id"]] = parse_labels(raw, job)
        write_json(OUT / "progress.json", {"completed_requests": index+1, "maximum_requests": 60, "phase": job["phase"], "updated_at_utc": now()})
        print(f"{index+1}/60 {job['phase']} {job['id']}", flush=True)
    result = analyze(spec, jobs, outputs, base, gate)
    print(json.dumps({"annotated_replies": result["annotated_existing_replies"], "summaries": result["summaries"]},ensure_ascii=False))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cached-only", action="store_true")
    main(parser.parse_args().cached_only)
