"""Design, boundary and measurement tests; no local model calls."""
import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from return_control_ablation import SPEC, styles, conditions, metrics, anchor_stream, contrast, decision
from run_feature_batch import payload


class ReturnControlTests(unittest.TestCase):
    def setUp(self):
        self.spec = json.loads(SPEC.read_text())
        self.rows = conditions()

    def case(self, mode="free_reply"):
        return next(r for r in self.rows if r["profile_id"] == "C1" and r["target_event"] == "A" and r["task_mode"] == mode)

    def test_64_request_bound_and_complete_pairing(self):
        self.assertEqual(len(self.rows), 64)
        self.assertEqual(len({r["condition_id"] for r in self.rows}), 64)
        for mode in ("free_reply", "continuation_challenge"):
            for arm in ("original", "clarified"):
                self.assertEqual(sum(r["task_mode"] == mode and r["arm"] == arm for r in self.rows), 16)

    def test_exactly_one_source_clause_replaced(self):
        s = styles(self.spec)
        self.assertEqual(s["original"].replace(self.spec["source_clause"], self.spec["replacement_clause"]), s["clarified"])
        self.assertNotIn("must not exceed", s["original"])
        self.assertIn("normal in other turns", s["clarified"])

    def test_same_inputs_and_seed_within_each_pair(self):
        for i in range(0,64,2):
            a,b = self.rows[i:i+2]
            for key in ("facts", "topic_words", "target_event", "task_mode", "variant_id", "repeat_index", "interview", "stimulus_prefix"):
                self.assertEqual(a[key], b[key])
            self.assertEqual(payload(a, [], 1)["options"], payload(b, [], 1)["options"])

    def test_word_boundaries_and_numeric_decimals(self):
        case = self.case()
        self.assertEqual(anchor_stream("The 146 items cost 46.5 dollars.", case)["sequence"], [])
        self.assertEqual(anchor_stream("forty-six dollars", case)["sequence"], ["R"])

    def test_within_sentence_order_is_preserved(self):
        case = self.case()
        a = metrics("Astronomy, then baking, then astronomy again.",case,self.spec)
        b = metrics("Astronomy and astronomy, then baking.",case,self.spec)
        self.assertTrue(a["primary_return"])
        self.assertTrue(a["strict_r_o_r"])
        self.assertFalse(b["primary_return"])

    def test_prefix_is_not_counted_as_generated_data(self):
        case = self.case("continuation_challenge")
        a = metrics("The bread class was in Briarfen and Elias came with me.",case,self.spec)
        self.assertFalse(a["primary_return"])
        self.assertTrue(a["other_present"])
        self.assertEqual(a["requested_fact_count"],0)
        self.assertTrue(a["adequate_challenge_continuation"])

    def test_requested_reference_is_return_after_fixed_prefix(self):
        case = self.case("continuation_challenge")
        a = metrics("Nadia came with me.",case,self.spec)
        self.assertTrue(a["primary_return"])
        self.assertFalse(a["return_after_other"])

    def test_empty_or_echo_cannot_be_adequate(self):
        case = self.case("continuation_challenge")
        self.assertFalse(metrics("Baking.",case,self.spec)["adequate_challenge_continuation"])
        self.assertFalse(metrics(case["stimulus_prefix"],case,self.spec)["adequate_challenge_continuation"])

    def test_missing_pair_is_not_zero_effect(self):
        row = {**self.case(),"primary_return":False}
        with self.assertRaises(ValueError):
            contrast([row],"primary_return")

    def test_no_baseline_return_is_not_improvement(self):
        s = [{"arm":a,"primary_return_count":0} for a in ("original","clarified")]
        self.assertEqual(decision(s,{}, {},"free_reply",self.spec)["status"], "insufficient_baseline_returns")


if __name__ == "__main__":
    unittest.main()
