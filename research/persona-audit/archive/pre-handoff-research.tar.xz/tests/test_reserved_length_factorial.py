import sys
import unittest
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from reserved_length_factorial import conditions, summarize, question_paragraph_flag, CAP
from run_feature_batch import payload


class ReservedLengthTests(unittest.TestCase):
    def test_complete_bounded_design(self):
        rows = conditions()
        self.assertEqual(len(rows), 24)
        self.assertEqual(len({r["condition_id"] for r in rows}), 24)
        self.assertTrue(all(len(r["interview"]) == 1 for r in rows))
        self.assertTrue(all(r["arm"].startswith("sentence_cap_") for r in rows))

    def test_factors_change_only_style_slot(self):
        groups = defaultdict(dict)
        for row in conditions():
            groups[(row["profile_id"], row["repeat_index"])][(row["reserved_bundle"], row["sentence_cap"])] = row
        for cells in groups.values():
            self.assertEqual(len(cells), 4)
            for style in (False, True):
                c3, c5 = cells[(style, 3)], cells[(style, 5)]
                self.assertEqual(c3["system_prompt"].replace("\n" + CAP.strip(), ""), c5["system_prompt"])
                self.assertEqual(c3["profile"], c5["profile"])
                self.assertEqual(c3["interview"], c5["interview"])
                self.assertEqual(payload(c3, [], 1)["options"], payload(c5, [], 1)["options"])
            self.assertEqual(len({payload(r, [], 1)["options"]["seed"] for r in cells.values()}), 1)
            self.assertTrue(all(r["system_prompt"].count("maximum of 5 sentences") == 1 for r in cells.values()))

    def test_factorial_arithmetic(self):
        result = summarize({("a", 0): {(False, 5): 100, (False, 3): 80, (True, 5): 60, (True, 3): 50}})
        self.assertEqual(result["reserved_minus_plain_at_cap5"]["mean"], -40)
        self.assertEqual(result["cap3_minus_cap5_plain"]["mean"], -20)
        self.assertEqual(result["interaction_reserved_effect_cap3_minus_cap5"]["mean"], 10)
        with self.assertRaises(ValueError):
            summarize({("a", 0): {(False, 5): 100}})

    def test_quality_flag_is_not_every_question_mark(self):
        self.assertFalse(question_paragraph_flag("It feels hard, you know? I am tired."))
        self.assertFalse(question_paragraph_flag("Can you help?"))
        self.assertTrue(question_paragraph_flag("I am tired.\n\nWhat happened?\n\nI stayed home."))


if __name__ == "__main__":
    unittest.main()
