"""Review preparation must not create ratings or silently alter actual text."""
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from prepare_feature_review import FIELDS, build_packet, choose_examples


class FeatureReviewTests(unittest.TestCase):
    def examples(self):
        return [{"style_id": style, "arm": "native_demo_mapping", "turn": 1,
                 "condition_id": "fixture-" + style, "request_sha256": "fixture-hash",
                 "interviewer_text": "Question?", "response_text": "Fixture " + str(i) + "."}
                for i, style in enumerate(["plain", "reserved", "tangent"])]

    def test_empty_ratings_and_verbatim_text(self):
        records = self.examples()
        text, answers, provenance = build_packet(records)
        self.assertEqual(len(answers), 3)
        for answer in answers:
            for field in FIELDS:
                self.assertIsNone(answer[field])
        for row in records:
            self.assertIn(row["response_text"], text)
        self.assertNotIn("native_demo_mapping", text)
        self.assertEqual({p["condition_id"] for p in provenance}, {r["condition_id"] for r in records})

    def test_rejects_missing_style_and_does_not_modify_input(self):
        records = self.examples()
        first = list(records)
        self.assertEqual(choose_examples(records), choose_examples(records))
        self.assertEqual(records, first)
        with self.assertRaises(ValueError):
            choose_examples(records[:2])


if __name__ == "__main__":
    unittest.main()
