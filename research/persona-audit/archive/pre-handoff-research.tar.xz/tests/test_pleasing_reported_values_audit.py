import sys
from pathlib import Path
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from pleasing_reported_values_audit import controls,score


class NumericAuditTests(unittest.TestCase):
    def test_authored_audit_controls(self):
        for row in controls():
            with self.subTest(id=row['id']):
                self.assertTrue(row['passed'],row)

    def test_span_traceability(self):
        text='The intensity is around an eight, on six out of seven days, for three quarters of an hour.'
        result=score(text,{'intensity':8,'frequency':6,'duration':45})
        for c in result['audited_claims']:
            self.assertEqual(text[c['raw_start']:c['raw_end']],c['raw_clause'])


if __name__=='__main__':
    unittest.main()
