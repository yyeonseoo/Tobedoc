"""Mathematical and manipulation tests; not tests of clinical validity."""
import sys
from pathlib import Path
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import measurement_audit as m


class MeasurementAuditTests(unittest.TestCase):
    def test_cases_and_base_split(self):
        cases=m.read(m.CASES)
        m.validate_cases(cases)
        for c in cases:
            rows=[r for r in m.variants(cases) if r['case_id']==c['id']]
            self.assertEqual(len(rows),9)
            self.assertEqual({r['split'] for r in rows},{c['split']})

    def test_contrasts_and_control_lengths(self):
        rows=m.variants(m.read(m.CASES))
        for cid in {r['case_id'] for r in rows}:
            g={r['variant']:r for r in rows if r['case_id']==cid}
            self.assertEqual(g['original']['text'],g['question_swap']['text'])
            self.assertEqual(len(m.words(g['insert_related']['text'])),len(m.words(g['insert_other']['text'])))
            self.assertEqual(len(m.words(g['original']['text'])),len(m.words(g['contradiction']['text'])))
            self.assertEqual(g['reverse']['sentences'],g['original']['sentences'][::-1])

    def test_cosine_guards(self):
        for a,b in (([0,0],[1,0]),([1],[1,0]),([float('nan')],[1])):
            with self.assertRaises(ValueError): m.cosine(a,b)
        self.assertAlmostEqual(m.cosine([1,2],[2,4]),1)

    def test_algebra_on_arbitrary_vectors(self):
        texts=['first word.','second word.','third word.','fourth word.','fifth word.']
        vectors={s:[i+1.,(i%2)+1.,-i*.2] for i,s in enumerate(texts)}
        vectors['question?']=[.2,.7,1.]
        a=m.measure(texts,'question?',vectors)
        r=m.measure(texts[::-1],'question?',vectors)
        d=m.measure([texts[0]]+texts,'question?',vectors)
        for key in m.METRICS: self.assertAlmostEqual(a[key],r[key])
        self.assertAlmostEqual(d['adjacent_cos']-a['adjacent_cos'],(1-a['adjacent_cos'])/5)
        self.assertAlmostEqual(d['duplicate_fraction'],1/6)

    def test_two_sentence_excess_is_zero(self):
        v={'a':[1.,0.],'b':[1.,1.],'q':[0.,1.]}
        self.assertAlmostEqual(m.measure(['a','b'],'q',v)['adjacency_excess'],0)

    def test_bootstrap_unit_and_ties(self):
        entries=[{'family':f,'value':v} for f in ('x','y') for v in (-1.,0.,1.,2.)]
        a=m.summarize(entries,repetitions=100)
        self.assertEqual(a,m.summarize(entries,repetitions=100))
        self.assertEqual((a['n_cases'],a['positive'],a['negative'],a['ties']),(8,4,2,2))
        self.assertAlmostEqual(a['mean'],.5)
        self.assertEqual(m.quantile([0,2],.5),1)


if __name__=='__main__': unittest.main()
