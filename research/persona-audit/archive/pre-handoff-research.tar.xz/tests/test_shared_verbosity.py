"""Offline design/matcher regression checks, no generated fixtures as findings."""
import sys
from pathlib import Path
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from shared_verbosity import conditions, modules, read, SPEC, contrast
from fact_disclosure_probe import match_fact
from run_feature_batch import payload
from run_local_pilot import fingerprint


class SharedVerbosityTests(unittest.TestCase):
    def test_design_balanced_and_matched(self):
        rows = conditions()
        self.assertEqual(len(rows), 80)
        self.assertEqual(len({r['condition_id'] for r in rows}), 80)
        for case in ('V1', 'V2', 'V3', 'V4'):
            for target in ('A', 'B'):
                for repeat in (8, 9):
                    group = [r for r in rows if (r['profile_id'], r['target_event'], r['repeat_index']) == (case, target, repeat)]
                    self.assertEqual(len(group), 5)
                    self.assertEqual(len({r['interview'][0]['text'] for r in group}), 1)
                    self.assertEqual(len({payload(r, [], 1)['options']['seed'] for r in group}), 1)
                    self.assertEqual(len({r['system_prompt'].split('Conversation style:')[0] for r in group}), 1)

    def test_baseline_cap_and_source_distinction(self):
        mods = modules()
        self.assertEqual(mods['neutral'], '')
        self.assertIn('concise, direct', mods['sim_concise'])
        self.assertIn('concise in other turns', mods['psi_verbose'])
        for row in conditions():
            self.assertNotIn('must not exceed', row['system_prompt'])
            self.assertNotIn('at most 5', row['system_prompt'])
            self.assertEqual(row['prompt_sha256'], fingerprint({'system_prompt': row['system_prompt'], 'interview': row['interview']}))
            self.assertEqual(payload(row, [], 1)['options']['num_predict'], 512)

    def test_finite_aliases_are_disjoint_and_token_bounded(self):
        for case in read(SPEC)['fictional_cases']:
            self.assertEqual(len(case['facts']), 8)
            for fact in case['facts']:
                self.assertTrue(match_fact(fact['description'], fact)['recognized_mention'])
                for alias in fact['aliases']:
                    self.assertTrue(match_fact(alias, fact)['recognized_mention'])
                for other in case['facts']:
                    if fact['id'] != other['id']:
                        self.assertFalse(match_fact(other['description'], fact)['recognized_mention'])
        fact = {'id': 'x', 'domain': 'A', 'aliases': ['crane']}
        self.assertFalse(match_fact('cranefly', fact)['recognized_mention'])
        self.assertTrue(match_fact('I did not see a crane.', fact)['recognized_mention'])

    def test_contrast_is_paired_not_response_pooling(self):
        rows = []
        for case, offset in [('V1', 100), ('V2', 200)]:
            for seed in (8, 9):
                for arm, delta in [('a', 5), ('b', 0)]:
                    rows.append({'profile_id': case, 'target_event': 'A', 'repeat_index': seed, 'style_id': arm,
                                 **{k: offset + seed + delta for k in ('word_count', 'sentences', 'requested_refs', 'other_refs', 'other_positive')}})
        result = contrast(list(reversed(rows)), 'a', 'b')
        self.assertEqual(result['word_count']['mean_difference'], 5)
        self.assertEqual(result['word_count']['case_means'], {'V1': 5, 'V2': 5})


if __name__ == '__main__':
    unittest.main()
