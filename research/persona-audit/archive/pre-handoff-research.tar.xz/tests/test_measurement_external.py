"""External-source schema, missingness and rank-statistic checks."""
import sys
from pathlib import Path
import unittest
import numpy as np
from statistics import correlation
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import measurement_external as e


class ExternalMeasurementTests(unittest.TestCase):
    def test_schema_and_source_clusters(self):
        if not e.RAW.exists(): self.skipTest('Official data not downloaded')
        rows=e.source_records()
        self.assertEqual(len(rows),1600)
        self.assertEqual(len({r['article_id'] for r in rows}),100)

    def test_spearman_average_ties(self):
        x=np.array([[1,2],[2,4],[2,3],[4,5]],dtype=float)
        y=np.array([1,2,3,5],dtype=float)
        r=e.column_correlations(x,y)
        self.assertAlmostEqual(r[0],correlation([1,2.5,2.5,4],[1,2,3,4]))
        self.assertAlmostEqual(r[1],correlation([1,3,2,4],[1,2,3,4]))
        np.testing.assert_equal(e.ranks([3,1,1,5]),[3,1.5,1.5,4])

    def test_constant_not_filled_zero(self):
        self.assertTrue(np.isnan(e.column_correlations([[1],[1],[1]],[1,2,3])[0]))

    def test_single_sentence_missing_not_zero(self):
        v,r=e.features([{'text':'One sentence only.','vector':None}])
        self.assertEqual(r,'fewer_than_two_sentences')
        self.assertIsNone(v['adjacent_cos'])
        self.assertEqual(v['sentence_count'],1)

    def test_metrics_match_authored_formulas(self):
        s=['The first sentence.','Another sentence here.','Last sentence now.']
        vectors={t:[float((i+j)%5+1) for j in range(512)] for i,t in enumerate(s)}
        got,reason=e.features([{'text':t,'vector':vectors[t]} for t in s])
        reference=e.core.measure(s,s[0],vectors)
        self.assertIsNone(reason)
        for m in e.METRICS: self.assertAlmostEqual(got[m],reference[m])


if __name__=='__main__': unittest.main()
