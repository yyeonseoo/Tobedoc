"""Authored implementation tests are not expert annotations or empirical evidence."""
import sys
from pathlib import Path
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from role_enrichment import matcher, read, SPEC


class RoleEnrichmentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.spec = read(SPEC)

    def test_all_authored_controls(self):
        for row in self.spec['controls']:
            with self.subTest(row['id']):
                self.assertEqual(bool(matcher(row['text'], {'name':'Helena','roles':[]},self.spec)['matches']),row['expected'])

    def test_source_specified_and_unspecified_are_distinct(self):
        specified = matcher('Tobias was the instructor.', {'name':'Tobias','roles':['instructor']}, self.spec)
        self.assertEqual(specified['matches'][0]['profile_role_status'],'source_specified')
        addition = matcher('Helena was an instructor.', {'name':'Helena','roles':[]}, self.spec)
        self.assertEqual(addition['matches'][0]['profile_role_status'],'profile_unspecified')
        unresolved = matcher('Celia was an instructor.', {'name':'Celia','roles':['speaker']}, self.spec)
        self.assertEqual(unresolved['matches'][0]['profile_role_status'],'different_role_label_not_adjudicated')

    def test_spans_and_deduplication(self):
        text = 'I worked with Helena, who was a very knowledgeable instructor.'
        result = matcher(text, {'name':'Helena','roles':[]}, self.spec)
        self.assertEqual(len(result['matches']),1)
        hit = result['matches'][0]
        self.assertEqual(text[hit['start']:hit['end']],hit['span'])
        self.assertEqual(text[hit['role_start']:hit['role_end']],'instructor')

    def test_whole_sentence_uncertainty_is_conservative_abstention(self):
        result = matcher('Helena was a teacher, but perhaps I misremember.', {'name':'Helena','roles':[]},self.spec)
        self.assertTrue(result['candidate'])
        self.assertTrue(result['abstained'])
        self.assertEqual(result['matches'],[])


if __name__=='__main__':
    unittest.main()
