import sys
from pathlib import Path
import tempfile
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import replay_frozen_analysis as r


class ReplayTests(unittest.TestCase):
    def test_json_keys_and_lists_not_numeric_changes(self):
        self.assertEqual(r.canonical({2:(3,4)}),{'2':[3,4]})
        self.assertNotEqual(r.canonical({'value':.1}),r.canonical({'value':.1001}))

    def test_immutable_comparison_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'result.json'
            r.immutable_json(p,{2:3})
            original=p.read_bytes()
            r.immutable_json(p,{2:3})
            self.assertEqual(p.read_bytes(),original)
            with self.assertRaises(ValueError):r.immutable_json(p,{2:4})
            self.assertEqual(p.read_bytes(),original)


if __name__=='__main__': unittest.main()
