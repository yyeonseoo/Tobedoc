"""Algebraic/implementation controls, not clinical validation."""
import itertools
import math
import sys
from pathlib import Path
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from topic_local_separation import local_metrics,association,measure,checked_cos


class TopicLocalTests(unittest.TestCase):
    def setUp(self):
        self.v=[[1.,0.],[.8,.2],[0.,1.],[-1.,0.]]

    def test_exact_permutation_expectation(self):
        values=[local_metrics(list(p))['adjacent_cos'] for p in itertools.permutations(self.v)]
        self.assertAlmostEqual(sum(values)/len(values),local_metrics(self.v)['all_pairs_cos'])

    def test_repeated_positions_expectation(self):
        v=[self.v[0],self.v[0],self.v[2]]
        values=[local_metrics(list(p))['adjacent_cos'] for p in itertools.permutations(v)]
        self.assertAlmostEqual(sum(values)/len(values),local_metrics(v)['all_pairs_cos'])

    def test_reversal(self):
        for k,v in local_metrics(self.v).items():
            self.assertAlmostEqual(v,local_metrics(list(reversed(self.v)))[k])

    def test_two_sentences_zero_excess(self):
        self.assertEqual(local_metrics(self.v[:2])['adjacency_excess'],0)

    def test_one_sentence_missing(self):
        self.assertIsNone(local_metrics(self.v[:1])['adjacent_cos'])

    def test_topic_swap_leaves_local_unchanged(self):
        a=measure(['one','two','three','four'],self.v,[[1,0]],[[0,1]])
        b=measure(['one','two','three','four'],self.v,[[0,1]],[[1,0]])
        self.assertEqual(a['adjacent_cos'],b['adjacent_cos'])
        self.assertAlmostEqual(a['topic_margin'],-b['topic_margin'])

    def test_topic_bag_invariance(self):
        self.assertAlmostEqual(association(self.v,[[1,0]]),association(list(reversed(self.v)),[[1,0]]))

    def test_invalid_vectors(self):
        for v in (None,[],[0,0],[math.nan,1]):
            with self.assertRaises(ValueError):
                checked_cos(v,[1,0])
        with self.assertRaises(ValueError):
            checked_cos([1,0],[1,0,0])

    def test_all_pair_order_independent(self):
        reordered=[self.v[i] for i in (0,2,1,3)]
        self.assertAlmostEqual(local_metrics(self.v)['all_pairs_cos'],local_metrics(reordered)['all_pairs_cos'])
        self.assertNotEqual(local_metrics(self.v)['adjacent_cos'],local_metrics(reordered)['adjacent_cos'])


if __name__=='__main__':
    unittest.main()
