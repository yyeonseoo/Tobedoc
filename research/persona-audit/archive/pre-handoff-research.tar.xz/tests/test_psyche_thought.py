"""Offline design/measurement tests. No model calls or clinician labels."""
from copy import deepcopy
import ast
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import psyche_thought as protocol


class ThoughtProtocolTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.spec = protocol.read(protocol.SPEC)
        cls.rows = protocol.build(cls.spec)

    def test_design_and_split(self):
        self.assertEqual(len(self.rows), 48)
        self.assertEqual(len({r['id'] for r in self.rows}), 48)
        self.assertEqual(sum(r['split'] == 'development' for r in self.rows), 16)
        self.assertEqual(sum(r['split'] == 'holdout' for r in self.rows), 32)

    def test_disjoint_cases_and_new_seeds(self):
        dev = {r['case_id'] for r in self.rows if r['split'] == 'development'}
        holdout = {r['case_id'] for r in self.rows if r['split'] == 'holdout'}
        self.assertFalse(dev & holdout)
        old = protocol.read(protocol.base.SPEC)
        self.assertFalse(set(self.spec['seeds']) & set(old['seeds']))

    def test_length_instruction_identical_everywhere(self):
        self.assertEqual(len({r['case'][self.spec['length_extension']] for r in self.rows}), 1)
        self.assertTrue(all(r['case']['MFC-Behavior']['Verbal productivity'] == 'Normal' for r in self.rows))

    def test_thought_pairs_change_only_target_fields(self):
        for row in self.rows:
            if row['thought'] != 'Normal':
                continue
            other = next(r for r in self.rows if r['thought'] == 'Derailment' and all(r[k] == row[k] for k in ('case_id', 'arm', 'question_id', 'seed')))
            a, b = deepcopy(row['case']), deepcopy(other['case'])
            a['MFC-Behavior']['Thought process'] = b['MFC-Behavior']['Thought process']
            if row['arm'] == 'source_operationalized':
                a[self.spec['thought_extension']] = b[self.spec['thought_extension']]
            self.assertEqual(a, b)
            self.assertEqual(row['payload']['messages'][1], other['payload']['messages'][1])

    def test_arm_difference_is_explicit_extension(self):
        for row in self.rows:
            if row['arm'] != 'source_operationalized':
                continue
            baseline = next(r for r in self.rows if r['arm'] == 'hub_category' and all(r[k] == row[k] for k in ('case_id', 'thought', 'question_id', 'seed')))
            case = deepcopy(row['case'])
            self.assertEqual(case.pop(self.spec['thought_extension']), self.spec['instructions'][row['thought']])
            self.assertEqual(case, baseline['case'])

    def test_case_identity_consistency(self):
        for row in self.rows:
            identity = row['case']['MFC-Profile']['Identifying data']
            appearance = row['case']['MFC-Behavior']['General appearance/attitude/behavior']
            self.assertIn(identity['Age'], appearance)
            if row['case_id'] != 'D-bookshop':
                self.assertNotIn('bookshop', str(row['case']).lower())

    def test_cases_validate_against_locked_schema(self):
        namespace = {'__name__': 'offline_thought_schema_test'}
        exec(compile(ast.parse(protocol.source_text('patienthub/schemas/base.py')), 'locked_base', 'exec'), namespace)
        tree = ast.parse(protocol.source_text('patienthub/schemas/psyche.py'))
        tree.body = [n for n in tree.body if not (isinstance(n, ast.ImportFrom) and n.module == 'patienthub.schemas.base')]
        exec(compile(tree, 'locked_psyche', 'exec'), namespace)
        for row in self.rows:
            namespace['PsycheCharacter'].model_validate(row['case'])

    def test_no_shared_history_or_unrendered_variables(self):
        for row in self.rows:
            messages = row['payload']['messages']
            self.assertEqual([r['role'] for r in messages], ['system', 'user'])
            self.assertNotIn('{{', messages[0]['content'])

    def test_review_subset_balanced(self):
        selected = [r for r in self.rows if r['review_subset']]
        self.assertEqual(len(selected), 12)
        self.assertEqual(len({(r['case_id'], r['arm'], r['thought']) for r in selected}), 12)

    def test_frozen_order_and_no_success_score(self):
        self.assertEqual(self.rows, protocol.build(self.spec))
        measured = protocol.describe('I make tea. I take the bus.', [1, 20])
        self.assertEqual(measured['words'], 7)
        self.assertEqual(measured['sentence_count'], 2)
        self.assertNotIn('clinical_score', measured)

    def test_segmentation_error_is_visible_not_zero(self):
        with patch.object(protocol, 'segment', side_effect=AssertionError('span failure')):
            measured = protocol.describe('I make tea.', [1, 20])
        self.assertIsNone(measured['sentence_count'])
        self.assertEqual(measured['words'], 3)
        self.assertIn('span failure', measured['segmentation_error'])


if __name__ == '__main__':
    unittest.main()
