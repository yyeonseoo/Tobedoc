"""No network calls or actual model inference in these unit tests."""
import copy
import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from run_local_pilot import MODEL, OPTIONS, build_payload, classify, fingerprint, select_conditions
from summarize_local_pilot import text_metrics, verify_turn


class LocalPilotTests(unittest.TestCase):
    def test_selection_is_exactly_one_person_six_conditions(self):
        rows = select_conditions()
        self.assertEqual(len(rows), 6)
        self.assertEqual({r["profile_id"] for r in rows}, {"1-1"})
        self.assertEqual({r["case_family_id"] for r in rows}, {"Abe"})
        self.assertEqual(rows[0]["style_id"], "plain")
        self.assertEqual(len({r["condition_id"] for r in rows}), 6)

    def test_matched_seeds_and_complete_history(self):
        rows = [r for r in select_conditions() if r["style_id"] == "plain"]
        payloads = [build_payload(r, [], 1) for r in rows]
        self.assertEqual(payloads[0]["options"], payloads[1]["options"])
        self.assertFalse(payloads[0]["think"])
        history = [{"role": "user", "content": "question"}, {"role": "assistant", "content": "actual reply"}]
        payload = build_payload(rows[0], history, 2)
        self.assertEqual(payload["messages"][1:3], history)
        with self.assertRaises(ValueError):
            build_payload(rows[0], [], 2)

    def test_conservative_context_guard_does_not_truncate(self):
        row = copy.deepcopy(select_conditions()[0])
        row["system_prompt"] = "x" * OPTIONS["num_ctx"]
        with self.assertRaises(ValueError):
            build_payload(row, [], 1)

    def test_completion_classification_preserves_errors(self):
        base = {"done": True, "model": MODEL, "message": {"content": "A real reply."}, "done_reason": "stop"}
        self.assertEqual(classify(base), "completed")
        self.assertEqual(classify({**base, "done_reason": "length"}), "truncated")
        self.assertEqual(classify({**base, "message": {"content": ""}}), "empty_response")
        self.assertEqual(classify({**base, "model": "wrong"}), "model_mismatch")
        self.assertEqual(classify({**base, "error": "failure"}), "provider_error")

    def test_word_and_sentence_counts_are_descriptive(self):
        result = text_metrics("I don't know. Bills keep coming!")
        self.assertEqual(result["word_count"], 6)
        self.assertEqual(result["sentence_count_heuristic"], 2)
        self.assertEqual(text_metrics("")["word_count"], 0)
        self.assertEqual(text_metrics("It's just... difficult. I don't know.")["sentence_count_heuristic"], 2)
        self.assertEqual(text_metrics('I wondered, "What if?" Then I sat there.')["sentence_count_heuristic"], 2)

    def test_provenance_rejects_fixtures_and_edited_raw_text(self):
        condition = copy.deepcopy(select_conditions()[0])
        condition["_model_digest"] = "test-digest"
        payload = build_payload(condition, [], 1)
        request = {"payload": payload, "request_sha256": fingerprint(payload)}
        record = {**{k: condition[k] for k in ["condition_id", "style_id", "arm", "profile_id"]},
                  "request_sha256": fingerprint(payload), "prompt_sha256": condition["prompt_sha256"],
                  "turn": 1, "response_text": "unaltered", "raw_response": {"message": {"content": "unaltered"}},
                  "model_digest": "test-digest", "is_fixture": False}
        verify_turn(record, request, condition, [])
        with self.assertRaises(ValueError):
            verify_turn({**record, "is_fixture": True}, request, condition, [])
        with self.assertRaises(ValueError):
            verify_turn({**record, "response_text": "edited"}, request, condition, [])


if __name__ == "__main__":
    unittest.main()
