"""Mechanism-level tests; no clinical labels, network, inference, or OS NLP."""
import math
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/"scripts"))
from analyze_feature_robustness import (contrast, fixed_two_minimum, paired_rows,
    regex_sentences, relative_length, select_length_pairs, solve_least_squares)


def row(style, turn, value, repeat=0, profile="one", count=4, words=50):
    return {"style_id": style, "condition_id": f"{style}-{profile}-{repeat}",
            "profile_id": profile, "repeat_index": repeat, "turn": turn,
            "features": {"value": value, "word_count": words, "sentence_count": count}}


class RobustnessTests(unittest.TestCase):
    def test_regex_alternative_is_declared_normalization(self):
        self.assertEqual(regex_sentences('I think... maybe. "Yes!" Next?'), ['I think  maybe', '"Yes', 'Next'])
        self.assertEqual(regex_sentences("..."), [])

    def test_fixed_pair_exposure_uses_exact_all_pairs(self):
        self.assertAlmostEqual(fixed_two_minimum([.1, .5, .9]), (.1+.1+.5)/3)
        self.assertIsNone(fixed_two_minimum([.5]))
        self.assertIsNone(fixed_two_minimum([None, .5]))
        self.assertEqual(fixed_two_minimum([.2, .4]), .2)

    def test_word_distance_is_symmetric(self):
        self.assertEqual(relative_length(50, 100), relative_length(100, 50))
        self.assertEqual(relative_length(50, 50), 0)
        self.assertIsNone(relative_length(0, 0))

    def test_matching_never_rematches_other_turns(self):
        rows = [row("plain", 1, 0, words=100), row("tangent", 1, 1, words=50),
                row("plain", 2, 0, words=50), row("tangent", 2, 1, words=100)]
        pairs = paired_rows(rows, "tangent")
        self.assertEqual(len(select_length_pairs(pairs, "words_only", .2)), 0)
        self.assertEqual(len(select_length_pairs(pairs, "sentences_only", .2)), 2)

    def test_matching_requires_both_for_joint_rule(self):
        pair = [(row("tangent", 1, 1, words=54, count=4), row("plain", 1, 0, words=50, count=5))]
        self.assertEqual(len(select_length_pairs(pair, "words_only", .2)), 1)
        self.assertEqual(len(select_length_pairs(pair, "words_and_sentences", .2)), 0)
        with self.assertRaises(ValueError):
            select_length_pairs(pair, "unknown", .2)

    def test_empty_contrast_does_not_become_zero(self):
        result = contrast([], "value")
        self.assertIsNone(result["block_weighted_difference"])
        self.assertEqual(result["eligible_response_pairs"], 0)

    def test_block_weights_are_not_response_weights(self):
        pairs = [(row("tangent", 1, 1), row("plain", 1, 0)),
                 (row("tangent", 2, 1), row("plain", 2, 0)),
                 (row("tangent", 1, 4, repeat=1), row("plain", 1, 0, repeat=1))]
        result = contrast(pairs, "value")
        self.assertEqual(result["block_weighted_difference"], 2.5)
        self.assertEqual(result["response_weighted_difference"], 2)

    def test_missing_feature_pairs_are_excluded_and_counted(self):
        result = contrast([(row("tangent", 1, None), row("plain", 1, 0))], "value")
        self.assertEqual(result["eligible_response_pairs"], 0)
        self.assertIsNone(result["block_weighted_difference"])

    def test_pairing_requires_original_reference(self):
        with self.assertRaises(ValueError):
            paired_rows([row("tangent", 1, 1)], "tangent")

    def test_regression_recovers_known_coefficients(self):
        x = [[1, 0, 0], [1, 1, 0], [1, 0, 1], [1, 2, 3]]
        y = [2+3*a-4*b for _, a, b in x]
        fit = solve_least_squares(x, y)
        for actual, expected in zip(fit["coefficients"], [2, 3, -4]):
            self.assertAlmostEqual(actual, expected)
        self.assertLess(fit["residual_sum_squares"], 1e-20)

    def test_regression_fails_on_rank_deficiency(self):
        with self.assertRaises(ValueError):
            solve_least_squares([[1, 2], [1, 2]], [1, 2])


if __name__ == "__main__":
    unittest.main()
