import sys
from pathlib import Path
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from pleasing_measures import controls,measure,numeric_claims
from pleasing_study import conditions,modules,read,SPEC


class PleasingTests(unittest.TestCase):
    def test_authored_controls(self):
        for row in controls():
            with self.subTest(row=row['id']):
                self.assertTrue(row['passed'],row)

    def test_two_stage_ceilings(self):
        self.assertEqual(len(conditions('discovery')),40)
        self.assertEqual(len(conditions('followup')),32)

    def test_no_case_seed_overlap(self):
        a,b=conditions('discovery'),conditions('followup')
        for key in ('profile_id','repeat_index'):
            self.assertFalse({r[key] for r in a}&{r[key] for r in b})

    def test_exact_single_clause(self):
        m=modules()
        for s in ('psi','sim'):
            self.assertEqual(m[s+'_factlock'],m[s+'_original']+'\n'+read(SPEC)['followup']['added_clause'])

    def test_unit_conversion(self):
        scores=measure('7/10, five days a week, 1 hour and 15 minutes.',{'intensity':7,'frequency':5,'duration':75})
        self.assertEqual(scores['correct_slots'],3)

    def test_raw_clauses_and_cues(self):
        text='Not a big deal: eight out of ten, six days a week, forty-five minutes.'
        scores=measure(text,{'intensity':8,'frequency':6,'duration':45})
        for c in scores['claims']:
            self.assertEqual(text[c['raw_start']:c['raw_end']],c['raw_clause'])
        for c in scores['cue_spans']:
            self.assertEqual(text[c['start']:c['end']],c['span'])


if __name__=='__main__':
    unittest.main()
