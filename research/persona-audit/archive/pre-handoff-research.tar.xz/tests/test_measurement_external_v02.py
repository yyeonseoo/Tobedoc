import sys
from pathlib import Path
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import measurement_external_v02 as v


class MissingTokenRepairTests(unittest.TestCase):
    def test_punctuation_segment_is_explicit_exclusion(self):
        measures,reason=v.features([{'text':'A full sentence.','vector':None},{'text':'...','vector':None}])
        self.assertEqual(reason,'empty_lexical_sentence')
        self.assertEqual(measures['word_count'],3)
        self.assertIsNone(measures['lexical_adjacent'])
        self.assertIsNone(measures['adjacent_cos'])

    def test_normal_single_sentence_keeps_original_rule(self):
        measures,reason=v.features([{'text':'A full sentence.','vector':None}])
        self.assertEqual(reason,'fewer_than_two_sentences')


if __name__=='__main__': unittest.main()
