import sys
from pathlib import Path
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"scripts"))
from run_framework_pilot import conditions
from run_feature_batch import payload
from analyze_framework_pilot import paired_contrast,between_programs


class FrameworkPilotTests(unittest.TestCase):
    def test_only_frozen_pilot_executes(self):
        rows=conditions()
        self.assertEqual(len(rows),18)
        self.assertEqual(len({r["condition_id"] for r in rows}),18)
        self.assertEqual({r["profile_id"] for r in rows},{"D1","D2","D3"})
        self.assertEqual({r["repeat_index"] for r in rows},{0})
        self.assertTrue(all(len(r["interview"])==4 for r in rows))

    def test_plain_identity_control(self):
        rows=conditions()
        for case in ["D1","D2","D3"]:
            pair=[r for r in rows if r["profile_id"]==case and r["style_id"]=="plain" and r["arm"] in ["simple_baseline","patient_psi_style"]]
            self.assertEqual(payload(pair[0],[],1),payload(pair[1],[],1))

    def test_missing_turns_are_paired_not_imputed(self):
        rows=[]
        for turn,a,b in [(1,None,.8),(2,.2,.4),(3,.9,None),(4,.3,.5)]:
            for style,value in [("plain",a),("verbose",b)]:
                rows.append({"profile_id":"D1","arm":"p","style_id":style,"turn":turn,"features":{"f":value}})
        result=paired_contrast(rows,"p","f")
        self.assertEqual(result["eligible_turn_pairs"],2)
        self.assertAlmostEqual(result["verbose_minus_plain"],.2)
        self.assertIsNone(paired_contrast(rows,"p","f",True)["verbose_minus_plain"])

    def test_cross_program_requires_four_valid_cells(self):
        rows=[]
        for p,s,v in [("p","plain",.2),("p","verbose",.5),("simple_baseline","plain",.1),("simple_baseline","verbose",.2)]:
            rows.append({"profile_id":"D1","arm":p,"style_id":s,"turn":1,"features":{"f":v}})
        self.assertAlmostEqual(between_programs(rows,"p","f")["difference_of_style_contrasts"],.2)
        rows[0]["features"]["f"]=None
        self.assertIsNone(between_programs(rows,"p","f")["difference_of_style_contrasts"])

    def test_empty_contrast_is_not_zero(self):
        result=paired_contrast([],"p","f")
        self.assertEqual(result["eligible_cases"],0)
        self.assertIsNone(result["verbose_minus_plain"])


if __name__=="__main__":
    unittest.main()
