"""Small offline regression tests; no model, network or original package import."""
import sys
from pathlib import Path
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import audit_psyche_roleplay_sources as audit


class SourceAuditTests(unittest.TestCase):
    def test_schema_inventory_is_twelve(self):
        self.assertEqual(len(audit.behavior_fields()), 12)

    def test_source_integrity(self):
        self.assertEqual(len(audit.verify_sources(audit.read_json(audit.LOCK))), 15)

    def test_existing_profiles_are_schema_valid(self):
        result = audit.validate_profile_fixtures()
        self.assertEqual((result['valid_profiles'], result['profiles']), (2, 2))

    def test_mocked_refinement_drops_history(self):
        result = audit.bounded_roleplay_test()
        self.assertEqual(result['assessment_history'], [])
        self.assertTrue(result['draft_has_prior_history'])
        self.assertEqual(result['actual_llm_calls'], 0)

    def test_literal_block_preserves_after_whitespace_only_line(self):
        text = 'en:\n  assessment: |\n    before\n  \n    {{ conv_history }}\n  next: |\n    other\nzh:\n  assessment: |\n    excluded\n'
        result = audit.yaml_english_block(text, 'assessment')
        self.assertIn('{{ conv_history }}', result)
        self.assertNotIn('other', result)
        self.assertNotIn('excluded', result)

    def test_absent_block_fails(self):
        with self.assertRaises(ValueError):
            audit.yaml_english_block('en:\n  response: |\n    x\n', 'absent')

    def test_prompt_inputs_and_named_examples(self):
        result = audit.prompt_inventory()
        self.assertIn('conv_history', result['roleplay_assessment_variables'])
        self.assertFalse(result['thought_process_has_named_flight_of_ideas_example'])
        self.assertFalse(result['thought_process_has_named_circumstantiality_example'])

    def test_reported_theme_counts_keep_the_correct_unit(self):
        phase = audit.read_json(audit.PHASE)
        self.assertEqual(phase['roleplay_paper_frequency_denominator'], 25)
        self.assertEqual([r['count'] for r in phase['published_theme_counts']], [14, 7, 14, 19, 9, 3, 12])
        self.assertFalse((audit.BASE / 'data/resources/roleplayDoh_principles.json').exists())


if __name__ == '__main__':
    unittest.main()
