"""Locked one-field intervention design; no generation or patient ratings."""
import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/"scripts"))
from run_thought_alias_ablation import conditions
from run_feature_batch import payload
from run_local_pilot import fingerprint
from analyze_thought_alias_ablation import contains_token_sequence, effect, summarize, NATIVE, ALIAS


class ThoughtAliasDesignTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.rows = conditions()

    def test_twenty_four_fresh_paired_dialogues(self):
        self.assertEqual(len(self.rows), 24)
        self.assertEqual(len({r["condition_id"] for r in self.rows}), 24)
        self.assertEqual({r["style_id"] for r in self.rows}, {"plain", "tangent"})
        self.assertEqual({r["repeat_index"] for r in self.rows}, {0, 1})
        self.assertEqual({r["case_family_id"] for r in self.rows}, {"Abe"})

    def test_each_adjacent_pair_is_matched_and_opposite_arms(self):
        for a, b in zip(self.rows[::2], self.rows[1::2]):
            self.assertEqual((a["style_id"], a["profile_id"], a["repeat_index"]),
                             (b["style_id"], b["profile_id"], b["repeat_index"]))
            self.assertNotEqual(a["arm"], b["arm"])

    def test_rendered_prompt_has_exactly_one_field_change(self):
        for a, b in zip(self.rows[::2], self.rows[1::2]):
            native = a if a["arm"] == "native_demo_mapping" else b
            alias = b if native is a else a
            expected = native["system_prompt"].replace("Automatic Thoughts: undefined",
                         "Automatic Thoughts: "+native["profile"]["auto_thought"])
            self.assertEqual(alias["system_prompt"], expected)
            self.assertEqual(alias["interview"], native["interview"])
            self.assertEqual(alias["profile"], {**native["profile"], "auto_thoughts": native["profile"]["auto_thought"]})
            self.assertEqual(alias["missing_fields"], ["core_belief", "intermediate_belief_depression"])

    def test_actual_prompt_fingerprint_and_length_instructions(self):
        for row in self.rows:
            self.assertEqual(row["prompt_sha256"], fingerprint({"system_prompt": row["system_prompt"], "interview": row["interview"]}))
            self.assertIn("maximum of 5 sentences", row["system_prompt"])
            self.assertIn("Core Beliefs: undefined", row["system_prompt"])

    def test_seed_and_generation_options_are_matched(self):
        for a, b in zip(self.rows[::2], self.rows[1::2]):
            pa, pb = payload(a, [], 1), payload(b, [], 1)
            self.assertEqual(pa["options"], pb["options"])
            self.assertEqual(pa["model"], pb["model"])
            self.assertEqual(pa["options"]["seed"], 20261030+100*a["repeat_index"]+1)

    def test_literal_sequence_is_not_just_word_overlap(self):
        self.assertEqual(contains_token_sequence("Maybe I should have tried harder, yes.", "I should have tried harder."), 1)
        self.assertEqual(contains_token_sequence("I tried harder but should have left.", "I should have tried harder."), 0)
        self.assertIsNone(contains_token_sequence("anything", ""))

    def test_effect_counts_missing_without_filling_zero(self):
        result = effect([{"native": .2, "alias": .3}, {"native": .4, "alias": .1}, {"native": None, "alias": .5}])
        self.assertEqual(result["eligible_pairs"], 2)
        self.assertAlmostEqual(result["alias_minus_native"], -.1)
        self.assertEqual(result["positive_pairs"], 1)
        self.assertEqual(result["negative_pairs"], 1)
        self.assertIsNone(effect([])["alias_minus_native"])

    def test_first_turn_is_not_pooled_with_later_turns(self):
        rows = []
        for style in ["plain", "tangent"]:
            for arm, values in [(NATIVE, [.1, .9]), (ALIAS, [.3, .1])]:
                for turn, value in enumerate(values, 1):
                    rows.append({"style_id": style, "profile_id": "one", "repeat_index": 0,
                                 "arm": arm, "turn": turn, "features": {"f": value}})
        first, _ = summarize(rows, ["f"], True)
        whole, _ = summarize(rows, ["f"])
        self.assertAlmostEqual(first["plain"]["f"]["alias_minus_native"], .2)
        self.assertAlmostEqual(whole["plain"]["f"]["alias_minus_native"], -.3)


if __name__ == "__main__":
    unittest.main()
