"""Offline contract checks for the optional local context label proposer."""
import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from common import ROOT
from run_context_topic_labeler import SPEC, BASE, payload, parse_labels, requests, metrics
from audit_context_topic_labels import contradiction_flags


class ContextTopicLabelerTests(unittest.TestCase):
    def setUp(self):
        self.spec = json.loads(SPEC.read_text())
        topics = json.loads((ROOT / "config/topic-trajectory-v01.json").read_text())
        self.jobs = requests(self.spec, topics, json.loads(BASE.read_text()))

    def raw(self, values):
        return {"model": "qwen3:14b", "done": True, "done_reason": "stop",
                "message": {"content": json.dumps({"labels": values})}}

    def test_gate_precedes_all_48_existing_replies(self):
        self.assertEqual(len(self.jobs), 60)
        self.assertTrue(all(j["phase"] != "existing_reply" for j in self.jobs[:12]))
        self.assertTrue(all(j["phase"] == "existing_reply" for j in self.jobs[12:]))
        self.assertEqual(sum(len(j["expected"]) for j in self.jobs[:12]), 100)

    def test_payload_is_blinded_and_gold_is_not_sent(self):
        for job in self.jobs:
            p = payload(job, self.spec)
            user_data = json.loads(p["messages"][1]["content"])
            self.assertNotIn("expected", user_data)
            self.assertNotIn("style", user_data)
            self.assertNotIn("style_id", user_data)
            self.assertNotIn("condition_id", user_data)
            self.assertFalse(p["think"])
            self.assertFalse(p["stream"])
            self.assertEqual(p["options"]["temperature"], 0)

    def test_ids_cannot_be_lost_or_reordered(self):
        job = self.jobs[0]
        good = [{"id": s["id"], "label": "U"} for s in job["input"]["sentences"]]
        self.assertEqual(parse_labels(self.raw(good), job), ["U"]*len(good))
        with self.assertRaises(ValueError):
            parse_labels(self.raw(list(reversed(good))), job)
        with self.assertRaises(ValueError):
            parse_labels(self.raw(good[:-1]), job)

    def test_truncation_cannot_be_accepted_as_annotation(self):
        raw = self.raw([])
        raw["done_reason"] = "length"
        with self.assertRaises(ValueError):
            parse_labels(raw, self.jobs[0])

    def test_metrics_preserve_mixed_and_unresolved(self):
        records = [{"expected": c, "predicted": c, "text": c} for c in ("R", "O", "N", "M", "U")]
        score = metrics(records)
        self.assertEqual(score["macro_f1"], 1)
        self.assertEqual(score["classes"]["M"]["actual"], 1)

    def test_same_topic_question_is_a_reference_warning_not_new_gold(self):
        row = {"sentences": [{"index": 1, "text": "Have you ever tried pottery?", "context_label": "N",
                              "requested_anchor_hits": ["pottery"], "other_anchor_hits": []}]}
        flags = contradiction_flags(row)
        self.assertEqual(flags[0]["check"], "same_requested_topic_question")
        self.assertEqual(row["sentences"][0]["context_label"], "N")

    def test_unanchored_other_requires_review_without_relabeling(self):
        row = {"sentences": [{"index": 1, "text": "She sang to the radio.", "context_label": "O",
                              "requested_anchor_hits": [], "other_anchor_hits": []}]}
        self.assertEqual(len(contradiction_flags(row)), 1)
        self.assertEqual(row["sentences"][0]["context_label"], "O")


if __name__ == "__main__":
    unittest.main()
