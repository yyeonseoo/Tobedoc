import ast
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import psyche_factorial as experiment
from audit_psyche_roleplay_sources import source_text


class ProtocolTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.spec = json.loads(experiment.SPEC.read_text())
        cls.rows = experiment.build(cls.spec)

    def test_exact_balanced_design(self):
        self.assertEqual(len(self.rows), 16)
        self.assertEqual(len({r['id'] for r in self.rows}), 16)
        self.assertEqual(len({r['prompt_sha256'] for r in self.rows}), 8)

    def test_single_clause_prompt_difference(self):
        for row in self.rows:
            if row['arm'] != 'hub_unchanged':
                continue
            paired = next(r for r in self.rows if r['arm'] == 'quantity_clause_only' and all(r[k] == row[k] for k in ('quantity', 'thought', 'seed')))
            original = row['payload']['messages'][0]['content']
            self.assertEqual(original.replace(self.spec['edit']['old'], self.spec['edit']['new']), paired['payload']['messages'][0]['content'])

    def test_only_two_mfc_fields_change(self):
        for row in self.rows:
            restored = json.loads(json.dumps(row['case']))
            for field in ('Verbal productivity', 'Thought process'):
                restored['MFC-Behavior'][field] = self.spec['case']['MFC-Behavior'][field]
            self.assertEqual(restored, self.spec['case'])

    def test_all_cases_valid_against_locked_schema(self):
        namespace = {'__name__': 'offline_factorial_schema_test'}
        exec(compile(ast.parse(source_text('patienthub/schemas/base.py')), 'locked_base', 'exec'), namespace)
        tree = ast.parse(source_text('patienthub/schemas/psyche.py'))
        tree.body = [n for n in tree.body if not (isinstance(n, ast.ImportFrom) and n.module == 'patienthub.schemas.base')]
        exec(compile(tree, 'locked_psyche', 'exec'), namespace)
        model = namespace['PsycheCharacter']
        for row in self.rows:
            model.model_validate(row['case'])

    def test_identical_fresh_histories(self):
        for row in self.rows:
            messages = row['payload']['messages']
            self.assertEqual([m['role'] for m in messages], ['system', 'user'])
            self.assertEqual(messages[1]['content'], self.spec['interviewer_question'])
            self.assertNotIn('{{', messages[0]['content'])

    def test_seed_does_not_change_prompt(self):
        self.assertEqual(len({r['payload']['options']['seed'] for r in self.rows}), 2)
        self.assertEqual(experiment.build(self.spec), self.rows)

    def test_truncation_never_counted_completed(self):
        response = {'done': True, 'done_reason': 'length', 'model': self.spec['model'], 'message': {'content': 'Example'}}
        self.assertEqual(experiment.classify(response, self.spec), 'truncated')
        response['done_reason'] = 'stop'
        response['eval_count'] = 768
        self.assertEqual(experiment.classify(response, self.spec), 'truncated')

    def test_descriptors_are_not_clinical_scores(self):
        result = experiment.describe('I make tea. Then I take the bus.', self.spec['case'])
        self.assertEqual(result['words'], 8)
        self.assertEqual(result['approx_sentence_units'], 2)
        self.assertNotIn('coherence', result)


if __name__ == '__main__':
    unittest.main()
