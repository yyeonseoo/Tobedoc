import sys
import unittest
from collections import defaultdict
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from fact_disclosure_probe import conditions, match_fact, paired
from disclosure_order_followup import conditions as crossed_conditions
from run_feature_batch import payload


class DisclosureProbeTests(unittest.TestCase):
    def test_bounded_matched_design(self):
        with patch("urllib.request.urlopen", side_effect=AssertionError("No network during preparation")):
            rows = conditions()
        self.assertEqual(len(rows), 18)
        groups = defaultdict(list)
        for row in rows:
            groups[(row["profile_id"], row["repeat_index"])].append(row)
            self.assertEqual(len(row["facts"]), 6)
            self.assertEqual(sum(f["domain"] == "personal" for f in row["facts"]), 3)
            self.assertEqual(len(row["interview"]), 1)
            self.assertNotIn("sentences each turn", row["system_prompt"])
        self.assertEqual(len(groups), 6)
        for group in groups.values():
            self.assertEqual(len(group), 3)
            self.assertEqual(len({r["interview"][0]["text"] for r in group}), 1)
            self.assertEqual(len({str(payload(r, [], 1)["options"]) for r in group}), 1)
            self.assertTrue(all(r["facts"] == group[0]["facts"] for r in group))

    def test_numeric_boundaries_and_spelled_forms(self):
        fact = {"id": "fee", "domain": "event", "aliases": ["25", "twenty five"]}
        self.assertTrue(match_fact("The fee is $25.", fact)["recognized_mention"])
        self.assertTrue(match_fact("It costs twenty-five dollars.", fact)["recognized_mention"])
        self.assertFalse(match_fact("There are 125 people.", fact)["recognized_mention"])
        self.assertFalse(match_fact("It costs 25.50 dollars.", fact)["recognized_mention"])
        self.assertFalse(match_fact("It costs 25,000 dollars.", fact)["recognized_mention"])

    def test_negated_reference_is_flagged_not_called_correct(self):
        fact = {"id": "amount", "domain": "personal", "aliases": ["260"]}
        found = match_fact("It is not 260 dollars.", fact)
        self.assertTrue(found["recognized_mention"])
        self.assertTrue(found["matches"][0]["negation_nearby_flag"])

    def test_all_supplied_fact_descriptions_are_recognizable(self):
        for row in conditions():
            for fact in row["facts"]:
                self.assertTrue(match_fact(fact["description"], fact)["recognized_mention"])

    def test_paired_contrast_and_missing_cells(self):
        rows = []
        for case in range(3):
            for repeat in range(2):
                for style, fraction in [("r", 1/3), ("b", 1)]:
                    rows.append({"profile_id": case, "repeat_index": repeat, "style_id": style,
                                 "fraction": {"personal": fraction, "event": 1}})
        self.assertAlmostEqual(paired(rows, "r", "b", "personal")["mean"], -2/3)
        self.assertAlmostEqual(paired(rows, "r", "b", "personal_minus_event")["mean"], -2/3)
        with self.assertRaises(ValueError):
            paired(rows[:-1], "r", "b", "personal")

    def test_followup_crosses_order_without_changing_seed_or_profile(self):
        originals = {r["condition_id"]: r for r in conditions()}
        crossed = crossed_conditions()
        self.assertEqual(len(crossed), 6)
        for row in crossed:
            old = originals[row["condition_id"].replace("X-", "D-", 1)]
            self.assertEqual(row["style_id"], "psi_reserved_no_numeric_cap")
            self.assertEqual(row["system_prompt"], old["system_prompt"])
            self.assertEqual(row["facts"], old["facts"])
            self.assertEqual(payload(row, [], 1)["options"], payload(old, [], 1)["options"])
            self.assertNotEqual(row["interview"][0]["text"], old["interview"][0]["text"])


if __name__ == "__main__":
    unittest.main()
