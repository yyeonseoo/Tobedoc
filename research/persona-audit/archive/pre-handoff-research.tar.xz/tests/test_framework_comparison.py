"""Offline checks for the prepared, not yet generated, module comparison."""
import sys
from pathlib import Path
import unittest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"scripts"))
from prepare_framework_comparison import build
from common import digest


class FrameworkComparisonTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.plan,cls.rows,cls.pilot,cls.audit,cls.measurement=build()

    def test_bounded_pilot_excludes_heldout(self):
        self.assertEqual(len(self.rows),72)
        self.assertEqual(len(self.pilot),18)
        self.assertEqual({r["split"] for r in self.pilot},{"development"})
        self.assertEqual({r["repeat_index"] for r in self.pilot},{0})

    def test_disjoint_person_families(self):
        dev={r["case_family"] for r in self.rows if r["split"]=="development"}
        test={r["case_family"] for r in self.rows if r["split"]=="heldout"}
        self.assertEqual(len(dev),3)
        self.assertEqual(len(test),3)
        self.assertFalse(dev & test)

    def test_complete_pairs_and_common_questions(self):
        for case in self.plan["cases"]:
            group=[r for r in self.rows if r["case_id"]==case["id"]]
            self.assertEqual(len(group),12)
            self.assertEqual(len({tuple(r["interview"]) for r in group}),1)
            for program in self.plan["programs"]:
                for repeat in [0,1]:
                    self.assertEqual({r["style"] for r in group if r["program"]==program and r["repeat_index"]==repeat},{"plain","verbose"})

    def test_only_one_common_cap_and_no_missing_fields(self):
        for r in self.rows:
            self.assertEqual(r["system_prompt"].count("at most 5 sentences"),1)
            self.assertNotIn("must not exceed",r["system_prompt"])
            self.assertNotIn("undefined",r["system_prompt"])
            self.assertEqual(r["prompt_sha256"],digest(r["system_prompt"].encode()))
            self.assertIsNone(r["response_text"])
            self.assertEqual(r["generation_status"],"not_run")

    def test_unchanged_feature_contract_and_honest_scope(self):
        features=self.measurement["features"]
        self.assertEqual(len(features),17)
        self.assertEqual(sum(f["analysis_role"]=="primary_descriptive" for f in features),8)
        self.assertEqual(self.audit["new_generation_calls"],0)
        self.assertFalse(self.audit["native_patientsim_execution_ready"])
        self.assertTrue(all(r["scope"]=="controlled_style_module_port_not_native_framework" for r in self.rows))


if __name__=="__main__":
    unittest.main()
