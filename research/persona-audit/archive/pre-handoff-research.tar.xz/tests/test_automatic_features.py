"""No inference/downloads/manual labels; mathematical and design-level checks."""
import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from common import ROOT
from extract_automatic_features import adjacent, centroid, cosine, mattr, mean, slope, summaries, words
from run_feature_batch import conditions, payload


class AutomaticFeatureTests(unittest.TestCase):
    def test_cosine_and_missing_are_not_fabricated(self):
        self.assertEqual(cosine([1, 0], [1, 0]), 1)
        self.assertEqual(cosine([1, 0], [0, 1]), 0)
        self.assertEqual(cosine([1, 0], [-1, 0]), -1)
        self.assertIsNone(cosine(None, [1, 0]))
        self.assertIsNone(cosine([0, 0], [1, 0]))
        self.assertIsNone(centroid([[1, 0], None]))
        with self.assertRaises(ValueError):
            cosine([1, 0], [1])

    def test_fixed_mattr_and_tokenization(self):
        self.assertEqual(words("I’m not sure, I don't know."), ["i'm", "not", "sure", "i", "don't", "know"])
        self.assertIsNone(mattr(["short"] * 19))
        self.assertEqual(mattr(["same"] * 20), .05)
        self.assertEqual(mattr([str(i) for i in range(22)]), 1)

    def test_normalised_slope(self):
        self.assertAlmostEqual(slope([.2, .4, .6]), .4)
        self.assertAlmostEqual(slope([.6, .4, .2]), -.4)
        self.assertIsNone(slope([.4]))

    def test_reversal_invariance_and_duplication_inflation(self):
        vectors = [[1, 0], [0, 1], [-1, 0]]
        original = mean(adjacent(vectors))
        self.assertEqual(original, mean(adjacent(list(reversed(vectors)))))
        self.assertGreater(mean(adjacent([vectors[0]] + vectors)), original)
        self.assertEqual(adjacent([[1, 0]]), [])

    def test_original_only_complete_matched_design(self):
        cases = conditions()
        self.assertEqual(len(cases), 36)
        self.assertEqual(len({c["condition_id"] for c in cases}), 36)
        self.assertEqual({c["arm"] for c in cases}, {"native_demo_mapping"})
        self.assertEqual({c["case_family_id"] for c in cases}, {"Abe"})
        self.assertEqual(len({c["style_id"] for c in cases}), 6)
        for repeat in [0, 1]:
            seeds = {payload(c, [], 1)["options"]["seed"] for c in cases if c["repeat_index"] == repeat}
            self.assertEqual(len(seeds), 1)

    def test_seventeen_features_no_manual_clinical_score(self):
        spec = json.loads((ROOT / "config/automatic-features-v01.json").read_text())
        self.assertEqual(len(spec["features"]), 17)
        self.assertEqual(len({f["id"] for f in spec["features"]}), 17)
        self.assertFalse(spec["manual_rating_used"])
        self.assertFalse(spec["clinical_composite_score_created"])

    def test_dialogue_not_turn_weighting_and_paired_contrast(self):
        rows = []
        for style, values in [("plain", [2, 2, 2, 2]), ("tangent", [4, 4, 4, 4])]:
            for value in values:
                rows.append({"condition_id": style, "profile_id": "one", "style_id": style,
                             "arm": "native_demo_mapping", "repeat_index": 0, "features": {"word_count": value}})
        dialogues, profiles, contrasts = summaries(rows, ["word_count"])
        self.assertEqual(len(dialogues), 2)
        self.assertEqual(contrasts[0]["paired_blocks"], 1)
        self.assertEqual(contrasts[0]["mean_difference_from_plain"], 2)


if __name__ == "__main__":
    unittest.main()
