"""Offline protocol tests; no inference or synthetic clinical score fixtures."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'scripts'))
import psyche_controls as controls


class ControlProtocolTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.spec = controls.read(controls.SPEC)
        cls.previous = controls.read(controls.old.SPEC)
        cls.rows = controls.build(cls.spec, cls.previous)

    def test_balanced_32_requests(self):
        self.assertEqual(len(self.rows), 32)
        self.assertEqual(len({r['id'] for r in self.rows}), 32)
        for arm in self.spec['arms']:
            self.assertEqual(sum(r['arm'] == arm for r in self.rows), 8)

    def test_exact_cache_reuse_four(self):
        self.assertEqual(len(controls.cache_candidates(self.rows, self.previous)), 4)

    def test_modified_payload_not_reused(self):
        rows = deepcopy(self.rows)
        for row in rows:
            row['payload']['messages'][1]['content'] += ' Please.'
        self.assertEqual(controls.cache_candidates(rows, self.previous), {})

    def test_identical_model_options_across_arms(self):
        for row in self.rows:
            self.assertEqual(row['payload']['model'], self.previous['model'])
            self.assertEqual(row['payload']['options'], {**self.previous['options'], 'seed': row['seed']})
            self.assertFalse(row['payload']['think'])

    def test_no_thought_factor_or_history(self):
        for row in self.rows:
            self.assertEqual(row['case']['MFC-Behavior']['Thought process'], 'Normal')
            self.assertEqual([m['role'] for m in row['payload']['messages']], ['system', 'user'])

    def test_numeric_instruction_once_and_only_when_provided(self):
        for row in self.rows:
            count = row['payload']['messages'][0]['content'].count('Output constraint:')
            self.assertEqual(count, int(row['numeric_instruction_provided']))

    def test_original_schema_fields_preserved(self):
        for row in self.rows:
            case = deepcopy(row['case'])
            extension = case.pop(self.spec['json_extension_key'], None)
            self.assertEqual(extension is not None, row['arm'] == 'hub_json_numeric')
            case['MFC-Behavior']['Verbal productivity'] = self.previous['case']['MFC-Behavior']['Verbal productivity']
            self.assertEqual(case, self.previous['case'])

    def test_tail_and_json_contain_identical_instruction(self):
        for row in self.rows:
            if row['arm'] != 'hub_json_numeric':
                continue
            instruction = row['case'][self.spec['json_extension_key']]
            paired = next(r for r in self.rows if r['arm'] == 'hub_tail_numeric' and all(r[k] == row[k] for k in ('quantity', 'question', 'seed')))
            self.assertTrue(paired['payload']['messages'][0]['content'].endswith(instruction))

    def test_ranges_are_disjoint(self):
        self.assertLess(self.spec['targets']['Normal'][1], self.spec['targets']['Increased'][0])
        self.assertEqual(self.spec['gate']['target_denominator'], 8)

    def test_frozen_reproducible_order(self):
        self.assertEqual(self.rows, controls.build(self.spec, self.previous))


if __name__ == '__main__':
    unittest.main()
