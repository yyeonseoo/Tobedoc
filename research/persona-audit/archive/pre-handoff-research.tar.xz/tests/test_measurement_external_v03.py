import sys
from pathlib import Path
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
import measurement_external_v03 as r


class RuleSegmentationTests(unittest.TestCase):
    def test_lowercase_tokenized_sentences(self):
        text='i went home . i cooked dinner . i ate it .'
        self.assertEqual([s['text'] for s in r.segment(text)],['i went home .','i cooked dinner .','i ate it .'])

    def test_fixed_abbreviations_and_decimal(self):
        text='dr . park spent 2.5 hours working . he left .'
        self.assertEqual(len(r.segment(text)),2)
        self.assertTrue(r.segment(text)[0]['text'].startswith('dr . park'))

    def test_original_spans_unicode_and_whitespace(self):
        text='  a cat 🐈 slept .\nnext day it woke .  '
        for s in r.segment(text):
            a=2*s['utf16_start'];b=a+2*s['utf16_length']
            self.assertEqual(text.encode('utf-16-le')[a:b].decode('utf-16-le'),s['text'])

    def test_no_punctuation_is_not_invented_sentences(self):
        self.assertEqual(len(r.segment('one short summary without punctuation')),1)

    def test_punctuation_only_segment_not_silently_deleted(self):
        self.assertEqual([s['text'] for s in r.segment('a sentence . ... another one .')],['a sentence .','...','another one .'])

    def test_official_first_record_has_five_boundaries(self):
        if not r.RAW.exists(): self.skipTest('Official source not downloaded')
        text=r.stats.source_records()[0]['text']
        self.assertEqual(len(r.segment(text)),5)


if __name__=='__main__': unittest.main()
