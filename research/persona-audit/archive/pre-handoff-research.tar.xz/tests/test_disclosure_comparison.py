"""Offline implementation checks, not clinical gold labels."""
import sys
from pathlib import Path
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from disclosure_comparison import conditions,styles,read,SPEC
from disclosure_cues import cues,check_controls
from run_feature_batch import payload
from run_local_pilot import fingerprint
from fact_disclosure_probe import match_fact


class DisclosureComparisonTests(unittest.TestCase):
    def test_cue_controls(self):
        controls=check_controls()
        self.assertEqual(len(controls),40)
        for row in controls:
            with self.subTest(row['id']):
                self.assertTrue(row['passed'],str(row))

    def test_fully_crossed_matched_conditions(self):
        rows=conditions()
        self.assertEqual(len(rows),40)
        self.assertEqual(len({r['condition_id'] for r in rows}),40)
        for person in ('DC1','DC2'):
            for order in ('event_first','personal_first'):
                for seed in (10,11):
                    group=[r for r in rows if (r['profile_id'],r['order'],r['repeat_index'])==(person,order,seed)]
                    self.assertEqual(len(group),5)
                    self.assertEqual(len({r['interview'][0]['text'] for r in group}),1)
                    self.assertEqual(len({payload(r,[],1)['options']['seed'] for r in group}),1)
                    self.assertEqual(len({r['system_prompt'].split('Conversation style:')[0] for r in group}),1)

    def test_exact_cap_removal_and_hashes(self):
        modules=styles()
        self.assertEqual(modules['neutral'],'')
        self.assertIn('guarded in some turns',modules['psi_reserved'])
        self.assertIn('May refuses',modules['sim_distrust'])
        for row in conditions():
            self.assertNotIn('must not exceed',row['system_prompt'])
            self.assertEqual(row['prompt_sha256'],fingerprint({'system_prompt':row['system_prompt'],'interview':row['interview']}))

    def test_fact_domains_and_nonoverlap(self):
        for case in read(SPEC)['fictional_cases']:
            for domain in ('event','personal'):
                self.assertEqual(sum(f['domain']==domain for f in case['facts']),3)
            for fact in case['facts']:
                self.assertTrue(match_fact(fact['description'],fact)['recognized_mention'])
                for other in case['facts']:
                    if fact['id']!=other['id']:
                        self.assertFalse(match_fact(other['description'],fact)['recognized_mention'])

    def test_cue_spans_are_original_text_and_uncertainty_separate(self):
        text='I’d rather not share that. I do not know it.'
        found=cues(text)
        self.assertTrue(found['nondisclosure']['present'])
        self.assertTrue(found['uncertainty']['present'])
        for value in found.values():
            for hit in value['matches']:
                self.assertEqual(text[hit['start']:hit['end']],hit['span'])
        self.assertFalse(cues("I can't remember.")['nondisclosure']['present'])


if __name__=='__main__':
    unittest.main()
