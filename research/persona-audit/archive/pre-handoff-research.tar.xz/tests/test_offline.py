"""Check source integrity and the material assumptions behind the first pilot."""
import csv
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from common import read_source, source_records
from audit_sources import extract_template, parse_styles
from prepare_pilot import build_conditions, js_string, repair_profile, render_prompt
import fetch_sources
from local_preflight import local_metadata
from common import ROOT, digest


class SourceAndPilotTests(unittest.TestCase):
    def test_compute_policy_has_no_paid_or_automatic_model_actions(self):
        policy = json.loads((ROOT / "config/compute-policy.json").read_text())
        for key in ["paid_model_api_allowed", "automatic_credit_purchase_allowed",
                    "automatic_model_download_allowed", "automatic_package_install_allowed"]:
            self.assertFalse(policy[key])
        self.assertFalse(policy["local_llm"]["experimental_backbone_selected"])
        self.assertFalse(policy["local_llm"]["clinical_judge_selected"])
        self.assertFalse(policy["remote_mac_mini"]["automatic_jobs_allowed"])

    def test_preflight_rejects_inference_and_download_routes(self):
        for route in ["/api/chat", "/api/generate", "/api/pull", "https://example.org/api/tags"]:
            with self.subTest(route=route), self.assertRaises(ValueError):
                local_metadata(route)

    def test_feature_locators_are_present_but_not_clinically_validated(self):
        with (ROOT / "catalog/feature-map.csv").open(encoding="utf-8", newline="") as f:
            rows = list(csv.DictReader(f))
        self.assertEqual(len(rows), 27)
        self.assertEqual(len({r["feature_id"] for r in rows}), 27)
        for row in rows:
            with self.subTest(feature=row["feature_id"]):
                self.assertIn(row["locator"].lower(), read_source(row["source_id"]).lower())
                self.assertIn(row["mapping_status"], {"advisor_review_pending", "not_applicable"})

    def test_integrity_failure_preserves_original_hash_across_retries(self):
        with tempfile.TemporaryDirectory() as task_dir:
            root = Path(task_dir)
            (root / "locked.txt").write_text("changed", encoding="utf-8")
            item = {"id": "locked", "url": "https://example.org/locked", "kind": "text"}
            prior = {**item, "status": "ok", "local_raw": "locked.txt", "local_text": "locked.txt",
                     "sha256": digest(b"original"), "text_sha256": digest(b"original")}
            with patch.object(fetch_sources, "ROOT", root), patch.object(fetch_sources.urllib.request, "urlopen") as network:
                first = fetch_sources.fetch_one(item, {}, {"locked": prior})
                second = fetch_sources.fetch_one(item, {}, {"locked": first})
                network.assert_not_called()
            for result in [first, second]:
                self.assertEqual(result["status"], "error")
                self.assertEqual(result["sha256"], prior["sha256"])
            self.assertEqual((root / "locked.txt").read_text(), "changed")

    def test_all_sources_are_accessible_and_hash_verified(self):
        config = json.loads((ROOT / "config/sources.json").read_text())
        self.assertEqual(set(source_records()), {x["id"] for x in config["sources"]})
        self.assertEqual(len(source_records()), 23)
        for source_id in source_records():
            with self.subTest(source_id=source_id):
                self.assertTrue(read_source(source_id).strip())

    def test_javascript_missing_and_array_semantics(self):
        self.assertEqual(js_string(["one", "two"]), "one,two")
        self.assertEqual(js_string(None), "null")
        template = "${data.missing} ${patientTypeContent}"
        self.assertEqual(render_prompt(template, {}, "")[0], "undefined ")

    def test_demo_is_one_person_not_three(self):
        profiles = json.loads(read_source("psi_profiles"))
        self.assertEqual(len(profiles), 3)
        self.assertEqual({x["name"] for x in profiles}, {"Abe"})

    def test_missing_fields_are_real_and_repair_removes_them(self):
        template = extract_template(read_source("psi_formatter"))
        for profile in json.loads(read_source("psi_profiles")):
            raw, missing = render_prompt(template, profile, "")
            self.assertEqual(set(missing), {"core_belief", "auto_thoughts", "intermediate_belief_depression"})
            self.assertIn("undefined", raw)
            repaired, changes = repair_profile(profile)
            rendered, missing = render_prompt(template, repaired, "")
            self.assertFalse(missing)
            self.assertNotIn("undefined", rendered)
            self.assertEqual(len(changes), 3)
            self.assertEqual(repaired["auto_thoughts"], profile["auto_thought"])
            self.assertEqual(repaired["history"], profile["history"])
            before, after = profile["intermediate_belief"].split("[during depression]", 1)
            self.assertEqual(repaired["intermediate_belief"], before.strip())
            self.assertEqual(repaired["intermediate_belief_depression"], after.strip())

    def test_styles_and_competing_limits_are_preserved(self):
        styles = parse_styles(read_source("psi_styles"))
        self.assertEqual(set(styles), {"plain", "upset", "verbose", "reserved", "tangent", "pleasing"})
        self.assertIn("must not return back to topic during a turn", styles["tangent"])
        self.assertIn("must not exceed 8 sentences", styles["verbose"])
        self.assertIn("maximum of 5 sentences", extract_template(read_source("psi_formatter")))

    def test_conditions_are_unique_matched_and_have_no_fake_results(self):
        records = build_conditions()
        self.assertEqual(len(records), 36)
        self.assertEqual(len({x["condition_id"] for x in records}), 36)
        for record in records:
            self.assertIsNone(record["response_text"])
            self.assertIsNone(record["clinical_rating"])
            self.assertIsNone(record["backend_model_id"])
            self.assertEqual(record["inference_status"], "not_run")
            self.assertFalse(record["is_schizophrenia_case"])
            self.assertEqual(len(record["interview"]), 4)
        for profile in {x["profile_id"] for x in records}:
            for style in {x["style_id"] for x in records}:
                pair = [x for x in records if x["profile_id"] == profile and x["style_id"] == style]
                self.assertEqual(len(pair), 2)
                self.assertEqual(pair[0]["interview"], pair[1]["interview"])
                self.assertNotEqual(pair[0]["prompt_sha256"], pair[1]["prompt_sha256"])

    def test_unsupported_template_expression_fails_closed(self):
        with self.assertRaises(ValueError):
            render_prompt("${unknown.expression}", {}, "")


if __name__ == "__main__":
    unittest.main()
