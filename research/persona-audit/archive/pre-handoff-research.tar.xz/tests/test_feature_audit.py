import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from build_feature_audit import build, report, ROOT
from common import digest


class FeatureAuditTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with patch("urllib.request.urlopen", side_effect=AssertionError("Offline audit must not access network")):
            cls.audit = build()

    def test_scope_and_numeric_reproduction(self):
        self.assertEqual(len(self.audit["inventory"]), 18)
        self.assertEqual(len(self.audit["styles"]), 6)
        self.assertEqual(self.audit["verification"]["native_responses_hash_checked"], 144)
        self.assertEqual(self.audit["verification"]["inventory_source_anchors_checked"], 18)
        self.assertEqual(self.audit["verification"]["cross_source_metric_contrasts_checked"], 51)
        self.assertEqual(self.audit["new_generation_calls"], 0)
        self.assertEqual(self.audit["llm_judge_calls"], 0)

    def test_fixed_examples_in_report_without_rewriting(self):
        text = report(self.audit)
        for row in self.audit["styles"]:
            example = row["example"]
            self.assertEqual(example["condition_id"], f"F-1-1-{row['style']}-R0")
            self.assertEqual(example["turn"], 1)
            self.assertIn(example["response_text"], text)
        self.assertIn("질문 유사도 +0.002", text)
        self.assertIn("초기 상황 유사도 +0.010", text)

    def test_inputs_remain_unchanged(self):
        for row in self.audit["provenance"]:
            self.assertEqual(digest((ROOT / row["path"]).read_bytes()), row["sha256"])


if __name__ == "__main__":
    unittest.main()
