import sys
import unittest
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from topic_selection_probe import conditions, event_metrics, paired, STYLES
from fact_disclosure_probe import match_fact
from run_feature_batch import payload


class TopicSelectionTests(unittest.TestCase):
    def test_frozen_full_cross_and_shared_inputs(self):
        rows = conditions()
        self.assertEqual(len(rows), 48)
        self.assertEqual(len({r["condition_id"] for r in rows}), 48)
        blocks = defaultdict(list)
        for row in rows:
            blocks[(row["profile_id"], row["target_event"], row["variant_id"], row["repeat_index"])].append(row)
            self.assertNotIn("sentences each turn", row["system_prompt"])
            self.assertEqual(len(row["interview"]), 1)
            for fact in row["facts"]:
                self.assertTrue(match_fact(fact["description"], fact)["recognized_mention"])
        self.assertEqual(len(blocks), 16)
        for block in blocks.values():
            self.assertEqual({r["style_id"] for r in block}, set(STYLES))
            self.assertEqual(len({r["interview"][0]["text"] for r in block}), 1)
            self.assertEqual(len({str(payload(r, [], 1)["options"]) for r in block}), 1)
            self.assertTrue(all(r["facts"] == block[0]["facts"] for r in block))

    def test_distinct_markers_and_return_sequence(self):
        facts = [{"id": "a", "domain": "A", "aliases": ["mira"]}, {"id": "b", "domain": "B", "aliases": ["owen"]}]
        before = event_metrics("Mira was there. Owen came later.", facts, "A")
        after = event_metrics("Owen was there. Mira came later.", facts, "A")
        self.assertEqual(before["marker_class"], "both")
        self.assertFalse(before["other_then_requested_marker"])
        self.assertTrue(after["other_then_requested_marker"])
        absent = event_metrics("I do not remember.", facts, "A")
        self.assertEqual(absent["marker_class"], "neither")
        self.assertIsNone(absent["other_share_of_matched_facts"])

    def test_paired_missing_is_not_zero(self):
        rows = [{"profile_id": "N", "target_event": "A", "variant_id": "V", "repeat_index": 4,
                 "style_id": s, "metric": v} for s, v in [("tangent", 1), ("verbose", 0)]]
        self.assertEqual(paired(rows, "tangent", "verbose", "metric")["mean"], 1)
        with self.assertRaises(ValueError):
            paired(rows[:1], "tangent", "verbose", "metric")


if __name__ == "__main__":
    unittest.main()
