"""Deterministic tests; no model inference, networking or clinical labels."""
import json
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from common import ROOT
from analyze_topic_trajectory import (SPEC, anchors, classify, classification_metrics,
                                     exact_utf16, make_controls, other_topic, sequence_metrics)
from audit_discourse_return import discourse_cue


class TopicTrajectoryTests(unittest.TestCase):
    def setUp(self):
        self.spec = json.loads(SPEC.read_text())
        self.params = {"high": .4, "low": .3, "margin": .1}

    def item(self, r, o, literal="U", n=10):
        return {"literal_label": literal, "requested_cos": r, "other_cos": o, "word_count": n}

    def test_crossed_controls_and_context_reversal(self):
        controls = make_controls(self.spec)
        self.assertEqual(len(controls), 80)
        self.assertEqual(len({c["id"] for c in controls}), 80)
        self.assertEqual(other_topic(self.spec, "train"), "pottery")
        a = next(c for c in controls if c["id"] == "holdout-train-requested_literal")
        b = next(c for c in controls if c["id"] == "holdout-pottery-other_literal")
        self.assertEqual(a["text"], b["text"])
        self.assertEqual((a["expected"], b["expected"]), ("R", "O"))

    def test_anchor_boundaries_not_substrings(self):
        self.assertFalse(anchors("My training is over.", self.spec, "train"))
        self.assertTrue(anchors("The TRAIN arrived.", self.spec, "train"))

    def test_literal_labels_override_similarity_without_claiming_truth(self):
        for label in ("R", "O", "B"):
            self.assertEqual(classify(self.item(.01, .99, label), self.params), label)

    def test_short_or_missing_abstains(self):
        self.assertEqual(classify(self.item(.1, .1, n=4), self.params), "U")
        self.assertEqual(classify(self.item(None, .1), self.params), "U")

    def test_low_score_is_candidate_not_forced_topic(self):
        self.assertEqual(classify(self.item(.29, .2), self.params), "D")
        self.assertEqual(classify(self.item(.3, .2), self.params), "U")

    def test_margin_and_high_threshold(self):
        self.assertEqual(classify(self.item(.55, .3), self.params), "R")
        self.assertEqual(classify(self.item(.3, .55), self.params), "O")
        self.assertEqual(classify(self.item(.5, .49), self.params), "U")

    def test_distinguish_other_then_return_from_full_excursion(self):
        self.assertTrue(sequence_metrics(["R", "O", "U", "R"])["requested_away_requested"])
        self.assertTrue(sequence_metrics(["O", "R"])["other_then_requested"])
        self.assertFalse(sequence_metrics(["O", "R"])["requested_away_requested"])
        self.assertFalse(sequence_metrics(["R", "B", "R"])["other_then_requested"])
        self.assertFalse(sequence_metrics(["R", "U", "R"])["requested_away_requested"])

    def test_sequence_order_not_bag_of_labels(self):
        self.assertTrue(sequence_metrics(["R", "D", "R"])["requested_away_requested"])
        self.assertFalse(sequence_metrics(["R", "R", "D"])["requested_away_requested"])
        self.assertEqual(sequence_metrics(["R", "U", "O", "R"])["definite_label_changes"], 2)

    def test_utf16_spans_preserve_non_bmp_characters(self):
        self.assertEqual(exact_utf16("A😀. Train.", 5, 6), "Train.")

    def test_confusion_metrics_keep_abstention(self):
        items = [{"expected": label, "predicted": label, "literal_label": "U", "text": label} for label in ("R", "O", "D", "U", "B")]
        score = classification_metrics(items)
        self.assertEqual(score["macro_f1"], 1)
        self.assertEqual(score["anchorless_known_topic_recall"], 1)

    def test_narrow_cue_excludes_physical_movement(self):
        spec = json.loads((ROOT / "config/discourse-return-cue-v01.json").read_text())
        for c in spec["controls"]:
            self.assertEqual(discourse_cue(c["text"], anchors(c["text"], self.spec, c["requested_topic"]), spec), c["expected"], c["text"])


if __name__ == "__main__":
    unittest.main()
