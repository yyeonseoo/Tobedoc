"""Known-style discrimination is exploratory and uses training-only preprocessing."""
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from analyze_feature_profiles import eta_squared, nearest_centroid, performance
from extract_automatic_features import STYLES


class FeatureProfileTests(unittest.TestCase):
    def test_centroids_and_no_test_label_fitting(self):
        train = [{"style_id": style, "feature_means": {"f": float(i)}} for i, style in enumerate(STYLES)]
        test = [{"condition_id": "example", "style_id": "wrong-label-not-used-for-fitting", "feature_means": {"f": 3.0}}]
        result = nearest_centroid(train, test, ["f"])
        self.assertEqual(result[0]["predicted_style"], STYLES[3])

    def test_confusion_and_macro_f1(self):
        result = performance([{"true_style": s, "predicted_style": s} for s in STYLES])
        self.assertEqual(result["accuracy"], 1.0)
        self.assertEqual(result["macro_f1"], 1.0)

    def test_descriptive_eta_is_not_significance(self):
        rows = [{"style_id": s, "feature_means": {"f": float(i)}} for i, s in enumerate(STYLES)]
        self.assertEqual(eta_squared(rows, "f"), 1.0)
        constant = [{"style_id": s, "feature_means": {"f": 1.0}} for s in STYLES]
        self.assertEqual(eta_squared(constant, "f"), 0.0)


if __name__ == "__main__":
    unittest.main()
