import sys
import unittest
from collections import defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from disclosure_transfer import conditions, contrasts, ARMS
from fact_disclosure_probe import conditions as old_conditions, match_fact
from run_feature_batch import payload


class DisclosureTransferTests(unittest.TestCase):
    def test_full_cross_and_new_inputs(self):
        rows = conditions()
        self.assertEqual(len(rows), 32)
        self.assertEqual(len({r["condition_id"] for r in rows}), 32)
        self.assertTrue({r["profile_id"] for r in rows}.isdisjoint({r["profile_id"] for r in old_conditions()}))
        self.assertTrue({r["repeat_index"] for r in rows}.isdisjoint({0, 1}))
        blocks = defaultdict(list)
        for r in rows:
            blocks[(r["profile_id"], r["variant_id"], r["repeat_index"])].append(r)
            self.assertEqual(len(r["interview"]), 1)
            for fact in r["facts"]:
                self.assertTrue(match_fact(fact["description"], fact)["recognized_mention"])
        self.assertEqual(len(blocks), 8)
        for block in blocks.values():
            self.assertEqual(len(block), 4)
            self.assertEqual(len({str(payload(r, [], 1)["options"]) for r in block}), 1)
            self.assertEqual(len({r["interview"][0]["text"] for r in block}), 2)
            for style in ARMS:
                pair = [r for r in block if r["style_id"] == style]
                self.assertEqual(pair[0]["system_prompt"], pair[1]["system_prompt"])

    def test_difference_of_differences_and_missing_cell(self):
        rows = []
        for style in ARMS:
            for order in ["event_first", "personal_first"]:
                count = 0 if style == ARMS[1] and order == "personal_first" else 3
                rows.append({"profile_id": "a", "variant_id": "v", "repeat_index": 2,
                             "style_id": style, "order": order, "count": {"personal": count}})
        self.assertEqual(contrasts(rows)["mean_interaction"], -1)
        with self.assertRaises(ValueError):
            contrasts(rows[:-1])


if __name__ == "__main__":
    unittest.main()
