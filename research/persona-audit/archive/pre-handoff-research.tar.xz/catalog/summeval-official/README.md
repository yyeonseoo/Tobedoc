# Official SummEval annotation snapshot

The JSONL in this directory is downloaded only from the official authors' link:
https://storage.googleapis.com/sfr-summarization-repo-research/model_annotations.aligned.jsonl

Landing page: https://github.com/Yale-LILY/SummEval
Paper: https://aclanthology.org/2021.tacl-1.24/

This is a general-news summarization evaluation resource, not patient speech.
The authors release model summaries and existing human ratings without the
source news articles. We do not reconstruct articles, contact authors, claim
clinical ratings, or redistribute source news. The repository's software MIT
license must not be treated as a blanket license to underlying news content.
Raw text is retained locally for research reproducibility; shared reports use
derived statistics rather than reproducing the summaries.
