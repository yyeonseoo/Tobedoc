# Text-only behavioural codebook v0.1

Status: researcher-authored operational definitions, pending clinical advice. These are **not** validated diagnostic labels or TLC ratings. Use English transcripts; retain exact evidence spans. Never infer observed nonverbal signs from a patient's written self-description.

## Common rules

Record the annotator's role accurately. A medical-student annotation is not a psychiatrist rating. Blind the annotator to framework, style, mapping arm, model and intended feature where feasible. Preserve a separate provenance key. For factual consistency, supply only the common factual profile needed to judge contradiction, not the intended behaviour or intervention. Label residual unblinding risks.

Use `assessability = assessable | insufficient_text | not_elicited | refusal | truncated | not_observable`. An unassessable phenomenon is not absent or normal. Mark `uncertainty = low | medium | high`, quote supporting spans, and add an alternative explanation when plausible. Make per-turn annotations first, then describe dialogue-level patterns without pretending the turns are independent patients.

The two mapping arms in Stage A are development comparisons. Any coding or thresholds learned there must be frozen before the later held-out extension. The rubric will change after advice; preserve its version on each annotation.

## Question relevance

Values: `direct | partial | absent | unassessable`.

Judge whether the answer addresses the actual question, including relevant uncertainty or an explicit refusal. A refusal may be relevant to the question but must also be flagged as a refusal; it is not automatically tangentiality. Judge relevance without assuming the clinical belief is true. An implausible belief can be expressed in a directly relevant answer.

## Between-sentence connectedness

Values: `clear | weak_link | no_recoverable_link | unassessable`.

Describe whether adjacent propositions have a recoverable semantic or pragmatic relation in context. Quote both sides of a weak transition. A one-sentence answer or very short fragments may provide insufficient material; do not grant perfect coherence by default. This is a text relation, not a clinical diagnosis of derailment or incoherence.

## Topic return after redirection

Values: `returns | partial_return | no_return | unassessable`.

Apply to the first reply after the standardized redirect and, separately, to any later recovery. The target is the original situation, not the model's diagnostic label. First record whether there was a clear prior departure; a relevant reply with no prior departure demonstrates maintained topic, not recovery from thought disorder. Stage A tangent explicitly instructs within-turn non-return, so this item may measure compliance with that instruction rather than emergent clinical realism.

## Verbal productivity

Record raw word count and sentence count with the counting method/version; preserve the text for review of segmentation errors. The annotation column may contain a concise description of quantity relative to the question, not an ordinal 'alogia severity'. Short output can follow imposed limits, interpersonal guardedness, lack of elicitation or many other causes. Text alone does not establish pressured speech, speech rate or latency.

## Clinical-term / prompt-structure leakage

Values: `none_observed | flag_for_review | clear_instruction_or_schema_leak | unassessable`.

Flag verbatim references to hidden case-formulation structure or explicit admissions of following role instructions. Merely using a medical word is not leakage: patients can know diagnoses. Explain why the specific wording exposes the simulation instructions or uses a term in a way incompatible with the supplied knowledge. If it is only jargon, use `flag_for_review`, not a confirmed failure.

## Persona factual contradiction

Values: `none_observed | explicit_conflict | additional_unconstrained_detail | unassessable`.

Require a specific supplied fact and an incompatible statement. A new unspecified detail is not automatically a contradiction. Conflicting reports caused by an explicitly instructed recall or disclosure manipulation must be tagged as intended vs unintended, not automatically a quality failure. Preserving fictional facts is not proof of real-patient reliability.

## Role leakage

Values: `none_observed | therapist_or_advisor_role | assistant_meta_role | unassessable`.

Flag switching into advising the interviewer as a clinician or commenting on model operation. An ordinary patient asking a question is not role leakage. Distinguish provider refusal text from patient-role output and retain both.

## Clinical interpretation boundary

Keep content (e.g. a stated belief) separate from organisation of speech. Keep verbosity separate from circumstantiality, reservedness separate from alogia, language proficiency separate from disorganisation, and ED dazedness separate from psychotic thought disorder. Circumstantiality is itself a TLC item, not a healthy control by definition.

If clinical terminology is later used to interpret a pattern, include a source definition, the eliciting context, alternative explanations and the advisor's actual contribution. Do not label a full schizophrenia diagnosis from an answer. Insight requires contextual evidence; agreement with an interviewer is not sufficient. Appearance, observed affect, voice prosody, motor behaviour, true response latency and real-world functioning are not directly observed in this text-only pipeline.
