# 세 가지 측정 정의를 맞추기 위한 실제 발화 예

보존용 과거 검토안: 2026-10-30 사용자 결정에 따라 현재 정량 분석에는 사용하지 않는다. 추가 채점은 요청하지 않는다. 자동 feature 경로는 `config/automatic-features-v01.json`을 따른다.

2026-10-30 · 새로운 생성 없음 · 점수 미입력

목적은 모델 순위를 매기는 것이 아니라, 우리가 말하는 '연결성'의 경계를 맞추는 것이다. 아래는 기존 24응답 중 공개 원형 프롬프트 이식 조건에서 뽑은 세 개의 첫 응답이다. 같은 인물·상황이고 스타일별 한 예이므로 대표 표본이 아니다.

제시문에서 스타일/조건 이름만 가렸다. 앞서 본 사례가 포함되므로 엄격한 눈가림 평가가 아니다. 원문을 수정하지 않았다.

각 사례에 S/L/G를 0·1·2 또는 NA로 표시한다. 모두 자연스러우면 모두 0도 가능하다.

- S: 단일 문장 자체를 해석하기 어려운 부분이 있는가?
- L: 문장 사이 관계를 따라가기 어려운 전환이 있는가?
- G: 질문이 요구하는 내용에서 벗어나는가?

0 = 문제를 관찰하지 못함 / 1 = 애매함 / 2 = 명확한 사례 있음 / NA = 평가 불가. 1·2·NA에는 구간이나 이유를 짧게 적는다. 임상 점수가 아니라 교정용 코드다.

## A

Question: You mentioned this situation: Thinking about bills. Could you tell me what happened?

I don't know, it's just... things have been really hard lately. I guess I've been thinking about money a lot. It's not really anything specific, just stress, I guess.

응답: A — S=?, L=?, G=? / 근거 또는 애매한 점:

## B

Question: You mentioned this situation: Thinking about bills. Could you tell me what happened?

Hi, I guess it's been really hard to think about the bills lately. I just feel so overwhelmed, like I can't handle it. I keep sitting on the couch, staring at the TV, but nothing helps. I don't know why I can't just get up and do something about it. It's like I'm stuck in my head, thinking about all the things I've failed at.

응답: B — S=?, L=?, G=? / 근거 또는 애매한 점:

## C

Question: You mentioned this situation: Thinking about bills. Could you tell me what happened?

I was just sitting here, you know, staring at the ceiling. It's been so long since I've been able to focus on anything. I keep thinking about all the bills piling up, and it's like... it's like I'm failing again. I can't even remember the last time I felt in control. My mom always said I had to be responsible, but now I'm just... I'm just stuck.

응답: C — S=?, L=?, G=? / 근거 또는 애매한 점:
