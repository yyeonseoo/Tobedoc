# Decision log

## 2026-10-28 — Initial implementation audit

- Scope: English, synthetic text, no patient recruitment or gated clinical corpus on the critical path. Team prototype is optional. Basis: user's stated constraints and research aim.
- Unit of analysis: declared clinical feature → implemented input/rule → observed behaviour. Do not infer neural attention from prompt text.
- First executable object: pinned PATIENT-Ψ prompt-level port, not a claim to reproduce the entire application or original trial. Rationale: public feature definitions and a traceable prompt path.
- Immediate intervention: map three missing demo fields using existing information only. Preserve other instructions in both arms. The decomposition of the explicit depression subsection is an authored repair, not an author-endorsed official patch.
- Sample interpretation: three situations for one named persona; no independent-patient inference. The 36 conditions are development-only.
- Comparison: PatientSim public code for native construct/implementation audit; later shared-case extension only under matched inputs. No MIMIC profile export.
- PSYCHE: paper v1 only until an author-origin implementation is established; any new implementation must be labelled reconstruction. Its score targets interviewers, not patient fidelity. Do not label it schizophrenia validated.
- Clinical mapping: 27 source-traceable entries, all substantive clinical mappings pending advice. WHO chapter-level diagnostic mapping is not yet established. Source traceability is not content validity.
- Human evaluation: professor advice only; no promised formal clinician annotation, inter-rater agreement or clinical validation.
- Paid generation: not executed. No usable provider API environment variable was present when checked. Actual model and total cost cap remain unset. No key values were printed or written.
- Evidence preservation: 23 public-source snapshots pinned by SHA-256. Reuse good snapshots; fail closed on local integrity/version mismatch. Keep source hashes even when a repeat integrity check fails.
- Publication: no runtime snapshots or example data should be publicly redistributed merely because they are downloadable. Review per-source rights and keep caches out of version control by default.

## Required updates before expansion

Record advisor feedback and codebook version; provider/model and cap; actual run IDs and failures; Stage A results including negative findings; development/held-out case-family split; final endpoints and analysis plan. No completed inference or clinical result may be inferred from this list of planned actions.

## 2026-10-28 — Plus-only, local-first workflow

- User directs difficult reasoning to the assistant and repeatable processing to their Macs. Default to existing subscription allowance; no paid APIs or additional credits without new authorization. Supersedes API-key acquisition as a prerequisite to research progress.
- Official product documentation checked: https://learn.chatgpt.com/docs/pricing . Included usage and API-key billing are separate; local command execution does not mean the assistant is a locally running LLM or uses no subscription allowance.
- Current host inspected: Apple M5, 24 GiB, arm64. NumPy/pandas available in the bundled Python; no inference framework installation was performed.
- Ollama has qwen3:14b, reported 14.8B and Q4_K_M. Metadata only inspected; no model download, generation or performance benchmark. Candidate, not automatically selected experimental backbone. Preserve native-vs-port distinction.
- Mac mini remains uninspected; no remote job or file transfer authorized by this operational preference alone.
- New policy and portable local preflight record resource facts without calling inference endpoints or reading secrets. Full local outputs remain files; return only summaries and targeted evidence to the assistant.

## 2026-10-29 — Actual local prototype for the 18:00 team discussion

- User authorizes execution and requests a Korean 2–3-page Markdown or Word report, with English code. Chosen deliverable: Markdown plus full English transcripts and a portable local-code/data ZIP.
- Used the installed Qwen3-14B only, pinned digest and Q4_K_M. PATIENT-Ψ prompt port, not native GPT-4/paper replication. No paid API or model/package download. This is a development backbone decision, not final clinical-study model selection.
- Technical gate: first native/plain dialogue, four completed turns; inspected before continuing. Kept these same replies as the first cell, not a separate independent sample or best-of selection.
- Completed six conditions on Abe situation 1-1: plain/reserved/tangent × original demo mapping/proposed mapping repair, four turns each, one repeat. Twenty-four completed replies; all actual history retained. Generation settings, raw payloads, model metadata, timings and hashes preserved.
- Analysis refinement: naive sentence splitting mishandled ellipses/closing quotes. Preserved v1 archive; v2 counts plus unblinded assistant text review yield 12/24 sentence-cap flags. These are output-constraint counts, not clinical ratings.
- Outcome boundary: no schizophrenia validation, expert ratings, population tests or cross-framework generation comparison. Financial content after repair is not evidence of causal clinical improvement; bills are supplied to both arms and three fields were changed together.
- Portable bundle excludes full clinical-paper caches; contains only minimum PATIENT-Ψ snapshots with MIT notice, generated outputs, scoped local code and metadata. Verify extraction, hashes and offline reanalysis before delivery.

## 2026-10-30 — Automatic quantitative feature profiling, before improvement

- User authorizes the full local quantitative process. Manual S/L/G grading is excluded; the calibration packet is archival with no ratings. No LLM judge or clinical composite is used.
- Froze 17 feature definitions and generated a new original-demo-mapping corpus: 6 public PATIENT-Ψ styles, 3 situations, 2 repeats, 4 turns. Exactly 36 dialogues / 144 completed replies; one example person Abe. Original mapping and instructions are unchanged. Prior 24 replies are not pooled into this analysis.
- Existing Qwen3-14B generated all replies with matched seeds and actual history. No paid API or additional model/package download was requested.
- Apple English NLEmbedding 512D revision 1, NLTokenizer, POS/lemma tagging and Python arithmetic supply the automatic features. Cached vectors allow numeric reanalysis without inference or OS model access.
- Dialogue-level profiles and six matched situation/repeat blocks are descriptive, not patient-population inference. Leave-one-situation-out classification predicts known prompt styles, not clinical labels. Accuracy: surface-8 47.2%, similarity-9 27.8%, all-17 33.3%.
- Tangent mean adjacent cosine 0.4046 vs plain 0.4649; six paired differences are negative. Situation-reply cosine does not decrease on average. Reversal invariance and duplication sensitivity show why similarity is not a validated clinical coherence score.
- Preserved all features, missing denominators, raw NLP output, sentence spans, plots and reproducibility bundle. Extracted the archive offline and verified identical numeric profiles. Current result: analysis/automatic-features-v01/native-features-20261030/.

## 2026-10-30 — Post-hoc robustness and source-to-observation audit

- User authorizes the proposed existing-corpus sensitivity and prompt-feature analysis. No new responses, manual labels, LLM judge, model download, package installation, or paid API calls.
- Freeze the descriptive sensitivity specification before running the new analyses, explicitly after inspection of the initial results; not a preregistration. Preserve the original 17 feature cells and verify them by recomputation from hashed text/vector caches.
- Match only original situation/repeat/turn pairs; do not rematch different questions or truncate responses. Word difference <=20% yields 17/24 pairs, six blocks, tangent-minus-plain adjacent cosine -0.0557. Joint equal sentence count leaves four pairs in three blocks; no length-independent effect claim. Export the complete 10/20/30% grid and both weighting schemes.
- Full contrast -0.0602; all three situation means negative. Alternative regex segmentation plus ellipsis/terminal-punctuation normalization yields -0.0641. Same Apple embedding backend; not cross-embedding validation or a boundary-only intervention.
- Response-pair-difference regression is descriptive and model dependent. Length may be a mediator; adjusted association is not a causal direct effect. No p-values or patient-population inference.
- Tangent question-similarity slope contrast is -0.0000817, while first-to-last contrast is -0.0245. Similarity proxies do not consistently establish directional drift or no-return behavior. T3 redirection is confounded with question/turn/history; no causal redirection inference.
- Source audit extracts all 19 numbered behavioral clauses. Seven have only partial numeric proxies, twelve are not directly measured. These are researcher-authored measurement-coverage categories, not patient/clinical grades or model failure counts. Other shared constraints are audited separately.
- Preserve permissive mixed-turn and scripted session-change instructions; do not require the style in every turn. Record nested sentence caps (verbose 8/common 5; upset/reserved 3/common 5) without claiming they are logically impossible constraints. All 36 prompts retain the three previously documented undefined fields.
- Follow-up output: analysis/feature-robustness-v01/native-features-20261030/. Forty unit tests pass, all raw histories and baseline features verify, and seven exact numeric result files reproduce from a newly extracted combined bundle using --cached-only.

## 2026-10-30 — Single-field automatic-thought delivery ablation

- User authorizes the next stage. Choose one exact alias only: auto_thought -> auto_thoughts. Leave the two other undefined fields, style instructions, sentence limits, questions, and all profile content unchanged. Verify all 12 matched prompt pairs differ only at that one rendered field.
- Lock the analysis before generating this run; this is an already inspected development example, not preregistration or clinical confirmation. Restrict the pilot to plain/tangent, three situations, two repeats, two arms, four turns: 24 new dialogues / 96 actual responses.
- Both arms are freshly generated. Randomize arm order within matched situation/style/repeat groups (5 native-first, 7 alias-first). Same pinned Qwen3-14B digest/options and seed rule; no paid APIs, package/model downloads or clinical/LLM ratings. Completed 96/96, no failures or truncations.
- Primary endpoint is T1 response-centroid cosine to the provided situation-specific thought text, separately by style. T1 avoids divergent generated history. Four-turn averages are secondary prompt-plus-history path outcomes, not the same estimand.
- Primary alias-minus-native: plain +0.050889 (4/6 positive), tangent -0.022422 (2/6 positive). Four-turn means +0.015176 and -0.001091; the positive plain average is not consistent across blocks (2/6 positive). No p-values, clinical fidelity, belief endorsement or patient-population inference.
- Adjacent cosine changes: plain -0.015655, tangent +0.000137. Tangent-minus-plain gap changes from -0.060246 to -0.044454, mainly because plain decreases. Do not call the gap reduction improved tangent coherence. Preserve all 20 features and every paired difference.
- Fresh native replay matches all 48 historical requests and response strings. This describes that replay only, not a general deterministic-seed guarantee. Historical data do not replace current experimental controls.
- Undefined-token removal and semantic-content addition are not separated. Original context already contains related information, so small changes do not imply the field is generally irrelevant. Same persona/cases and one embedding backend remain limitations.
- Output: analysis/thought-alias-v01/thought-alias-20261030/. Verify 48 local tests, 18 scoped bundled tests, numeric CSV cells, real request histories, and exact offline re-extraction/reanalysis without model calls. Raw outputs and original attachments remain preserved.

## 2026-10-30 — Efficient common-feature and cross-source comparison preparation

- User requests proceeding while conserving subscription tokens. Reuse locked source snapshots and feature implementations; no new LLM generation, downloads or external source fetches.
- Freeze the existing 17 feature definitions into eight primary descriptive and nine exploratory endpoints. Explicitly leave clinical thought disorder, intelligibility, semantic repetition and paraphrased fact contradiction unmeasured. No new clinical/composite scoring.
- Choose the shared declared plain/verbose construct for the initial comparison. Do not align PATIENT-Ψ tangent with PatientSim dazedness as one severity axis. Compare extracted style instructions on a shared wrapper, not complete native frameworks or original-paper performance.
- Prepare simple baseline, PATIENT-Ψ style content (remove only its embedded sentence-cap sentence), and verbatim PatientSim personality content; common fictional case facts/questions/five-sentence cap. Preserve and disclose remaining differences such as mixed-turn/trust instructions. No PatientSim ED wrapper, CEFR, recall, dazedness or native word caps in this controlled module experiment.
- Inspect PatientAgent assembly without executing upstream code: independent language/recall modules, scripted reduction every 4–5 turns, and sentence_length_limit.json dependency. Native cap file is not cached; full PatientAgent/processing has not been ported. Native PatientSim execution remains not ready, not silently approximated.
- Six invented, nonclinical case families, three development and three heldout. Prepare 72 full-design dialogue conditions (288 potential calls). First bounded pilot is 18 development dialogue conditions / 72 potential calls, repeat zero only. No generated responses or heldout evaluation exist yet. A generation runner remains a separate next implementation step.
- All 53 local tests pass. Preparation outputs: analysis/comparison-preparation-v01/. Frozen plan: config/framework-comparison-v01.json. No comparative performance result is claimed.

## 2026-10-30 — Execute the bounded cross-source module pilot

- User authorizes the next stage. Complete exactly the prepared 18 development dialogues / 72 real responses using the pinned installed Qwen3-14B; repeat zero only. No heldout generation, model/package downloads, paid APIs, human/LLM ratings, retries or best-of selection.
- Reuse the 17 existing features. For missing features, compare only common valid plain/verbose turns within each case; for difference-of-differences require all four cells on the same case/question. Preserve denominators and nulls. No patient-population inference or native-framework ranking.
- Average words plain -> verbose: simple 70.42 -> 95.92 (+25.50), PATIENT style 70.42 -> 87.42 (+17.00), PatientSim personality 47.92 -> 98.92 (+51.00). Each word-count gain is positive in all three cases. The larger PatientSim gain partly reflects a lower plain anchor; its verbose mean is only 3 words above simple baseline.
- PatientSim personality adjacent cosine increases +0.04599 while question cosine decreases -0.07183 and initial-situation cosine decreases -0.08962; all three contrasts keep their respective direction in all three cases. Similarity axes are distinct; none are clinical ground truth.
- Feasibility gate: 64/72 replies are exactly five OS sentences; 8/72 exceed the stated cap, and none are below five. OS/regex sentence counts agree in this corpus. Do not enlarge to 288 or generate heldout data before a development-only cap sensitivity check. This is a pilot-informed design decision, not a preregistered numerical stopping test.
- Simple/plain and PATIENT/plain have identical prepared prompts. All 12 paired requests and returned reply strings match; these are technical identity controls, not independent models or extra case families. There are 60 unique response strings among 72 actual requests.
- Verify all 72 histories, 1224 feature cells, local tests (58), and cache-only reanalysis. Correct only the generated progress helper's legacy one-person metadata to three fictional case families and zero real patient participants; raw requests/responses are untouched.
- Results: analysis/framework-pilot-v01/framework-pilot-20261030/. Full raw run: pilot/runs/framework-pilot-20261030/. Keep the preparation plan unchanged as the locked pre-execution specification.
